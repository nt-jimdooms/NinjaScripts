#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class PrintMAXTest : Indicator
	{
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Indicator here.";
				Name										= "PrintMAXTest";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				AddPlot(Brushes.Orange, "MyPlot");
			}
			else if (State == State.Configure)
			{
			}
		}

		protected override void OnBarUpdate()
		{
			if (CurrentBar < 1)
				return;
			
			MyPlot[0] = Close[0];
			
			Print(Open[0] + " " + MAX(MyPlot, 5)[0]);
			if (Open[0] >  MAX(MyPlot, 5)[0])
			{
				Print("if (Open[0] >  MAX(MyPlot, 5)[0]) is true");
			}
			
			Print(Open[0] + " " + MAX(MyPlot, 5)[1]);
			if (Open[0] >  MAX(MyPlot, 5)[1])
			{
				Print("if (Open[0] >  MAX(MyPlot, 5)[1]) is true");
			}
		}

		#region Properties

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> MyPlot
		{
			get { return Values[0]; }
		}
		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private PrintMAXTest[] cachePrintMAXTest;
		public PrintMAXTest PrintMAXTest()
		{
			return PrintMAXTest(Input);
		}

		public PrintMAXTest PrintMAXTest(ISeries<double> input)
		{
			if (cachePrintMAXTest != null)
				for (int idx = 0; idx < cachePrintMAXTest.Length; idx++)
					if (cachePrintMAXTest[idx] != null &&  cachePrintMAXTest[idx].EqualsInput(input))
						return cachePrintMAXTest[idx];
			return CacheIndicator<PrintMAXTest>(new PrintMAXTest(), input, ref cachePrintMAXTest);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.PrintMAXTest PrintMAXTest()
		{
			return indicator.PrintMAXTest(Input);
		}

		public Indicators.PrintMAXTest PrintMAXTest(ISeries<double> input )
		{
			return indicator.PrintMAXTest(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.PrintMAXTest PrintMAXTest()
		{
			return indicator.PrintMAXTest(Input);
		}

		public Indicators.PrintMAXTest PrintMAXTest(ISeries<double> input )
		{
			return indicator.PrintMAXTest(input);
		}
	}
}

#endregion
