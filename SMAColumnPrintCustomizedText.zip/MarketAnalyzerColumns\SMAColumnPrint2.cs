#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion

//This namespace holds MarketAnalyzerColumns in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public class SMAColumnPrint2 : MarketAnalyzerColumn
	{
        private Indicators.SMA OUL;
		private string currentText;
		private double currentValue;
		
		private double close;
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Market Analyzer Column here.";
				Name										= "SMAColumnPrint2";
				Calculate									= Calculate.OnBarClose;
				DataType = typeof(string);
                               
            }
			else if (State == State.Configure)
			{
                OUL = SMA(20);
            }
		}

        protected override void OnBarUpdate()
        {
            currentValue = OUL[0];
			close = Close[0];          
        }
		
		protected override void OnMarketData(MarketDataEventArgs marketDataUpdate)
		{
			if (marketDataUpdate.MarketDataType == MarketDataType.Last)
			{
				if (close > currentValue)
	            {
	                Print(Instrument.FullName + " Sup " + " Close: " + close + " CV: " + currentValue);
	                currentText = "SUP: " + Bars.Instrument.MasterInstrument.FormatPrice(currentValue);
	            }
	            else if (marketDataUpdate.Price <= currentValue)
	            {
	                Print(Instrument.FullName + " Res " + " Close: " + close + " CV: " + currentValue);
	                currentText = "RES: " + Bars.Instrument.MasterInstrument.FormatPrice(currentValue);
	            }  
				
				CurrentValue = currentValue;
			}
		}
		
		public override string Format(double value)
		{
			return currentText;
		}
    }
}
