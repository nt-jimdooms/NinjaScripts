// 
// Copyright (C) 2019, NinjaTrader LLC <www.ninjatrader.com>.
// NinjaTrader reserves the right to modify or overwrite this NinjaScript component with each release.
//
#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

// This namespace holds all strategies and is required. Do not change it.
namespace NinjaTrader.NinjaScript.Strategies
{
    public class SampleOnOrderUpdateReverseExample : Strategy
    {
        private Order entryOrderLong = null; // This variable holds an object representing our entry order
        private Order stopOrderLong = null; // This variable holds an object representing our stop loss order
        private Order targetOrderLong = null; // This variable holds an object representing our profit target order
		
		private Order entryOrderShort = null; // This variable holds an object representing our entry order
        private Order stopOrderShort = null; // This variable holds an object representing our stop loss order
        private Order targetOrderShort = null; // This variable holds an object representing our profit target order
		
        private int sumFilledLong = 0; // This variable tracks the quantities of each execution making up the entry order
		private int sumFilledShort = 0; // This variable tracks the quantities of each execution making up the entry order

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = @"Sample Using OnOrderUpdate() and OnExecution() methods to submit protective orders";
                Name = "SampleOnOrderUpdateReverseExample";
                Calculate = Calculate.OnBarClose;
                EntriesPerDirection = 1;
                EntryHandling = EntryHandling.AllEntries;
                IsExitOnSessionCloseStrategy = true;
                ExitOnSessionCloseSeconds = 30;
                IsFillLimitOnTouch = false;
                MaximumBarsLookBack = MaximumBarsLookBack.TwoHundredFiftySix;
                OrderFillResolution = OrderFillResolution.Standard;
                Slippage = 0;
                StartBehavior = StartBehavior.WaitUntilFlat;
                TimeInForce = TimeInForce.Gtc;
                TraceOrders = true;
                RealtimeErrorHandling = RealtimeErrorHandling.StopCancelClose;
                StopTargetHandling = StopTargetHandling.ByStrategyPosition;
                BarsRequiredToTrade = 20;
            }
            else if (State == State.Realtime)
            {
                // one time only, as we transition from historical
                // convert any old historical order object references
                // to the new live order submitted to the real-time account
                if (entryOrderLong != null)
                    entryOrderLong = GetRealtimeOrder(entryOrderLong);
                if (stopOrderLong != null)
                    stopOrderLong = GetRealtimeOrder(stopOrderLong);
                if (targetOrderLong != null)
                    targetOrderLong = GetRealtimeOrder(targetOrderLong);
				
				if (entryOrderShort != null)
                    entryOrderShort = GetRealtimeOrder(entryOrderShort);
                if (stopOrderShort != null)
                    stopOrderShort = GetRealtimeOrder(stopOrderShort);
                if (targetOrderShort != null)
                    targetOrderShort = GetRealtimeOrder(targetOrderShort);
            }
        }

        protected override void OnBarUpdate()
        {
			if (State == State.Historical)
				return;
            // Submit an entry market order if we currently don't have an entry order open and are past the BarsRequiredToTrade bars amount
            if (entryOrderLong == null && Position.MarketPosition == MarketPosition.Flat && CurrentBar > BarsRequiredToTrade)
            {
                /* Enter Long. We will assign the resulting Order object to entryOrderLong1 in OnOrderUpdate() */
                EnterLong(1, "MyEntryLong");
            }
			
			// Reverse
            if (entryOrderShort == null && Position.MarketPosition == MarketPosition.Long && BarsSinceEntryExecution("MyEntryLong") == 2)
            {
				Print("?");
                /* Enter Short. We will assign the resulting Order object to entryOrderLong1 in OnOrderUpdate() */
                EnterShort(1, "MyEntryShort");
            }

            /* If we have a long position and the current price is 4 ticks in profit, raise the stop-loss order to breakeven.
			We use (7 * (TickSize / 2)) to denote 4 ticks because of potential precision issues with doubles. Under certain
			conditions (4 * TickSize) could end up being 3.9999 instead of 4 if the TickSize was 1. Using our method of determining
			4 ticks helps cope with the precision issue if it does arise. */
            if (Position.MarketPosition == MarketPosition.Long && Close[0] >= Position.AveragePrice + (7 * (TickSize / 2)))
            {
                // Checks to see if our Stop Order has been submitted already
                if (stopOrderLong != null && stopOrderLong.StopPrice < Position.AveragePrice)
                {
                    // Modifies stop-loss to breakeven
                    stopOrderLong = ExitLongStopMarket(0, true, stopOrderLong.Quantity, Position.AveragePrice, "MyStop", "MyEntryLong");
                }
            }
        }

        protected override void OnOrderUpdate(Order order, double limitPrice, double stopPrice, int quantity, int filled, double averageFillPrice, OrderState orderState, DateTime time, ErrorCode error, string nativeError)
        {
            // Handle entry orders here. The entryOrderLong object allows us to identify that the order that is calling the OnOrderUpdate() method is the entry order.
            // Assign entryOrderLong in OnOrderUpdate() to ensure the assignment occurs when expected.
            // This is more reliable than assigning Order objects in OnBarUpdate, as the assignment is not gauranteed to be complete if it is referenced immediately after submitting
            if (order.Name == "MyEntryLong")
            {
                entryOrderLong = order;

                // Reset the entryOrderLong object to null if order was cancelled without any fill
                if (order.OrderState == OrderState.Cancelled && order.Filled == 0)
                {
                    entryOrderLong = null;
                    sumFilledLong = 0;
                }
            }
			
			if (order.Name == "MyEntryShort")
            {
                entryOrderShort = order;

                // Reset the entryOrderLong object to null if order was cancelled without any fill
                if (order.OrderState == OrderState.Cancelled && order.Filled == 0)
                {
                    entryOrderShort = null;
                    sumFilledShort = 0;
                }
            }
        }

        protected override void OnExecutionUpdate(Execution execution, string executionId, double price, int quantity, MarketPosition marketPosition, string orderId, DateTime time)
        {
            /* We advise monitoring OnExecution to trigger submission of stop/target orders instead of OnOrderUpdate() since OnExecution() is called after OnOrderUpdate()
			which ensures your strategy has received the execution which is used for internal signal tracking. */
            if (entryOrderLong != null && entryOrderLong == execution.Order)
            {
                if (execution.Order.OrderState == OrderState.Filled || execution.Order.OrderState == OrderState.PartFilled || (execution.Order.OrderState == OrderState.Cancelled && execution.Order.Filled > 0))
                {
                    // We sum the quantities of each execution making up the entry order
                    sumFilledLong += execution.Quantity;

                    // Submit exit orders for partial fills
                    if (execution.Order.OrderState == OrderState.PartFilled)
                    {
                        stopOrderLong = ExitLongStopMarket(0, true, execution.Order.Filled, execution.Order.AverageFillPrice - 4 * TickSize, "MyStopLong", "MyEntryLong");
                        targetOrderLong = ExitLongLimit(0, true, execution.Order.Filled, execution.Order.AverageFillPrice + 8 * TickSize, "MyTargetLong", "MyEntryLong");
                    }
                    // Update our exit order quantities once orderstate turns to filled and we have seen execution quantities match order quantities
                    else if (execution.Order.OrderState == OrderState.Filled && sumFilledLong == execution.Order.Filled)
                    {
                        // Stop-Loss order for OrderState.Filled
                        stopOrderLong = ExitLongStopMarket(0, true, execution.Order.Filled, execution.Order.AverageFillPrice - 4 * TickSize, "MyStopLong", "MyEntryLong");
                        targetOrderLong = ExitLongLimit(0, true, execution.Order.Filled, execution.Order.AverageFillPrice + 8 * TickSize, "MyTargetLong", "MyEntryLong");
                    }

                    // Resets the entryOrderLong object and the sumFilledLong counter to null / 0 after the order has been filled
                    if (execution.Order.OrderState != OrderState.PartFilled && sumFilledLong == execution.Order.Filled)
                    {
                        entryOrderLong = null;
                        sumFilledLong = 0;
                    }
                }
            }

            // Reset our stop order and target orders' Order objects after our position is closed. (1st Entry)
            if ((stopOrderLong != null && stopOrderLong == execution.Order) || (targetOrderLong != null && targetOrderLong == execution.Order))
            {
                if (execution.Order.OrderState == OrderState.Filled || execution.Order.OrderState == OrderState.PartFilled)
                {
                    stopOrderLong = null;
                    targetOrderLong = null;
                }
            }
			
			// Short Side
			if (entryOrderShort != null && entryOrderShort == execution.Order)
            {
                if (execution.Order.OrderState == OrderState.Filled || execution.Order.OrderState == OrderState.PartFilled || (execution.Order.OrderState == OrderState.Cancelled && execution.Order.Filled > 0))
                {
                    // We sum the quantities of each execution making up the entry order
                    sumFilledShort += execution.Quantity;

                    // Submit exit orders for partial fills
                    if (execution.Order.OrderState == OrderState.PartFilled)
                    {
                        stopOrderShort = ExitShortStopMarket(0, true, execution.Order.Filled, execution.Order.AverageFillPrice + 4 * TickSize, "MyStopShort", "MyEntryShort");
                        targetOrderShort = ExitShortLimit(0, true, execution.Order.Filled, execution.Order.AverageFillPrice - 8 * TickSize, "MyTargetShort", "MyEntryShort");
                    }
                    // Update our exit order quantities once orderstate turns to filled and we have seen execution quantities match order quantities
                    else if (execution.Order.OrderState == OrderState.Filled && sumFilledShort == execution.Order.Filled)
                    {
                        // Stop-Loss order for OrderState.Filled
                        stopOrderShort = ExitShortStopMarket(0, true, execution.Order.Filled, execution.Order.AverageFillPrice + 4 * TickSize, "MyStopShort", "MyEntryShort");
                        targetOrderShort = ExitShortLimit(0, true, execution.Order.Filled, execution.Order.AverageFillPrice - 8 * TickSize, "MyTargetShort", "MyEntryShort");
                    }

                    // Resets the entryOrderShort object and the sumFilledShort counter to null / 0 after the order has been filled
                    if (execution.Order.OrderState != OrderState.PartFilled && sumFilledShort == execution.Order.Filled)
                    {
                        entryOrderShort = null;
                        sumFilledShort = 0;
                    }
                }
            }

            // Reset our stop order and target orders' Order objects after our position is closed. (1st Entry)
            if ((stopOrderShort != null && stopOrderShort == execution.Order) || (targetOrderShort != null && targetOrderShort == execution.Order))
            {
                if (execution.Order.OrderState == OrderState.Filled || execution.Order.OrderState == OrderState.PartFilled)
                {
                    stopOrderShort = null;
                    targetOrderShort = null;
                }
            }
        }
    }
}