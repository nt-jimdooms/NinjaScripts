#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class CompareVolumetricOFCD : Indicator
	{
		private OrderFlowCumulativeDelta cumulativeDelta;
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Indicator here.";
				Name										= "CompareVolumetricOFCD";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= true;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
			}
			else if (State == State.Configure)
			{
				AddDataSeries(Data.BarsPeriodType.Tick, 1);
			}
			else if (State == State.DataLoaded)
			{
				// Instantiate the indicator
				cumulativeDelta = OrderFlowCumulativeDelta(CumulativeDeltaType.BidAsk, CumulativeDeltaPeriod.Session, 0);
			}
		}

		protected override void OnBarUpdate()
		{
	        if (Bars == null)
	          return;
			
			if (BarsInProgress == 0)
			{
				NinjaTrader.NinjaScript.BarsTypes.VolumetricBarsType barsType = Bars.BarsSeries.BarsType as    
				NinjaTrader.NinjaScript.BarsTypes.VolumetricBarsType;

				if (barsType == null)
					return;	 
				try
				{
					double price;
					Print("=========================================================================");
					Print(Time[0] + " " + State);
					Print("BarDelta (Volumetric): " + barsType.Volumes[CurrentBar].BarDelta);
				}
				catch{}
				Print("BarDelta (OFCD): " + (cumulativeDelta.DeltaClose[0] - cumulativeDelta.DeltaOpen[0]));
			}
			else if (BarsInProgress == 1)
			{
				// We have to update the secondary series of the cached indicator to make sure the values we get in BarsInProgress == 0 are in sync
				cumulativeDelta.Update(cumulativeDelta.BarsArray[1].Count - 1, 1);
			}
		}
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private CompareVolumetricOFCD[] cacheCompareVolumetricOFCD;
		public CompareVolumetricOFCD CompareVolumetricOFCD()
		{
			return CompareVolumetricOFCD(Input);
		}

		public CompareVolumetricOFCD CompareVolumetricOFCD(ISeries<double> input)
		{
			if (cacheCompareVolumetricOFCD != null)
				for (int idx = 0; idx < cacheCompareVolumetricOFCD.Length; idx++)
					if (cacheCompareVolumetricOFCD[idx] != null &&  cacheCompareVolumetricOFCD[idx].EqualsInput(input))
						return cacheCompareVolumetricOFCD[idx];
			return CacheIndicator<CompareVolumetricOFCD>(new CompareVolumetricOFCD(), input, ref cacheCompareVolumetricOFCD);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.CompareVolumetricOFCD CompareVolumetricOFCD()
		{
			return indicator.CompareVolumetricOFCD(Input);
		}

		public Indicators.CompareVolumetricOFCD CompareVolumetricOFCD(ISeries<double> input )
		{
			return indicator.CompareVolumetricOFCD(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.CompareVolumetricOFCD CompareVolumetricOFCD()
		{
			return indicator.CompareVolumetricOFCD(Input);
		}

		public Indicators.CompareVolumetricOFCD CompareVolumetricOFCD(ISeries<double> input )
		{
			return indicator.CompareVolumetricOFCD(input);
		}
	}
}

#endregion
