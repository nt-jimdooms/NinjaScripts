#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private LabeledHorizontalLines[] cacheLabeledHorizontalLines;

		
		public LabeledHorizontalLines LabeledHorizontalLines(float fontSize, HorizLabelSideType labelSide, HorizLabelAreaType labelArea)
		{
			return LabeledHorizontalLines(Input, fontSize, labelSide, labelArea);
		}


		
		public LabeledHorizontalLines LabeledHorizontalLines(ISeries<double> input, float fontSize, HorizLabelSideType labelSide, HorizLabelAreaType labelArea)
		{
			if (cacheLabeledHorizontalLines != null)
				for (int idx = 0; idx < cacheLabeledHorizontalLines.Length; idx++)
					if (cacheLabeledHorizontalLines[idx].FontSize == fontSize && cacheLabeledHorizontalLines[idx].LabelSide == labelSide && cacheLabeledHorizontalLines[idx].LabelArea == labelArea && cacheLabeledHorizontalLines[idx].EqualsInput(input))
						return cacheLabeledHorizontalLines[idx];
			return CacheIndicator<LabeledHorizontalLines>(new LabeledHorizontalLines(){ FontSize = fontSize, LabelSide = labelSide, LabelArea = labelArea }, input, ref cacheLabeledHorizontalLines);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.LabeledHorizontalLines LabeledHorizontalLines(float fontSize, HorizLabelSideType labelSide, HorizLabelAreaType labelArea)
		{
			return indicator.LabeledHorizontalLines(Input, fontSize, labelSide, labelArea);
		}


		
		public Indicators.LabeledHorizontalLines LabeledHorizontalLines(ISeries<double> input , float fontSize, HorizLabelSideType labelSide, HorizLabelAreaType labelArea)
		{
			return indicator.LabeledHorizontalLines(input, fontSize, labelSide, labelArea);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.LabeledHorizontalLines LabeledHorizontalLines(float fontSize, HorizLabelSideType labelSide, HorizLabelAreaType labelArea)
		{
			return indicator.LabeledHorizontalLines(Input, fontSize, labelSide, labelArea);
		}


		
		public Indicators.LabeledHorizontalLines LabeledHorizontalLines(ISeries<double> input , float fontSize, HorizLabelSideType labelSide, HorizLabelAreaType labelArea)
		{
			return indicator.LabeledHorizontalLines(input, fontSize, labelSide, labelArea);
		}

	}
}

#endregion
