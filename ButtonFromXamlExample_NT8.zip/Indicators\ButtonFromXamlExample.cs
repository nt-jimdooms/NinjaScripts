#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

using System.Windows.Controls;
using System.IO;
using System.Windows.Markup;

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class ButtonFromXamlExample : Indicator
	{
		private bool longButtonClicked;
		//private bool shortButtonClicked;
		private System.Windows.Controls.Button longButton;
		//private System.Windows.Controls.Button shortButton;
		private System.Windows.Controls.Grid myGrid;

		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"";
				Name										= "ButtonFromXamlExample";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
			}
			else if (State == State.Configure)
			{
			}
			else if (State == State.Historical)
			{
				if (UserControlCollection.Contains(myGrid))
					return;
				
				Dispatcher.InvokeAsync((() =>
				{
					myGrid = new System.Windows.Controls.Grid
					{
						Name = "MyCustomGrid", HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Top
					};
					
					System.Windows.Controls.ColumnDefinition column1 = new System.Windows.Controls.ColumnDefinition();
					//System.Windows.Controls.ColumnDefinition column2 = new System.Windows.Controls.ColumnDefinition();
					
					myGrid.ColumnDefinitions.Add(column1);
					//myGrid.ColumnDefinitions.Add(column2);

					try
					{
						//Page page;
						FileStream fs = new FileStream(System.IO.Path.Combine(NinjaTrader.Core.Globals.UserDataDir, @"bin\Custom\Indicators\ButtonFromXamlExampleContent.xaml"), FileMode.Open);
						//page = (Page)XamlReader.Load(fs);

						//if (page == null)
						//	return;

						//longButton = LogicalTreeHelper.FindLogicalNode(page, "ExampleButton") as Button;
						longButton = (Button)XamlReader.Load(fs) as Button;
						if (longButton == null)
							return;

						//longButton = new System.Windows.Controls.Button
						//{
						//	Name = "LongButton", Content = "LONG", Foreground = Brushes.White, Background = Brushes.Green
						//};

						//shortButton = new System.Windows.Controls.Button
						//{
						//	Name = "ShortButton", Content = "SHORT", Foreground = Brushes.Black, Background = Brushes.Red
						//};

						longButton.Click += OnButtonClick;
						//shortButton.Click += OnButtonClick;

						System.Windows.Controls.Grid.SetColumn(longButton, 0);
						//System.Windows.Controls.Grid.SetColumn(shortButton, 1);

						myGrid.Children.Add(longButton);
						//myGrid.Children.Add(shortButton);

						//exampleCheckBox = LogicalTreeHelper.FindLogicalNode(page, "ExampleCheckBox") as CheckBox;
						//exampleQuantityUpDown = LogicalTreeHelper.FindLogicalNode(page, "ExampleQuantityUpDown") as QuantityUpDown;
						//exampleOption1RadioButton = LogicalTreeHelper.FindLogicalNode(page, "ExampleOption1RadioButton") as RadioButton;
						//exampleOption2RadioButton = LogicalTreeHelper.FindLogicalNode(page, "ExampleOption2RadioButton") as RadioButton;
						//exampleTextBox = LogicalTreeHelper.FindLogicalNode(page, "ExampleTextBox") as TextBox;

						//DependencyObject pageContent = page.Content as DependencyObject;

						//return pageContent;
					}
					catch (Exception e)
					{
						Print(e.ToString());
						return;
					}
					
					UserControlCollection.Add(myGrid);
				}));
			}
			else if (State == State.Terminated)
			{
				Dispatcher.InvokeAsync((() =>
				{
					if (myGrid != null)
					{
						if (longButton != null)
						{
							myGrid.Children.Remove(longButton);
							longButton.Click -= OnButtonClick;
							longButton = null;
						}
						//if (shortButton != null)
						//{
						//	myGrid.Children.Remove(shortButton);
						//	shortButton.Click -= OnButtonClick;
						//	shortButton = null;
						//}
					}
				}));
			}
		}

		protected override void OnBarUpdate()
		{
			//Add your custom indicator logic here.
		}

		private void OnButtonClick(object sender, RoutedEventArgs rea)
		{
			System.Windows.Controls.Button button = sender as System.Windows.Controls.Button;
			//if (button == longButton && button.Name == "LongButton" && button.Content == "LONG")
			if (button == longButton)
			{
				Print("button clicked");
				//button.Content = "Exit L";
				//button.Name = "ExitLongButton";
				//longButtonClicked = true;
				return;
			}

			//if (button == shortButton && button.Name == "ShortButton" && button.Content == "SHORT")
			//{
			//	button.Content = "Exit S";
			//	button.Name = "ExitShortButton";
			//	shortButtonClicked = true;
			//	return;
			//}

			//if (button == longButton && button.Name == "ExitLongButton" && button.Content == "Exit L")
			//{
			//	button.Content = "LONG";
			//	button.Name = "LongButton";
			//	longButtonClicked = false;
			//	return;
			//}

			//if (button == shortButton && button.Name == "ExitShortButton" && button.Content == "Exit S")
			//{
			//	button.Content = "SHORT";
			//	button.Name = "ShortButton";
			//	shortButtonClicked = false;
			//	return;
			//}
		}
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ButtonFromXamlExample[] cacheButtonFromXamlExample;
		public ButtonFromXamlExample ButtonFromXamlExample()
		{
			return ButtonFromXamlExample(Input);
		}

		public ButtonFromXamlExample ButtonFromXamlExample(ISeries<double> input)
		{
			if (cacheButtonFromXamlExample != null)
				for (int idx = 0; idx < cacheButtonFromXamlExample.Length; idx++)
					if (cacheButtonFromXamlExample[idx] != null &&  cacheButtonFromXamlExample[idx].EqualsInput(input))
						return cacheButtonFromXamlExample[idx];
			return CacheIndicator<ButtonFromXamlExample>(new ButtonFromXamlExample(), input, ref cacheButtonFromXamlExample);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ButtonFromXamlExample ButtonFromXamlExample()
		{
			return indicator.ButtonFromXamlExample(Input);
		}

		public Indicators.ButtonFromXamlExample ButtonFromXamlExample(ISeries<double> input )
		{
			return indicator.ButtonFromXamlExample(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ButtonFromXamlExample ButtonFromXamlExample()
		{
			return indicator.ButtonFromXamlExample(Input);
		}

		public Indicators.ButtonFromXamlExample ButtonFromXamlExample(ISeries<double> input )
		{
			return indicator.ButtonFromXamlExample(input);
		}
	}
}

#endregion
