#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class TakeScreenshotAfterOrderAccepted : Indicator
	{
		private Account account;
		
		private bool waitForRender;
		
		NinjaTrader.Gui.Chart.Chart chart;
        bool takeShot = true;
        System.Windows.Media.Imaging.BitmapFrame outputFrame;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Indicator here.";
				Name										= "TakeScreenshotAfterOrderAccepted";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
			}
			else if (State == State.DataLoaded)
			{
				// Find our Sim101 account
		        lock (Account.All)
		              account = Account.All.FirstOrDefault(a => a.Name == AccountName);

		        // Subscribe to account item and order updates
		        if (account != null)
				{
					account.OrderUpdate 		+= OnOrderUpdate;
				}
			}
			else if(State == State.Terminated)
			{
				// Make sure to unsubscribe to the account item subscription
        		if (account != null)
				{
					account.OrderUpdate 		-= OnOrderUpdate;
				}
			}
		}
		

	    private void OnOrderUpdate(object sender, OrderEventArgs e)
	    {
			if (e.OrderState == OrderState.Accepted)
			{
				waitForRender = true;
				ForceRefresh();
				//ChartControl.InvalidateVisual(); // Unsupported and known to cause performance issues. Use at your own risk!
			}
	    }
		
		private void OnExecutionUpdate(object sender, ExecutionEventArgs e)
	    {
	         // Output the execution
	         NinjaTrader.Code.Output.Process(string.Format("Instrument: {0} Quantity: {1} Price: {2}",
	              e.Execution.Instrument.FullName, e.Quantity, e.Price), PrintTo.OutputTab1);
	    }
		
		protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
		{
			if (waitForRender)
			{
				waitForRender = false;
				
				ChartControl.Dispatcher.InvokeAsync(new Action(() =>
                {
					chart = Window.GetWindow(ChartControl) as Chart;
                    if (chart != null && takeShot == true)
                    {
                        System.Windows.Media.Imaging.RenderTargetBitmap screenCapture = chart.GetScreenshot(ShareScreenshotType.Chart);
                        outputFrame = System.Windows.Media.Imaging.BitmapFrame.Create(screenCapture);

                        if (screenCapture != null)
                        {
                            System.Windows.Media.Imaging.PngBitmapEncoder png = new System.Windows.Media.Imaging.PngBitmapEncoder();
                            png.Frames.Add(outputFrame);

                            using (System.IO.Stream stream = System.IO.File.Create(string.Format(@"{0}\{1}", Core.Globals.UserDataDir, "MyScreenshot.png")))
                                png.Save(stream);

                            Print("Screenshot saved to " + Core.Globals.UserDataDir);
                            takeShot = false;
                        }
                    }
                }));
			}
		}

		protected override void OnBarUpdate()
		{
			//Add your custom indicator logic here.
		}
		
		[TypeConverter(typeof(NinjaTrader.NinjaScript.AccountNameConverter))]
		public string AccountName { get; set; }
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private TakeScreenshotAfterOrderAccepted[] cacheTakeScreenshotAfterOrderAccepted;
		public TakeScreenshotAfterOrderAccepted TakeScreenshotAfterOrderAccepted()
		{
			return TakeScreenshotAfterOrderAccepted(Input);
		}

		public TakeScreenshotAfterOrderAccepted TakeScreenshotAfterOrderAccepted(ISeries<double> input)
		{
			if (cacheTakeScreenshotAfterOrderAccepted != null)
				for (int idx = 0; idx < cacheTakeScreenshotAfterOrderAccepted.Length; idx++)
					if (cacheTakeScreenshotAfterOrderAccepted[idx] != null &&  cacheTakeScreenshotAfterOrderAccepted[idx].EqualsInput(input))
						return cacheTakeScreenshotAfterOrderAccepted[idx];
			return CacheIndicator<TakeScreenshotAfterOrderAccepted>(new TakeScreenshotAfterOrderAccepted(), input, ref cacheTakeScreenshotAfterOrderAccepted);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.TakeScreenshotAfterOrderAccepted TakeScreenshotAfterOrderAccepted()
		{
			return indicator.TakeScreenshotAfterOrderAccepted(Input);
		}

		public Indicators.TakeScreenshotAfterOrderAccepted TakeScreenshotAfterOrderAccepted(ISeries<double> input )
		{
			return indicator.TakeScreenshotAfterOrderAccepted(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.TakeScreenshotAfterOrderAccepted TakeScreenshotAfterOrderAccepted()
		{
			return indicator.TakeScreenshotAfterOrderAccepted(Input);
		}

		public Indicators.TakeScreenshotAfterOrderAccepted TakeScreenshotAfterOrderAccepted(ISeries<double> input )
		{
			return indicator.TakeScreenshotAfterOrderAccepted(input);
		}
	}
}

#endregion
