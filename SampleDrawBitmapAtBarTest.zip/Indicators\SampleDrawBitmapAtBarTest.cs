#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

namespace NinjaTrader.NinjaScript.Indicators
{
	public class SampleDrawBitmapAtBarTest : Indicator
	{
		private SharpDX.Direct2D1.Bitmap myBitmap;
		private SharpDX.IO.NativeFileStream fileStream;
		private SharpDX.WIC.BitmapDecoder bitmapDecoder;
		private SharpDX.WIC.FormatConverter converter;
		private SharpDX.WIC.BitmapFrameDecode frame;
		
		private string FileName;
		private bool NeedToUpdate;
		
		// Create Series<bool> to tell if we want to draw something for a particular bar
		private Series<bool> DrawImageSeries;

		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Name = "SampleDrawBitmapAtBarTest";
				Calculate = Calculate.OnBarClose;
				IsOverlay = true;
				ScaleJustification = NinjaTrader.Gui.Chart.ScaleJustification.Right;
				IsSuspendedWhileInactive = true;
				FileName = "SampleDrawBitmapAtBarTest.png";
				
				AddPlot(new Stroke(Brushes.White, 5), PlotStyle.Line, "MyPlot");

			}
			else if (State == State.DataLoaded)
			{
				// Create Series<bool> to tell if we want to draw something for a particular bar
				DrawImageSeries = new Series<bool>(this, MaximumBarsLookBack.Infinite);
			}
		}

		protected override void OnBarUpdate()
		{
			if (CurrentBar < 3)
				return;
			
			DrawImageSeries[0] = true;
			
			if (DrawImageSeries[3])
				DrawImageSeries[3] = false;
			
			Value[0] = High[0] + 3 * TickSize;
		}
		
		private void UpdateImage(string fileName)
		{
			// Dispose all Render dependant resources on RenderTarget change.
			if (myBitmap != null) 		myBitmap.Dispose();
			if (fileStream != null) 	fileStream.Dispose();
			if (bitmapDecoder != null) 	bitmapDecoder.Dispose();
			if (converter != null) 		converter.Dispose();
			if (frame != null) 			frame.Dispose();
			
			if (RenderTarget == null) return;
			
			// Neccessary for creating WIC objects.
			fileStream = new SharpDX.IO.NativeFileStream(System.IO.Path.Combine(NinjaTrader.Core.Globals.UserDataDir + "templates/MyResources/", fileName), SharpDX.IO.NativeFileMode.Open, SharpDX.IO.NativeFileAccess.Read);
			// Used to read the image source file.
			bitmapDecoder = new SharpDX.WIC.BitmapDecoder(Core.Globals.WicImagingFactory, fileStream, SharpDX.WIC.DecodeOptions.CacheOnDemand);
			// Get the first frame of the image.
			frame = bitmapDecoder.GetFrame(0);
			// Convert it to a compatible pixel format.			
			converter = new SharpDX.WIC.FormatConverter(Core.Globals.WicImagingFactory);
			converter.Initialize(frame, SharpDX.WIC.PixelFormat.Format32bppPRGBA);
			// Create the new Bitmap1 directly from the FormatConverter.
			myBitmap = SharpDX.Direct2D1.Bitmap.FromWicBitmap(RenderTarget, converter);
		}


		public override void OnRenderTargetChanged()
		{
			base.OnRenderTargetChanged();
			
			UpdateImage(FileName);			
		}

		protected override void OnRender(NinjaTrader.Gui.Chart.ChartControl chartControl, NinjaTrader.Gui.Chart.ChartScale chartScale)
		{
			if (RenderTarget == null || Bars == null || Bars.Instrument == null || myBitmap == null)
				return;
			
			if (NeedToUpdate)
			{
				UpdateImage(FileName);
				NeedToUpdate = false;
			}
			
			// Limit Custom Rendering to ChartBars.FromIndex and ChartBars.ToIndex
            for (int idx = ChartBars.FromIndex; idx <= ChartBars.ToIndex; idx++)
            {
				// Reference Series objects with GetValueAt(idx).
				if(DrawImageSeries.GetValueAt(idx))
				{					
					RenderTarget.DrawBitmap(myBitmap, 
											new SharpDX.RectangleF((float)ChartControl.GetXByBarIndex(ChartBars, idx) - ChartControl.Properties.BarDistance/2,
																	(float)chartScale.GetYByValue(High.GetValueAt(idx)),
																	(float)ChartControl.Properties.BarDistance,
																	(float)chartScale.GetYByValue(High.GetValueAt(idx)) - chartScale.GetYByValue(Low.GetValueAt(idx))),
											1.0f,
											SharpDX.Direct2D1.BitmapInterpolationMode.Linear);
				}
			}
			
			//Draw plots after bitmap.
			base.OnRender(chartControl, chartScale);
		}
		
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private SampleDrawBitmapAtBarTest[] cacheSampleDrawBitmapAtBarTest;
		public SampleDrawBitmapAtBarTest SampleDrawBitmapAtBarTest()
		{
			return SampleDrawBitmapAtBarTest(Input);
		}

		public SampleDrawBitmapAtBarTest SampleDrawBitmapAtBarTest(ISeries<double> input)
		{
			if (cacheSampleDrawBitmapAtBarTest != null)
				for (int idx = 0; idx < cacheSampleDrawBitmapAtBarTest.Length; idx++)
					if (cacheSampleDrawBitmapAtBarTest[idx] != null &&  cacheSampleDrawBitmapAtBarTest[idx].EqualsInput(input))
						return cacheSampleDrawBitmapAtBarTest[idx];
			return CacheIndicator<SampleDrawBitmapAtBarTest>(new SampleDrawBitmapAtBarTest(), input, ref cacheSampleDrawBitmapAtBarTest);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.SampleDrawBitmapAtBarTest SampleDrawBitmapAtBarTest()
		{
			return indicator.SampleDrawBitmapAtBarTest(Input);
		}

		public Indicators.SampleDrawBitmapAtBarTest SampleDrawBitmapAtBarTest(ISeries<double> input )
		{
			return indicator.SampleDrawBitmapAtBarTest(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.SampleDrawBitmapAtBarTest SampleDrawBitmapAtBarTest()
		{
			return indicator.SampleDrawBitmapAtBarTest(Input);
		}

		public Indicators.SampleDrawBitmapAtBarTest SampleDrawBitmapAtBarTest(ISeries<double> input )
		{
			return indicator.SampleDrawBitmapAtBarTest(input);
		}
	}
}

#endregion
