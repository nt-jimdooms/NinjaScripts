#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class OrderFlowVWAPMultipleResetIntervals : Indicator
	{
		private OrderFlowVWAP vwapSessionStandard, vwapWeekStandard;
		private OrderFlowVWAP vwapSessionTick, vwapWeekTick;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Indicator here.";
				Name										= "OrderFlowVWAPMultipleResetIntervals";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
			}
			else if (State == State.DataLoaded)
			{
				AddDataSeries(BarsPeriodType.Tick, 1);
			}
			else if (State == State.DataLoaded)
			{
				vwapSessionStandard = OrderFlowVWAP(VWAPResolution.Standard, Bars.TradingHours, VWAPStandardDeviations.Three, 1, 2, 3);
				vwapWeekStandard = OrderFlowVWAP(VWAPResolution.Standard, Bars.TradingHours, VWAPStandardDeviations.Three, 1, 2, 999);
				vwapWeekStandard.ResetInterval = VWAPResetInterval.Week;
				vwapWeekStandard.SD3Multiplier = 3;
				
				vwapSessionTick = OrderFlowVWAP(VWAPResolution.Tick, Bars.TradingHours, VWAPStandardDeviations.Three, 1, 2, 3);
				vwapWeekTick = OrderFlowVWAP(VWAPResolution.Tick, Bars.TradingHours, VWAPStandardDeviations.Three, 1, 2, 999);
				vwapWeekTick.ResetInterval = VWAPResetInterval.Week;
				vwapWeekTick.SD3Multiplier = 3;
			}
		}

		protected override void OnBarUpdate()
		{
			//Add your custom indicator logic here.
			
			if (BarsInProgress == 1) // Must use the BarsInProgress for this script's single tick data 
			{
				// We have to update the secondary tick series of the cached indicator using Tick Resolution to make sure the values we get in BarsInProgress == 0 are in sync
				vwapSessionTick.Update(vwapSessionTick.BarsArray[1].Count - 1, 1); // Must use BarsArray[1] here since the single tick data series is BarsArray[1] in the VWAP indicator
				vwapWeekTick.Update(vwapWeekTick.BarsArray[1].Count - 1, 1); // Must use BarsArray[1] here since the single tick data series is BarsArray[1] in the VWAP indicator
			}
		}
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private OrderFlowVWAPMultipleResetIntervals[] cacheOrderFlowVWAPMultipleResetIntervals;
		public OrderFlowVWAPMultipleResetIntervals OrderFlowVWAPMultipleResetIntervals()
		{
			return OrderFlowVWAPMultipleResetIntervals(Input);
		}

		public OrderFlowVWAPMultipleResetIntervals OrderFlowVWAPMultipleResetIntervals(ISeries<double> input)
		{
			if (cacheOrderFlowVWAPMultipleResetIntervals != null)
				for (int idx = 0; idx < cacheOrderFlowVWAPMultipleResetIntervals.Length; idx++)
					if (cacheOrderFlowVWAPMultipleResetIntervals[idx] != null &&  cacheOrderFlowVWAPMultipleResetIntervals[idx].EqualsInput(input))
						return cacheOrderFlowVWAPMultipleResetIntervals[idx];
			return CacheIndicator<OrderFlowVWAPMultipleResetIntervals>(new OrderFlowVWAPMultipleResetIntervals(), input, ref cacheOrderFlowVWAPMultipleResetIntervals);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.OrderFlowVWAPMultipleResetIntervals OrderFlowVWAPMultipleResetIntervals()
		{
			return indicator.OrderFlowVWAPMultipleResetIntervals(Input);
		}

		public Indicators.OrderFlowVWAPMultipleResetIntervals OrderFlowVWAPMultipleResetIntervals(ISeries<double> input )
		{
			return indicator.OrderFlowVWAPMultipleResetIntervals(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.OrderFlowVWAPMultipleResetIntervals OrderFlowVWAPMultipleResetIntervals()
		{
			return indicator.OrderFlowVWAPMultipleResetIntervals(Input);
		}

		public Indicators.OrderFlowVWAPMultipleResetIntervals OrderFlowVWAPMultipleResetIntervals(ISeries<double> input )
		{
			return indicator.OrderFlowVWAPMultipleResetIntervals(input);
		}
	}
}

#endregion
