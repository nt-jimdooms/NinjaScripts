#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class AccountItemIndicator : Indicator
	{
		private Account account;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Indicator here.";
				Name										= "AccountItemIndicator";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
			}
			else if (State == State.DataLoaded)
			{
				// Find our Sim101 account
				lock (Account.All)
					account = Account.All.FirstOrDefault(a => a.Name == "Playback101");

				// Subscribe to account item updates
				if (account != null)
				{
					account.AccountItemUpdate += OnAccountItemUpdate;
					Account.AccountStatusUpdate += OnAccountStatusUpdate;
				}
			}
			else if(State == State.Terminated)
			{
				// Make sure to unsubscribe to the account item subscription
        		if (account != null)
				{
            		account.AccountItemUpdate -= OnAccountItemUpdate;
					Account.AccountStatusUpdate -= OnAccountStatusUpdate;
				}
			}
		}

		protected override void OnBarUpdate()
		{
			//Add your custom indicator logic here.
			
		}
		
		// This method is fired on any change of an account value
	    private void OnAccountItemUpdate(object sender, AccountItemEventArgs e)
		{
		     // Output the account item
		     NinjaTrader.Code.Output.Process(string.Format("Account: {0} AccountItem: {1} Value: {2}",
		          e.Account.Name, e.AccountItem, e.Value), PrintTo.OutputTab1);

		}
		
		private void OnAccountStatusUpdate(object sender, AccountStatusEventArgs e)
		{
			Print(String.Format("{0} connection updated", account.Connection.Options.Name));
		}
	
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private AccountItemIndicator[] cacheAccountItemIndicator;
		public AccountItemIndicator AccountItemIndicator()
		{
			return AccountItemIndicator(Input);
		}

		public AccountItemIndicator AccountItemIndicator(ISeries<double> input)
		{
			if (cacheAccountItemIndicator != null)
				for (int idx = 0; idx < cacheAccountItemIndicator.Length; idx++)
					if (cacheAccountItemIndicator[idx] != null &&  cacheAccountItemIndicator[idx].EqualsInput(input))
						return cacheAccountItemIndicator[idx];
			return CacheIndicator<AccountItemIndicator>(new AccountItemIndicator(), input, ref cacheAccountItemIndicator);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.AccountItemIndicator AccountItemIndicator()
		{
			return indicator.AccountItemIndicator(Input);
		}

		public Indicators.AccountItemIndicator AccountItemIndicator(ISeries<double> input )
		{
			return indicator.AccountItemIndicator(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.AccountItemIndicator AccountItemIndicator()
		{
			return indicator.AccountItemIndicator(Input);
		}

		public Indicators.AccountItemIndicator AccountItemIndicator(ISeries<double> input )
		{
			return indicator.AccountItemIndicator(input);
		}
	}
}

#endregion
