#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Controls;
using System.Windows.Media.Imaging;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class ScreenIndi : Indicator
	{
		private System.Timers.Timer myTimer;
		private bool DoOnce;
		private Chart chart;
		private int oldSelectedIndex;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Indicator here.";
				Name										= "ScreenIndi";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= true;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= false;
			}
			else if (State == State.DataLoaded)
			{
				DoOnce = true;
			}
			else if (State == State.Terminated)
			{
		  		// Stops the timer and removes the timer event handler
				if (myTimer != null)
				{
			  		myTimer.Enabled = false;
			  		myTimer.Elapsed -= TimerEventProcessor;
					myTimer = null;
				}
			}
		}

		protected override void OnBarUpdate()
		{
			//Add your custom indicator logic here.
			SendToTelegram("Test Message");
		}
		
		private void TimerEventProcessor(Object myObject, EventArgs myEventArgs)
		{
			/* Important to use the TriggerCustomEvent() to ensure that NinjaScript indexes and pointers are correctly set.
			Do not process your code here. Process your code in the MyCustomHandler method. */
			TriggerCustomEvent(MyCustomHandler, 0, myTimer.Interval);
		}
		
		private void MyCustomHandler(object state)
		{			
			DoOnce = true;
			myTimer.Enabled = false;
			
			chart.Dispatcher.InvokeAsync(() =>
			{
				var screenCapture = chart.GetScreenshot(ShareScreenshotType.Chart);
				var outputFrame = BitmapFrame.Create(screenCapture);

				var png = new PngBitmapEncoder();
				png.Frames.Add(outputFrame);

				var filePath = string.Format(@"{0}\tmp\Tab{1}.png", Core.Globals.UserDataDir, Instrument.FullName);

				using (Stream stream = File.Create(filePath))
					png.Save(stream);

				//Share("Telegram ###", message, filePath);
				chart.MainTabControl.SelectedIndex = oldSelectedIndex;
			});
			
			// Stops the timer and removes the timer event handler
			if (myTimer != null)
			{
		  		myTimer.Enabled = false;
		  		myTimer.Elapsed -= TimerEventProcessor;
				myTimer = null;
			}
		}
		
		private int GetCurrentIndicatorTabIndex(ChartPanel chartPanel)
		{
			var currentIndicatorTabIndex = 0;
			var chart = chartPanel.ChartControl.OwnerChart;

			for (var i = 0; i < chart.MainTabControl.Items.Count; i++)
			{
				if ((string)((TabItem) chart.MainTabControl.Items[i]).Header != chartPanel.ChartControl.ChartTab.ActualTabName) continue;
				currentIndicatorTabIndex = i;
				break;
			}

			return currentIndicatorTabIndex;
		}

		public void SendToTelegram(string message)
		{
			if (State != State.Realtime || message == null) return;
			
			ChartPanel.ChartControl.OwnerChart.Dispatcher.InvokeAsync(() =>
			{
				chart = ChartPanel.ChartControl.OwnerChart;			
				oldSelectedIndex = chart.MainTabControl.SelectedIndex;
				chart.MainTabControl.SelectedIndex = GetCurrentIndicatorTabIndex(ChartPanel);
				chart.ActiveChartControl.InvalidateVisual();
				
			});
			
			DoOnce = false;
				
			// Instantiates the timer and sets the interval to 1 seconds.
			myTimer = new System.Timers.Timer(1000);
	  		myTimer.Elapsed += TimerEventProcessor;
			myTimer.Enabled = true;
		}
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ScreenIndi[] cacheScreenIndi;
		public ScreenIndi ScreenIndi()
		{
			return ScreenIndi(Input);
		}

		public ScreenIndi ScreenIndi(ISeries<double> input)
		{
			if (cacheScreenIndi != null)
				for (int idx = 0; idx < cacheScreenIndi.Length; idx++)
					if (cacheScreenIndi[idx] != null &&  cacheScreenIndi[idx].EqualsInput(input))
						return cacheScreenIndi[idx];
			return CacheIndicator<ScreenIndi>(new ScreenIndi(), input, ref cacheScreenIndi);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ScreenIndi ScreenIndi()
		{
			return indicator.ScreenIndi(Input);
		}

		public Indicators.ScreenIndi ScreenIndi(ISeries<double> input )
		{
			return indicator.ScreenIndi(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ScreenIndi ScreenIndi()
		{
			return indicator.ScreenIndi(Input);
		}

		public Indicators.ScreenIndi ScreenIndi(ISeries<double> input )
		{
			return indicator.ScreenIndi(input);
		}
	}
}

#endregion
