// 
// Copyright (C) 2015, NinjaTrader LLC <www.ninjatrader.com>.
// NinjaTrader reserves the right to modify or overwrite this NinjaScript component with each release.
//
#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

// This namespace holds all strategies and is required. Do not change it.
namespace NinjaTrader.NinjaScript.Strategies
{
	public class SampleOnOrderUpdatePartialTestCQG : Strategy
	{
		private Order entryOrder1						= null; // This variable holds an object representing our entry order
		private Order stopOrder1                        = null; // This variable holds an object representing our stop loss order
		private Order targetOrder1                      = null; // This variable holds an object representing our profit target order
		
		private int Quantity1							= 4;
		
		private bool doCancelClose = false;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description								= @"Sample Using OnOrderUpdate() and OnExecution() methods to submit protective orders";
				Name                                    = "SampleOnOrderUpdatePartialTestCQG";
				Calculate                               = Calculate.OnBarClose;
				EntriesPerDirection                     = 2;
				EntryHandling                           = EntryHandling.AllEntries;
				IsExitOnSessionCloseStrategy            = true;
				ExitOnSessionCloseSeconds               = 30;
				IsFillLimitOnTouch                      = false;
				MaximumBarsLookBack                     = MaximumBarsLookBack.TwoHundredFiftySix;
				OrderFillResolution                     = OrderFillResolution.Standard;
				Slippage                                = 0;
				StartBehavior                           = StartBehavior.WaitUntilFlat;
				TimeInForce                             = TimeInForce.Gtc;
				TraceOrders                             = false;
				RealtimeErrorHandling                   = RealtimeErrorHandling.StopCancelClose;
				StopTargetHandling                      = StopTargetHandling.ByStrategyPosition;
				BarsRequiredToTrade                     = 20;
			}
			else if (State == State.Realtime)
			{
				// one time only, as we transition from historical
			    // convert any old historical order object references
			    // to the new live order submitted to the real-time account
			    if (entryOrder1 != null)
			        entryOrder1 = GetRealtimeOrder(entryOrder1);
				if (stopOrder1 != null)
			        stopOrder1 = GetRealtimeOrder(stopOrder1);
				if (targetOrder1 != null)
			        targetOrder1 = GetRealtimeOrder(targetOrder1);
			}
		}

		protected override void OnBarUpdate()
		{
			if(State == State.Historical)
				return;
			// Submit an entry market order if we currently don't have an entry order open and are past the BarsRequiredToTrade bars amount
			if (entryOrder1 == null && Position.MarketPosition == MarketPosition.Flat && CurrentBar > BarsRequiredToTrade)
			{
				/* Enter Long. We will assign the resulting Order object to entryOrder1 in OnOrderUpdate() */
				EnterLong(Quantity1, "MyEntry1");
			}
			
			if (Position.MarketPosition == MarketPosition.Long && BarsSinceEntryExecution() == 0)
			{
				if (Position.Quantity != stopOrder1.Quantity || Position.Quantity != targetOrder1.Quantity)
					Print(Time[0].ToString() + " Stop/Target Order Quantity does not match Position.Quantity" );
				
				doCancelClose = true;
				CancelOrder(stopOrder1);
				CancelOrder(targetOrder1);
			}
		}

		protected override void OnOrderUpdate(Order order, double limitPrice, double stopPrice, int quantity, int filled, double averageFillPrice, OrderState orderState, DateTime time, ErrorCode error, string nativeError)
		{
			// Handle entry orders here. The entryOrder object allows us to identify that the order that is calling the OnOrderUpdate() method is the entry order.
			// Assign entryOrder in OnOrderUpdate() to ensure the assignment occurs when expected.
            // This is more reliable than assigning Order objects in OnBarUpdate, as the assignment is not gauranteed to be complete if it is referenced immediately after submitting
			if (order.Name == "MyEntry1")
    		{	
        		entryOrder1 = order;

                // Reset the entryOrder object to null if order was cancelled without any fill
                if (order.OrderState == OrderState.Cancelled && order.Filled == 0)
					entryOrder1 = null;
			}			
			
			// Cancel Target and Stop
			if (order.Name == "MyStop1" && order.OrderState == OrderState.Cancelled)
			{
				stopOrder1 = null;
				if (Position.MarketPosition == MarketPosition.Long && stopOrder1 == null && targetOrder1 == null && doCancelClose)
				{
					ExitLong();
					doCancelClose = false;
				}
			}
			if (order.Name == "MyTarget1" && order.OrderState == OrderState.Cancelled)
			{
				targetOrder1 = null;
				if (Position.MarketPosition == MarketPosition.Long && stopOrder1 == null && targetOrder1 == null && doCancelClose)
				{
					ExitLong();
					doCancelClose = false;
				}
			}
		}

		protected override void OnExecutionUpdate(Execution execution, string executionId, double price, int quantity, MarketPosition marketPosition, string orderId, DateTime time)
		{
			/* We advise monitoring OnExecution to trigger submission of stop/target orders instead of OnOrderUpdate() since OnExecution() is called after OnOrderUpdate()
			which ensures your strategy has received the execution which is used for internal signal tracking. */
			if (entryOrder1 != null && entryOrder1 == execution.Order)
            {
				if (execution.Order.OrderState == OrderState.Filled || execution.Order.OrderState == OrderState.PartFilled || (execution.Order.OrderState == OrderState.Cancelled && execution.Order.Filled > 0))
				{
                    if (execution.Order.OrderState == OrderState.PartFilled)
                    {
                        stopOrder1 = ExitLongStopMarket(0, true, execution.Order.Filled, execution.Order.AverageFillPrice - 50 * TickSize, "MyStop1", "MyEntry1");
                        targetOrder1 = ExitLongLimit(0, true, execution.Order.Filled, execution.Order.AverageFillPrice + 50 * TickSize, "MyTarget1", "MyEntry1");
                    }
                    else if (execution.Order.OrderState == OrderState.Filled)
                    {
                    // Stop-Loss order for OrderState.Filled
					    stopOrder1 = ExitLongStopMarket(0, true, execution.Order.Filled, execution.Order.AverageFillPrice - 50 * TickSize, "MyStop1", "MyEntry1");
					    targetOrder1 = ExitLongLimit(0, true, execution.Order.Filled, execution.Order.AverageFillPrice + 50 * TickSize, "MyTarget1", "MyEntry1");
                    }
					
					// Resets the entryOrder object to null after the order has been filled
					if (execution.Order.OrderState != OrderState.PartFilled)
						entryOrder1 = null;
				}
			}

			// Reset our stop order and target orders' Order objects after our position is closed. (1st Entry)
			if ((stopOrder1 != null && stopOrder1 == execution.Order) || (targetOrder1 != null && targetOrder1 == execution.Order))
			{
				if (execution.Order.OrderState == OrderState.Filled || execution.Order.OrderState == OrderState.PartFilled)
				{
					stopOrder1 = null;
					targetOrder1 = null;
				}
			}
		}

		#region Properties
		#endregion
	}
}