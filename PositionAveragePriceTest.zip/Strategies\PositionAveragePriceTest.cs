#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies
{
	public class PositionAveragePriceTest : Strategy
	{
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Strategy here.";
				Name										= "PositionAveragePriceTest";
				Calculate									= Calculate.OnBarClose;
				EntriesPerDirection							= 3;
				EntryHandling								= EntryHandling.AllEntries;
				IsExitOnSessionCloseStrategy				= true;
				ExitOnSessionCloseSeconds					= 30;
				IsFillLimitOnTouch							= false;
				MaximumBarsLookBack							= MaximumBarsLookBack.TwoHundredFiftySix;
				OrderFillResolution							= OrderFillResolution.Standard;
				Slippage									= 0;
				StartBehavior								= StartBehavior.WaitUntilFlat;
				TimeInForce									= TimeInForce.Gtc;
				TraceOrders									= false;
				RealtimeErrorHandling						= RealtimeErrorHandling.StopCancelClose;
				StopTargetHandling							= StopTargetHandling.PerEntryExecution;
				BarsRequiredToTrade							= 20;
				// Disable this property for performance gains in Strategy Analyzer optimizations
				// See the Help Guide for additional information
				IsInstantiatedOnEachOptimizationIteration	= true;
			}
			else if (State == State.Configure)
			{
			}
		}
			
		private double Entry1Price, Entry2Price, Entry3Price;
		private int totalQuantityForPos = 0;

		protected override void OnExecutionUpdate(Cbi.Execution execution, string executionId, double price, int quantity, 
			Cbi.MarketPosition marketPosition, string orderId, DateTime time)
		{
			Print("");
			Print("OEU: " + Position.AveragePrice);
			
			if (execution.Order.Name == "Entry1")
				Entry1Price = execution.Price;
			if (execution.Order.Name == "Entry2")
				Entry2Price = execution.Price;
			if (execution.Order.Name == "Entry3")
				Entry3Price = execution.Price;
			
			if (execution.Order.Name == "Entry1" || execution.Order.Name == "Entry2" || execution.Order.Name == "Entry3")
				totalQuantityForPos++;
			
			
			if (Position.MarketPosition == MarketPosition.Flat)
			{
				Entry1Price = Entry2Price = Entry3Price = 0;
				totalQuantityForPos = 0;
			}
			
			Print("OEU: " + (Entry1Price + Entry2Price + Entry3Price) / totalQuantityForPos);
		}

		private int count = 0;
		protected override void OnBarUpdate()
		{
			if (State == State.Historical)
				return;
			
			if (count == 0)
				EnterLong(1, "Entry1");
			if (count == 1)
				EnterLong(1, "Entry2");
			if (count == 2)
				EnterLong(1, "Entry3");
			
			if (count == 3)
				ExitLong(1, "Exit1", "Entry1");
			if (count == 4)
				ExitLong(1, "Exit2", "Entry2");
			if (count == 5)
				ExitLong(1, "Exit3", "Entry3");
			
				
			count++;
		}
	}
}
