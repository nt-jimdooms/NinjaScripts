using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;
using System.Linq;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Gui;

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public class LastPriceChange : Gui.NinjaScript.MarketAnalyzerColumnRenderBase
	{
		private Brush	fillUpBrush;
		private Brush	fillNuBrush;
		private Brush	fillDnBrush;
		private Brush	color;
		private Brush	color2;
		private Brush	color3;
		private int		opacity;
		
		private Brush	textBrush;
		private Brush	color4;
		private int		opacity2;
		
		private double lastPrice;
		
		private int isUp;

		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description				= "Simple Example for rendering in a MarketAnalyzerColumn";
				Name					= "LastPriceChange";
				IsDataSeriesRequired	= false;
				Color					= Brushes.Green;
				Color2					= Brushes.Gray;
				Color3					= Brushes.Red;
				Opacity					= 50;
				
				Color4					= Brushes.Black;
				Opacity2				= 100;
			}
		}

		public override string Format(double value)
		{
			return (value == double.MinValue ? string.Empty : Instrument.MasterInstrument.FormatPrice(value));
		}

		protected override void OnMarketData(Data.MarketDataEventArgs marketDataUpdate)
		{
			if (marketDataUpdate.IsReset)
				CurrentValue = double.MinValue;
			else if (marketDataUpdate.MarketDataType == Data.MarketDataType.Last)
				CurrentValue = marketDataUpdate.Price;
			
			if (lastPrice == CurrentValue)
				isUp = 0;
			else if (CurrentValue > lastPrice)
				isUp = 1;
			else
				isUp = 2;
			
			lastPrice = CurrentValue;
		}

		public override void OnRender(DrawingContext dc, System.Windows.Size renderSize)
		{
			List<LineSegment>		lineSegments	= new List<LineSegment>();

			if (fillUpBrush == null)
				fillUpBrush = new SolidColorBrush() { Color = (Color as SolidColorBrush).Color, Opacity = (double) Opacity / 100 };
				
			if (fillNuBrush == null)
				fillNuBrush = new SolidColorBrush() { Color = (Color2 as SolidColorBrush).Color, Opacity = (double) Opacity / 100 };
				
			if (fillDnBrush == null)
				fillDnBrush = new SolidColorBrush() { Color = (Color3 as SolidColorBrush).Color, Opacity = (double) Opacity / 100 };
				
			if (textBrush == null)
				textBrush = new SolidColorBrush() { Color = (Color4 as SolidColorBrush).Color, Opacity = (double) Opacity2 / 100 };
			
			// Draw something for the Background. DrawGeometry is used here, but DrawRect could be used instead.
			lineSegments.Add(new LineSegment(new System.Windows.Point(0, 0), true));
			lineSegments.Add(new LineSegment(new System.Windows.Point(0, renderSize.Height), true));
			lineSegments.Add(new LineSegment(new System.Windows.Point(renderSize.Width, renderSize.Height), true));
			lineSegments.Add(new LineSegment(new System.Windows.Point(renderSize.Width, 0), true));

			List<PathFigure> pathFiguresFill = new List<PathFigure>();
			pathFiguresFill.Add(new PathFigure(new System.Windows.Point(0, 0), lineSegments.ToArray(), true));
			PathGeometry pgFill = new PathGeometry(pathFiguresFill);
				
			if (isUp == 0)
				dc.DrawGeometry(fillNuBrush, null, pgFill);
			if (isUp == 1)
				dc.DrawGeometry(fillUpBrush, null, pgFill);
			if (isUp == 2)
				dc.DrawGeometry(fillDnBrush, null, pgFill);
			
			// Draw Text since we are inheriting from Gui.NinjaScript.MarketAnalyzerColumnRenderBase
			dc.DrawText(new FormattedText(CurrentValue.ToString(), System.Globalization.CultureInfo.CurrentCulture, System.Windows.FlowDirection.LeftToRight , new Typeface("Arial"), 12, textBrush), new System.Windows.Point(0, 0));
		}

		#region Properties
		[XmlIgnore]
		[Display(Name = "BG Up Color", GroupName = "GuiPropertyCategoryVisual", Order = 10)]
		public Brush Color
		{
			get { return  color; }
			set { color = value; fillUpBrush = null; }
		}
		
		[XmlIgnore]
		[Display(Name = "BG Nu Color", GroupName = "GuiPropertyCategoryVisual", Order = 11)]
		public Brush Color2
		{
			get { return  color2; }
			set { color2 = value; fillNuBrush = null; }
		}
		
		[XmlIgnore]
		[Display(Name = "BG Dn Color", GroupName = "GuiPropertyCategoryVisual", Order = 12)]
		public Brush Color3
		{
			get { return  color3; }
			set { color3 = value; fillDnBrush = null; }
		}

		[Range(0, 100)]
		[Display(Name = "BG Opacity", GroupName = "GuiPropertyCategoryVisual", Order = 20)]
		public int Opacity
		{
			get { return opacity;}
			set { opacity = value; fillUpBrush = null; fillNuBrush = null; fillDnBrush = null; }
		}
		
		[XmlIgnore]
		[Display(Name = "Text Color", GroupName = "GuiPropertyCategoryVisual", Order = 30)]
		public Brush Color4
		{
			get { return  color4; }
			set { color4 = value; textBrush = null; }
		}

		[Range(0, 100)]
		[Display(Name = "Text Opacity", GroupName = "GuiPropertyCategoryVisual", Order = 40)]
		public int Opacity2
		{
			get { return opacity2;}
			set { opacity2 = value; textBrush = null; }
		}
		#endregion
	}
}