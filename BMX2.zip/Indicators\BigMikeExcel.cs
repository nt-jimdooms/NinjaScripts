#region Using declarations
using System;
using System.IO;
using System.Drawing;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
using Excel = Microsoft.Office.Interop.Excel;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class BigMikeExcel : Indicator
	{
		private bool workSheetFound = false;
		private bool excelOpen=false;
		private string fullFileName;
		private string simpleFileName;
		Excel.Application excelApp;
		Excel._Workbook excelWorkBook;
		Excel._Worksheet excelSheet;
		Excel.Range excelRange;
		private int rowCount = 1;
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Indicator here.";
				Name										= "BigMikeExcel";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				Temp										= 1;
				ExcelFile									= @"C:\DTTest.xlsx";
				ExcelSheetName								= @"Sheet1";
			}
			else if (State == State.Configure)
			{
			}
		}

		protected override void OnBarUpdate()
		{
			if (excelOpen == false)
				SetUpSpreadsheet();
			
			// Post prices to Excel
			rowCount ++;
			excelSheet.Cells[rowCount,1] = ToDay(Time[0]);
			excelSheet.Cells[rowCount,2] = ToTime(Time[0]);
			excelSheet.Cells[rowCount,3] = Open[0];
			excelSheet.Cells[rowCount,4] = High[0];
			excelSheet.Cells[rowCount,5] = Low[0];
			excelSheet.Cells[rowCount,6] = Close[0];
			excelSheet.Cells[rowCount,7] = Volume[0];
			if (rowCount == 201) 
				rowCount = 1;	
		}
		
		#region SupportingMethods
		
		// Set up the spreadsheet
		private void SetUpSpreadsheet()
		{
			OpenWorkbook(ExcelFile);
			excelSheet = (Excel._Worksheet)FindSheet(excelWorkBook, ExcelSheetName);
			if (excelSheet == null) 
			{
				Alert("openError", Priority.High, "Error opening spreadsheet - check indicator parameters",
				"Alert1.wav", 10, Brushes.Black, Brushes.Yellow);
			}
			try
			{
				// Get the range of cells we want to format into an object
				excelRange = excelSheet.get_Range("A1","A201");
				// Font Color
				excelRange.Font.Color = System.Windows.Media.ColorConverter.ConvertFromString(System.Windows.Media.Brushes.DarkBlue.ToString());
				// Background Color
				excelRange.Interior.Color = System.Windows.Media.ColorConverter.ConvertFromString(System.Windows.Media.Brushes.Cornsilk.ToString());
				// Bold
				excelRange.Font.Bold = true;
				// Clear the contents
				excelRange.ClearContents();
				// Other columns
				excelRange = excelSheet.get_Range("B1","B201");
				excelRange.Font.Color = System.Windows.Media.ColorConverter.ConvertFromString(System.Windows.Media.Brushes.DarkBlue.ToString());
				excelRange.Interior.Color = System.Windows.Media.ColorConverter.ConvertFromString(System.Windows.Media.Brushes.Cornsilk.ToString());
				excelRange.Font.Bold = true;
				excelRange.ClearContents();
				excelRange = excelSheet.get_Range("C1","C201");
				excelRange.Font.Color = System.Windows.Media.ColorConverter.ConvertFromString(System.Windows.Media.Brushes.Black.ToString());
				excelRange.Interior.Color = System.Windows.Media.ColorConverter.ConvertFromString(System.Windows.Media.Brushes.Cornsilk.ToString());
				excelRange.Font.Bold = false;
				excelRange.ClearContents();
				excelRange = excelSheet.get_Range("D1","D201");
				excelRange.Font.Color = System.Windows.Media.ColorConverter.ConvertFromString(System.Windows.Media.Brushes.Black.ToString());
				excelRange.Interior.Color = System.Windows.Media.ColorConverter.ConvertFromString(System.Windows.Media.Brushes.Cornsilk.ToString());
				excelRange.Font.Bold = false;
				excelRange.ClearContents();
				excelRange = excelSheet.get_Range("E1","E201");
				excelRange.Font.Color = System.Windows.Media.ColorConverter.ConvertFromString(System.Windows.Media.Brushes.Black.ToString());
				excelRange.Interior.Color = System.Windows.Media.ColorConverter.ConvertFromString(System.Windows.Media.Brushes.Cornsilk.ToString());
				excelRange.Font.Bold = false;
				excelRange.ClearContents();
				excelRange = excelSheet.get_Range("F1","F201");
				excelRange.Font.Color = System.Windows.Media.ColorConverter.ConvertFromString(System.Windows.Media.Brushes.Black.ToString());
				excelRange.Interior.Color = System.Windows.Media.ColorConverter.ConvertFromString(System.Windows.Media.Brushes.Cornsilk.ToString());
				excelRange.Font.Bold = false;
				excelRange.ClearContents();
				excelRange = excelSheet.get_Range("G1","G201");
				excelRange.Font.Color = System.Windows.Media.ColorConverter.ConvertFromString(System.Windows.Media.Brushes.Red.ToString());
				excelRange.Interior.Color = System.Windows.Media.ColorConverter.ConvertFromString(System.Windows.Media.Brushes.Cornsilk.ToString());
				excelRange.Font.Bold = true;
				excelRange.ClearContents();
				excelApp.Visible = true;
				excelApp.UserControl = true;
				excelOpen = true;
				excelRange = excelSheet.get_Range("A1","G1");
				excelRange.Font.Color = System.Windows.Media.ColorConverter.ConvertFromString(System.Windows.Media.Brushes.Black.ToString());
				excelRange.Interior.Color = System.Windows.Media.ColorConverter.ConvertFromString(System.Windows.Media.Brushes.LightGray.ToString());
				excelRange.Font.Bold = true;				
				excelSheet.Cells[1,1] = "Date";
				excelSheet.Cells[1,2] = "Time";
				excelSheet.Cells[1,3] = "Open";
				excelSheet.Cells[1,4] = "High";
				excelSheet.Cells[1,5] = "Low";
				excelSheet.Cells[1,6] = "Close";
				excelSheet.Cells[1,7] = "Volume";
			}
				catch
			{
				Alert("Exception formatting Excel", Priority.High, "Error opening spreadsheet - check indicator parameters",
				"Alert1.wav", 10, Brushes.Black, Brushes.Yellow);
			}			

			// Set up some column colours
			
		}
		
		// Return the worksheet with the given name.
		private Excel.Worksheet FindSheet(Excel._Workbook excelWorkBook, string ExcelSheetName)
		{    
			foreach (Excel.Worksheet excelSheet in excelWorkBook.Sheets)    
			{        
				if (excelSheet.Name == ExcelSheetName) return excelSheet;   
			}    
			return null;
		}
		
		// Open the workbook
		private void OpenWorkbook(string FileName)
		{

		    try
            {
                excelApp = (Excel.Application)System.Runtime.InteropServices.Marshal.GetActiveObject("Excel.Application");
            }
            catch
            {
                excelApp = new Microsoft.Office.Interop.Excel.Application();
            }
			simpleFileName = Path.GetFileName(ExcelFile);
            try
            {
               excelWorkBook = excelApp.Workbooks.get_Item(simpleFileName);
            }
            catch
            {
                excelWorkBook = (Excel._Workbook) (excelApp.Workbooks.Open(ExcelFile,
					false, true, Type.Missing,Type.Missing, Type.Missing, Type.Missing,Type.Missing,
					Type.Missing, Type.Missing, Type.Missing,Type.Missing, Type.Missing, Type.Missing,Type.Missing));
            }
		} 
		
		#endregion

		#region Properties
		[Browsable(false)]
		[XmlIgnore()]
		[Display(Name="Temp", Order=1, GroupName="Parameters")]
		public int Temp
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name="Excel File Name", Description="Excel File Name with full path. Information will be displayed in an Excel Spreadsheet which is included with this indicator", Order=2, GroupName="Parameters")]
		public string ExcelFile
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name="Excel Sheet Name", Description="Excel Sheet name e.g. Sheet1, Sheet2, Sheet3. Case Sensitive", Order=3, GroupName="Parameters")]
		public string ExcelSheetName
		{ get; set; }
		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private BigMikeExcel[] cacheBigMikeExcel;
		public BigMikeExcel BigMikeExcel(string excelFile, string excelSheetName)
		{
			return BigMikeExcel(Input, excelFile, excelSheetName);
		}

		public BigMikeExcel BigMikeExcel(ISeries<double> input, string excelFile, string excelSheetName)
		{
			if (cacheBigMikeExcel != null)
				for (int idx = 0; idx < cacheBigMikeExcel.Length; idx++)
					if (cacheBigMikeExcel[idx] != null && cacheBigMikeExcel[idx].ExcelFile == excelFile && cacheBigMikeExcel[idx].ExcelSheetName == excelSheetName && cacheBigMikeExcel[idx].EqualsInput(input))
						return cacheBigMikeExcel[idx];
			return CacheIndicator<BigMikeExcel>(new BigMikeExcel(){ ExcelFile = excelFile, ExcelSheetName = excelSheetName }, input, ref cacheBigMikeExcel);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.BigMikeExcel BigMikeExcel(string excelFile, string excelSheetName)
		{
			return indicator.BigMikeExcel(Input, excelFile, excelSheetName);
		}

		public Indicators.BigMikeExcel BigMikeExcel(ISeries<double> input , string excelFile, string excelSheetName)
		{
			return indicator.BigMikeExcel(input, excelFile, excelSheetName);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.BigMikeExcel BigMikeExcel(string excelFile, string excelSheetName)
		{
			return indicator.BigMikeExcel(Input, excelFile, excelSheetName);
		}

		public Indicators.BigMikeExcel BigMikeExcel(ISeries<double> input , string excelFile, string excelSheetName)
		{
			return indicator.BigMikeExcel(input, excelFile, excelSheetName);
		}
	}
}

#endregion
