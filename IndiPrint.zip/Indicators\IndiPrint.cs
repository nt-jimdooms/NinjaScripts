#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class IndiPrint : Indicator
	{
		private System.Windows.Controls.Button myButton;
		private System.Windows.Controls.Grid myGrid;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description							= @"IndiPrint";
				Name								= "IndiPrint";
				Calculate							= Calculate.OnBarClose;
			}
			else if (State == State.Historical)
			{
				if (UserControlCollection.Contains(myGrid))
					return;
				
				Dispatcher.InvokeAsync((() =>
				{
					myGrid = new System.Windows.Controls.Grid
					{
						Name = "MyCustomGrid", HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Top
					};
					
					System.Windows.Controls.ColumnDefinition column1 = new System.Windows.Controls.ColumnDefinition();
					System.Windows.Controls.ColumnDefinition column2 = new System.Windows.Controls.ColumnDefinition();
					
					myGrid.ColumnDefinitions.Add(column1);
					myGrid.ColumnDefinitions.Add(column2);
					
					myButton = new System.Windows.Controls.Button
					{
						Name = "MyButton", Content = "Press Me", Foreground = Brushes.White, Background = Brushes.Black
					};
					
					myButton.Click += OnButtonClick;
					
					System.Windows.Controls.Grid.SetColumn(myButton, 0);
					
					myGrid.Children.Add(myButton);
					
					UserControlCollection.Add(myGrid);
				}));
			}
			else if (State == State.Terminated)
			{
				Dispatcher.InvokeAsync((() =>
				{
					if (myGrid != null)
					{
						if (myButton != null)
						{
							myGrid.Children.Remove(myButton);
							myButton.Click -= OnButtonClick;
							myButton = null;
						}
					}
				}));
			}
		}

		protected override void OnBarUpdate()
		{
		}
		
		private void OnButtonClick(object sender, RoutedEventArgs rea)
		{
			System.Windows.Controls.Button button = sender as System.Windows.Controls.Button;
			if (button == myButton && button.Name == "MyButton")
			{
				lock (ChartControl.Indicators)
				{
					foreach (IndicatorBase indi in ChartControl.Indicators)
				    {
						for (int i = 0; i < indi.Plots.Count(); i++)
						{
							if (indi.Plots[i] != null)
							{
								for (int j = 0; j < indi.Values[i].Count; j++)
								{
									Print(String.Format("Name: {0}, Index: {1} Value: {2} PlotName: {3}", indi.Name, j, indi.Values[i].GetValueAt(j), indi.Plots[i].Name));
								}
							}
						}
					}
				}
				return;
			}
			
		}
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private IndiPrint[] cacheIndiPrint;
		public IndiPrint IndiPrint()
		{
			return IndiPrint(Input);
		}

		public IndiPrint IndiPrint(ISeries<double> input)
		{
			if (cacheIndiPrint != null)
				for (int idx = 0; idx < cacheIndiPrint.Length; idx++)
					if (cacheIndiPrint[idx] != null &&  cacheIndiPrint[idx].EqualsInput(input))
						return cacheIndiPrint[idx];
			return CacheIndicator<IndiPrint>(new IndiPrint(), input, ref cacheIndiPrint);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.IndiPrint IndiPrint()
		{
			return indicator.IndiPrint(Input);
		}

		public Indicators.IndiPrint IndiPrint(ISeries<double> input )
		{
			return indicator.IndiPrint(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.IndiPrint IndiPrint()
		{
			return indicator.IndiPrint(Input);
		}

		public Indicators.IndiPrint IndiPrint(ISeries<double> input )
		{
			return indicator.IndiPrint(input);
		}
	}
}

#endregion
