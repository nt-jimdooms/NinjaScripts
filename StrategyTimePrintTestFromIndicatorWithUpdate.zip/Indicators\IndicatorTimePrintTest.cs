#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class IndicatorTimePrintTest : Indicator
	{
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Indicator here.";
				Name										= "IndicatorTimePrintTest";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				AddPlot(Brushes.White, "MyPlot");
			}
			else if (State == State.Configure)
			{
				AddDataSeries("NQ 03-22", BarsPeriodType.Second, 10);
			}
		}

		protected override void OnBarUpdate()
		{
			//if (BarsInProgress != 0)
			//	return;
			
			if (CurrentBars[0] < 1 || CurrentBars[1] < 1)
				return;
			
			Value[0] = Closes[1][0]-Closes[0][0];
			
			if (State == State.Realtime)
				Print(String.Format("Primary Timestamp: {0} Secondary Timestamp: {1} PC Clock: {2} BIP: {3}", Times[0][0], Times[1][0], DateTime.Now, BarsInProgress));
			
		}
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private IndicatorTimePrintTest[] cacheIndicatorTimePrintTest;
		public IndicatorTimePrintTest IndicatorTimePrintTest()
		{
			return IndicatorTimePrintTest(Input);
		}

		public IndicatorTimePrintTest IndicatorTimePrintTest(ISeries<double> input)
		{
			if (cacheIndicatorTimePrintTest != null)
				for (int idx = 0; idx < cacheIndicatorTimePrintTest.Length; idx++)
					if (cacheIndicatorTimePrintTest[idx] != null &&  cacheIndicatorTimePrintTest[idx].EqualsInput(input))
						return cacheIndicatorTimePrintTest[idx];
			return CacheIndicator<IndicatorTimePrintTest>(new IndicatorTimePrintTest(), input, ref cacheIndicatorTimePrintTest);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.IndicatorTimePrintTest IndicatorTimePrintTest()
		{
			return indicator.IndicatorTimePrintTest(Input);
		}

		public Indicators.IndicatorTimePrintTest IndicatorTimePrintTest(ISeries<double> input )
		{
			return indicator.IndicatorTimePrintTest(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.IndicatorTimePrintTest IndicatorTimePrintTest()
		{
			return indicator.IndicatorTimePrintTest(Input);
		}

		public Indicators.IndicatorTimePrintTest IndicatorTimePrintTest(ISeries<double> input )
		{
			return indicator.IndicatorTimePrintTest(input);
		}
	}
}

#endregion
