#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies
{
	[TypeConverter("NinjaTrader.NinjaScript.Strategies.MyConverter")]
	public class EnumShowHidePropertiesTest : Strategy
	{
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"";
				Name										= "EnumShowHidePropertiesTest";
				MyEnum = EnumShowHidePropertiesTestEnums.EnumsTest.Value1;
				ToggleValue1 = 1;
				ToggleValue2 = 2;
				ToggleValue3 = 3;
			}
		}

		protected override void OnBarUpdate()
		{
			//Add your custom strategy logic here.
		}
		
		//[NinjaScriptProperty]
		[RefreshProperties(RefreshProperties.All)]		
		public EnumShowHidePropertiesTestEnums.EnumsTest MyEnum
		{ get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name = "Toggle value #1", Order = 2, GroupName = "Use Case #1")]
		public int ToggleValue1
		{ get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name = "Toggle value #2", Order = 3, GroupName = "Use Case #1")]
		public int ToggleValue2
		{ get; set; }
		
		[NinjaScriptProperty]
		[Display(Name = "Enum Used", Order = 3, GroupName = "")]
		public int ToggleValue3
		{ get; set; }
	}


	// This custom TypeConverter is applied ot the entire indicator object and handles two of our use cases
	// IMPORTANT: Inherit from IndicatorBaseConverter so we get default NinjaTrader property handling logic
	// IMPORTANT: Not doing this will completely break the property grids!
	// If targeting a "Strategy", use the "StrategyBaseConverter" base type instead
	public class MyConverter : StrategyBaseConverter
	{
		public override PropertyDescriptorCollection GetProperties(ITypeDescriptorContext context, object component, Attribute[] attrs)
		{
			// we need the indicator instance which actually exists on the grid
			EnumShowHidePropertiesTest strategy = component as EnumShowHidePropertiesTest;

			// base.GetProperties ensures we have all the properties (and associated property grid editors)
			// NinjaTrader internal logic determines for a given indicator
			PropertyDescriptorCollection propertyDescriptorCollection = base.GetPropertiesSupported(context)
																		? base.GetProperties(context, component, attrs)
																		: TypeDescriptor.GetProperties(component, attrs);

			if (strategy == null || propertyDescriptorCollection == null)
				return propertyDescriptorCollection;


			#region Use Case #1: Show/hide properties based on secondary input

			// These two values are will be shown/hidden (toggled) based on "ShowHideToggle" bool value
			PropertyDescriptor toggleValue1 = propertyDescriptorCollection["ToggleValue1"];
			PropertyDescriptor toggleValue2 = propertyDescriptorCollection["ToggleValue2"];
			PropertyDescriptor toggleValue3 = propertyDescriptorCollection["ToggleValue3"];

			// This removes the following properties from the grid to start off with
			propertyDescriptorCollection.Remove(toggleValue1);
			propertyDescriptorCollection.Remove(toggleValue2);
			propertyDescriptorCollection.Remove(toggleValue3);
			
			strategy.ToggleValue3 = (int)strategy.MyEnum;

			// Now that We've removed the default property descriptors, we can decide if they need to be re-added
			// If "ShowHideToggle" is set to true, re-add these values to the property collection
			if (strategy.MyEnum == EnumShowHidePropertiesTestEnums.EnumsTest.Value1)
			{
				propertyDescriptorCollection.Add(toggleValue1);
				propertyDescriptorCollection.Add(toggleValue2);
			}

			// otherwise, nothing else to do since they were already removed

			#endregion

			return propertyDescriptorCollection;
		}

		// Important: This must return true otherwise the type convetor will not be called
		public override bool GetPropertiesSupported(ITypeDescriptorContext context)
		{ return true; }
	}
}

namespace EnumShowHidePropertiesTestEnums
{
	public enum EnumsTest
	{
		Value1,
		Value2
	}
}
