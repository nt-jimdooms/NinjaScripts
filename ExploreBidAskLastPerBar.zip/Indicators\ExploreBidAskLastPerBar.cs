#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class ExploreBidAskLastPerBar : Indicator
	{
		private Dictionary<int, double> Bids, Asks, Lasts;
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Indicator here.";
				Name										= "ExploreBidAskLastPerBar";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= true;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
			}
			else if (State == State.Configure)
			{
     			AddDataSeries("GC 06-18", BarsPeriodType.Tick, 1, MarketDataType.Ask); // BIP1
      			AddDataSeries("GC 06-18", BarsPeriodType.Tick, 1, MarketDataType.Bid); // BIP2
				AddDataSeries("GC 06-18", BarsPeriodType.Tick, 1, MarketDataType.Last); // BIP3
				
				Bids = new Dictionary<int, double>();
				Asks = new Dictionary<int, double>();
				Lasts = new Dictionary<int, double>();
			}
		}
		
		private int activeBar = -1;
		
		private int BarsToPrint = 2;

		protected override void OnBarUpdate()
		{
			if(CurrentBars[0] > BarsToPrint)
				return;
			
			if(BarsInProgress == 1) // Ask
			{
				Asks.Add(CurrentBar, Close[0]);
			}
			else if (BarsInProgress == 2) // Bid
			{
				Bids.Add(CurrentBar, Close[0]);
			}
			else if (BarsInProgress == 3) // Last
			{
				Lasts.Add(CurrentBar, Close[0]);
			}
			
			Print("OBU: " + BarsInProgress + " " + CurrentBars[0] + " " + Close[0] + " " + Time[0].ToString("hh:mm:ss.ffff tt"));
			if(BarsInProgress == 0 && activeBar !=CurrentBar)
			{
				Print("");
				Print(" New Bar: " + CurrentBar);
				Print("");
				
				foreach(KeyValuePair<int, double> item in Asks)
				{
					Print("Ask: " + item.Key + " Ask Price: " + item.Value);
				}
				Print("");
				
				foreach(KeyValuePair<int, double> item in Bids)
				{
					Print("Bid: " + item.Key + " Bid Price: " + item.Value);
				}
				Print("");
				
				foreach(KeyValuePair<int, double> item in Lasts)
				{
					Print("Last: " + item.Key + " Last Price: " + item.Value);
				}
				
				Asks.Clear();
				Bids.Clear();
				Lasts.Clear();
				
				Print("");
				Print("OBU Close: " + Close[0]);
				Print("");
				activeBar = CurrentBar;
			}
		}
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ExploreBidAskLastPerBar[] cacheExploreBidAskLastPerBar;
		public ExploreBidAskLastPerBar ExploreBidAskLastPerBar()
		{
			return ExploreBidAskLastPerBar(Input);
		}

		public ExploreBidAskLastPerBar ExploreBidAskLastPerBar(ISeries<double> input)
		{
			if (cacheExploreBidAskLastPerBar != null)
				for (int idx = 0; idx < cacheExploreBidAskLastPerBar.Length; idx++)
					if (cacheExploreBidAskLastPerBar[idx] != null &&  cacheExploreBidAskLastPerBar[idx].EqualsInput(input))
						return cacheExploreBidAskLastPerBar[idx];
			return CacheIndicator<ExploreBidAskLastPerBar>(new ExploreBidAskLastPerBar(), input, ref cacheExploreBidAskLastPerBar);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ExploreBidAskLastPerBar ExploreBidAskLastPerBar()
		{
			return indicator.ExploreBidAskLastPerBar(Input);
		}

		public Indicators.ExploreBidAskLastPerBar ExploreBidAskLastPerBar(ISeries<double> input )
		{
			return indicator.ExploreBidAskLastPerBar(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ExploreBidAskLastPerBar ExploreBidAskLastPerBar()
		{
			return indicator.ExploreBidAskLastPerBar(Input);
		}

		public Indicators.ExploreBidAskLastPerBar ExploreBidAskLastPerBar(ISeries<double> input )
		{
			return indicator.ExploreBidAskLastPerBar(input);
		}
	}
}

#endregion
