// 
// Copyright (C) 2016, NinjaTrader LLC <www.ninjatrader.com>.
// NinjaTrader reserves the right to modify or overwrite this NinjaScript component with each release.
//
#region Using declarations
using System;
using System.ComponentModel;
using NinjaTrader;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using System.Diagnostics;
#endregion

//Notes:  Name of Bar type must be in capital letters

namespace NinjaTrader.NinjaScript.BarsTypes
{
	
		//Notes:
	
		//Must enter whole number, for Yen, .0088620 would be entered in pricetocal% from 88620.  For CL 40.40 would be 4040.
		//If the instrument does not have a decimal in its price, or a ticksize smaller than 1, it will be displayed as basis points.  
	   //For example the dow jones, an output of 744 would mean 7.44%
			
		//This bartype will display the percent change from the user entered  price.  There is an issue with display, in that say the dow jones is up .9 percent from last.
		//since dow doens't have a decimal, the chart is goofy.  In this case you should set a value of 2 for the parameter "1 for %, 2 for BPS".  This will divide the value
		//by .01, which then displays the value in basis points.  This is the solution for now.
	
		//Written By Alan Palmer
		
	public class AlanPercentBarType : BarsType 
	{
		
		private double PriceToCalcChangeFrom;
		
		private double 	newPriceToCalcFrom;
				
		private double PublicPriceCalcMethod1(double s, Bars bars)  //Modifying the method above, pass it a bars object, which we use to see if the ticksize has a decimal.
		{
			//Getting the ticksize of the contract.
			decimal xvalue = (decimal)bars.Instrument.MasterInstrument.TickSize;
				
			int decValue;
			
			//This is the issue causing the problem with YM., which tick isn't less than 1.
			if(xvalue==1)
				decValue = 0;//(int)xvalue;
			else
				 decValue  = xvalue.ToString().Substring(xvalue.ToString().IndexOf(".")).Length - 1;	///We check the amount of decimals of the contracts price/tick size.
				
			///Once we know the tick size/decmials of the contract, we adjust the user input value
			/// for its decimal.  We have to do this because the Value and Value2, which we use for the 
			/// user input value, are int, and dont' take a decimal.  This allows the user to specify a 
			/// number like 50.45 for crude oil.
			
			
			//Could try a switch/case.		
			//These are to adjust the contract for its decimal.F
			if(decValue ==0)
			{
				newPriceToCalcFrom = PriceToCalcChangeFrom;
//				NinjaTrader.Code.Output.Process(newPriceToCalcFrom.ToString()+"newPriceToCalcFrom", PrintTo.OutputTab1);
			}
			
			if(decValue ==1)
			{
				newPriceToCalcFrom = PriceToCalcChangeFrom *.1 ;
//				NinjaTrader.Code.Output.Process(newPriceToCalcFrom.ToString()+"newPriceToCalcFrom", PrintTo.OutputTab1);
			}
			
			if(decValue ==2)
			{
				newPriceToCalcFrom = PriceToCalcChangeFrom *.01 ;
//				NinjaTrader.Code.Output.Process(newPriceToCalcFrom.ToString()+"newPriceToCalcFrom", PrintTo.OutputTab1);
			}
			
			
			if(decValue ==3)
			{
				newPriceToCalcFrom = PriceToCalcChangeFrom *.001 ;
//				NinjaTrader.Code.Output.Process(newPriceToCalcFrom.ToString()+"newPriceToCalcFrom", PrintTo.OutputTab1);
			}
			
			
			if(decValue ==4)
			{
				newPriceToCalcFrom = PriceToCalcChangeFrom *.0001 ;
//				NinjaTrader.Code.Output.Process(newPriceToCalcFrom.ToString()+"newPriceToCalcFrom", PrintTo.OutputTab1);
			}
			
		
			if(decValue ==5)
			{
				newPriceToCalcFrom = PriceToCalcChangeFrom *.00001 ;
//				NinjaTrader.Code.Output.Process(newPriceToCalcFrom.ToString()+"newPriceToCalcFrom", PrintTo.OutputTab1);
			}
			
			if(decValue ==6)
			{
				newPriceToCalcFrom = PriceToCalcChangeFrom *.000001 ;
//				NinjaTrader.Code.Output.Process(newPriceToCalcFrom.ToString()+"newPriceToCalcFrom", PrintTo.OutputTab1);
			}
			if(decValue ==7)
			{
				newPriceToCalcFrom = PriceToCalcChangeFrom *.0000001 ;
//				NinjaTrader.Code.Output.Process(newPriceToCalcFrom.ToString()+"newPriceToCalcFrom", PrintTo.OutputTab1);
			}
			if(decValue ==8)
			{
				newPriceToCalcFrom = PriceToCalcChangeFrom *.00000001 ;
//				NinjaTrader.Code.Output.Process(newPriceToCalcFrom.ToString()+"newPriceToCalcFrom", PrintTo.OutputTab1);
			}
			
			//NinjaTrader.Code.Output.Process(s.ToString()+"s", PrintTo.OutputTab1);
			
			
			///We get the net change value from the current price, s, and the user inputted value which has been adjusted.
			double xValue = ((s - newPriceToCalcFrom)/newPriceToCalcFrom)*100;
				
		//	NinjaTrader.Code.Output.Process(xValue.ToString(), PrintTo.OutputTab1);

			if(bars.Instrument.MasterInstrument.TickSize<1)   ///IF the tick less than 1, like the ES, then percent will be displayed as a percent.
				return xValue;  
			
			else if(bars.Instrument.MasterInstrument.TickSize>=1)  ///IF the tick is 1, like the dow, then percent will be displayed as BPS.
				return xValue/.01;  
			
			else
				return xValue;  //Always have to return something.
			
		}

		public override void ApplyDefaultValue(BarsPeriod period)
		{
			period.BarsPeriodTypeName = "Alanbars";
			
			PriceToCalcChangeFrom =period.Value2;			
		}
		
		public override void ApplyDefaultBasePeriodValue(BarsPeriod period)
		{
			switch (period.BaseBarsPeriodType)
			{
				case BarsPeriodType.Day		: period.BaseBarsPeriodValue = 1;		DaysToLoad = 365; 	break;
				case BarsPeriodType.Minute	: period.BaseBarsPeriodValue = 1;		DaysToLoad = 50;		break;
				case BarsPeriodType.Month	: period.BaseBarsPeriodValue = 1;		DaysToLoad = 5475;	break;
				case BarsPeriodType.Second	: period.BaseBarsPeriodValue = 30;		DaysToLoad = 3;		break;
				case BarsPeriodType.Tick	: period.BaseBarsPeriodValue = 150;		DaysToLoad = 3;		break;
				case BarsPeriodType.Volume	: period.BaseBarsPeriodValue = 1000;	DaysToLoad = 3;		break;
				case BarsPeriodType.Week	: period.BaseBarsPeriodValue = 1;		DaysToLoad = 1825;	break;
				case BarsPeriodType.Year	: period.BaseBarsPeriodValue = 1;		DaysToLoad = 15000;	break;				
			
			}
			
		}

		public override string ChartLabel(System.DateTime time)   
		{
			switch (BarsPeriod.BaseBarsPeriodType)
			{
				case BarsPeriodType.Day		: return BarsTypeDay.ChartLabel(time);
				case BarsPeriodType.Minute	: return BarsTypeMinute.ChartLabel(time);
				case BarsPeriodType.Month	: return BarsTypeMonth.ChartLabel(time);
				case BarsPeriodType.Second	: return BarsTypeSecond.ChartLabel(time);
				case BarsPeriodType.Tick	: return BarsTypeTick.ChartLabel(time);
				case BarsPeriodType.Volume	: return BarsTypeTick.ChartLabel(time);
				case BarsPeriodType.Week	: return BarsTypeDay.ChartLabel(time);
				case BarsPeriodType.Year	: return BarsTypeYear.ChartLabel(time);
				default						: return BarsTypeDay.ChartLabel(time);
					
			}
		}

		public override int GetInitialLookBackDays(BarsPeriod barsPeriod, TradingHours tradingHours, int barsBack)
		{
			switch (BarsPeriod.BaseBarsPeriodType)
			{
				case BarsPeriodType.Day		:	return (int) Math.Ceiling((barsPeriod.BaseBarsPeriodValue * barsBack * 7.0) / 4.5);
				case BarsPeriodType.Minute	:
					int minutesPerWeek = 0;
					lock (tradingHours.Sessions)
					{
						foreach (Session session in tradingHours.Sessions)
						{
							int beginDay = (int)session.BeginDay;
							int endDay = (int)session.EndDay;
							if (beginDay > endDay)
								endDay += 7;

							minutesPerWeek += (endDay - beginDay) * 1440 + ((session.EndTime / 100) * 60 + (session.EndTime % 100)) - ((session.BeginTime / 100) * 60 + (session.BeginTime % 100));
						}
					}

					return (int)Math.Max(1, Math.Ceiling(barsBack / Math.Max(1, minutesPerWeek / 7.0 / barsPeriod.BaseBarsPeriodValue) * 1.05));
				case BarsPeriodType.Month	:	return barsPeriod.BaseBarsPeriodValue * barsBack * 31;
				case BarsPeriodType.Second	:	return (int) Math.Max(1, Math.Ceiling(barsBack / Math.Max(1, 8.0 * 60 * 60 / barsPeriod.BaseBarsPeriodValue)) * 7.0 / 5.0);	// 8 hours
				case BarsPeriodType.Tick	:	return 1;
				case BarsPeriodType.Volume	:	return 1;
				case BarsPeriodType.Week	:	return barsPeriod.BaseBarsPeriodValue * barsBack * 7;
				case BarsPeriodType.Year	:	return barsPeriod.BaseBarsPeriodValue * barsBack * 365;
				default						:	return 1;	
					
			
			}
		}

		public override double GetPercentComplete(Bars bars, DateTime now)
		{
			switch (BarsPeriod.BaseBarsPeriodType)
			{
				case BarsPeriodType.Day		:	return now.Date <= bars.LastBarTime.Date
															? 1.0 - (bars.LastBarTime.AddDays(1).Subtract(now).TotalDays / bars.BarsPeriod.BaseBarsPeriodValue)
															: 1;
				case BarsPeriodType.Minute	:	return now <= bars.LastBarTime ? 1.0 - (bars.LastBarTime.Subtract(now).TotalMinutes / bars.BarsPeriod.BaseBarsPeriodValue) : 1;
				case BarsPeriodType.Month	: 
					if (now.Date <= bars.LastBarTime.Date)
					{
						int month = now.Month;
						int daysInMonth = (month == 2) ? (DateTime.IsLeapYear(now.Year) ? 29 : 28) : (month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12 ? 31 : 30);
						return (daysInMonth - (bars.LastBarTime.Date.AddDays(1).Subtract(now).TotalDays / bars.BarsPeriod.BaseBarsPeriodValue)) / daysInMonth;
					}
					return 1;
				case BarsPeriodType.Second	:	return now <= bars.LastBarTime ? 1.0 - (bars.LastBarTime.Subtract(now).TotalSeconds / bars.BarsPeriod.BaseBarsPeriodValue) : 1;
				case BarsPeriodType.Tick	:	return (double) bars.TickCount / bars.BarsPeriod.BaseBarsPeriodValue;
				case BarsPeriodType.Volume	:	return (bars.Count == 0) ? 0 : (double) bars.GetVolume(bars.Count - 1) / bars.BarsPeriod.BaseBarsPeriodValue;
				case BarsPeriodType.Week	:	return now.Date <= bars.LastBarTime.Date ? (7 - (bars.LastBarTime.AddDays(1).Subtract(now).TotalDays / bars.BarsPeriod.BaseBarsPeriodValue)) / 7 : 1;
				case BarsPeriodType.Year	: 
					if (now.Date <= bars.LastBarTime.Date)
					{							
						double daysInYear = DateTime.IsLeapYear(now.Year) ? 366 : 365;
						return (daysInYear - (bars.LastBarTime.Date.AddDays(1).Subtract(now).TotalDays / bars.BarsPeriod.BaseBarsPeriodValue)) / daysInYear;
					}
					return 1;
				default						: return 1;
			}
		}

		protected override void OnDataPoint(Bars bars, double open, double high, double low, double close, DateTime time, long volume, bool isBar, double bid, double ask)
		{
			if (SessionIterator == null)
				SessionIterator = new SessionIterator(bars);

			switch (BarsPeriod.BaseBarsPeriodType)
			{
				case BarsPeriodType.Day:
					{
						if (bars.Count == 0)
						{
							if (isBar || bars.TradingHours.Sessions.Count == 0)
								{
									
								AddBar(bars, PublicPriceCalcMethod1(open, bars), PublicPriceCalcMethod1(high, bars), PublicPriceCalcMethod1(high, bars),  PublicPriceCalcMethod1(close, bars), time.Date, volume);	
	 							}
							else
							{
								SessionIterator.CalculateTradingDay(time, false);
					
								AddBar(bars, PublicPriceCalcMethod1(open, bars), PublicPriceCalcMethod1(high, bars), PublicPriceCalcMethod1(low, bars),  PublicPriceCalcMethod1(close, bars), SessionIterator.ActualTradingDayExchange, volume);		
							}
						}
						else
						{
							DateTime barTime;
							if (isBar)
								barTime = time.Date;
							else
							{
								if (bars.TradingHours.Sessions.Count > 0 && SessionIterator.IsNewSession(time, false))
								{
									SessionIterator.CalculateTradingDay(time, false);
									barTime = SessionIterator.ActualTradingDayExchange;
									if (barTime < bars.LastBarTime.Date)
										barTime = bars.LastBarTime.Date; // Make sure timestamps are ascending
								}
								else
									barTime = bars.LastBarTime.Date; // Make sure timestamps are ascending
							}

							if (bars.DayCount < bars.BarsPeriod.BaseBarsPeriodValue
								|| (isBar && bars.Count > 0 && barTime == bars.LastBarTime.Date)
								|| (!isBar && bars.Count > 0 && barTime <= bars.LastBarTime.Date))
							{
				
								UpdateBar(bars,  PublicPriceCalcMethod1(high, bars), PublicPriceCalcMethod1(low, bars),  PublicPriceCalcMethod1(close, bars), barTime, volume);
			
							}
							else
							{
				
								///using new method which dynamically displays BPS vs tick.
								AddBar(bars, PublicPriceCalcMethod1(open, bars), PublicPriceCalcMethod1(high, bars), PublicPriceCalcMethod1(low, bars),  PublicPriceCalcMethod1(close, bars), barTime, volume);
							}
						}

						break;
					}

				case BarsPeriodType.Minute:
					{
						if (bars.Count == 0)
						{
							AddBar(bars, PublicPriceCalcMethod1(open, bars), PublicPriceCalcMethod1(high, bars), PublicPriceCalcMethod1(low, bars),  PublicPriceCalcMethod1(close, bars), TimeToBarTimeMinute(bars, time, isBar), volume);
								
		
						}	
						else if (!isBar && time < bars.LastBarTime)
						{
							UpdateBar(bars, PublicPriceCalcMethod1(high, bars), PublicPriceCalcMethod1(low, bars),  PublicPriceCalcMethod1(close, bars), bars.LastBarTime, volume);
							
							
						}
						else if (isBar && time <= bars.LastBarTime)
						{
				
							UpdateBar(bars, PublicPriceCalcMethod1(high, bars), PublicPriceCalcMethod1(low, bars),  PublicPriceCalcMethod1(close, bars), bars.LastBarTime, volume);
						
						}
						else
						{

							time		= TimeToBarTimeMinute(bars, time, isBar);
						
							AddBar(bars, PublicPriceCalcMethod1(open, bars), PublicPriceCalcMethod1(high, bars), PublicPriceCalcMethod1(low, bars),  PublicPriceCalcMethod1(close, bars), time, volume);
							
			
						}

						break;
					}
				case BarsPeriodType.Month:
					{
						if (bars.Count == 0)
						{
							AddBar(bars,  PublicPriceCalcMethod1(open, bars), PublicPriceCalcMethod1(high, bars), PublicPriceCalcMethod1(low, bars),  PublicPriceCalcMethod1(close, bars), TimeToBarTimeMonth(time, bars.BarsPeriod.BaseBarsPeriodValue), volume);
						
						}
							else if ((time.Month <= bars.LastBarTime.Month && time.Year == bars.LastBarTime.Year) || time.Year < bars.LastBarTime.Year)
						{
							if (high != bars.GetHigh(bars.Count - 1) || low != bars.GetLow(bars.Count - 1) || close != bars.GetClose(bars.Count - 1) || volume > 0)
							{
	
								UpdateBar(bars, PublicPriceCalcMethod1(high, bars), PublicPriceCalcMethod1(low, bars),  PublicPriceCalcMethod1(close, bars), bars.LastBarTime, volume);
								
							}
						}
						else
						{

							AddBar(bars, PublicPriceCalcMethod1(open, bars), PublicPriceCalcMethod1(high, bars), PublicPriceCalcMethod1(low, bars),  PublicPriceCalcMethod1(close, bars), TimeToBarTimeMonth(time, bars.BarsPeriod.BaseBarsPeriodValue), volume);
					
							
						}
						break;
					}
				case BarsPeriodType.Second:
					{
						if (bars.Count == 0)
						{
							DateTime barTime = TimeToBarTimeSecond(bars, time, isBar);
							AddBar(bars, PublicPriceCalcMethod1(open, bars), PublicPriceCalcMethod1(high, bars), PublicPriceCalcMethod1(low, bars),  PublicPriceCalcMethod1(close, bars), barTime, volume);
				
						}
						else
						{
							if (bars.BarsPeriod.BaseBarsPeriodValue > 1 && time < bars.LastBarTime || bars.BarsPeriod.BaseBarsPeriodValue == 1 && time <= bars.LastBarTime)
							{

								UpdateBar(bars, PublicPriceCalcMethod1(high, bars), PublicPriceCalcMethod1(low, bars),  PublicPriceCalcMethod1(close, bars), bars.LastBarTime, volume);
					
								
							}
							else
							{

								time		= TimeToBarTimeSecond(bars, time, isBar);
								
								AddBar(bars, PublicPriceCalcMethod1(open, bars), PublicPriceCalcMethod1(high, bars), PublicPriceCalcMethod1(low, bars),  PublicPriceCalcMethod1(close, bars), time, volume);
								
							}
						}
						break;
					}
				case BarsPeriodType.Tick:
					{
						
						bool isNewSession = SessionIterator.IsNewSession(time, isBar);
						
						if (isNewSession)
							SessionIterator.GetNextSession(time, isBar);
						
						if (bars.BarsPeriod.BaseBarsPeriodValue == 1)
						{
							AddBar(bars, PublicPriceCalcMethod1(open, bars), PublicPriceCalcMethod1(high, bars), PublicPriceCalcMethod1(low, bars),  PublicPriceCalcMethod1(close, bars), time, volume, bid, ask);
						
						}
							else if (bars.Count == 0)
							{	
								AddBar(bars, PublicPriceCalcMethod1(open, bars), PublicPriceCalcMethod1(high, bars), PublicPriceCalcMethod1(low, bars),  PublicPriceCalcMethod1(close, bars), time, volume);

							}
						
						else if (bars.Count > 0 && (!bars.IsResetOnNewTradingDay || !isNewSession) &&
							 bars.BarsPeriod.BaseBarsPeriodValue > 1 &&
							 bars.TickCount < bars.BarsPeriod.BaseBarsPeriodValue)
						{
							UpdateBar(bars, PublicPriceCalcMethod1(high, bars), PublicPriceCalcMethod1(low, bars),  PublicPriceCalcMethod1(close, bars), time, volume);

						}
						else
						{
							AddBar(bars, PublicPriceCalcMethod1(open, bars), PublicPriceCalcMethod1(high, bars), PublicPriceCalcMethod1(low, bars),  PublicPriceCalcMethod1(close, bars), time, volume);
						}
						break;						
						
						
					}
				case BarsPeriodType.Volume:
					{
						if (bars.Count == 0)
						{
							while (volume > bars.BarsPeriod.BaseBarsPeriodValue)
							{

								AddBar(bars, PublicPriceCalcMethod1(open, bars), PublicPriceCalcMethod1(high, bars), PublicPriceCalcMethod1(low, bars),  PublicPriceCalcMethod1(close, bars), time, bars.BarsPeriod.BaseBarsPeriodValue);
								volume -= bars.BarsPeriod.BaseBarsPeriodValue;
							}
							if (volume > 0)
							{
								AddBar(bars, PublicPriceCalcMethod1(open, bars), PublicPriceCalcMethod1(high, bars), PublicPriceCalcMethod1(low, bars),  PublicPriceCalcMethod1(close, bars), time, volume);

							}
						}
						else
						{
							long volumeTmp		= 0;
							bool isNewSession	= SessionIterator.IsNewSession(time, isBar);
							if (!bars.IsResetOnNewTradingDay || !isNewSession)
							{
								volumeTmp = Math.Min(bars.BarsPeriod.BaseBarsPeriodValue - bars.GetVolume(bars.Count - 1), volume);
								if (volumeTmp > 0)
								{
									UpdateBar(bars,PublicPriceCalcMethod1(high, bars), PublicPriceCalcMethod1(low, bars),  PublicPriceCalcMethod1(close, bars), time, volumeTmp);

				
								}
							}

							if (isNewSession)
								SessionIterator.GetNextSession(time, isBar);

							volumeTmp = volume - volumeTmp;
							while (volumeTmp > 0)
							{

								AddBar(bars, PublicPriceCalcMethod1(open, bars), PublicPriceCalcMethod1(high, bars), PublicPriceCalcMethod1(low, bars),  PublicPriceCalcMethod1(close, bars), time, Math.Min(volumeTmp, bars.BarsPeriod.BaseBarsPeriodValue));
							

								volumeTmp -= bars.BarsPeriod.BaseBarsPeriodValue;
							}
						}

						break;
					}
				case BarsPeriodType.Week:
					{
						if (bars.Count == 0)
						{
							AddBar(bars, PublicPriceCalcMethod1(open, bars), PublicPriceCalcMethod1(high, bars), PublicPriceCalcMethod1(low, bars),  PublicPriceCalcMethod1(close, bars), TimeToBarTimeWeek(time, time.AddDays((6 - (((int)time.DayOfWeek + 1) % 7)) + ((bars.BarsPeriod.BaseBarsPeriodValue - 1) * 7)), bars.BarsPeriod.BaseBarsPeriodValue), volume);
						
						}
						else if (time.Date <= bars.LastBarTime.Date)
						{
							UpdateBar(bars, PublicPriceCalcMethod1(high, bars), PublicPriceCalcMethod1(low, bars),  PublicPriceCalcMethod1(close, bars), bars.LastBarTime, volume);
						
						}
						else
						{

							AddBar(bars,  PublicPriceCalcMethod1(open, bars), PublicPriceCalcMethod1(high, bars), PublicPriceCalcMethod1(low, bars),  PublicPriceCalcMethod1(close, bars), TimeToBarTimeWeek(time.Date, bars.LastBarTime.Date, bars.BarsPeriod.BaseBarsPeriodValue), volume);
						
						}
						
						break;
					}
				case BarsPeriodType.Year:
					{
						if (bars.Count == 0)
						{
							AddBar(bars, PublicPriceCalcMethod1(open, bars), PublicPriceCalcMethod1(high, bars), PublicPriceCalcMethod1(low, bars),  PublicPriceCalcMethod1(close, bars), TimeToBarTimeYear(time, bars.BarsPeriod.BaseBarsPeriodValue), volume);
						
			
						}
						else
						{
							if (time.Year <= bars.LastBarTime.Year)
							{

								UpdateBar(bars, PublicPriceCalcMethod1(high, bars), PublicPriceCalcMethod1(low, bars),  PublicPriceCalcMethod1(close, bars), bars.LastBarTime, volume);
							
		
							}
							else
							{
								AddBar(bars,  PublicPriceCalcMethod1(open, bars), PublicPriceCalcMethod1(high, bars), PublicPriceCalcMethod1(low, bars),  PublicPriceCalcMethod1(close, bars), TimeToBarTimeYear(time.Date, bars.BarsPeriod.BaseBarsPeriodValue), volume);
							
							}
						}

						break;
					}
			}
			
			bars.LastPrice = PublicPriceCalcMethod1(close, bars);

			}

	
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Name						= "AlanPercentBarType";   
				BarsPeriod					= new BarsPeriod { BarsPeriodType = (BarsPeriodType) 666, BarsPeriodTypeName = "AlanPercentBarType", Value = 1 };  
				
				DaysToLoad					= 20;
				PriceToCalcChangeFrom =0;			
				
			
			}
			else if (State == State.Configure)
			{
				PriceToCalcChangeFrom = BarsPeriod.Value2;  //Setting the value of our PriceToCalcChangeFrom variable to Value2, which we set in 
								
				switch (BarsPeriod.BaseBarsPeriodType)
				{
					case BarsPeriodType.Minute	: BuiltFrom = BarsPeriodType.Minute; IsIntraday = true; IsTimeBased = true; break;
					case BarsPeriodType.Second	: BuiltFrom = BarsPeriodType.Tick;   IsIntraday = true;	IsTimeBased = true; break;
					case BarsPeriodType.Tick	:
					case BarsPeriodType.Volume	: BuiltFrom = BarsPeriodType.Tick;	IsIntraday = true;	IsTimeBased = false; break;
					default						: BuiltFrom = BarsPeriodType.Day;	IsIntraday = false;	IsTimeBased = true; break;
				
				}
					

				switch (BarsPeriod.BaseBarsPeriodType)
				{
					case BarsPeriodType.Day		: Name = string.Format("{0} {1} AlanPercentBarType{2}",	BarsPeriod.BaseBarsPeriodValue, BarsPeriod.BaseBarsPeriodValue == 1 ? Resource.GuiDaily		: Resource.GuiDay, BarsPeriod.MarketDataType != MarketDataType.Last		? string.Format(" - {0}", BarsPeriod.MarketDataType) : string.Empty);	break;
					case BarsPeriodType.Minute	: Name = string.Format("{0} Min AlanPercentBarType{1}",	BarsPeriod.BaseBarsPeriodValue, BarsPeriod.MarketDataType != MarketDataType.Last ? string.Format(" - {0}", BarsPeriod.MarketDataType) : string.Empty);																						break;
					case BarsPeriodType.Month	: Name = string.Format("{0} {1} AlanPercentBarType{2}",	BarsPeriod.BaseBarsPeriodValue, BarsPeriod.BaseBarsPeriodValue == 1 ? Resource.GuiMonthly	: Resource.GuiMonth, BarsPeriod.MarketDataType != MarketDataType.Last	? string.Format(" - {0}", BarsPeriod.MarketDataType) : string.Empty);	break;
					case BarsPeriodType.Second	: Name = string.Format("{0} {1} AlanPercentBarType{2}",	BarsPeriod.BaseBarsPeriodValue, BarsPeriod.BaseBarsPeriodValue == 1 ? Resource.GuiSecond	: Resource.GuiSeconds, BarsPeriod.MarketDataType != MarketDataType.Last ? string.Format(" - {0}", BarsPeriod.MarketDataType) : string.Empty);	break;
					case BarsPeriodType.Tick	: Name = string.Format("{0} Tick AlanPercentBarType{1}",	BarsPeriod.BaseBarsPeriodValue, BarsPeriod.MarketDataType != MarketDataType.Last ? string.Format(" - {0}", BarsPeriod.MarketDataType) : string.Empty);																						break;
					case BarsPeriodType.Volume	: Name = string.Format("{0} Volume AlanPercentBarType{1}",	BarsPeriod.BaseBarsPeriodValue, BarsPeriod.MarketDataType != MarketDataType.Last ? string.Format(" - {0}", BarsPeriod.MarketDataType) : string.Empty);																						break;
					case BarsPeriodType.Week	: Name = string.Format("{0} {1} AlanPercentBarType{2}",	BarsPeriod.BaseBarsPeriodValue, BarsPeriod.BaseBarsPeriodValue == 1 ? Resource.GuiWeekly	: Resource.GuiWeeks, BarsPeriod.MarketDataType != MarketDataType.Last	? string.Format(" - {0}", BarsPeriod.MarketDataType) : string.Empty);	break;
					case BarsPeriodType.Year	: Name = string.Format("{0} {1} AlanPercentBarType{2}",	BarsPeriod.BaseBarsPeriodValue, BarsPeriod.BaseBarsPeriodValue == 1 ? Resource.GuiYearly	: Resource.GuiYears, BarsPeriod.MarketDataType != MarketDataType.Last	? string.Format(" - {0}", BarsPeriod.MarketDataType) : string.Empty);	break;
				}

				Properties.Remove(Properties.Find("PointAndFigurePriceType",	true));
				Properties.Remove(Properties.Find("ReversalType",				true));
				Properties.Remove(Properties.Find("Value",						true));
			
				//You can't create user inputs, but you can override existing ones like Value2.
				//Properties.Remove(Properties.Find("Value2",						true));  Don't want to remove it from UI.
			
				///Change the display name of Value2.
				SetPropertyName("Value2", "Price to Calc %");
				
			}
		}

		private DateTime TimeToBarTimeMinute(Bars bars, DateTime time, bool isBar)
		{
			if (SessionIterator.IsNewSession(time, isBar))
				SessionIterator.GetNextSession(time, isBar);

			if (bars.IsResetOnNewTradingDay || (!bars.IsResetOnNewTradingDay && bars.Count == 0))
			{
				DateTime barTimeStamp = isBar
					? SessionIterator.ActualSessionBegin.AddMinutes(Math.Ceiling(Math.Ceiling(Math.Max(0, time.Subtract(SessionIterator.ActualSessionBegin).TotalMinutes)) / bars.BarsPeriod.BaseBarsPeriodValue) * bars.BarsPeriod.BaseBarsPeriodValue)
					: SessionIterator.ActualSessionBegin.AddMinutes(bars.BarsPeriod.BaseBarsPeriodValue + Math.Floor(Math.Floor(Math.Max(0, time.Subtract(SessionIterator.ActualSessionBegin).TotalMinutes)) / bars.BarsPeriod.BaseBarsPeriodValue) * bars.BarsPeriod.BaseBarsPeriodValue);
				if (bars.TradingHours.Sessions.Count > 0 && barTimeStamp > SessionIterator.ActualSessionEnd) // Cut last bar in session down to session end on odd session end time
					barTimeStamp = SessionIterator.ActualSessionEnd;
				return barTimeStamp;
			}
			else
			{
				DateTime lastBarTime	= bars.GetTime(bars.Count - 1);
				DateTime barTimeStamp	= isBar
					? lastBarTime.AddMinutes(Math.Ceiling(Math.Ceiling(Math.Max(0, time.Subtract(lastBarTime).TotalMinutes)) / bars.BarsPeriod.BaseBarsPeriodValue) * bars.BarsPeriod.BaseBarsPeriodValue)
					: lastBarTime.AddMinutes(bars.BarsPeriod.BaseBarsPeriodValue + Math.Floor(Math.Floor(Math.Max(0, time.Subtract(lastBarTime).TotalMinutes)) / bars.BarsPeriod.BaseBarsPeriodValue) * bars.BarsPeriod.BaseBarsPeriodValue);
				if (bars.TradingHours.Sessions.Count > 0 && barTimeStamp > SessionIterator.ActualSessionEnd)
				{
					DateTime saveActualSessionEnd = SessionIterator.ActualSessionEnd;
					SessionIterator.GetNextSession(SessionIterator.ActualSessionEnd.AddSeconds(1), isBar);
					barTimeStamp = SessionIterator.ActualSessionBegin.AddMinutes((int) barTimeStamp.Subtract(saveActualSessionEnd).TotalMinutes);
				}
				return barTimeStamp;
			}
		}

		private static DateTime TimeToBarTimeMonth(DateTime time, int periodValue)
		{
			DateTime result = new DateTime(time.Year, time.Month, 1);
			for (int i = 0; i < periodValue; i++)
				result = result.AddMonths(1);

			return result.AddDays(-1);
		}

		private DateTime TimeToBarTimeSecond(Bars bars, DateTime time, bool isBar)
		{
			if (SessionIterator.IsNewSession(time, isBar))
				SessionIterator.GetNextSession(time, isBar);

			if (bars.IsResetOnNewTradingDay || !bars.IsResetOnNewTradingDay && bars.Count == 0)
			{
				DateTime barTimeStamp = isBar
					? SessionIterator.ActualSessionBegin.AddSeconds(Math.Ceiling(Math.Ceiling(Math.Max(0, time.Subtract(SessionIterator.ActualSessionBegin).TotalSeconds)) / bars.BarsPeriod.BaseBarsPeriodValue) * bars.BarsPeriod.BaseBarsPeriodValue)
					: SessionIterator.ActualSessionBegin.AddSeconds(bars.BarsPeriod.BaseBarsPeriodValue + Math.Floor(Math.Floor(Math.Max(0, time.Subtract(SessionIterator.ActualSessionBegin).TotalSeconds)) / bars.BarsPeriod.BaseBarsPeriodValue) * bars.BarsPeriod.BaseBarsPeriodValue);
				if (bars.TradingHours.Sessions.Count > 0 && barTimeStamp > SessionIterator.ActualSessionEnd) // Cut last bar in session down to session end on odd session end time
					barTimeStamp = SessionIterator.ActualSessionEnd;
				return barTimeStamp;
			}
			else
			{
				DateTime lastBarTime	= bars.GetTime(bars.Count - 1);
				DateTime barTimeStamp	= isBar
					? lastBarTime.AddSeconds(Math.Ceiling(Math.Ceiling(Math.Max(0, time.Subtract(lastBarTime).TotalSeconds)) / bars.BarsPeriod.BaseBarsPeriodValue) * bars.BarsPeriod.BaseBarsPeriodValue)
					: lastBarTime.AddSeconds(bars.BarsPeriod.BaseBarsPeriodValue + Math.Floor(Math.Floor(Math.Max(0, time.Subtract(lastBarTime).TotalSeconds)) / bars.BarsPeriod.BaseBarsPeriodValue) * bars.BarsPeriod.BaseBarsPeriodValue);
				if (bars.TradingHours.Sessions.Count > 0 && barTimeStamp > SessionIterator.ActualSessionEnd)
				{
					DateTime saveActualSessionEnd = SessionIterator.ActualSessionEnd;
					SessionIterator.GetNextSession(SessionIterator.ActualSessionEnd.AddSeconds(1), isBar);
					barTimeStamp = SessionIterator.ActualSessionBegin.AddSeconds((int) barTimeStamp.Subtract(saveActualSessionEnd).TotalSeconds);
				}
				return barTimeStamp;
			}
		}

		private static DateTime TimeToBarTimeWeek(DateTime time, DateTime periodStart, int periodValue)
		{
			return periodStart.Date.AddDays(Math.Ceiling(Math.Ceiling(time.Date.Subtract(periodStart.Date).TotalDays) / (periodValue * 7)) * (periodValue * 7)).Date;
		}

		private static DateTime TimeToBarTimeYear(DateTime time, int periodValue)
		{
			DateTime result = new DateTime(time.Year, 1, 1);
			for (int i = 0; i < periodValue; i++)
				result = result.AddYears(1);

			return result.AddDays(-1);
		}
	
	}
}
