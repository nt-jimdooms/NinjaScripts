//
// Copyright (C) 2020, NinjaTrader LLC <www.ninjatrader.com>.
// NinjaTrader reserves the right to modify or overwrite this NinjaScript component with each release.
//
#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

// This namespace holds indicators in this folder and is required. Do not change it.
namespace NinjaTrader.NinjaScript.Indicators
{
	/// <summary>
	/// The SMAForceOnBarClose (Simple Moving Average) is an indicator that shows the average value of a security's price over a period of time.
	/// </summary>
	public class SMAForceOnBarClose : Indicator
	{
		private double priorSum;
		private double sum;

		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description					= NinjaTrader.Custom.Resource.NinjaScriptIndicatorDescriptionSMA;
				Name						= "SMAForceOnBarClose";
				IsOverlay					= true;
				IsSuspendedWhileInactive	= true;
				Period						= 14;

				AddPlot(Brushes.Goldenrod, NinjaTrader.Custom.Resource.NinjaScriptIndicatorNameSMA);
			}
			else if (State == State.Configure)
			{
				priorSum	= 0;
				sum			= 0;
			}
		}

		protected override void OnBarUpdate()
		{
			if (CurrentBar == 0)
				Value[0] = Input[0];
			
			if (CurrentBar < 1)
				return;
			
			if (IsFirstTickOfBar)
			{
				int idx = 1;
				priorSum = sum;

				sum = priorSum + Input[0+idx] - (CurrentBar >= Period+idx ? Input[Period+idx] : 0);
				Value[idx] = sum / (CurrentBar < Period ? CurrentBar+idx : Period);
				Value[0] = Value[idx];
			}
			else
				Value[0] = Value[1];
		}

		#region Properties
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Period", GroupName = "NinjaScriptParameters", Order = 0)]
		public int Period
		{ get; set; }
		#endregion
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private SMAForceOnBarClose[] cacheSMAForceOnBarClose;
		public SMAForceOnBarClose SMAForceOnBarClose(int period)
		{
			return SMAForceOnBarClose(Input, period);
		}

		public SMAForceOnBarClose SMAForceOnBarClose(ISeries<double> input, int period)
		{
			if (cacheSMAForceOnBarClose != null)
				for (int idx = 0; idx < cacheSMAForceOnBarClose.Length; idx++)
					if (cacheSMAForceOnBarClose[idx] != null && cacheSMAForceOnBarClose[idx].Period == period && cacheSMAForceOnBarClose[idx].EqualsInput(input))
						return cacheSMAForceOnBarClose[idx];
			return CacheIndicator<SMAForceOnBarClose>(new SMAForceOnBarClose(){ Period = period }, input, ref cacheSMAForceOnBarClose);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.SMAForceOnBarClose SMAForceOnBarClose(int period)
		{
			return indicator.SMAForceOnBarClose(Input, period);
		}

		public Indicators.SMAForceOnBarClose SMAForceOnBarClose(ISeries<double> input , int period)
		{
			return indicator.SMAForceOnBarClose(input, period);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.SMAForceOnBarClose SMAForceOnBarClose(int period)
		{
			return indicator.SMAForceOnBarClose(Input, period);
		}

		public Indicators.SMAForceOnBarClose SMAForceOnBarClose(ISeries<double> input , int period)
		{
			return indicator.SMAForceOnBarClose(input, period);
		}
	}
}

#endregion
