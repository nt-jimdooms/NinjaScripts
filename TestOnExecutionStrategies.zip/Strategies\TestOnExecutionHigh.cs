#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies
{
	public class TestOnExecutionHigh : Strategy
	{
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Strategy here.";
				Name										= "TestOnExecutionHigh";
				Calculate									= Calculate.OnBarClose;
				IsExitOnSessionCloseStrategy = false;
                Slippage = 0;
                TraceOrders = false;
                BarsRequiredToTrade = 0;
                EntriesPerDirection = 1;
                OrderFillResolution = OrderFillResolution.High;
			}
		}

		protected override void OnBarUpdate()
        {
            // Load "ES 09-12" Day bars from 5/1/2012 - 8/1/2012
            if (Time[0].Date == DateTime.Parse("2012-06-13").Date)
            {
				Print("OBU " + Time[0] + " placed entry");
			
                var order = EnterShort("Entry1");
            }
            if (Time[0].Date == DateTime.Parse("2012-06-15").Date)
            {
				
                if (Position.MarketPosition == MarketPosition.Flat)
                {
                    Print("OBU " + Time[0] + " placed second entry");
                    EnterLong();
                }
            }
            if (Time[0].Date == DateTime.Parse("2012-06-22").Date)
            {
				
                ExitLong();
            }
        }
        protected override void OnExecutionUpdate(Execution execution, string executionId, double price, int quantity, MarketPosition marketPosition, string orderId, DateTime time)
        {
			Print("OnExecution " + execution.Name + " "  + time);
            if (execution.Order.Name == "Entry1")
            {
				Print("Submit ExitShortStopMarket " + time);
                ExitShortStopMarket(0, true, 1, 1347, "ExitMarket", "");
            }
        }
	}
}
