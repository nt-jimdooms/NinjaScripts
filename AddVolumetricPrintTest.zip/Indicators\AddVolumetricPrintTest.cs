#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class AddVolumetricPrintTest : Indicator
	{
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Indicator here.";
				Name										= "AddVolumetricPrintTest";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
			}
			else if (State == State.Configure)
			{
				AddVolumetric(null, BarsPeriodType.Minute, 1, VolumetricDeltaType.BidAsk, 1);
			}
		}

		protected override void OnBarUpdate()
		{
			if (Bars == null)
          		return; 

			NinjaTrader.NinjaScript.BarsTypes.VolumetricBarsType barsType = BarsArray[1].BarsType as    
			NinjaTrader.NinjaScript.BarsTypes.VolumetricBarsType;

			if (barsType == null)
			  return;
			
			if (CurrentBars[1] < 1)
				return;


			try
			{
			  double price;
			  Print("=========================================================================");
			  Print("Bar: " + CurrentBars[1]);
			  Print("Trades: " + barsType.Volumes[CurrentBars[1]].Trades);
			  Print("Total Volume: " + barsType.Volumes[CurrentBars[1]].TotalVolume);
			  Print("Total Buying Volume: " + barsType.Volumes[CurrentBars[1]].TotalBuyingVolume);
			  Print("Total Selling Volume: " + barsType.Volumes[CurrentBars[1]].TotalSellingVolume);
			  Print("Delta for bar: " + barsType.Volumes[CurrentBars[1]].BarDelta);
			  Print("Delta for bar (%): " + barsType.Volumes[CurrentBars[1]].GetDeltaPercent());
			  Print("Delta for Close: " + barsType.Volumes[CurrentBars[1]].GetDeltaForPrice(Close[0]));
			  Print("Ask for Close: " + barsType.Volumes[CurrentBars[1]].GetAskVolumeForPrice(Close[0]));
			  Print("Bid for Close: " + barsType.Volumes[CurrentBars[1]].GetBidVolumeForPrice(Close[0]));
			  Print("Volume for Close: " + barsType.Volumes[CurrentBars[1]].GetTotalVolumeForPrice(Close[0]));
			  Print("Maximum Ask: " + barsType.Volumes[CurrentBars[1]].GetMaximumVolume(true, out price) + " at price: " + price);
			  Print("Maximum Bid: " + barsType.Volumes[CurrentBars[1]].GetMaximumVolume(false, out price) + " at price: " + price);
			  Print("Maximum Combined: " + barsType.Volumes[CurrentBars[1]].GetMaximumVolume(null, out price) + " at price: " + price);
			  Print("Maximum Positive Delta: " + barsType.Volumes[CurrentBars[1]].GetMaximumPositiveDelta());
			  Print("Maximum Negative Delta: " + barsType.Volumes[CurrentBars[1]].GetMaximumNegativeDelta());
			  Print("Max seen delta (bar): " + barsType.Volumes[CurrentBars[1]].MaxSeenDelta);
			  Print("Min seen delta (bar): " + barsType.Volumes[CurrentBars[1]].MinSeenDelta);
			  Print("Cumulative delta (bar): " + barsType.Volumes[CurrentBars[1]].CumulativeDelta);
			}
			catch{}
		}
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private AddVolumetricPrintTest[] cacheAddVolumetricPrintTest;
		public AddVolumetricPrintTest AddVolumetricPrintTest()
		{
			return AddVolumetricPrintTest(Input);
		}

		public AddVolumetricPrintTest AddVolumetricPrintTest(ISeries<double> input)
		{
			if (cacheAddVolumetricPrintTest != null)
				for (int idx = 0; idx < cacheAddVolumetricPrintTest.Length; idx++)
					if (cacheAddVolumetricPrintTest[idx] != null &&  cacheAddVolumetricPrintTest[idx].EqualsInput(input))
						return cacheAddVolumetricPrintTest[idx];
			return CacheIndicator<AddVolumetricPrintTest>(new AddVolumetricPrintTest(), input, ref cacheAddVolumetricPrintTest);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.AddVolumetricPrintTest AddVolumetricPrintTest()
		{
			return indicator.AddVolumetricPrintTest(Input);
		}

		public Indicators.AddVolumetricPrintTest AddVolumetricPrintTest(ISeries<double> input )
		{
			return indicator.AddVolumetricPrintTest(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.AddVolumetricPrintTest AddVolumetricPrintTest()
		{
			return indicator.AddVolumetricPrintTest(Input);
		}

		public Indicators.AddVolumetricPrintTest AddVolumetricPrintTest(ISeries<double> input )
		{
			return indicator.AddVolumetricPrintTest(input);
		}
	}
}

#endregion
