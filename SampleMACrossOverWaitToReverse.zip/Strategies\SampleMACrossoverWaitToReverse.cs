//
// Copyright (C) 2021, NinjaTrader LLC <www.ninjatrader.com>.
// NinjaTrader reserves the right to modify or overwrite this NinjaScript component with each release.
//
#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds strategies in this folder and is required. Do not change it.
namespace NinjaTrader.NinjaScript.Strategies
{
	public class SampleMACrossoverWaitToReverse : Strategy
	{
		private SMA smaFast;
		private SMA smaSlow;

		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description	= NinjaTrader.Custom.Resource.NinjaScriptStrategyDescriptionSampleMACrossOver;
				Name		= "SampleMACrossoverWaitToReverse";
				Fast		= 10;
				Slow		= 25;
				// This strategy has been designed to take advantage of performance gains in Strategy Analyzer optimizations
				// See the Help Guide for additional information
				IsInstantiatedOnEachOptimizationIteration = false;
			}
			else if (State == State.DataLoaded)
			{
				smaFast = SMA(Fast);
				smaSlow = SMA(Slow);

				smaFast.Plots[0].Brush = Brushes.Goldenrod;
				smaSlow.Plots[0].Brush = Brushes.SeaGreen;

				AddChartIndicator(smaFast);
				AddChartIndicator(smaSlow);
			}
		}

		protected override void OnBarUpdate()
		{
			if (CurrentBar < BarsRequiredToTrade)
				return;

			if (Position.MarketPosition == MarketPosition.Flat)
			{
				if (CrossAbove(smaFast, smaSlow, 1))
				{
					EnterLong("LongEntry");
				}
				else if (CrossBelow(smaFast, smaSlow, 1))
				{
					EnterShort("ShortEntry");
				}
			}
			else if (Position.MarketPosition == MarketPosition.Long)
			{
				if (CrossBelow(smaFast, smaSlow, 1))
				{
					ExitLong("Close Before Reversal", "LongEntry");			
				}
			}
			else if (Position.MarketPosition == MarketPosition.Short)
			{
				if (CrossAbove(smaFast, smaSlow, 1))
				{
					ExitShort("Close Before Reversal", "ShortEntry");
				}
			}
		}
		
		protected override void OnExecutionUpdate(Execution execution, string executionId, double price, int quantity, MarketPosition marketPosition, string orderId, DateTime time)
		{
			// This code handles the reversal. Instead of using a bool, we look for the specific signal name and check the direction of the execution to determine if it was a long or short trade.
			if (execution.Name == "Close Before Reversal")
			{
				if (execution.MarketPosition == MarketPosition.Long)
				{
					EnterLong("LongEntry");
				}
				else if (execution.MarketPosition == MarketPosition.Short)
				{
					EnterShort("ShortEntry");
				}
			}
		}

		#region Properties
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Fast", GroupName = "NinjaScriptStrategyParameters", Order = 0)]
		public int Fast
		{ get; set; }

		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Slow", GroupName = "NinjaScriptStrategyParameters", Order = 1)]
		public int Slow
		{ get; set; }
		#endregion
	}
}
