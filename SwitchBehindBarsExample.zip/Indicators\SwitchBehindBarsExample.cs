#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
using System.Reflection;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class SwitchBehindBarsExample : Indicator
	{
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Indicator here.";
				Name										= "SwitchBehindBarsExample";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= true;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				DrawBehindBars								= true;
				AddPlot(new Stroke(Brushes.Orange, 5), PlotStyle.Line, "Plot");
			}
			else if (State == State.Historical)
			{
				if (DrawBehindBars)
					SetZOrder(-1);
				else
					SetZOrder(10001);
			}
		}

		protected override void OnBarUpdate()
		{
			Value[0] = Close[0];
		}
		
//		public override void CopyTo(NinjaScript ninjaScript)
//		{
//			base.CopyTo(ninjaScript);

//			Type		newInstType	= ninjaScript.GetType();
//			FieldInfo 	field 		= newInstType.GetField("myZOrder", BindingFlags.NonPublic | BindingFlags.Instance);

//			if (field == null)
//				return;
			
//			//Core.Globals.AssemblyRegistry.GetType(typeof(IntWrapper).FullName;
//			//object newInstance = oldPercentWrapper.AssemblyClone(Core.Globals.AssemblyRegistry.GetType(typeof(IntWrapper).FullName));
//			try {
//			((SwitchBehindBarsExample)ninjaScript).myZOrder = (int) field.GetValue(this);
//			}
//			catch { }
//		}

		#region Properties
		[NinjaScriptProperty]
		[Display(Name="DrawBehindBars", Order=1, GroupName="Parameters")]
		public bool DrawBehindBars
		{ get; set; }
		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private SwitchBehindBarsExample[] cacheSwitchBehindBarsExample;
		public SwitchBehindBarsExample SwitchBehindBarsExample(bool drawBehindBars)
		{
			return SwitchBehindBarsExample(Input, drawBehindBars);
		}

		public SwitchBehindBarsExample SwitchBehindBarsExample(ISeries<double> input, bool drawBehindBars)
		{
			if (cacheSwitchBehindBarsExample != null)
				for (int idx = 0; idx < cacheSwitchBehindBarsExample.Length; idx++)
					if (cacheSwitchBehindBarsExample[idx] != null && cacheSwitchBehindBarsExample[idx].DrawBehindBars == drawBehindBars && cacheSwitchBehindBarsExample[idx].EqualsInput(input))
						return cacheSwitchBehindBarsExample[idx];
			return CacheIndicator<SwitchBehindBarsExample>(new SwitchBehindBarsExample(){ DrawBehindBars = drawBehindBars }, input, ref cacheSwitchBehindBarsExample);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.SwitchBehindBarsExample SwitchBehindBarsExample(bool drawBehindBars)
		{
			return indicator.SwitchBehindBarsExample(Input, drawBehindBars);
		}

		public Indicators.SwitchBehindBarsExample SwitchBehindBarsExample(ISeries<double> input , bool drawBehindBars)
		{
			return indicator.SwitchBehindBarsExample(input, drawBehindBars);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.SwitchBehindBarsExample SwitchBehindBarsExample(bool drawBehindBars)
		{
			return indicator.SwitchBehindBarsExample(Input, drawBehindBars);
		}

		public Indicators.SwitchBehindBarsExample SwitchBehindBarsExample(ISeries<double> input , bool drawBehindBars)
		{
			return indicator.SwitchBehindBarsExample(input, drawBehindBars);
		}
	}
}

#endregion
