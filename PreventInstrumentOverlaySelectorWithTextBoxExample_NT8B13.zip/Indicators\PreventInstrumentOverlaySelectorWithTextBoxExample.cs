using System.Windows.Controls;
using NinjaTrader.Gui.NinjaScript;
using NinjaTrader.NinjaScript.Indicators;

#region Using declarations

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;

#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 

namespace NinjaTrader.NinjaScript.Indicators
{
	public class PreventInstrumentOverlaySelectorWithTextBoxExample : Indicator
	{
		private TextBox textBox;

		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Name = "PreventInstrumentOverlaySelectorWithTextBoxExample";
				Description = "Adds a custom textbox to the chart";
				IsOverlay = false;
			}
			else if (State == State.Configure)
			{
			}

				// Once the NinjaScript object has reached State.Historical, our custom control can now be added to the chart
			else if (State == State.Historical)
			{
				// Because we're dealing with UI elements, we need to use the Dispatcher which created the object
				// in order for us to update the contents that are created on the main UI thread
				Dispatcher.InvokeAsync((() =>
				{
					textBox = new TextBox();

					textBox.PreviewKeyDown += TextBox_PreviewKeyDown;
				
					UserControlCollection.Add(textBox);
				}));
			}

			else if (State == State.Terminated)
			{
				if (textBox != null)
				{
					textBox.PreviewKeyDown -= TextBox_PreviewKeyDown;
				}
				if (textBox != null && UserControlCollection.Contains(textBox))
					UserControlCollection.Remove(textBox);
			}
		}

		private void TextBox_PreviewKeyDown(object sender, KeyEventArgs e)
		{
			// this is pretty dumb, but should get you started
			// might want to validate this by using SHIFT or something
			// so Overlay Instrument Selector isn't unusable...
			TextBox textBoxSender = (TextBox) sender;
			textBoxSender.Text += e.Key.ToString();
			// handle the keydown event for the text box
			e.Handled = true;
		}


		protected override void OnBarUpdate()
		{
			//Add your custom indicator logic here.
		}
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private PreventInstrumentOverlaySelectorWithTextBoxExample[] cachePreventInstrumentOverlaySelectorWithTextBoxExample;
		public PreventInstrumentOverlaySelectorWithTextBoxExample PreventInstrumentOverlaySelectorWithTextBoxExample()
		{
			return PreventInstrumentOverlaySelectorWithTextBoxExample(Input);
		}

		public PreventInstrumentOverlaySelectorWithTextBoxExample PreventInstrumentOverlaySelectorWithTextBoxExample(ISeries<double> input)
		{
			if (cachePreventInstrumentOverlaySelectorWithTextBoxExample != null)
				for (int idx = 0; idx < cachePreventInstrumentOverlaySelectorWithTextBoxExample.Length; idx++)
					if (cachePreventInstrumentOverlaySelectorWithTextBoxExample[idx] != null &&  cachePreventInstrumentOverlaySelectorWithTextBoxExample[idx].EqualsInput(input))
						return cachePreventInstrumentOverlaySelectorWithTextBoxExample[idx];
			return CacheIndicator<PreventInstrumentOverlaySelectorWithTextBoxExample>(new PreventInstrumentOverlaySelectorWithTextBoxExample(), input, ref cachePreventInstrumentOverlaySelectorWithTextBoxExample);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.PreventInstrumentOverlaySelectorWithTextBoxExample PreventInstrumentOverlaySelectorWithTextBoxExample()
		{
			return indicator.PreventInstrumentOverlaySelectorWithTextBoxExample(Input);
		}

		public Indicators.PreventInstrumentOverlaySelectorWithTextBoxExample PreventInstrumentOverlaySelectorWithTextBoxExample(ISeries<double> input )
		{
			return indicator.PreventInstrumentOverlaySelectorWithTextBoxExample(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.PreventInstrumentOverlaySelectorWithTextBoxExample PreventInstrumentOverlaySelectorWithTextBoxExample()
		{
			return indicator.PreventInstrumentOverlaySelectorWithTextBoxExample(Input);
		}

		public Indicators.PreventInstrumentOverlaySelectorWithTextBoxExample PreventInstrumentOverlaySelectorWithTextBoxExample(ISeries<double> input )
		{
			return indicator.PreventInstrumentOverlaySelectorWithTextBoxExample(input);
		}
	}
}

#endregion
