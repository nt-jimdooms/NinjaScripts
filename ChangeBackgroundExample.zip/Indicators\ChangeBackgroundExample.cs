#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class ChangeBackgroundExample : Indicator
	{
		private Brush myBrush;
		private bool brushSet;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Indicator here.";
				Name										= "ChangeBackgroundExample";
				Calculate									= Calculate.OnBarClose;
			}
			else if (State == State.DataLoaded)
			{
				brushSet = false;
			}
			else if (State == State.Historical)
			{
				myBrush = ChartControl.Properties.ChartBackground;
				ChartControl.Properties.ChartBackground = Brushes.Black;
				brushSet = true;
			}
			else if (State == State.Terminated)
			{
				if (ChartControl != null && brushSet)
				{
					ChartControl.Properties.ChartBackground = myBrush;
					brushSet = false;
				}
			}
		}
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ChangeBackgroundExample[] cacheChangeBackgroundExample;
		public ChangeBackgroundExample ChangeBackgroundExample()
		{
			return ChangeBackgroundExample(Input);
		}

		public ChangeBackgroundExample ChangeBackgroundExample(ISeries<double> input)
		{
			if (cacheChangeBackgroundExample != null)
				for (int idx = 0; idx < cacheChangeBackgroundExample.Length; idx++)
					if (cacheChangeBackgroundExample[idx] != null &&  cacheChangeBackgroundExample[idx].EqualsInput(input))
						return cacheChangeBackgroundExample[idx];
			return CacheIndicator<ChangeBackgroundExample>(new ChangeBackgroundExample(), input, ref cacheChangeBackgroundExample);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ChangeBackgroundExample ChangeBackgroundExample()
		{
			return indicator.ChangeBackgroundExample(Input);
		}

		public Indicators.ChangeBackgroundExample ChangeBackgroundExample(ISeries<double> input )
		{
			return indicator.ChangeBackgroundExample(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ChangeBackgroundExample ChangeBackgroundExample()
		{
			return indicator.ChangeBackgroundExample(Input);
		}

		public Indicators.ChangeBackgroundExample ChangeBackgroundExample(ISeries<double> input )
		{
			return indicator.ChangeBackgroundExample(input);
		}
	}
}

#endregion
