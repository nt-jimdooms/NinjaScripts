// 
// Copyright (C) 2015, NinjaTrader LLC <www.ninjatrader.com>.
// NinjaTrader reserves the right to modify or overwrite this NinjaScript component with each release.
//
#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

// This namespace holds all strategies and is required. Do not change it.
namespace NinjaTrader.NinjaScript.Strategies
{
	public class QATestExecutionTime : Strategy
	{
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description								= @"Sample Using OnOrderUpdate() and OnExecution() methods to submit protective orders";
				Name                                    = "QATestExecutionTime";
				Calculate                               = Calculate.OnBarClose;
				EntriesPerDirection                     = 1;
				EntryHandling                           = EntryHandling.AllEntries;
				IsExitOnSessionCloseStrategy            = true;
				ExitOnSessionCloseSeconds               = 30;
				IsFillLimitOnTouch                      = false;
				MaximumBarsLookBack                     = MaximumBarsLookBack.TwoHundredFiftySix;
				OrderFillResolution                     = OrderFillResolution.Standard;
				Slippage                                = 0;
				StartBehavior                           = StartBehavior.WaitUntilFlat;
				TimeInForce                             = TimeInForce.Gtc;
				TraceOrders                             = false;
				RealtimeErrorHandling                   = RealtimeErrorHandling.StopCancelClose;
				StopTargetHandling                      = StopTargetHandling.PerEntryExecution;
				BarsRequiredToTrade                     = 20;
			}
		}

		protected override void OnBarUpdate()
		{
			// Submit an entry market order if we currently don't have an entry order open and are past the BarsRequiredToTrade bars amount
			if (CurrentBar > BarsRequiredToTrade && Position.MarketPosition == MarketPosition.Flat)
			{
				/* Enter Long. We will assign the resulting Order object to entryOrder in OnOrderUpdate() */
				EnterLong(1, "MyEntry");
			}
		}

		protected override void OnExecutionUpdate(Execution execution, string executionId, double price, int quantity, MarketPosition marketPosition, string orderId, DateTime time)
		{
			/* We advise monitoring OnExecution to trigger submission of stop/target orders instead of OnOrderUpdate() since OnExecution() is called after OnOrderUpdate()
			which ensures your strategy has received the execution which is used for internal signal tracking. */
			if (execution.Order.Name == "MyEntry")
			{
				if (execution.Order.OrderState == OrderState.Filled || execution.Order.OrderState == OrderState.PartFilled || (execution.Order.OrderState == OrderState.Cancelled && execution.Order.Filled > 0))
				{
					//if ( ToDay(execution.Time) >= 20191010)
					if ( ToDay(execution.Time) >= ToDay(DateTime.Now))
						Print(CurrentBar + " " + execution.Time + " " + (execution.Order.AverageFillPrice - 20 * TickSize));
					// Stop-Loss order 4 ticks below our entry price
					ExitLongStopMarket(0, true, execution.Order.Filled, execution.Order.AverageFillPrice - 20 * TickSize, "MyStop", "MyEntry");

					// Target order 8 ticks above our entry price
					ExitLongLimit(0, true, execution.Order.Filled, execution.Order.AverageFillPrice + 20 * TickSize, "MyTarget", "MyEntry");
				}
			}
		}

		#region Properties
		#endregion
	}
}