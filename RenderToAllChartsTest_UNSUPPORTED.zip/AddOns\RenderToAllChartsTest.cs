#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.Gui.Tools;
using System.Reflection;
#endregion

//This namespace holds Add ons in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.AddOns
{
	public class RenderToAllChartsTest : NinjaTrader.NinjaScript.AddOnBase
	{
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Add on here.";
				Name										= "RenderToAllCharts";
			}
			else if (State == State.Configure)
			{
			}
		}
		
		protected override void OnWindowCreated(Window window)
		{
			if (window is Chart)
			{
				Chart chart = window as Chart;
				chart.Activated += (s, e) => {
					foreach (System.Windows.Controls.TabItem tab in chart.MainTabControl.Items)
					{
						(tab.Content as ChartTab).ChartControl.ChartPanels[0].Scales[ScaleJustification.Right].ChartObjects.Add(new MyObject());
					}
				};
			}
		}
		
		protected override void OnWindowDestroyed(Window window)
		{
			if (window is Chart)
			{
				Chart chart = window as Chart;
				foreach (NinjaTrader.Gui.NinjaScript.IChartObject obj in chart.ActiveChartControl.ChartPanels[0].Scales[ScaleJustification.Right].ChartObjects.ToList())
				{
					NinjaTrader.NinjaScript.AddOns.MyObject myObject = obj as NinjaTrader.NinjaScript.AddOns.MyObject;
					if (myObject != null)
						chart.ActiveChartControl.ChartPanels[0].Scales[ScaleJustification.Right].ChartObjects.Remove(myObject);
				}
			}
		}
	}
	
	public class MyObject : ChartObject
	{
		private bool doOnce = true;
		private SharpDX.Direct2D1.Brush myBrush;
		
		public override void OnRender(ChartControl cc, ChartScale cs)
		{
			if (doOnce)
			{
				Print("Chart Loaded");
				doOnce = false;
			}
			
			if (myBrush == null)
				myBrush = Brushes.Red.ToDxBrush(RenderTarget);
			
			RenderTarget.DrawLine(new SharpDX.Vector2(ChartPanel.X, ChartPanel.Y), new SharpDX.Vector2(ChartPanel.X + ChartPanel.W, ChartPanel.Y + ChartPanel.H), myBrush);
		}
		
		public override void OnRenderTargetChanged()
		{
			if (myBrush != null)
				myBrush.Dispose();
			
			if (RenderTarget != null)
				myBrush = Brushes.Red.ToDxBrush(RenderTarget);		
		}
	}
}
