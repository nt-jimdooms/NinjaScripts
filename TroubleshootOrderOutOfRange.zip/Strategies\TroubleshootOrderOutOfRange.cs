#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it.
namespace NinjaTrader.NinjaScript.Strategies
{
	public class TroubleshootOrderOutOfRange : Strategy
	{
		private double ShortEntryPrice, ShortStopLossPrice;
		private Order  SE, SX;

		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Name = "TroubleshootOrderOutOfRange";
				Calculate = Calculate.OnBarClose;
				OrderFillResolution = OrderFillResolution.Standard;
				TraceOrders = true;
				IsUnmanaged = true;
			}
		}

        protected override void OnExecutionUpdate(Cbi.Execution execution, string executionId, double price, int quantity, 
			Cbi.MarketPosition marketPosition, string orderId, DateTime time)
		{			
			Print(execution.ToString());
			
Print("");
Print(String.Format("This bar: Time: {0} Open: {1} High: {2} Low: {3} Close: {4}", Bars.GetTime(CurrentBar), Bars.GetOpen(CurrentBar), Bars.GetHigh(CurrentBar), Bars.GetLow(CurrentBar), Bars.GetClose(CurrentBar)));
Print(String.Format("Next bar: Time: {0} Open: {1} High: {2} Low: {3} Close: {4}", Bars.GetTime(CurrentBar+1), Bars.GetOpen(CurrentBar+1), Bars.GetHigh(CurrentBar+1), Bars.GetLow(CurrentBar+1), Bars.GetClose(CurrentBar+1)));
Print("");
			
			if (SE != null && execution.Order == SE && execution.Order.OrderState == OrderState.Filled)
            {		
Print(" !!! Order in question submitted to: " + ShortStopLossPrice);			
Print("");
			 SX = SubmitOrderUnmanaged(0, OrderAction.Buy, OrderType.StopMarket, quantity, 0.0, ShortStopLossPrice, "", "ORDER IN QUESTION");
		    }
		}

		protected override void OnBarUpdate()
		{		
			DateTime _Date = new DateTime(2020, 4, 23, 00, 00, 00);
			
			DateTime _CurrentDate = Time[0].Date;
			
			if (_CurrentDate == _Date && High[0] == 2801.50 && Low[0] == 2793.50)
			{
				ShortEntryPrice    = Low[0]  - 2*TickSize;
				ShortStopLossPrice = High[0] + 2*TickSize;
				SE = SubmitOrderUnmanaged(0, OrderAction.Sell, OrderType.StopLimit, 1, ShortEntryPrice, ShortEntryPrice, string.Empty, "Short Entry");
			}
		}
	}
}
