#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class SetStateTest : Indicator
	{
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Indicator here.";
				Name										= "SetStateTest";
				Calculate									= Calculate.OnPriceChange;
				IsOverlay									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
			}
			else if (State == State.Realtime)
			{
				SetState(State.Terminated);
			}
			Print("SetStateScript State Update: " + State.ToString());
		}

		protected override void OnBarUpdate()
		{
			Print(String.Format("State: {0} CurrentBar: {1}", State, CurrentBar));
		}
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private SetStateTest[] cacheSetStateTest;
		public SetStateTest SetStateTest()
		{
			return SetStateTest(Input);
		}

		public SetStateTest SetStateTest(ISeries<double> input)
		{
			if (cacheSetStateTest != null)
				for (int idx = 0; idx < cacheSetStateTest.Length; idx++)
					if (cacheSetStateTest[idx] != null &&  cacheSetStateTest[idx].EqualsInput(input))
						return cacheSetStateTest[idx];
			return CacheIndicator<SetStateTest>(new SetStateTest(), input, ref cacheSetStateTest);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.SetStateTest SetStateTest()
		{
			return indicator.SetStateTest(Input);
		}

		public Indicators.SetStateTest SetStateTest(ISeries<double> input )
		{
			return indicator.SetStateTest(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.SetStateTest SetStateTest()
		{
			return indicator.SetStateTest(Input);
		}

		public Indicators.SetStateTest SetStateTest(ISeries<double> input )
		{
			return indicator.SetStateTest(input);
		}
	}
}

#endregion
