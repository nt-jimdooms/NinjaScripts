#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class BarsRequestTestIndi : Indicator
	{
		private NinjaTrader.Data.BarsRequest barsRequest;
		private DateTime SecondaryStart, SecondaryEnd;
		private Bars bars;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Indicator here.";
				Name										= "BarsRequestTestIndi";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
			}
			else if (State == State.DataLoaded)
			{
				DoBarsRequest(Instrument);
			}
			else if (State == State.Terminated)
			{
				// Dispose BarsRequest
				if(barsRequest != null)
				{
					barsRequest.Update     -= BROnBarUpdate;
					barsRequest.Dispose();
				}
			}
		}

		protected override void OnBarUpdate()
		{
			//Add your custom indicator logic here.
		}
		
		private NinjaTrader.Data.BarsRequest DoBarsRequest(Instrument instrument)
		{
			barsRequest 				= new NinjaTrader.Data.BarsRequest(instrument, Bars.FromDate, DateTime.Now);
			barsRequest.BarsPeriod 		= new NinjaTrader.Data.BarsPeriod { BarsPeriodType = BarsPeriod.BarsPeriodType, Value = BarsPeriod.Value };
			barsRequest.TradingHours    = NinjaTrader.Data.TradingHours.Get("Default 24 x 7");
			barsRequest.Update     		+= BROnBarUpdate;
			barsRequest.Request(new Action<NinjaTrader.Data.BarsRequest, ErrorCode, string>((b, errorCode, errorMessage) =>
			{
				NinjaTrader.Core.Globals.RandomDispatcher.InvokeAsync(new Action(() =>
				{
					if (errorCode != ErrorCode.NoError)
				    {
				      // Handle any errors in requesting bars here
				      NinjaTrader.Code.Output.Process(string.Format("Error on requesting bars: {0}, {1}",
				                                      errorCode, errorMessage), PrintTo.OutputTab1);
				      return;
				    }
					bars = b.Bars;
				 
				    // Output the bars we requested. Note: The last returned bar may be a currently in-progress bar
//				    for (int i = 0; i < b.Bars.Count; i++)
//				    {
//				      // Output the bars
//				      NinjaTrader.Code.Output.Process(string.Format("Historical Time: {0} Open: {1} High: {2} Low: {3} Close: {4} Volume: {5}",
//				                                      b.Bars.GetTime(i),
//				                                      b.Bars.GetOpen(i),
//				                                      b.Bars.GetHigh(i),
//				                                      b.Bars.GetLow(i),
//				                                      b.Bars.GetClose(i),
//				                                      b.Bars.GetVolume(i)), PrintTo.OutputTab1);
//				    }
				}));
			}));
			return barsRequest;
		}
		
		private void BROnBarUpdate(object sender, NinjaTrader.Data.BarsUpdateEventArgs e)
		{	
			/* Depending on the BarsPeriod type of your barsRequest you can have situations where more than one bar is
   			   updated by a single tick. Be sure to process the full range of updated bars to ensure you did not miss a bar. */
			
			ClearOutputWindow();
			
			NinjaTrader.Code.Output.Process(string.Format("BarsCount: {0}", e.BarsSeries.Count), PrintTo.OutputTab1);
			// Output bar information on each tick
//			for (int i = e.MinIndex; i <= e.MaxIndex; i++)
//			{
//				// Processing every single tick
//				NinjaTrader.Code.Output.Process(string.Format("Realtime Time: {0} Open: {1} High: {2} Low: {3} Close: {4}",
//			                                e.BarsSeries.GetTime(i),
//			                                e.BarsSeries.GetOpen(i),
//			                                e.BarsSeries.GetHigh(i),
//			                                e.BarsSeries.GetLow(i),
//			                                e.BarsSeries.GetClose(i)), PrintTo.OutputTab1);
//			}
		}
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private BarsRequestTestIndi[] cacheBarsRequestTestIndi;
		public BarsRequestTestIndi BarsRequestTestIndi()
		{
			return BarsRequestTestIndi(Input);
		}

		public BarsRequestTestIndi BarsRequestTestIndi(ISeries<double> input)
		{
			if (cacheBarsRequestTestIndi != null)
				for (int idx = 0; idx < cacheBarsRequestTestIndi.Length; idx++)
					if (cacheBarsRequestTestIndi[idx] != null &&  cacheBarsRequestTestIndi[idx].EqualsInput(input))
						return cacheBarsRequestTestIndi[idx];
			return CacheIndicator<BarsRequestTestIndi>(new BarsRequestTestIndi(), input, ref cacheBarsRequestTestIndi);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.BarsRequestTestIndi BarsRequestTestIndi()
		{
			return indicator.BarsRequestTestIndi(Input);
		}

		public Indicators.BarsRequestTestIndi BarsRequestTestIndi(ISeries<double> input )
		{
			return indicator.BarsRequestTestIndi(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.BarsRequestTestIndi BarsRequestTestIndi()
		{
			return indicator.BarsRequestTestIndi(Input);
		}

		public Indicators.BarsRequestTestIndi BarsRequestTestIndi(ISeries<double> input )
		{
			return indicator.BarsRequestTestIndi(input);
		}
	}
}

#endregion
