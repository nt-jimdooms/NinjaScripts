#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies
{
	public class MultiStopTargetExitMethods : Strategy
	{
		private int L1Quantity, L2Quantity, L3Quantity, S1Quantity, S2Quantity, S3Quantity;
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Strategy here.";
				Name										= "MultiStopTargetExitMethods";
				Calculate									= Calculate.OnBarClose;
				EntriesPerDirection							= 3;
				EntryHandling								= EntryHandling.AllEntries;
				IsExitOnSessionCloseStrategy				= true;
				ExitOnSessionCloseSeconds					= 30;
				IsFillLimitOnTouch							= false;
				MaximumBarsLookBack							= MaximumBarsLookBack.TwoHundredFiftySix;
				OrderFillResolution							= OrderFillResolution.Standard;
				Slippage									= 0;
				StartBehavior								= StartBehavior.WaitUntilFlat;
				TimeInForce									= TimeInForce.Gtc;
				TraceOrders									= false;
				RealtimeErrorHandling						= RealtimeErrorHandling.StopCancelClose;
				StopTargetHandling							= StopTargetHandling.PerEntryExecution;
				BarsRequiredToTrade							= 20;
				// Disable this property for performance gains in Strategy Analyzer optimizations
				// See the Help Guide for additional information
				IsInstantiatedOnEachOptimizationIteration	= true;
			}
			else if (State == State.DataLoaded)
			{
				L1Quantity = L2Quantity = L3Quantity = 5;
				S1Quantity = S2Quantity = S3Quantity = 5;
			}
		}

		protected override void OnBarUpdate()
		{
			if(State == State.Historical)
				return;
			
			if (Position.MarketPosition == MarketPosition.Flat)
			{				
				if(Close[0] > Open[0])
				{
					EnterShort(S1Quantity, "ShortEntry1");
					EnterShort(S2Quantity, "ShortEntry2");
					EnterShort(S3Quantity, "ShortEntry3");
				}
				if(Open[0] > Close[0])
				{
					EnterLong(L1Quantity, "LongEntry1");
					EnterLong(L2Quantity, "LongEntry2");
					EnterLong(L3Quantity, "LongEntry3");
				}
			}
			
			if (Position.MarketPosition == MarketPosition.Long)
			{
				if(Close[0] >= Position.AveragePrice + 10 * TickSize)
				{
					ExitLongStopMarket(0, true, L1Quantity, Position.AveragePrice, "L1Exit", "LongEntry1");
					ExitLongStopMarket(0, true, L2Quantity, Position.AveragePrice, "L2Exit", "LongEntry2");
					ExitLongStopMarket(0, true, L3Quantity, Position.AveragePrice, "L3Exit", "LongEntry3");
				}
				else
				{
					ExitLongStopMarket(0, true, L1Quantity, Position.AveragePrice - 5 * TickSize, "L1Exit", "LongEntry1");
					ExitLongStopMarket(0, true, L2Quantity, Position.AveragePrice - 5 * TickSize, "L2Exit", "LongEntry2");
					ExitLongStopMarket(0, true, L3Quantity, Position.AveragePrice - 5 * TickSize, "L3Exit", "LongEntry3");
				}
			}
			
			if (Position.MarketPosition == MarketPosition.Short)
			{
				if (Close[0] <= Position.AveragePrice - 10 * TickSize)
				{
					ExitShortStopMarket(0, true, S1Quantity, Position.AveragePrice, "S1Exit", "ShortEntry1");
					ExitShortStopMarket(0, true, S2Quantity, Position.AveragePrice, "S2Exit", "ShortEntry2");
					ExitShortStopMarket(0, true, S3Quantity, Position.AveragePrice, "S3Exit", "ShortEntry3");
				}
				else
				{
					ExitShortStopMarket(0, true, S1Quantity, Position.AveragePrice + 5 * TickSize, "S1Exit", "ShortEntry1");
					ExitShortStopMarket(0, true, S2Quantity, Position.AveragePrice + 5 * TickSize, "S2Exit", "ShortEntry2");
					ExitShortStopMarket(0, true, S3Quantity, Position.AveragePrice + 5 * TickSize, "S3Exit", "ShortEntry3");
				}
			}
		}
	}
}
