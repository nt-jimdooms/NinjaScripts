#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class DisplayInDataBoxOnly : Indicator
	{
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Indicator here.";
				Name										= "DisplayInDataBoxOnly";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= true;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				ShowTransparentPlotsInDataBox 				= true;
				PlotName = "Enter Plot Name Here";
			}
			else if (State == State.Configure)
			{
				AddPlot(Brushes.Transparent, PlotName);
			}
		}

		protected override void OnBarUpdate()
		{
			Value[0] = Input[0];
		}
		
		#region Properties
		[NinjaScriptProperty]
		[Display(Name="PlotName", Order=1, GroupName="Parameters")]
		public string PlotName
		{ get; set; }
		#endregion
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private DisplayInDataBoxOnly[] cacheDisplayInDataBoxOnly;
		public DisplayInDataBoxOnly DisplayInDataBoxOnly(string plotName)
		{
			return DisplayInDataBoxOnly(Input, plotName);
		}

		public DisplayInDataBoxOnly DisplayInDataBoxOnly(ISeries<double> input, string plotName)
		{
			if (cacheDisplayInDataBoxOnly != null)
				for (int idx = 0; idx < cacheDisplayInDataBoxOnly.Length; idx++)
					if (cacheDisplayInDataBoxOnly[idx] != null && cacheDisplayInDataBoxOnly[idx].PlotName == plotName && cacheDisplayInDataBoxOnly[idx].EqualsInput(input))
						return cacheDisplayInDataBoxOnly[idx];
			return CacheIndicator<DisplayInDataBoxOnly>(new DisplayInDataBoxOnly(){ PlotName = plotName }, input, ref cacheDisplayInDataBoxOnly);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.DisplayInDataBoxOnly DisplayInDataBoxOnly(string plotName)
		{
			return indicator.DisplayInDataBoxOnly(Input, plotName);
		}

		public Indicators.DisplayInDataBoxOnly DisplayInDataBoxOnly(ISeries<double> input , string plotName)
		{
			return indicator.DisplayInDataBoxOnly(input, plotName);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.DisplayInDataBoxOnly DisplayInDataBoxOnly(string plotName)
		{
			return indicator.DisplayInDataBoxOnly(Input, plotName);
		}

		public Indicators.DisplayInDataBoxOnly DisplayInDataBoxOnly(ISeries<double> input , string plotName)
		{
			return indicator.DisplayInDataBoxOnly(input, plotName);
		}
	}
}

#endregion
