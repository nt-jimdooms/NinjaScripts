//
// Copyright (C) 2021, NinjaTrader LLC <www.ninjatrader.com>
// NinjaTrader reserves the right to modify or overwrite this NinjaScript component
// Coded by NinjaTrader_ChelseaB
//
#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Linq;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

// The NinjaTrader.NinjaScript.Indicators namespace holds all indicators and is required. Do not change it.
namespace NinjaTrader.NinjaScript.Indicators.DataManagementExamples
{
	public class DynamicBarsRequestExample : Indicator
	{
		#region Variables
		private InstrumentSelector						instrumentSelector;
		private System.Windows.Controls.Grid			myGrid;
		private System.Windows.Controls.Button			startRequest, stopRequest;
		private BarsRequest								secondaryBarsRequest;
		private Instrument								secondaryInstrument;
		#endregion

		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description							= @"Enter the description for your new custom Indicator here.";
				Name								= "DynamicBarsRequestExample";
				Calculate							= Calculate.OnEachTick;
				IsOverlay							= true;
			}
			else if (State == State.Historical)
			{
				ClearOutputWindow();

				if (ChartControl != null)
				{
					ChartControl.Dispatcher.InvokeAsync((Action)(() =>
					{
						InsertWPFControls();
					}));
				}
			}
			else if (State == State.Terminated)
			{
				if (ChartControl != null)
				{
					ChartControl.Dispatcher.InvokeAsync((Action)(() =>
					{
						RemoveWPFControls();
					}));
				}

				if (secondaryBarsRequest != null)
				{
					secondaryBarsRequest.Dispose();
					secondaryBarsRequest	= null;
				}
			}
		}

		protected void InsertWPFControls()
		{
			myGrid = new System.Windows.Controls.Grid
			{
				Name = "MyCustomGrid",
				HorizontalAlignment = HorizontalAlignment.Right,
				VerticalAlignment = VerticalAlignment.Top
			};

			myGrid.RowDefinitions.Add(new RowDefinition() { Height = new GridLength(15) });
			myGrid.RowDefinitions.Add(new RowDefinition());
			myGrid.RowDefinitions.Add(new RowDefinition());
			myGrid.RowDefinitions.Add(new RowDefinition());

			myGrid.ColumnDefinitions.Add(new ColumnDefinition());
			myGrid.ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(10) });

			instrumentSelector = new InstrumentSelector()
			{
				Margin = new Thickness(2.5)
			};
			Grid.SetRow(instrumentSelector, 1);
			myGrid.Children.Add(instrumentSelector);

			startRequest = new Button
			{
				Name		= "startRequestButton",
				Content		= "Start BarsRequest",
				Foreground	= Brushes.White,
				Background	= Brushes.Green,
				Margin		= new Thickness(2.5)
			};

			startRequest.Click += StartRequest_Click;
			Grid.SetRow(startRequest, 2);
			myGrid.Children.Add(startRequest);

			stopRequest = new Button
			{
				Name		= "stopRequestButton",
				Content		= "Stop BarsRequest",
				Foreground	= Brushes.White,
				Background	= Brushes.Green,
				Margin		= new Thickness(2.5)
			};

			stopRequest.Click += StopRequest_Click;
			Grid.SetRow(stopRequest, 3);
			myGrid.Children.Add(stopRequest);

			UserControlCollection.Add(myGrid);
		}

		protected override void OnBarUpdate()
		{
			if (State != State.Realtime)
				return;
			
			if (PrintPrimaryInfo)
			{
				if (PrintHistorical && State == State.Historical)
					Print(string.Format("{0} | primary historical | {1} | {2}", Time[0], Instrument.FullName, Close[0]));
				else if (State == State.Realtime)
					Print(string.Format("{0} | primary realtime | {1} | {2}", Time[0], Instrument.FullName, Close[0]));
			}
		}

		protected void OnSecondaryBarUpdate(object sender, BarsUpdateEventArgs e)
		{
			Bars secondaryBars = sender as Bars;
			Print(string.Format("{0} | barsRequest realtime | {1} | {2}", secondaryBars.GetTime(secondaryBars.Count - 1),
				secondaryBars.Instrument.FullName, secondaryBars.GetClose(secondaryBars.Count - 1)));
		}

		private void StartRequest_Click(object sender, RoutedEventArgs args)
		{
			RequestSeries();
		}

		private void StopRequest_Click(object sender, RoutedEventArgs args)
		{
			if (secondaryBarsRequest != null)
			{
				secondaryBarsRequest.Dispose();
				secondaryBarsRequest		= null;
			}
		}

		protected void RemoveWPFControls()
		{
			startRequest.Click	-= StartRequest_Click;
			stopRequest.Click	-= StopRequest_Click;
		}

		public void RequestSeries()
		{
			if (secondaryBarsRequest != null)
			{
				secondaryBarsRequest.Dispose();
				secondaryBarsRequest	= null;
			}

			secondaryInstrument = instrumentSelector.Instrument;

			if (secondaryInstrument == null)
			{
				Print("Invalid instrument");
				return;
			}

			Print("Loading secondary instrument: " + secondaryInstrument.FullName);

			TradingHours tradingHours	= secondaryInstrument.MasterInstrument.TradingHours;
			BarsPeriod barsPeriod		= new BarsPeriod() { BarsPeriodType = BarsPeriodType.Minute, Value = 1 };

			secondaryBarsRequest = new BarsRequest(secondaryInstrument, 2)
			{
				MergePolicy		= MergePolicy.MergeBackAdjusted,
				BarsPeriod		= barsPeriod,
				TradingHours	= tradingHours
			};

			secondaryBarsRequest.Update += OnSecondaryBarUpdate;

			secondaryBarsRequest.Request(new Action<BarsRequest, ErrorCode, string>((bars, errorCode, errorMessage) =>
			{
				if (errorCode != ErrorCode.NoError)
				{
					// Handle any errors in requesting bars here
					NinjaTrader.Code.Output.Process(string.Format("Error on requesting bars: {0}, {1}",
													errorCode, errorMessage), PrintTo.OutputTab1);
					return;
				}

				// Output the bars we requested. Note: The last returned bar may be a currently in-progress bar
				//for (int i = bars.Bars.Count - 1; i >= 0; i--)
				if (PrintHistorical)
				{
					for (int i = 0; i < bars.Bars.Count; i++)
					{
						// Output the bars
						Print(string.Format("{0} | barsRequest historical | {1} | Open: {2}, High: {3}, Low: {4}, Close: {5}, Volume: {6}",
								bars.Bars.GetTime(i),
								bars.Bars.Instrument.FullName,
								bars.Bars.GetOpen(i),
								bars.Bars.GetHigh(i),
								bars.Bars.GetLow(i),
								bars.Bars.GetClose(i),
								bars.Bars.GetVolume(i)
							));
					}
				}

				// If requesting real-time bars, but there are currently no connections
				lock (Connection.Connections)
					if (Connection.Connections.FirstOrDefault() == null)
						NinjaTrader.Code.Output.Process("No connection for real-time data", PrintTo.OutputTab1);
			}));			
		}

		#region Properties
		[NinjaScriptProperty]
		[Display(Name = "Print primary info", Description = "Print bar info for primary bars", Order = 0, GroupName = "NinjaScriptParameters")]
		public bool PrintPrimaryInfo
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Print historical", Description = "Print historical data", Order = 1, GroupName = "NinjaScriptParameters")]
		public bool PrintHistorical
		{ get; set; }
		#endregion
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private DataManagementExamples.DynamicBarsRequestExample[] cacheDynamicBarsRequestExample;
		public DataManagementExamples.DynamicBarsRequestExample DynamicBarsRequestExample(bool printPrimaryInfo, bool printHistorical)
		{
			return DynamicBarsRequestExample(Input, printPrimaryInfo, printHistorical);
		}

		public DataManagementExamples.DynamicBarsRequestExample DynamicBarsRequestExample(ISeries<double> input, bool printPrimaryInfo, bool printHistorical)
		{
			if (cacheDynamicBarsRequestExample != null)
				for (int idx = 0; idx < cacheDynamicBarsRequestExample.Length; idx++)
					if (cacheDynamicBarsRequestExample[idx] != null && cacheDynamicBarsRequestExample[idx].PrintPrimaryInfo == printPrimaryInfo && cacheDynamicBarsRequestExample[idx].PrintHistorical == printHistorical && cacheDynamicBarsRequestExample[idx].EqualsInput(input))
						return cacheDynamicBarsRequestExample[idx];
			return CacheIndicator<DataManagementExamples.DynamicBarsRequestExample>(new DataManagementExamples.DynamicBarsRequestExample(){ PrintPrimaryInfo = printPrimaryInfo, PrintHistorical = printHistorical }, input, ref cacheDynamicBarsRequestExample);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.DataManagementExamples.DynamicBarsRequestExample DynamicBarsRequestExample(bool printPrimaryInfo, bool printHistorical)
		{
			return indicator.DynamicBarsRequestExample(Input, printPrimaryInfo, printHistorical);
		}

		public Indicators.DataManagementExamples.DynamicBarsRequestExample DynamicBarsRequestExample(ISeries<double> input , bool printPrimaryInfo, bool printHistorical)
		{
			return indicator.DynamicBarsRequestExample(input, printPrimaryInfo, printHistorical);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.DataManagementExamples.DynamicBarsRequestExample DynamicBarsRequestExample(bool printPrimaryInfo, bool printHistorical)
		{
			return indicator.DynamicBarsRequestExample(Input, printPrimaryInfo, printHistorical);
		}

		public Indicators.DataManagementExamples.DynamicBarsRequestExample DynamicBarsRequestExample(ISeries<double> input , bool printPrimaryInfo, bool printHistorical)
		{
			return indicator.DynamicBarsRequestExample(input, printPrimaryInfo, printHistorical);
		}
	}
}

#endregion
