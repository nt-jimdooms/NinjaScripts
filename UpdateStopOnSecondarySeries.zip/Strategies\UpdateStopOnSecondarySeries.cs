#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies
{
	public class UpdateStopOnSecondarySeries : Strategy
	{
		private int StopLossMode;


		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Strategy here.";
				Name										= "UpdateStopOnSecondarySeries";
				Calculate									= Calculate.OnBarClose;
				EntriesPerDirection							= 1;
				EntryHandling								= EntryHandling.AllEntries;
				IsExitOnSessionCloseStrategy				= true;
				ExitOnSessionCloseSeconds					= 30;
				IsFillLimitOnTouch							= false;
				MaximumBarsLookBack							= MaximumBarsLookBack.TwoHundredFiftySix;
				OrderFillResolution							= OrderFillResolution.Standard;
				Slippage									= 0;
				StartBehavior								= StartBehavior.WaitUntilFlat;
				TimeInForce									= TimeInForce.Gtc;
				TraceOrders									= false;
				RealtimeErrorHandling						= RealtimeErrorHandling.StopCancelClose;
				StopTargetHandling							= StopTargetHandling.PerEntryExecution;
				BarsRequiredToTrade							= 20;
				// Disable this property for performance gains in Strategy Analyzer optimizations
				// See the Help Guide for additional information
				IsInstantiatedOnEachOptimizationIteration	= true;
				StopLossMode					= 0;
			}
			else if (State == State.Configure)
			{
				AddDataSeries(BarsPeriodType.Second, 5);
			}
		}

		protected override void OnBarUpdate()
		{
			if (BarsInProgress == 0)
			{
				if (CurrentBars[0] < 1)
					return;

				if ((Positions[0].MarketPosition == MarketPosition.Flat)
					 && (Close[0] > Open[0]))
				{
					EnterLong(0, Convert.ToInt32(DefaultQuantity), "");
					StopLossMode = 0;
				}
			}
			
			if (BarsInProgress == 1)
			{
				if ((Positions[0].MarketPosition == MarketPosition.Long)
					 && (StopLossMode == 0))
				{
					ExitLongStopMarket(0, true, Convert.ToInt32(DefaultQuantity), (Positions[0].AveragePrice + (-10 * TickSize)) , "", "");
				}
				
				if ((Positions[0].MarketPosition == MarketPosition.Long)
					 && (StopLossMode == 1))
				{
					ExitLongStopMarket(0, true, Convert.ToInt32(DefaultQuantity), Positions[0].AveragePrice, "", "");
				}
				
				if ((Positions[0].MarketPosition == MarketPosition.Long)
					 && (StopLossMode == 2))
				{
					ExitLongStopMarket(0, true, Convert.ToInt32(DefaultQuantity), (Positions[0].AveragePrice + (10 * TickSize)) , "", "");
				}
				
				if ((Positions[0].MarketPosition == MarketPosition.Long)
					 && (Close[0] >= (Positions[0].AveragePrice + (10 * TickSize)) )
					 && (StopLossMode == 0))
				{
					StopLossMode = 1;
				}
				
				
				if ((Positions[0].MarketPosition == MarketPosition.Long)
					 && (Close[0] >= (Positions[0].AveragePrice + (20 * TickSize)) )
					 && (StopLossMode == 1))
				{
					StopLossMode = 2;
				}
			}
			
		}
	}
}
