#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class DelayedEventExample : Indicator
	{
		private System.Timers.Timer myTimer;
		private bool DoOnce;
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Indicator here.";
				Name										= "DelayedEventExample";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
			}
			else if (State == State.DataLoaded)
			{
				DoOnce = true;
			}
			else if (State == State.Terminated)
			{
		  		// Stops the timer and removes the timer event handler
				if (myTimer != null)
				{
			  		myTimer.Enabled = false;
			  		myTimer.Elapsed -= TimerEventProcessor;
					myTimer = null;
				}
			}
		}

		protected override void OnBarUpdate()
		{
			if (Close[0] > Open[0] && DoOnce && State == State.Realtime)
			{
				DoOnce = false;
				
				// Instantiates the timer and sets the interval to 1 seconds.
				myTimer = new System.Timers.Timer(1000);
		  		myTimer.Elapsed += TimerEventProcessor;
				myTimer.Enabled = true;
			}
		}
		
		private void TimerEventProcessor(Object myObject, EventArgs myEventArgs)
		{
			/* Important to use the TriggerCustomEvent() to ensure that NinjaScript indexes and pointers are correctly set.
			Do not process your code here. Process your code in the MyCustomHandler method. */
			TriggerCustomEvent(MyCustomHandler, 0, myTimer.Interval);
		}
		
		private void MyCustomHandler(object state)
		{
			Print("Hello");
			
			DoOnce = true;
			myTimer.Enabled = false;
			
			// Stops the timer and removes the timer event handler
			if (myTimer != null)
			{
		  		myTimer.Enabled = false;
		  		myTimer.Elapsed -= TimerEventProcessor;
				myTimer = null;
			}
		}
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private DelayedEventExample[] cacheDelayedEventExample;
		public DelayedEventExample DelayedEventExample()
		{
			return DelayedEventExample(Input);
		}

		public DelayedEventExample DelayedEventExample(ISeries<double> input)
		{
			if (cacheDelayedEventExample != null)
				for (int idx = 0; idx < cacheDelayedEventExample.Length; idx++)
					if (cacheDelayedEventExample[idx] != null &&  cacheDelayedEventExample[idx].EqualsInput(input))
						return cacheDelayedEventExample[idx];
			return CacheIndicator<DelayedEventExample>(new DelayedEventExample(), input, ref cacheDelayedEventExample);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.DelayedEventExample DelayedEventExample()
		{
			return indicator.DelayedEventExample(Input);
		}

		public Indicators.DelayedEventExample DelayedEventExample(ISeries<double> input )
		{
			return indicator.DelayedEventExample(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.DelayedEventExample DelayedEventExample()
		{
			return indicator.DelayedEventExample(Input);
		}

		public Indicators.DelayedEventExample DelayedEventExample(ISeries<double> input )
		{
			return indicator.DelayedEventExample(input);
		}
	}
}

#endregion
