#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class CaptureInstrumentBarsPeriodOnClick : Indicator
	{
		private SharpDX.Direct2D1.Brush			DXBrush1;
		private SharpDX.Direct2D1.Brush			DXBrush2;
		
		private string barsPeriod = "blank";
		private string instrument = "blank";
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description							= @"";
				Name								= "CaptureInstrumentBarsPeriodOnClick";
				Calculate							= Calculate.OnBarClose;
				IsOverlay							= true;
				DisplayInDataBox					= false;
				DrawOnPricePanel					= true;
				ScaleJustification					= NinjaTrader.Gui.Chart.ScaleJustification.Right;
			}
			else if (State == State.Historical)
			{
				if (RenderTarget != null)
				{
					DXBrush1 = Brushes.Red.ToDxBrush(RenderTarget);
					DXBrush2 = Brushes.Black.ToDxBrush(RenderTarget);
				}
				
				if (ChartControl != null)
					ChartPanel.MouseLeftButtonDown += MouseClicked;
			}
			else if (State == State.Terminated)
			{
				if (ChartControl != null)
					ChartPanel.MouseLeftButtonDown -= MouseClicked;
			}
		}

		protected override void OnBarUpdate() {	}
				
		protected void MouseClicked(object sender, MouseButtonEventArgs e)
		{
			instrument = BarsArray[0].Instrument.FullName;
			barsPeriod = BarsArray[0].BarsPeriod.ToString();
			
			// trigger the chart invalidate so that the render loop starts even if there is no data being received
			ChartControl.InvalidateVisual();
			e.Handled = true;
		}

		protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
		{
			if (IsInHitTest)
				return;
			
			if (instrument != BarsArray[0].Instrument.FullName || barsPeriod != BarsArray[0].BarsPeriod.ToString())
				return;
			
			DrawString(RenderTarget, ChartPanel, instrument, ChartControl.Properties.LabelFont, DXBrush1, ChartPanel.W/2, ChartPanel.H/2, DXBrush2);
			DrawString(RenderTarget, ChartPanel, barsPeriod, ChartControl.Properties.LabelFont, DXBrush1, ChartPanel.W/2, ChartPanel.H/2 - ChartControl.Properties.LabelFont.TextFormatHeight, DXBrush2);
		}

		public override void OnRenderTargetChanged()
		{
			// renew the brush any time the render target changes to save cpu and memory resources
			if (DXBrush1 != null)
				DXBrush1.Dispose();
			if (DXBrush2 != null)
				DXBrush2.Dispose();

			if (RenderTarget != null)
			{
				DXBrush1 = Brushes.Red.ToDxBrush(RenderTarget);
				DXBrush2 = Brushes.Black.ToDxBrush(RenderTarget);
			}
		}
		
		/// <summary>
		/// Draws text with a background using SharpDX Brushes.
		/// </summary>
		/// <param name="renderTarget">The hosting NinjaScript's RenderTarget</param>
		/// <param name="chartPanel">The hosting NinjaScript's ChartPanel</param> 
		/// <param name="text">Text to display</param>
		/// <param name="font">SimpleFont to use for the drawn text</param>
		/// <param name="brush">SharpDX brush used for the text color</param>
		/// <param name="pointX">X coordinate</param>
		/// <param name="pointY">Y coordinate</param>
		/// <param name="areaBrush">SharpDX brush used for the text background color</param>
		/// <returns></returns>
		public void DrawString(SharpDX.Direct2D1.RenderTarget renderTarget, ChartPanel chartPanel, string text, NinjaTrader.Gui.Tools.SimpleFont font, SharpDX.Direct2D1.Brush brush, double pointX, double pointY, SharpDX.Direct2D1.Brush areaBrush)
		{
			SharpDX.DirectWrite.TextFormat textFormat = font.ToDirectWriteTextFormat();
			SharpDX.DirectWrite.TextLayout textLayout =
			new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory,
				text, textFormat, chartPanel.X + chartPanel.W,
				textFormat.FontSize);

			SharpDX.Vector2 TextPlotPoint = new System.Windows.Point(pointX, pointY-textLayout.Metrics.Height/2).ToVector2();
			
			float newW = textLayout.Metrics.Width; 
            float newH = textLayout.Metrics.Height;
            SharpDX.RectangleF PLBoundRect = new SharpDX.RectangleF((float)pointX, (float)pointY-textLayout.Metrics.Height/2, newW, newH);
            renderTarget.FillRectangle(PLBoundRect, areaBrush);
			
			renderTarget.DrawTextLayout(TextPlotPoint, textLayout, brush, SharpDX.Direct2D1.DrawTextOptions.NoSnap);
			textLayout.Dispose();
			textFormat.Dispose();
		}
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private CaptureInstrumentBarsPeriodOnClick[] cacheCaptureInstrumentBarsPeriodOnClick;
		public CaptureInstrumentBarsPeriodOnClick CaptureInstrumentBarsPeriodOnClick()
		{
			return CaptureInstrumentBarsPeriodOnClick(Input);
		}

		public CaptureInstrumentBarsPeriodOnClick CaptureInstrumentBarsPeriodOnClick(ISeries<double> input)
		{
			if (cacheCaptureInstrumentBarsPeriodOnClick != null)
				for (int idx = 0; idx < cacheCaptureInstrumentBarsPeriodOnClick.Length; idx++)
					if (cacheCaptureInstrumentBarsPeriodOnClick[idx] != null &&  cacheCaptureInstrumentBarsPeriodOnClick[idx].EqualsInput(input))
						return cacheCaptureInstrumentBarsPeriodOnClick[idx];
			return CacheIndicator<CaptureInstrumentBarsPeriodOnClick>(new CaptureInstrumentBarsPeriodOnClick(), input, ref cacheCaptureInstrumentBarsPeriodOnClick);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.CaptureInstrumentBarsPeriodOnClick CaptureInstrumentBarsPeriodOnClick()
		{
			return indicator.CaptureInstrumentBarsPeriodOnClick(Input);
		}

		public Indicators.CaptureInstrumentBarsPeriodOnClick CaptureInstrumentBarsPeriodOnClick(ISeries<double> input )
		{
			return indicator.CaptureInstrumentBarsPeriodOnClick(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.CaptureInstrumentBarsPeriodOnClick CaptureInstrumentBarsPeriodOnClick()
		{
			return indicator.CaptureInstrumentBarsPeriodOnClick(Input);
		}

		public Indicators.CaptureInstrumentBarsPeriodOnClick CaptureInstrumentBarsPeriodOnClick(ISeries<double> input )
		{
			return indicator.CaptureInstrumentBarsPeriodOnClick(input);
		}
	}
}

#endregion
