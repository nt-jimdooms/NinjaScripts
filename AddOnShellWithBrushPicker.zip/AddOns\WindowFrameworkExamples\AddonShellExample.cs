//
// Copyright (C) 2020, NinjaTrader LLC <www.ninjatrader.com>
// NinjaTrader reserves the right to modify or overwrite this NinjaScript component
// Coded by NinjaTrader_ChelseaB
//
#region Using Statements
using System;
using System.Linq;
using System.Windows;
using NinjaTrader.Core;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Tools;
using System.IO;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Xml.Linq;

// these using statements are for the attributes in the custom property class
using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;

// this using statement is added to quickly access the XamDateTimeEditor
using Infragistics.Windows.Editors;
#endregion

/* 
	// when exporting, add the following references to the export:
	* *ProgramFiles*\NinjaTrader 8\bin64\InfragisticsWPF4.Editors.v15.1.dll
	* *ProgramFiles*\NinjaTrader 8\bin64\InfragisticsWPF4.v15.1.dll

	// when exporting, add the following files to the exported .zip in the AddOns\WindowFramework folder:
	* *MyDocuments*\NinjaTrader 8\bin\Custom\AddOns\WindowFramework\AddonShellPageContent.xaml
*/
namespace NinjaTrader.NinjaScript.AddOns
{	
	/*
		* This is the Primary script in the set of scripts in this example, This script will be the first called script in NinjaTrader.
		* Unlike other NinjaScript documents, Debugging in an addon can be done unsing the folling statement
		* Output.Process("SomeString", PrintTo.OutputTab1);
    */
	public class AddonShellExample : AddOnBase
    {
		//These variables will be used in checking if the current Addon already has a menu item, and also stores the new menu item to be added.
		private NTMenuItem		ccNewMenu, newWindowMenuItem, subMenu;

        private void OnMenuItemClick(object sender, RoutedEventArgs e)
        {
            Globals.RandomDispatcher.InvokeAsync(new Action(() => new AddonShellExampleWindow().Show()));
        }

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description		= "";
                Name			= "AddonShellExample";
            }
        }

		protected override void OnWindowCreated(Window window)
        {
			/*
				* The following checks if the window created was the Control Center
				* If the window is the control center, the Control Center -> New menu is found by AutomationId with .FindFirst()
				* If the New menu is found, a menu item to open our addon is added
			*/
			ControlCenter controlCenter = window as ControlCenter;

            if (controlCenter == null)
                return;

            ccNewMenu	= controlCenter.FindFirst("ControlCenterMenuItemNew") as NTMenuItem;

            if (ccNewMenu == null)
                return;
			
			#region OptionalSubmenu
			// Optionally, we can create a sub-menu in the Control Center New menu with the automationId WindowFrameWorkExamplesMenuItem
			if (controlCenter.FindFirst("WindowFrameworkExamplesMenuItem") as NTMenuItem == null)
			{
				subMenu = new NTMenuItem { Header = "Window Framework Examples", Style = Application.Current.TryFindResource("MainMenuItem") as Style };

				// set an automationId on our submenu to identify it
				System.Windows.Automation.AutomationProperties.SetAutomationId(subMenu, "WindowFrameworkExamplesMenuItem");

				// Add the submenu to the Control Center -> New menu
				ccNewMenu.Items.Add(subMenu);
			}

			// Or add to an existing submenu if one exists with this automationid, to add multiple addons to the same submenu
			else
			{
				subMenu = controlCenter.FindFirst("WindowFrameworkExamplesMenuItem") as NTMenuItem;
			}
			#endregion

			// This is this menu item that actually opens the addon shell window. The Header is the menu item text
			newWindowMenuItem		= new NTMenuItem {
				Header	= "Addon Shell Example",
				Style	= Application.Current.TryFindResource("MainMenuItem") as Style
			};
			// A click handler is added to open our addon window when the menu item is clicked
			newWindowMenuItem.Click	+= OnMenuItemClick;

			// Add the menu item that opens the window to the sub menu instead of directly to the New menu
			subMenu.Items.Add(newWindowMenuItem);

			// If not using a submenu within the Control Center -> New menu, add the new menuitem directly to the Control Center New menu instead of the subMenu
			//ccNewMenu.Items.Add(addonShellWindowMenuItem);
        }

        protected override void OnWindowDestroyed(Window window)
        {
			// This checks if there is not a menu item or if the destroyed window is not the control center.
			if (newWindowMenuItem == null || !(window is ControlCenter) ||
					ccNewMenu == null ||
					!ccNewMenu.Items.Contains(subMenu))
				return;

			// remove the click handler
			newWindowMenuItem.Click	-= OnMenuItemClick;

			// remove the addon window menu item
			subMenu.Items.Remove(newWindowMenuItem);
			newWindowMenuItem = null;

			// if the submenu is empty, remove it as well
			if (subMenu.Items.Count < 1)
			{
				ccNewMenu.Items.Remove(subMenu);
				subMenu	= null;
			}
        }
	}	

	public class AddonShellExampleWindow : NTWindow, IWorkspacePersistence
	{
		private	TabControl						tabControl;
		public	AddonShellExampleWindowTabPage	SelectedTab;

		public bool								WindowBoolProperty;
		public double							WindowDoubleProperty;
		public int								WindowIntProperty;
		public string							WindowStringProperty;

		/*
			* This is the constructor for the new NTWindow.
			* This document sets up the basic window before it gets displayed.
			* This also defines what TabPage will be used and the Window Factory that will be used in the window creation process.
			* This document is also where you would set Tab defaults like if this window will have a tab control, if the tabs are movable etc..
			* The IWorkspacePersistence implementation is optional for saving / restoring from workspace
		*/
		public AddonShellExampleWindow()
		{
			Caption		= "Addon Shell Example";
			Width		= 400;
			Height		= 350;

			// set property window defaults
			WindowBoolProperty			= false;
			WindowDoubleProperty		= -.0002;
			WindowIntProperty			= -2;
			WindowStringProperty		= "Default window string";

			AddonShell_Tools.CustomClass propertyGridClass = new AddonShell_Tools.CustomClass();

			// This creates a tabControl which adds tabs to the window, which is optional
			tabControl = new TabControl();
			TabControlManager.SetIsMovable(tabControl, true);
			TabControlManager.SetCanAddTabs(tabControl, true);
			TabControlManager.SetCanRemoveTabs(tabControl, true);
			TabControlManager.SetFactory(tabControl, new AddonShellWindowFactory());

			System.ComponentModel.ICollectionView	myView = System.Windows.Data.CollectionViewSource.GetDefaultView(tabControl.Items);
			myView.CollectionChanged += TabCollectionChanged;

			Content = tabControl;
			tabControl.AddNTTabPage(new AddonShellExampleWindowTabPage());

			#region Optional context menu

			// This is a path geometry that looks like a check symbol
			System.Windows.Media.Geometry checkIcon = System.Windows.Media.Geometry.Parse(
				"M 12.4227,0.00012207C 12.4867,0.126587 12.5333,0.274536 " +
				"12.6787,0.321411C 9.49199,3.24792 6.704,6.57336 " +
				"4.69865,10.6827C 4.04399,11.08 3.47066,11.5573 2.83199, " +
				"11.9706C 2.09467,10.2198 1.692,8.13196 3.8147e-006, " +
				"7.33606C 0.500004,6.79871 1.31733,6.05994 1.93067,6.2428C " +
				"2.85999,6.51868 3.14,7.9054 3.60399,8.81604C 5.80133, " +
				"5.5387 8.53734,2.19202 12.4227,0.00012207 Z");

			// Try setting the Topmost with an AlwaysOnTop buttonThe alwaysOnTopButton will be used to enable / disable the Window.Topmost property
			MenuItem alwaysOnTopButton = new MenuItem { Header = "Always On Top" };

			alwaysOnTopButton.Click += (o, e) =>
			{
				alwaysOnTopButton.Icon	= (Topmost) ? null : checkIcon;
				Topmost					= !Topmost;
			};
			
			MenuItem contextPropertiesButton = new MenuItem { Header = "Properties" };

			contextPropertiesButton.Click += (o, e) =>
			{			
				//Code.Output.Process("Properties context MenuItem clicked", PrintTo.OutputTab1);

				// TODO: why does this have to be in the click handler? I can't instantiate outside of the click handler?
				Properties propertiesWindow = new Properties()
				{
					Caption				= "AddonShell Properties",
					PropertyGrid		= { SelectedObject = propertyGridClass },
					Owner				= this,
					Topmost				= true,
					ApplyHandler		= OnApplyAction,
					
				};

				// setup the propertyGridClass to have the values from the window and from the selected tab
				propertyGridClass.WindowBoolProperty	= WindowBoolProperty;
				propertyGridClass.WindowDoubleProperty	= WindowDoubleProperty;
				propertyGridClass.WindowIntProperty		= WindowIntProperty;
				propertyGridClass.WindowStringProperty	= WindowStringProperty;

				// get the currently selected tab for the properties
				SelectedTab = (tabControl.Items.GetItemAt(tabControl.SelectedIndex) as TabItem).Content as AddonShellExampleWindowTabPage;

				if (SelectedTab != null)
				{
					propertyGridClass.TabBoolProperty	= SelectedTab.TabBoolProperty;
					propertyGridClass.TabDoubleProperty	= SelectedTab.TabDoubleProperty;
					propertyGridClass.TabIntProperty	= SelectedTab.TabIntProperty;
					propertyGridClass.TabStringProperty	= SelectedTab.TabStringProperty;
				}

				propertiesWindow.ShowDialog();
				propertiesWindow.Activate();
			};

			ContextMenu = new ContextMenu() { Items = { alwaysOnTopButton, new Separator(), contextPropertiesButton } };
			#endregion

			// This is a inline Window Loaded handler, once the window loads, if the WorkspaceOptions are not present,
			// a new WorkspaceOptions object is created for this window using its GUID.
			Loaded += (o, e) =>
			{
				if (WorkspaceOptions == null)
				{
					WorkspaceOptions = new WorkspaceOptions("AddonShellExampleWindow" + Guid.NewGuid().ToString("N"), this);
				}
			};
		}

		// this is the apply / ok from the properties window saving the values back to the window class and tab
		private void OnApplyAction(object propertiesClass, bool saved)
		{
			AddonShell_Tools.CustomClass properties = (propertiesClass as AddonShell_Tools.CustomClass);

			WindowBoolProperty			= properties.WindowBoolProperty;
			WindowDoubleProperty		= properties.WindowDoubleProperty;
			WindowIntProperty			= properties.WindowIntProperty;
			WindowStringProperty		= properties.WindowStringProperty;

			if (SelectedTab != null)
			{
				SelectedTab.TabBoolProperty		= properties.TabBoolProperty;
				SelectedTab.TabDoubleProperty	= properties.TabDoubleProperty;
				SelectedTab.TabIntProperty		= properties.TabIntProperty;
				SelectedTab.TabStringProperty	= properties.TabStringProperty;
			}
		}

		// triggered anytime the tabCollection size changes
		public void TabCollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
		{
			if (e.NewItems != null)
			{
				//NinjaTrader.Code.Output.Process(string.Format("New tab added - {0}", tabControl.Items.Count), PrintTo.OutputTab1);

				TabItem newTab = tabControl.Items[tabControl.Items.Count - 1] as TabItem;

				if (newTab.Content == null)
				{
					//NinjaTrader.Code.Output.Process("New tab content is null", PrintTo.OutputTab1);
					return;
				}

				NTTabPage newTabPage = newTab.Content as NTTabPage;
				//NinjaTrader.Code.Output.Process(newTabPage.TabName, PrintTo.OutputTab1);
			}

			else if (e.OldItems != null)
			{
				//NinjaTrader.Code.Output.Process(string.Format("Tab removed", tabControl.Items.Count), PrintTo.OutputTab1);
				System.Windows.Controls.TabItem oldTab = e.OldItems[0] as System.Windows.Controls.TabItem;
				// TODO: the oldTab index is incorrect. It's always showing 1 even if the index was higher.
				//NinjaTrader.Code.Output.Process(string.Format("oldTab: index: {0} | Header: Tab {1} | {2}", e.OldItems.IndexOf(oldTab) + 1, oldTab.Header, oldTab.ToString()), PrintTo.OutputTab1);
				return;
			}
		}

		public void Restore(XDocument document, XElement element)
		{
			if (MainTabControl != null)
				MainTabControl.RestoreFromXElement(element);

			XElement rootNote = element.Element("AddonShellWindowSavedItemsRootNode");
			if (rootNote != null)
			{
				XElement windowBoolPropertyElement = rootNote.Element("WindowBoolProperty");
				if (windowBoolPropertyElement != null)
					WindowBoolProperty = Boolean.Parse(windowBoolPropertyElement.Value.ToString());

				XElement windowDoublePropertyElement = rootNote.Element("WindowDoubleProperty");
				if (windowDoublePropertyElement != null)
					WindowDoubleProperty = Double.Parse(windowDoublePropertyElement.Value.ToString());

				XElement windowIntPropertyElement = rootNote.Element("WindowIntProperty");
				if (windowIntPropertyElement != null)
					WindowIntProperty = Int32.Parse(windowIntPropertyElement.Value.ToString());

				XElement windowStringPropertyElement = rootNote.Element("WindowStringProperty");
				if (windowStringPropertyElement != null)
					WindowStringProperty = windowStringPropertyElement.Value.ToString();
			}
		}

		public void Save(XDocument document, XElement element)
		{
			// This is used for saving the tabcontrol itself, and open tabs with the workspace.
			if (MainTabControl != null)
				MainTabControl.SaveToXElement(element);

			if (element.Element("AddonShellWindowSavedItemsRootNode") != null)
				element.Element("AddonShellWindowSavedItemsRootNode").Remove();

			XElement rootElement = new XElement("AddonShellWindowSavedItemsRootNode");

			rootElement.Add(new XElement("WindowBoolProperty", WindowBoolProperty));
			rootElement.Add(new XElement("WindowDoubleProperty", WindowDoubleProperty));
			rootElement.Add(new XElement("WindowIntProperty", WindowIntProperty));
			rootElement.Add(new XElement("WindowStringProperty", WindowStringProperty));

			element.Add(rootElement);
		}

		public WorkspaceOptions WorkspaceOptions { get; set; }
	}

	public class AddonShellWindowFactory : INTTabFactory
	{
		// This class is simply to return the correct new objects when CreateParentWindow() and CreateTabPage() are called.
		public NTWindow CreateParentWindow()
		{
			return new AddonShellExampleWindow();
		}

		public NTTabPage CreateTabPage(string typeName, bool isNewWindow = false)
		{
			return new AddonShellExampleWindowTabPage();
		}
	}

	public class AddonShellExampleWindowTabPage : NTTabPage
	{
		private Button				exampleButton;
		private CheckBox			exampleCheckBox;
		private QuantityUpDown		exampleQuantityUpDown;
		private RadioButton			exampleOption1RadioButton, exampleOption2RadioButton;
		private TextBlock			exampleTextBlock;
		private TextBox				exampleTextBox;
		private XamDateTimeEditor	exampleDateEditor;
		private System.Windows.Controls.WpfPropertyGrid.Controls.BrushPicker exampleBrushPicker;

		public bool					TabBoolProperty;
		public double				TabDoubleProperty;
		public int					TabIntProperty;
		public string				TabStringProperty;

		/*
			* This is the constructor for the new NTTabPage.
		*/
		public AddonShellExampleWindowTabPage()
		{
			// the content of the page will go here.
			Content		= LoadXaml();
			Loaded		+= TabLoaded;
			Unloaded	+= TabUnloaded;

			// TODO: the addon framework names this with "@Function" do I need to do this as well?
			//TabName		= "Addon Shell";

			// set defaults
			TabBoolProperty		= false;
			TabDoubleProperty	= -.0001;
			TabIntProperty		= -1;
			TabStringProperty	= "Default tab string";
			
		}

		// triggered when the tab is clicked
		public void TabLoaded(object sender, System.Windows.RoutedEventArgs e)
		{
			//NinjaTrader.Code.Output.Process(string.Format("{0} {1} - loaded", GetHeaderPart(string.Empty), this.TabName.Substring(10)), PrintTo.OutputTab1);
		}

		// triggered when a tab is clicked away from
		public void TabUnloaded(object sender, System.Windows.RoutedEventArgs e)
		{
			//NinjaTrader.Code.Output.Process(string.Format("{0} {1} - unloaded", GetHeaderPart(string.Empty), this.TabName.Substring(10)), PrintTo.OutputTab1);
		}

		// Cleanup() is called when the tab is closed, this is to remove used resources or event handlers. 
		public override void Cleanup()
		{
			if (exampleButton != null)
				exampleButton.Click -= ExampleButton_Click;

			if (exampleDateEditor != null)
				exampleDateEditor.TextChanged -= ExampleDateEditor_TextChanged;

			if (exampleQuantityUpDown != null)
				exampleQuantityUpDown.PropertyChanged -= ExampleQuantityUpDown_PropertyChanged;

			base.Cleanup();
		}

		#region Controls event handlers
		// This appears in the output window when the Example Button is clicked
		private void ExampleButton_Click(object sender, RoutedEventArgs e)
		{
			Code.Output.Process("Button clicked", PrintTo.OutputTab1);
		}

		private void ExampleDateEditor_TextChanged(object sender, RoutedPropertyChangedEventArgs<string> e)
		{
			Code.Output.Process("DateEditor value changed: " + (sender as XamDateTimeEditor).Value.ToString(), PrintTo.OutputTab1);
		}

		private void ExampleQuantityUpDown_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
		{
			Code.Output.Process("QuantityUpDown value changed: " + (sender as QuantityUpDown).Value.ToString(), PrintTo.OutputTab1);
		}
		#endregion

		// This returns the default Tab Header text.
		protected override string GetHeaderPart(string variable)
		{
			return "Addon Shell";
		}

		// This loads the page from a xaml file, then finds any elements and assigns those to variables
		private DependencyObject LoadXaml()
		{
			try
			{
				using (System.IO.Stream assemblyResourceStream = GetManifestResourceStream("AddOns.WindowFrameworkExamples.AddonShellExampleContent.xaml"))
				{
					if (assemblyResourceStream == null)
						return null;

					System.IO.StreamReader	streamReader	= new System.IO.StreamReader(assemblyResourceStream);
					Page					page			= System.Windows.Markup.XamlReader.Load(streamReader.BaseStream) as Page;
					DependencyObject		pageContent		= null;

					if (page != null)
					{
						pageContent		= page.Content as DependencyObject;

						// Use LogicalTreeHelper to grab the xaml objects and assign these to variables
						exampleButton					= LogicalTreeHelper.FindLogicalNode(page, "ExampleButton") as Button;
						exampleCheckBox					= LogicalTreeHelper.FindLogicalNode(page, "ExampleCheckBox") as CheckBox;
						exampleQuantityUpDown			= LogicalTreeHelper.FindLogicalNode(page, "ExampleQuantityUpDown") as QuantityUpDown;
						exampleOption1RadioButton		= LogicalTreeHelper.FindLogicalNode(page, "ExampleOption1RadioButton") as RadioButton;
						exampleOption2RadioButton		= LogicalTreeHelper.FindLogicalNode(page, "ExampleOption2RadioButton") as RadioButton;
						exampleTextBlock				= LogicalTreeHelper.FindLogicalNode(page, "ExampleTextBlock") as TextBlock;
						exampleTextBox					= LogicalTreeHelper.FindLogicalNode(page, "ExampleTextBox") as TextBox;
						// https://www.infragistics.com/help/wpf/infragisticswpf.editors~infragistics.windows.editors.xamdatetimeeditor
						exampleDateEditor				= LogicalTreeHelper.FindLogicalNode(page, "ExampleDateEditor") as XamDateTimeEditor;
						
						exampleBrushPicker				= LogicalTreeHelper.FindLogicalNode(page, "ExampleBrushPicker") as System.Windows.Controls.WpfPropertyGrid.Controls.BrushPicker;

						#region Controls event handlers
						// add event handler methods if desired
						if (exampleButton != null)
							exampleButton.Click += ExampleButton_Click;

						if (exampleDateEditor != null)
							exampleDateEditor.TextChanged += ExampleDateEditor_TextChanged;

						if (exampleQuantityUpDown != null)
							exampleQuantityUpDown.PropertyChanged += ExampleQuantityUpDown_PropertyChanged;
						#endregion
					}

					return pageContent;
				}
			}
			catch (Exception exception)
			{
				Code.Output.Process(exception.ToString(), PrintTo.OutputTab1);
				NinjaScript.Log(exception.ToString(), Cbi.LogLevel.Error);
				return null;
			}
		}

		// This is used for restoring the elements of each tab from the workspace
		protected override void Restore(XElement element)
		{
			// for organization i'm separating the controls and tab properties in separate elements
			// restoring window controls values
			XElement itemsRootNode = element.Element("AddonShellNTTabSavedItemsRootNode");
			if (itemsRootNode != null)
			{
				XElement exampleCheckBoxElement = itemsRootNode.Element("exampleCheckBoxElement");
				if (exampleCheckBoxElement != null && exampleCheckBox != null)
					exampleCheckBox.IsChecked = Boolean.Parse(exampleCheckBoxElement.Value);

				XElement exampleQuantityUpDownElement = itemsRootNode.Element("exampleQuantityUpDownElement");
				if (exampleQuantityUpDownElement != null && exampleQuantityUpDown != null)
					exampleQuantityUpDown.Value = Int32.Parse(exampleQuantityUpDownElement.Value);

				XElement exampleOption1RadioButtonElement = itemsRootNode.Element("exampleOption1RadioButtonElement");
				if (exampleOption1RadioButtonElement != null && exampleOption1RadioButton != null)
					exampleOption1RadioButton.IsChecked = Boolean.Parse(exampleOption1RadioButtonElement.Value);

				XElement exampleOption2RadioButtonElement = itemsRootNode.Element("exampleOption2RadioButtonElement");
				if (exampleOption2RadioButtonElement != null && exampleOption2RadioButton != null)
					exampleOption2RadioButton.IsChecked = Boolean.Parse(exampleOption2RadioButtonElement.Value);

				XElement exampleTextBoxElement = itemsRootNode.Element("exampleTextBoxElement");
				if (exampleTextBoxElement != null && exampleTextBox != null)
					exampleTextBox.Text = exampleTextBoxElement.Value;

				XElement exampleDateEditorElement = itemsRootNode.Element("exampleDateEditorElement");
				if (exampleDateEditorElement != null && exampleDateEditor != null)
					exampleDateEditor.Value = DateTime.Parse(exampleDateEditorElement.Value);
			}

			// restoring tab properties
			XElement propertiesRootNode = element.Element("AddonShellNTTabPropertiesRootNode");
			if (itemsRootNode != null)
			{
				XElement tabBoolPropertyElement = propertiesRootNode.Element("TabBoolProperty");
				if (tabBoolPropertyElement != null)
					TabBoolProperty = Boolean.Parse(tabBoolPropertyElement.Value.ToString());

				XElement tabDoublePropertyElement = propertiesRootNode.Element("TabDoubleProperty");
				if (tabDoublePropertyElement != null)
					TabDoubleProperty = Double.Parse(tabDoublePropertyElement.Value.ToString());

				XElement tabIntPropertyElement = propertiesRootNode.Element("TabIntProperty");
				if (tabIntPropertyElement != null)
					TabIntProperty = Int32.Parse(tabIntPropertyElement.Value.ToString());

				XElement tabStringPropertyElement = propertiesRootNode.Element("TabStringProperty");
				if (tabStringPropertyElement != null)
					TabStringProperty = tabStringPropertyElement.Value.ToString();
			}
		}

		// This is used for saving the elements of each tab to the workspace
		protected override void Save(XElement element)
		{
			// the provided element is saved with the tabControl and saves to the xml workspace or template.
			// the tabControl automatically removes then appends this element to prevent duplicates.

			// for organization i'm separating the controls and tab properties in separate elements
			// saving control values
			XElement rootElement	= new XElement("AddonShellNTTabSavedItemsRootNode");

			if (exampleCheckBox != null)
				rootElement.Add(new XElement("exampleCheckBoxElement", exampleCheckBox.IsChecked));

			if (exampleQuantityUpDown != null)
				rootElement.Add(new XElement("exampleQuantityUpDownElement", exampleQuantityUpDown.Value.ToString()));

			if (exampleOption1RadioButton != null)
				rootElement.Add(new XElement("exampleOption1RadioButtonElement", exampleOption1RadioButton.IsChecked));

			if (exampleOption2RadioButton != null)
				rootElement.Add(new XElement("exampleOption2RadioButtonElement", exampleOption2RadioButton.IsChecked));

			if (exampleTextBox != null)
				rootElement.Add(new XElement("exampleTextBoxElement", exampleTextBox.Text));

			if (exampleDateEditor != null && exampleDateEditor.Value != null)
				rootElement.Add(new XElement("exampleDateEditorElement", exampleDateEditor.Value));

			element.Add(rootElement);

			// saving tab properties
			XElement propertiesRootElement = new XElement("AddonShellNTTabPropertiesRootNode");

			propertiesRootElement.Add(new XElement("TabBoolProperty", TabBoolProperty));
			propertiesRootElement.Add(new XElement("TabDoubleProperty", TabDoubleProperty));
			propertiesRootElement.Add(new XElement("TabIntProperty", TabIntProperty));
			propertiesRootElement.Add(new XElement("TabStringProperty", TabStringProperty));

			element.Add(propertiesRootElement);
		}

		public WorkspaceOptions WorkspaceOptions { get; set; }
	}
}

namespace AddonShell_Tools
{
	// This contains the class and inputs that will populate the Properties window
	public class CustomClass : System.ComponentModel.INotifyPropertyChanged
	{
		public CustomClass()
		{
		}

		// this event lets the property grid know that items have changed and the grid should be regenerated
		public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;

		// call this method to trigger the property grid to update after changes (for example in the set of a property)
		protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
		{
			if (PropertyChanged != null)
				PropertyChanged.Invoke(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
		}

		[NinjaTrader.NinjaScript.NinjaScriptProperty]
		[Display(Name = "Window Bool Property", GroupName = "Window Properties", Order = 0)]
		public bool WindowBoolProperty
		{ get; set; }

		[NinjaTrader.NinjaScript.NinjaScriptProperty]
		[Display(Name = "Window Double Property", GroupName = "Window Properties", Order = 1)]
		public double WindowDoubleProperty
		{ get; set; }

		[NinjaTrader.NinjaScript.NinjaScriptProperty]
		[Display(Name = "Window Int Property", GroupName = "Window Properties", Order = 2)]
		public int WindowIntProperty
		{ get; set; }

		[NinjaTrader.NinjaScript.NinjaScriptProperty]
		[Display(Name = "Window String Property", GroupName = "Window Properties", Order = 3)]
		public string WindowStringProperty
		{ get; set; }

		[NinjaTrader.NinjaScript.NinjaScriptProperty]
		[Display(Name = "Tab Bool Property", GroupName = "Tab Properties", Order = 4)]
		public bool TabBoolProperty
		{ get; set; }

		[NinjaTrader.NinjaScript.NinjaScriptProperty]
		[Display(Name = "Tab Double Property", GroupName = "Tab Properties", Order = 5)]
		public double TabDoubleProperty
		{ get; set; }

		[NinjaTrader.NinjaScript.NinjaScriptProperty]
		[Display(Name = "Tab Int Property", GroupName = "Tab Properties", Order = 6)]
		public int TabIntProperty
		{ get; set; }

		[NinjaTrader.NinjaScript.NinjaScriptProperty]
		[Display(Name = "Tab String Property", GroupName = "Tab Properties", Order = 7)]
		public string TabStringProperty
		{ get; set; }
	}
}