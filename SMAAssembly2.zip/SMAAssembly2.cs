#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private SMAAssembly[] cacheSMAAssembly;

		
		public SMAAssembly SMAAssembly(int period)
		{
			return SMAAssembly(Input, period);
		}


		
		public SMAAssembly SMAAssembly(ISeries<double> input, int period)
		{
			if (cacheSMAAssembly != null)
				for (int idx = 0; idx < cacheSMAAssembly.Length; idx++)
					if (cacheSMAAssembly[idx].Period == period && cacheSMAAssembly[idx].EqualsInput(input))
						return cacheSMAAssembly[idx];
			return CacheIndicator<SMAAssembly>(new SMAAssembly(){ Period = period }, input, ref cacheSMAAssembly);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.SMAAssembly SMAAssembly(int period)
		{
			return indicator.SMAAssembly(Input, period);
		}


		
		public Indicators.SMAAssembly SMAAssembly(ISeries<double> input , int period)
		{
			return indicator.SMAAssembly(input, period);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.SMAAssembly SMAAssembly(int period)
		{
			return indicator.SMAAssembly(Input, period);
		}


		
		public Indicators.SMAAssembly SMAAssembly(ISeries<double> input , int period)
		{
			return indicator.SMAAssembly(input, period);
		}

	}
}

#endregion
