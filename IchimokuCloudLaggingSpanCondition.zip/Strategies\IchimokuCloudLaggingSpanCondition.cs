#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies
{
	public class IchimokuCloudLaggingSpanCondition : Strategy
	{
		private IchimokuCloud IchimokuCloud1;

		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Strategy here.";
				Name										= "IchimokuCloudLaggingSpanCondition";
				Calculate									= Calculate.OnBarClose;
				EntriesPerDirection							= 1;
				EntryHandling								= EntryHandling.AllEntries;
				IsExitOnSessionCloseStrategy				= true;
				ExitOnSessionCloseSeconds					= 30;
				IsFillLimitOnTouch							= false;
				MaximumBarsLookBack							= MaximumBarsLookBack.TwoHundredFiftySix;
				OrderFillResolution							= OrderFillResolution.Standard;
				Slippage									= 0;
				StartBehavior								= StartBehavior.WaitUntilFlat;
				TimeInForce									= TimeInForce.Gtc;
				TraceOrders									= false;
				RealtimeErrorHandling						= RealtimeErrorHandling.StopCancelClose;
				StopTargetHandling							= StopTargetHandling.PerEntryExecution;
				BarsRequiredToTrade							= 20;
				// Disable this property for performance gains in Strategy Analyzer optimizations
				// See the Help Guide for additional information
				IsInstantiatedOnEachOptimizationIteration	= true;
			}
			else if (State == State.Configure)
			{
			}
			else if (State == State.DataLoaded)
			{				
				IchimokuCloud1				= IchimokuCloud(Close, false, false, 9, 26, 52, 40, Brushes.Green, Brushes.Red, 26);
				IchimokuCloud1.Plots[0].Brush = Brushes.Red;
				IchimokuCloud1.Plots[1].Brush = Brushes.Purple;
				IchimokuCloud1.Plots[2].Brush = Brushes.MediumBlue;
				IchimokuCloud1.Plots[3].Brush = Brushes.Green;
				IchimokuCloud1.Plots[4].Brush = Brushes.Red;
				AddChartIndicator(IchimokuCloud1);
			}
		}

		protected override void OnBarUpdate()
		{
			if (BarsInProgress != 0) 
				return;
			
			//IchimokuCloud1.Update();

			if (CurrentBars[0] < 27)
				return;

			if ((IchimokuCloud1.ChikouSpan[27] <= IchimokuCloud1.SenkouSpanA[27])
				 && (IchimokuCloud1.ChikouSpan[26] > IchimokuCloud1.SenkouSpanA[26]))
			{
				Print(Convert.ToString(CurrentBar-26));
			}
			
			//Print(String.Format("CurrentBar: {0} CurrentBar-26: {1} IchimokuCloud1.ChikouSpan[27]: {2} IchimokuCloud1.SenkouSpanA[27]: {3} IchimokuCloud1.ChikouSpan[26]: {4} IchimokuCloud1.SenkouSpanA[26]: {5}", CurrentBar, (CurrentBar-26), IchimokuCloud1.ChikouSpan[27], IchimokuCloud1.SenkouSpanA[27], IchimokuCloud1.ChikouSpan[26], IchimokuCloud1.SenkouSpanA[26]));
			
			
		}
	}
}
