#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies
{
	public class ParabolicStopExample : Strategy
	{
		private double stopValue;
		private bool doitonce = true;
		private ParabolicSAR myPsar;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Strategy here.";
				Name										= "ParabolicStopExample";
				Calculate									= Calculate.OnPriceChange;
				EntriesPerDirection							= 1;
				EntryHandling								= EntryHandling.AllEntries;
				IsExitOnSessionCloseStrategy				= true;
				ExitOnSessionCloseSeconds					= 30;
				IsFillLimitOnTouch							= false;
				MaximumBarsLookBack							= MaximumBarsLookBack.TwoHundredFiftySix;
				OrderFillResolution							= OrderFillResolution.Standard;
				Slippage									= 0;
				StartBehavior								= StartBehavior.WaitUntilFlat;
				TimeInForce									= TimeInForce.Gtc;
				TraceOrders									= false;
				RealtimeErrorHandling						= RealtimeErrorHandling.StopCancelClose;
				StopTargetHandling							= StopTargetHandling.PerEntryExecution;
				BarsRequiredToTrade							= 20;
				// Disable this property for performance gains in Strategy Analyzer optimizations
				// See the Help Guide for additional information
				IsInstantiatedOnEachOptimizationIteration	= true;
				Accel						= 0.02;  //defaults to ParabolicSar defaults
				AccelMax					= 0.2;
				AccelStep					= 0.02;
				AddPlot(new Stroke(Brushes.Red, 2), PlotStyle.Cross, "Pstop");
			}
			else if (State == State.Configure)
			{
				SetParabolicStop("",CalculationMode.Ticks, 20,  false, Accel, AccelMax, AccelStep);
			}
			else if (State == State.DataLoaded)
			{
				myPsar = ParabolicSAR(Accel, AccelMax, AccelStep);				
				AddChartIndicator(myPsar);
			}
		}
		protected override void OnOrderUpdate(Cbi.Order order, double limitPrice, double stopPrice, 
			int quantity, int filled, double averageFillPrice, 
			Cbi.OrderState orderState, DateTime time, Cbi.ErrorCode error, string comment)
		{
			if (order.Name == "Parabolic stop")
			{
				stopValue = order.StopPrice;
				Print (stopValue);
			}
		}

		protected override void OnBarUpdate()
		{
			if (State != State.Realtime)
				return;
			
			if (doitonce)
			{
				if (Close[1] > Open[1])
					EnterLong();
				else
					EnterShort();
				doitonce = false;
			}
			
			if (Position.MarketPosition != MarketPosition.Flat)
			{
				Pstop[0] = stopValue; // plot the stop level
			}
		}

		#region Properties
		[NinjaScriptProperty]
		[Range(0.0001, double.MaxValue)]
		[Display(Name="Accel", Order=1, GroupName="Parameters")]
		public double Accel
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0.0001, double.MaxValue)]
		[Display(Name="AccelMax", Order=2, GroupName="Parameters")]
		public double AccelMax
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0.0001, double.MaxValue)]
		[Display(Name="AccelStep", Order=3, GroupName="Parameters")]
		public double AccelStep
		{ get; set; }

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> Pstop
		{
			get { return Values[0]; }
		}
		#endregion

	}
}
