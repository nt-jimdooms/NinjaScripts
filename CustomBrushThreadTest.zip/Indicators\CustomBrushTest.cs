#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class CustomBrushTest : Indicator
	{
		
		private Brush CustomBrush1;
		private Brush CustomBrush2;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Indicator here.";
				Name										= "CustomBrushTest";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				AddPlot(Brushes.Orange, "Plot");
			}
			else if (State == State.Configure)
			{
				CustomBrush1 = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(20,255,20));
			}
			else if (State == State.DataLoaded)
			{
				CustomBrush2 = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(255,20,20));
				//CustomBrush2.Freeze();
			}
		}

		protected override void OnBarUpdate()
		{
			Value[0] = Close[0];
		}
		
		protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
		{
			base.OnRender(chartControl, chartScale);
			Plots[0].Brush = CustomBrush1;
			//Plots[0].Brush = CustomBrush2;
		}

		#region Properties

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> Plot
		{
			get { return Values[0]; }
		}
		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private CustomBrushTest[] cacheCustomBrushTest;
		public CustomBrushTest CustomBrushTest()
		{
			return CustomBrushTest(Input);
		}

		public CustomBrushTest CustomBrushTest(ISeries<double> input)
		{
			if (cacheCustomBrushTest != null)
				for (int idx = 0; idx < cacheCustomBrushTest.Length; idx++)
					if (cacheCustomBrushTest[idx] != null &&  cacheCustomBrushTest[idx].EqualsInput(input))
						return cacheCustomBrushTest[idx];
			return CacheIndicator<CustomBrushTest>(new CustomBrushTest(), input, ref cacheCustomBrushTest);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.CustomBrushTest CustomBrushTest()
		{
			return indicator.CustomBrushTest(Input);
		}

		public Indicators.CustomBrushTest CustomBrushTest(ISeries<double> input )
		{
			return indicator.CustomBrushTest(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.CustomBrushTest CustomBrushTest()
		{
			return indicator.CustomBrushTest(Input);
		}

		public Indicators.CustomBrushTest CustomBrushTest(ISeries<double> input )
		{
			return indicator.CustomBrushTest(input);
		}
	}
}

#endregion
