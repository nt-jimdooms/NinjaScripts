#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class SwingTest : Indicator
	{
		private Swing Swing1;
		private MACD MACD1;
		
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Indicator here.";
				Name										= "SwingTest";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
			}
			else if (State == State.DataLoaded)
			{				
				Swing1				= Swing(Close, 5);
				MACD1				= MACD(12, 26, 9);
			}
		}

		protected override void OnBarUpdate()
		{
			int MostRecentSwingLowIn50Bars = Swing1.SwingLowBar(0, 1, 50);
			int PreviousSwingLowIn50Bars = Swing1.SwingLowBar(0, 2, 50);
			
			bool isUnder = true;
			
			for (int i = 0; i < PreviousSwingLowIn50Bars; i++)
			{
				if (MACD1[i] > 0 || MACD1.Avg[i] > 0)
					isUnder = false;
			}
			
			Print(String.Format("Is Under from last swing low? {0} PreviousSwingLowIn50Bars (BarsAgo): {1}", isUnder, PreviousSwingLowIn50Bars));
		}
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private SwingTest[] cacheSwingTest;
		public SwingTest SwingTest()
		{
			return SwingTest(Input);
		}

		public SwingTest SwingTest(ISeries<double> input)
		{
			if (cacheSwingTest != null)
				for (int idx = 0; idx < cacheSwingTest.Length; idx++)
					if (cacheSwingTest[idx] != null &&  cacheSwingTest[idx].EqualsInput(input))
						return cacheSwingTest[idx];
			return CacheIndicator<SwingTest>(new SwingTest(), input, ref cacheSwingTest);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.SwingTest SwingTest()
		{
			return indicator.SwingTest(Input);
		}

		public Indicators.SwingTest SwingTest(ISeries<double> input )
		{
			return indicator.SwingTest(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.SwingTest SwingTest()
		{
			return indicator.SwingTest(Input);
		}

		public Indicators.SwingTest SwingTest(ISeries<double> input )
		{
			return indicator.SwingTest(input);
		}
	}
}

#endregion
