#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies
{
	public class ButtonCancelExample : Strategy
	{
		private System.Windows.Controls.Button EnterButton;
		private System.Windows.Controls.Button CancelButton;
		private System.Windows.Controls.Grid myGrid;
		private Order entryOrder;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description							= @"ButtonCancelExample";
				Name								= "ButtonCancelExample";
				Calculate							= Calculate.OnEachTick;
				EntriesPerDirection					= 1;
				EntryHandling						= EntryHandling.AllEntries;
				IsExitOnSessionCloseStrategy		= true;
				ExitOnSessionCloseSeconds			= 30;
				IsFillLimitOnTouch					= false;
				MaximumBarsLookBack					= MaximumBarsLookBack.TwoHundredFiftySix;
				OrderFillResolution					= OrderFillResolution.Standard;
				Slippage							= 0;
				StartBehavior						= StartBehavior.WaitUntilFlat;
				TimeInForce							= TimeInForce.Gtc;
				TraceOrders							= false;
				RealtimeErrorHandling				= RealtimeErrorHandling.StopCancelClose;
				StopTargetHandling					= StopTargetHandling.PerEntryExecution;
				BarsRequiredToTrade					= 20;
			}
			else if (State == State.Historical)
			{
				if (UserControlCollection.Contains(myGrid))
					return;
				
				Dispatcher.InvokeAsync((() =>
				{
					myGrid = new System.Windows.Controls.Grid
					{
						Name = "MyCustomGrid", HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Top
					};
					
					System.Windows.Controls.ColumnDefinition column1 = new System.Windows.Controls.ColumnDefinition();
					System.Windows.Controls.ColumnDefinition column2 = new System.Windows.Controls.ColumnDefinition();
					
					myGrid.ColumnDefinitions.Add(column1);
					myGrid.ColumnDefinitions.Add(column2);
					
					EnterButton = new System.Windows.Controls.Button
					{
						Name = "EnterButton", Content = "EnterButton", Foreground = Brushes.White, Background = Brushes.Green
					};
					
					CancelButton = new System.Windows.Controls.Button
					{
						Name = "CancelButton", Content = "CancelButton", Foreground = Brushes.Black, Background = Brushes.Red
					};
					
					EnterButton.Click += OnButtonClick;
					CancelButton.Click += OnButtonClick;
					
					System.Windows.Controls.Grid.SetColumn(EnterButton, 0);
					System.Windows.Controls.Grid.SetColumn(CancelButton, 1);
					
					myGrid.Children.Add(EnterButton);
					myGrid.Children.Add(CancelButton);
					
					UserControlCollection.Add(myGrid);
				}));
			}
			else if (State == State.Terminated)
			{
				Dispatcher.InvokeAsync((() =>
				{
					if (myGrid != null)
					{
						if (EnterButton != null)
						{
							myGrid.Children.Remove(EnterButton);
							EnterButton.Click -= OnButtonClick;
							EnterButton = null;
						}
						if (CancelButton != null)
						{
							myGrid.Children.Remove(CancelButton);
							CancelButton.Click -= OnButtonClick;
							CancelButton = null;
						}
					}
				}));
			}
		}

		protected override void OnBarUpdate()
		{
		}
		
		private void OnButtonClick(object sender, RoutedEventArgs rea)
		{
			System.Windows.Controls.Button button = sender as System.Windows.Controls.Button;
			if (button == EnterButton && button.Name == "EnterButton")
			{
				TriggerCustomEvent(o =>
			    {
			       if (Position.MarketPosition == MarketPosition.Flat)
					EnterLongLimit(0, true, 1, Low[0] - 10 * TickSize, "LongEntry");
			    }, null);
				return;
			}
			
			if (button == CancelButton && button.Name == "CancelButton")
			{
				TriggerCustomEvent(o =>
			    {
			       if (entryOrder != null)
					CancelOrder(entryOrder);
			    }, null);
				return;
			}
		}
		
		protected override void OnOrderUpdate(Order order, double limitPrice, double stopPrice, int quantity, int filled, double averageFillPrice, OrderState orderState, DateTime time, ErrorCode error, string nativeError)
        {
            // Handle entry orders here. The entryOrder object allows us to identify that the order that is calling the OnOrderUpdate() method is the entry order.
            // Assign entryOrder in OnOrderUpdate() to ensure the assignment occurs when expected.
            // This is more reliable than assigning Order objects in OnBarUpdate, as the assignment is not gauranteed to be complete if it is referenced immediately after submitting
            if (order.Name == "LongEntry")
            {
                entryOrder = order;

                // Reset the entryOrder object to null if order was cancelled without any fill
                if (order.OrderState == OrderState.Cancelled && order.Filled == 0)
                {
                    entryOrder = null;
                }
				else if (order.OrderState == OrderState.Filled)
					entryOrder = null;
            }
        }
	}
}