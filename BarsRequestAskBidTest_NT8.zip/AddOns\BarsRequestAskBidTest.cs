#region Using Statements

using System;
using System.Windows;
using NinjaTrader.Core;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript;
using System.IO;
using System.Windows.Controls;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Markup;
using System.Xml.Linq;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using IInstrumentProvider = NinjaTrader.Gui.Tools.IInstrumentProvider;
#endregion

// 
// Copyright (C) 2015, NinjaTrader LLC <www.ninjatrader.com>.
// NinjaTrader reserves the right to modify or overwrite this NinjaScript component with each release.
//

namespace NinjaTrader.NinjaScript.AddOns
{
	/*
		* This is the Primary script in the set of scripts in this example, This script will be the first called script in NinjaTrader. 
     
		* Unlike other NinjaScript documents, Debugging in an addon can be done unsing the folling statement
		* Output.Process("SomeString", PrintTo.OutputTab1);
    */
	public class BarsRequestAskBidTest : AddOnBase
    {
		//These variables will be used in checking if the current Addon already has a menu item, and also stores the new menu item to be added.
		private NTMenuItem existingMenuItems;
        private NTMenuItem newMenuItem;

        private void OnMenuItemClick(object sender, RoutedEventArgs e)
        {
            Globals.RandomDispatcher.InvokeAsync(new Action(() => new BarsRequestAskBidTestWindow().Show()));
        }

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = "";
                Name = "BarsRequestAskBidTest";
            }
        }

        protected override void OnWindowCreated(Window window)
        {
			/*
				* The following checks if the control center window is present.
				* If the control center is found, the MainMenu is checked for existing menu items with the same name as this addon. 
				* If no existing items are found, a new menu item is added for this addon. 
			*/
			ControlCenter controlCenter = window as ControlCenter;

            if (controlCenter == null)
                return;

            existingMenuItems = controlCenter.FindFirst("ControlCenterMenuItemNew") as NTMenuItem;

            if (existingMenuItems == null)
                return;

			// This is the new menu item to be created, this assigns the menu text and will be used to Add this item to the Main Menu. 
			newMenuItem = new NTMenuItem {Header = "BarsRequestAskBidTest", Style = Application.Current.TryFindResource("MainMenuItem") as Style};
			
            existingMenuItems.Items.Add(newMenuItem);
			// The new menu item will do nothing by its self, a click handler is added to complete the menu item and allow for clicks.
			newMenuItem.Click += OnMenuItemClick;
        }

        protected override void OnWindowDestroyed(Window window)
        {
			// This checks if there is not a menu item or if the destroyed window is not the control center.
			if (newMenuItem == null || !(window is ControlCenter) ||
					existingMenuItems == null ||
					!existingMenuItems.Items.Contains(newMenuItem))	
				return;

			// if the destroyed window was the control center, we clean up the click handler and remove the custom menu item and set it to null.
			newMenuItem.Click -= OnMenuItemClick;
			existingMenuItems.Items.Remove(newMenuItem);
			newMenuItem = null;
        }
	}

	public class BarsRequestAskBidTestWindow : NTWindow, IWorkspacePersistence
	{
		private BarsPeriod		barsPeriod;
		private BarsRequest[]	barsRequests;
		private string[]		symbolsList;
		private Cbi.Instrument	thisInstrument;

		public BarsRequestAskBidTestWindow()
		{
			Caption	= "BarsRequestAskBidTest";
			Width	= 400;
			Height	= 250;

			// This is a inline Window Loaded handler, once the window loads, if the WorkspaceOptions are not present,
			// a new WorkspaceOptions object is created for this window using its GUID.
			Loaded += (o, e) =>
			{
				if (WorkspaceOptions == null)
				{
					WorkspaceOptions = new WorkspaceOptions("BarsRequestAskBidTestWindow" + Guid.NewGuid().ToString("N"), this);
				}

				DoBarsRequest();
			};

			Closed += (o, e) =>
			{
				// clean up handlers
				if (barsRequests != null)				
					foreach (BarsRequest brequest in barsRequests)
						if (brequest != null)
							brequest.Update -= BarUpdate;
			};
		}

		private void DoBarsRequest()
		{
			symbolsList		= new string[] { "YM 06-17" };
			barsPeriod		= new BarsPeriod() { BarsPeriodType = BarsPeriodType.Minute, Value = 1 };
			barsRequests	= new BarsRequest[symbolsList.Count()];

			int i = 0;

			foreach (string symbol in symbolsList)
			{
				thisInstrument = Cbi.Instrument.GetInstrument(symbol);
				if (thisInstrument == null)
					return;

				barsRequests[i] = new BarsRequest(thisInstrument, 1)
				{
					BarsPeriod		= barsPeriod,
					TradingHours	= thisInstrument.MasterInstrument.TradingHours
				};

				barsRequests[i].Update += BarUpdate;

				barsRequests[i].Request(new Action<BarsRequest, ErrorCode, string>((bars, errorCode, errorMessage) =>
				{
					if (errorCode != ErrorCode.NoError)
					{
						// Handle any errors in requesting bars here
						NinjaTrader.Code.Output.Process(string.Format("Error on requesting bars: {0}, {1}",
								errorCode, errorMessage), PrintTo.OutputTab1);
						return;
					}

					// If requesting real-time bars, but there are currently no connections
					lock (Connection.Connections)
						if (Connection.Connections.FirstOrDefault() == null)
							NinjaTrader.Code.Output.Process("Real-Time Bars: Not connected.", PrintTo.OutputTab1);
				}));
			}
		}

		protected void BarUpdate(object sender, BarsUpdateEventArgs e)
		{
			Bars theBars = sender as Bars;
			string message = string.Format("{0:H:mm:ss.ffff} | {1} | ask: {2}, bid: {3}", NinjaTrader.Core.Globals.Now, theBars.Instrument.FullName, theBars.GetAsk(0), theBars.GetBid(0));
			NinjaTrader.Code.Output.Process(message, PrintTo.OutputTab1);
		}


		public void Restore(XDocument document, XElement element)
		{
			// This is used for restoring the elements of the document with the workspace. 
			if (MainTabControl != null)
				MainTabControl.RestoreFromXElement(element);
		}

		public void Save(XDocument document, XElement element)
		{
			// This is used for saving the elements of the document with the workspace.
			if (MainTabControl != null)
				MainTabControl.SaveToXElement(element);
		}

		public WorkspaceOptions WorkspaceOptions { get; set; }
	}
}
 