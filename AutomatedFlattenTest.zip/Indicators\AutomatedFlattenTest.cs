#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class AutomatedFlattenTest : Indicator
	{
		private Account account;
		
		private Order myEntryOrder;
    	private Order profitTarget;
    	private Order stopLoss;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Indicator here.";
				Name										= "AutomatedFlattenTest";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				
				AccountName 								= "Sim101";
			}
			else if (State == State.DataLoaded)
			{
				// Find our Sim101 account
		        lock (Account.All)
		              account = Account.All.FirstOrDefault(a => a.Name == AccountName);

		        // Subscribe to account item and order updates
		        if (account != null)
				{
					account.OrderUpdate 		+= OnOrderUpdate;
				}
			}
			else if (State == State.Realtime)
			{
				Order myFlattenOrder = null;
				
				foreach (Position pos in account.Positions)
				{
					if (pos.Instrument == Instrument)
					{
						if (pos.MarketPosition == MarketPosition.Long)
							myFlattenOrder = account.CreateOrder(Instrument, OrderAction.Sell, OrderType.Market, OrderEntry.Automated, TimeInForce.Gtc, pos.Quantity, 0, 0, "", "FlattenPosition "+DateTime.Now.ToString(), DateTime.Now, null);
						if (pos.MarketPosition == MarketPosition.Short)
							myFlattenOrder = account.CreateOrder(Instrument, OrderAction.BuyToCover, OrderType.Market, OrderEntry.Automated, TimeInForce.Gtc, pos.Quantity, 0, 0, "", "FlattenPosition "+DateTime.Now.ToString(), DateTime.Now, null);
					}
				}
				
				if (myFlattenOrder != null)
					account.Submit(new[] { myFlattenOrder });
			}
			else if(State == State.Terminated)
			{
				// Make sure to unsubscribe to the account item subscription
        		if (account != null)
				{
					account.OrderUpdate 		-= OnOrderUpdate;
				}
			}
		}

	    private void OnOrderUpdate(object sender, OrderEventArgs e)
	    {
			// Output the account item
	        //NinjaTrader.Code.Output.Process(e.Order.ToString(), PrintTo.OutputTab1);
			NinjaTrader.Code.Output.Process(e.Order.OrderEntry.ToString(), PrintTo.OutputTab1);
	    }
		
		[TypeConverter(typeof(NinjaTrader.NinjaScript.AccountNameConverter))]
		public string AccountName { get; set; }
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private AutomatedFlattenTest[] cacheAutomatedFlattenTest;
		public AutomatedFlattenTest AutomatedFlattenTest()
		{
			return AutomatedFlattenTest(Input);
		}

		public AutomatedFlattenTest AutomatedFlattenTest(ISeries<double> input)
		{
			if (cacheAutomatedFlattenTest != null)
				for (int idx = 0; idx < cacheAutomatedFlattenTest.Length; idx++)
					if (cacheAutomatedFlattenTest[idx] != null &&  cacheAutomatedFlattenTest[idx].EqualsInput(input))
						return cacheAutomatedFlattenTest[idx];
			return CacheIndicator<AutomatedFlattenTest>(new AutomatedFlattenTest(), input, ref cacheAutomatedFlattenTest);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.AutomatedFlattenTest AutomatedFlattenTest()
		{
			return indicator.AutomatedFlattenTest(Input);
		}

		public Indicators.AutomatedFlattenTest AutomatedFlattenTest(ISeries<double> input )
		{
			return indicator.AutomatedFlattenTest(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.AutomatedFlattenTest AutomatedFlattenTest()
		{
			return indicator.AutomatedFlattenTest(Input);
		}

		public Indicators.AutomatedFlattenTest AutomatedFlattenTest(ISeries<double> input )
		{
			return indicator.AutomatedFlattenTest(input);
		}
	}
}

#endregion
