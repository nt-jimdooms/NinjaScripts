#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class OneTickSyncRealtimeBarCloses : Indicator
	{
		private OrderFlowCumulativeDelta cumulativeDelta;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Name					= "OneTickSyncRealtimeBarCloses";
				Calculate				= Calculate.OnEachTick;
				RealtimeOnly			= true;
			}
			else if (State == State.Configure)
			{
				AddDataSeries(Data.BarsPeriodType.Tick, 1);
			}
			else if (State == State.DataLoaded)
			{
				cumulativeDelta = OrderFlowCumulativeDelta(CumulativeDeltaType.BidAsk, CumulativeDeltaPeriod.Bar, 0);
				rtBarClosed = false;
			}
		}
		
		private bool rtBarClosed;
		private int barsAgo2;

		protected override void OnBarUpdate()
		{		
			if (CurrentBars[0] < 2)
				return;
			
			if (BarsInProgress == 0)
			{				
				if ((State == State.Realtime || BarsArray[0].IsTickReplay) && IsFirstTickOfBar)
					rtBarClosed = true;
			
				if (rtBarClosed)
					return;
				
				// When processing historical data, the indicator plot for a closed bar is up-to-date in BIP 0
				// Also, the last historical bar will be triggered for BIP 0 and BIP 1.
				// We will want to skip the BIP 0 update from the last historical bar, and use the update from after BIP 1 instead
				// When processing Realtime data, and a bar is not closed, we do not have a corrected plot and we will still be one tick behind.
				// So we cannot do the same trick we use for the closed bar where we can wait for BIP 1 to get the corrected plot, so just get the update here. 
				if ((State == State.Realtime && Calculate != Calculate.OnBarClose)
					|| ((BarsArray[0].Count - CurrentBars[0] != 2 && State == State.Historical && Calculate == Calculate.OnBarClose)
					||  (BarsArray[0].Count - CurrentBars[0] != 1 && State == State.Historical && Calculate != Calculate.OnBarClose)))
					CheckMTFUpdatedValues(0);
			}
			else if (BarsInProgress == 1)
			{
				// Update the Multi Time Frame indicators' single tick data series
				cumulativeDelta.Update(cumulativeDelta.BarsArray[1].Count - 1, 1);
				
				// When processing Realtime data or Tick Replay, the indicator plot is assigned for the last bar of the primary data series.
				// So, to get an up-to-date value with all ticks, we can read the closed bar value on BIP 1, which comes after BIP 0 (since the indicator sets the prior bar value in BIP 0)
				// This trick only works for closed bars, because the indicator plot for the prior bar is corrected when the bar closes.
				if (rtBarClosed)
				{
					CheckMTFUpdatedValues(1);
					rtBarClosed = false;
				}
			}
		}
		
		private void CheckMTFUpdatedValues(int barsAgo)
		{
			// This method would be garaunteed to be called with the Multi Time Frame indicator values up to date.
			// Use Times[][], Closes[][], etc. since the method may be called from BIP 0 or BIP 1.
			bool debug = true;
			
			if (debug)
			{
				Print("");
				Print(barsAgo);
				Print(string.Format("{0} | {1} | OFCD[X+0]: {2}", BarsInProgress, Times[0][barsAgo],	cumulativeDelta.DeltaClose[barsAgo]));
				Print(string.Format("{0} | {1} | OFCD[X+1]: {2}", BarsInProgress, Times[0][barsAgo+1],  cumulativeDelta.DeltaClose[barsAgo+1]));
				Print(string.Format("{0} | {1} | OFCD[X+2]: {2}", BarsInProgress, Times[0][barsAgo+2], 	cumulativeDelta.DeltaClose[barsAgo+2]));
			}
		}
		
		[NinjaScriptProperty]
		[Display(Name = "Realtime", Description = "Controls if showing real-time data only or historical data only", GroupName = "Parameters", Order = 0)]
		public bool RealtimeOnly
		{ get; set; }
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private OneTickSyncRealtimeBarCloses[] cacheOneTickSyncRealtimeBarCloses;
		public OneTickSyncRealtimeBarCloses OneTickSyncRealtimeBarCloses(bool realtimeOnly)
		{
			return OneTickSyncRealtimeBarCloses(Input, realtimeOnly);
		}

		public OneTickSyncRealtimeBarCloses OneTickSyncRealtimeBarCloses(ISeries<double> input, bool realtimeOnly)
		{
			if (cacheOneTickSyncRealtimeBarCloses != null)
				for (int idx = 0; idx < cacheOneTickSyncRealtimeBarCloses.Length; idx++)
					if (cacheOneTickSyncRealtimeBarCloses[idx] != null && cacheOneTickSyncRealtimeBarCloses[idx].RealtimeOnly == realtimeOnly && cacheOneTickSyncRealtimeBarCloses[idx].EqualsInput(input))
						return cacheOneTickSyncRealtimeBarCloses[idx];
			return CacheIndicator<OneTickSyncRealtimeBarCloses>(new OneTickSyncRealtimeBarCloses(){ RealtimeOnly = realtimeOnly }, input, ref cacheOneTickSyncRealtimeBarCloses);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.OneTickSyncRealtimeBarCloses OneTickSyncRealtimeBarCloses(bool realtimeOnly)
		{
			return indicator.OneTickSyncRealtimeBarCloses(Input, realtimeOnly);
		}

		public Indicators.OneTickSyncRealtimeBarCloses OneTickSyncRealtimeBarCloses(ISeries<double> input , bool realtimeOnly)
		{
			return indicator.OneTickSyncRealtimeBarCloses(input, realtimeOnly);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.OneTickSyncRealtimeBarCloses OneTickSyncRealtimeBarCloses(bool realtimeOnly)
		{
			return indicator.OneTickSyncRealtimeBarCloses(Input, realtimeOnly);
		}

		public Indicators.OneTickSyncRealtimeBarCloses OneTickSyncRealtimeBarCloses(ISeries<double> input , bool realtimeOnly)
		{
			return indicator.OneTickSyncRealtimeBarCloses(input, realtimeOnly);
		}
	}
}

#endregion
