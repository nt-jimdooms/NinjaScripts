#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class TextPositionDLL : Indicator
	{
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Indicator here.";
				Name										= "TextPositionDLL";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				TextPos					= MyEnums.TextPosDLL.Center;
			}
			else if (State == State.Configure)
			{
			}
		}

		protected override void OnBarUpdate()
		{
			Draw.TextFixed(this, "tag", "Text", (NinjaTrader.NinjaScript.DrawingTools.TextPosition)TextPos);
		}

		#region Properties
		[NinjaScriptProperty]
		[Display(Name="TextPos", Order=1, GroupName="Parameters")]
		public MyEnums.TextPosDLL TextPos
		{ get; set; }
		
		#endregion

	}
}

namespace MyEnums
{
	public enum TextPosDLL
		{
			BottomLeft,
			BottomRight,
			Center,
			TopLeft,
			TopRight
		}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private TextPositionDLL[] cacheTextPositionDLL;
		public TextPositionDLL TextPositionDLL(MyEnums.TextPosDLL textPos)
		{
			return TextPositionDLL(Input, textPos);
		}

		public TextPositionDLL TextPositionDLL(ISeries<double> input, MyEnums.TextPosDLL textPos)
		{
			if (cacheTextPositionDLL != null)
				for (int idx = 0; idx < cacheTextPositionDLL.Length; idx++)
					if (cacheTextPositionDLL[idx] != null && cacheTextPositionDLL[idx].TextPos == textPos && cacheTextPositionDLL[idx].EqualsInput(input))
						return cacheTextPositionDLL[idx];
			return CacheIndicator<TextPositionDLL>(new TextPositionDLL(){ TextPos = textPos }, input, ref cacheTextPositionDLL);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.TextPositionDLL TextPositionDLL(MyEnums.TextPosDLL textPos)
		{
			return indicator.TextPositionDLL(Input, textPos);
		}

		public Indicators.TextPositionDLL TextPositionDLL(ISeries<double> input , MyEnums.TextPosDLL textPos)
		{
			return indicator.TextPositionDLL(input, textPos);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.TextPositionDLL TextPositionDLL(MyEnums.TextPosDLL textPos)
		{
			return indicator.TextPositionDLL(Input, textPos);
		}

		public Indicators.TextPositionDLL TextPositionDLL(ISeries<double> input , MyEnums.TextPosDLL textPos)
		{
			return indicator.TextPositionDLL(input, textPos);
		}
	}
}

#endregion
