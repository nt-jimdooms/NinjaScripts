#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class RugDisplayExample : Indicator
	{
		private SharpDX.Direct2D1.Brush			ellipseBrushDX;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Indicator here.";
				Name										= "RugDisplayExample";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= true;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
			}
		}

		protected override void OnBarUpdate()
		{
			//Add your custom indicator logic here.
		}
		
		protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
		{
			if (IsInHitTest)
				return;
			
			for (int barIndex = ChartBars.FromIndex; barIndex <= ChartBars.ToIndex; barIndex++)
    		{
				FillEllipse(RenderTarget, ChartControl.GetXByBarIndex(ChartBars, barIndex), ChartPanel.H, 5, 5, ellipseBrushDX);
			}
		}

		public override void OnRenderTargetChanged()
		{
			if (ellipseBrushDX != null)
				ellipseBrushDX.Dispose();

			if (RenderTarget != null)
				ellipseBrushDX = Brushes.Blue.ToDxBrush(RenderTarget);
		}
		
		
		private void FillEllipse(SharpDX.Direct2D1.RenderTarget renderTarget, double x, double y, float radiusX, float radiusY, SharpDX.Direct2D1.Brush brush)
		{
			FillEllipse(renderTarget, new SharpDX.Direct2D1.Ellipse(new SharpDX.Vector2(){ X = (float)x, Y = (float)y }, radiusX, radiusY), brush);
		}
		
		private void FillEllipse(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.Ellipse ellipse, SharpDX.Direct2D1.Brush brush)
		{
			renderTarget.FillEllipse(ellipse, brush);
		}
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private RugDisplayExample[] cacheRugDisplayExample;
		public RugDisplayExample RugDisplayExample()
		{
			return RugDisplayExample(Input);
		}

		public RugDisplayExample RugDisplayExample(ISeries<double> input)
		{
			if (cacheRugDisplayExample != null)
				for (int idx = 0; idx < cacheRugDisplayExample.Length; idx++)
					if (cacheRugDisplayExample[idx] != null &&  cacheRugDisplayExample[idx].EqualsInput(input))
						return cacheRugDisplayExample[idx];
			return CacheIndicator<RugDisplayExample>(new RugDisplayExample(), input, ref cacheRugDisplayExample);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.RugDisplayExample RugDisplayExample()
		{
			return indicator.RugDisplayExample(Input);
		}

		public Indicators.RugDisplayExample RugDisplayExample(ISeries<double> input )
		{
			return indicator.RugDisplayExample(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.RugDisplayExample RugDisplayExample()
		{
			return indicator.RugDisplayExample(Input);
		}

		public Indicators.RugDisplayExample RugDisplayExample(ISeries<double> input )
		{
			return indicator.RugDisplayExample(input);
		}
	}
}

#endregion
