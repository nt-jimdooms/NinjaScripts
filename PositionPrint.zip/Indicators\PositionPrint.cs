#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class PositionPrint : Indicator
	{
		private Account myAccount;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Indicator here.";
				Name										= "PositionPrint";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
			}
			else if (State == State.Realtime)
			{
				lock (Account.All)
          			myAccount = Account.All.FirstOrDefault(a => a.Name == "Sim101");
				
				lock (myAccount.Positions)
				{
				  foreach (Position position in myAccount.Positions)
				  {
					  if (position.Instrument == Instrument)
				      	Print(String.Format("Position: {0} at {1}", position.MarketPosition, position.GetUnrealizedProfitLoss(PerformanceUnit.Currency, Close[0])));
				  }
				  Print(myAccount.Get(AccountItem.GrossRealizedProfitLoss, Currency.UsDollar));
				}
			}
		}

		protected override void OnBarUpdate()
		{
			//Add your custom indicator logic here.
		}
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private PositionPrint[] cachePositionPrint;
		public PositionPrint PositionPrint()
		{
			return PositionPrint(Input);
		}

		public PositionPrint PositionPrint(ISeries<double> input)
		{
			if (cachePositionPrint != null)
				for (int idx = 0; idx < cachePositionPrint.Length; idx++)
					if (cachePositionPrint[idx] != null &&  cachePositionPrint[idx].EqualsInput(input))
						return cachePositionPrint[idx];
			return CacheIndicator<PositionPrint>(new PositionPrint(), input, ref cachePositionPrint);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.PositionPrint PositionPrint()
		{
			return indicator.PositionPrint(Input);
		}

		public Indicators.PositionPrint PositionPrint(ISeries<double> input )
		{
			return indicator.PositionPrint(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.PositionPrint PositionPrint()
		{
			return indicator.PositionPrint(Input);
		}

		public Indicators.PositionPrint PositionPrint(ISeries<double> input )
		{
			return indicator.PositionPrint(input);
		}
	}
}

#endregion
