#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies
{
	public class CheckExitExecutions : Strategy
	{
		private bool bFirstEntry;
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Strategy here.";
				Name										= "CheckExitExecutions";
				Calculate									= Calculate.OnBarClose;
				EntriesPerDirection							= 1;
				EntryHandling								= EntryHandling.AllEntries;
				IsExitOnSessionCloseStrategy				= true;
				ExitOnSessionCloseSeconds					= 30;
				IsFillLimitOnTouch							= false;
				MaximumBarsLookBack							= MaximumBarsLookBack.TwoHundredFiftySix;
				OrderFillResolution							= OrderFillResolution.Standard;
				Slippage									= 0;
				StartBehavior								= StartBehavior.WaitUntilFlat;
				TimeInForce									= TimeInForce.Gtc;
				TraceOrders									= false;
				RealtimeErrorHandling						= RealtimeErrorHandling.StopCancelClose;
				StopTargetHandling							= StopTargetHandling.PerEntryExecution;
				BarsRequiredToTrade							= 20;
				// Disable this property for performance gains in Strategy Analyzer optimizations
				// See the Help Guide for additional information
				IsInstantiatedOnEachOptimizationIteration	= true;
			}
			else if (State == State.DataLoaded)
			{
				bFirstEntry = false;
			}
		}

		protected override void OnBarUpdate()
		{
			int exitOffset = 0;
			if(Calculate == Calculate.OnEachTick)
				if(State == State.Historical)
					exitOffset = 0;
				else
					exitOffset = 1;
					
			Print("BarsSinceExitExecution " + BarsSinceExitExecution("MyExitSignal"));
			if(Position.MarketPosition == MarketPosition.Flat 
				&& (BarsSinceExitExecution("MyExitSignal") > exitOffset || !bFirstEntry))
			{
				EnterLong("MyEntrySignal");
				bFirstEntry = true;
			}
			if(Position.MarketPosition == MarketPosition.Long)
			{
				//Print("Position.AveragePrice: " + Position.AveragePrice + " CurrentBar: " + CurrentBar);
				if(BarsSinceEntryExecution("MyEntrySignal") == 3)
				{
					ExitLong("MyExitSignal", "MyEntrySignal");
					Print("");
				}
			}
		}
	}
}
