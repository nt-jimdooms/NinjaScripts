#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class CalculatePOCExample : Indicator
	{
		private Dictionary<double, double> MyVolumeDictionary;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Indicator here.";
				Name										= "CalculatePOCExample";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
			}
			else if (State == State.Configure)
			{
				AddDataSeries(BarsPeriodType.Tick, 1);
			}
			else if (State == State.DataLoaded)
			{
				MyVolumeDictionary = new Dictionary<double, double>();
			}
		}
		
		private double poc = 0;
		private double pocVolume = 0;

		protected override void OnBarUpdate()
		{
			if (BarsInProgress == 1)
			{
				if (Bars.IsFirstBarOfSession)
				{
					poc = 0;
					pocVolume = 0;
					MyVolumeDictionary.Clear();
				}
				
				if (!MyVolumeDictionary.ContainsKey(Close[0]))
					MyVolumeDictionary.Add(Close[0], Volume[0]);
				else
					MyVolumeDictionary[Close[0]] += Volume[0];
				
				foreach (KeyValuePair<double, double> kvp in MyVolumeDictionary)
				{
					if (kvp.Value > pocVolume)
					{
						pocVolume = kvp.Value;
						poc = kvp.Key;
					}
				}
			}
			else if (BarsInProgress == 0)
			{
				Print(CurrentBar + " " + Time[0] + " " + poc);
			}
		}
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private CalculatePOCExample[] cacheCalculatePOCExample;
		public CalculatePOCExample CalculatePOCExample()
		{
			return CalculatePOCExample(Input);
		}

		public CalculatePOCExample CalculatePOCExample(ISeries<double> input)
		{
			if (cacheCalculatePOCExample != null)
				for (int idx = 0; idx < cacheCalculatePOCExample.Length; idx++)
					if (cacheCalculatePOCExample[idx] != null &&  cacheCalculatePOCExample[idx].EqualsInput(input))
						return cacheCalculatePOCExample[idx];
			return CacheIndicator<CalculatePOCExample>(new CalculatePOCExample(), input, ref cacheCalculatePOCExample);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.CalculatePOCExample CalculatePOCExample()
		{
			return indicator.CalculatePOCExample(Input);
		}

		public Indicators.CalculatePOCExample CalculatePOCExample(ISeries<double> input )
		{
			return indicator.CalculatePOCExample(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.CalculatePOCExample CalculatePOCExample()
		{
			return indicator.CalculatePOCExample(Input);
		}

		public Indicators.CalculatePOCExample CalculatePOCExample(ISeries<double> input )
		{
			return indicator.CalculatePOCExample(input);
		}
	}
}

#endregion
