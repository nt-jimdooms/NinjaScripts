#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class SampleAtmTemplateSelector : Indicator
	{
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Indicator here.";
				Name										= "SampleAtmTemplateSelector";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
			}
			else if (State == State.Configure)
			{
			}
		}

		protected override void OnBarUpdate()
		{
			//Add your custom indicator logic here.
		}
		
		[TypeConverter(typeof(FriendlyAtmConverter))] // Converts the found ATM template file names to string values
		[PropertyEditor("NinjaTrader.Gui.Tools.StringStandardValuesEditorKey")] // Create the combo box on the property grid
		[Display(Name = "Atm Strategy", Order = 1, GroupName = "AtmStrategy")]
		public string AtmStrategy
		{ get; set; }
	}
	
	
	public class FriendlyAtmConverter : TypeConverter
	{  
	    // Set the values to appear in the combo box
	    public override StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
	    {
	        List<string> values = new List<string>();
	        string[] files = System.IO.Directory.GetFiles(System.IO.Path.Combine(NinjaTrader.Core.Globals.UserDataDir, "templates", "AtmStrategy"), "*.xml");  
	 
	        foreach(string atm in files)
	        {
	            values.Add(System.IO.Path.GetFileNameWithoutExtension(atm));
	            NinjaTrader.Code.Output.Process(System.IO.Path.GetFileNameWithoutExtension(atm), PrintTo.OutputTab1);
	        }
	        return new StandardValuesCollection(values);
	    }
	 
	    public override object ConvertFrom(ITypeDescriptorContext context, System.Globalization.CultureInfo culture, object value)
	    {
	        return value.ToString();
	    }
	 
	    public override object ConvertTo(ITypeDescriptorContext context, System.Globalization.CultureInfo culture, object value, Type destinationType)
	    {
	        return value;
	    }
	 
	    // required interface members needed to compile
	    public override bool CanConvertFrom(ITypeDescriptorContext context, Type sourceType)
	    { return true; }
	 
	    public override bool CanConvertTo(ITypeDescriptorContext context, Type destinationType)
	    { return true; }
	 
	    public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
	    { return true; }
	 
	    public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
	    { return true; }
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private SampleAtmTemplateSelector[] cacheSampleAtmTemplateSelector;
		public SampleAtmTemplateSelector SampleAtmTemplateSelector()
		{
			return SampleAtmTemplateSelector(Input);
		}

		public SampleAtmTemplateSelector SampleAtmTemplateSelector(ISeries<double> input)
		{
			if (cacheSampleAtmTemplateSelector != null)
				for (int idx = 0; idx < cacheSampleAtmTemplateSelector.Length; idx++)
					if (cacheSampleAtmTemplateSelector[idx] != null &&  cacheSampleAtmTemplateSelector[idx].EqualsInput(input))
						return cacheSampleAtmTemplateSelector[idx];
			return CacheIndicator<SampleAtmTemplateSelector>(new SampleAtmTemplateSelector(), input, ref cacheSampleAtmTemplateSelector);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.SampleAtmTemplateSelector SampleAtmTemplateSelector()
		{
			return indicator.SampleAtmTemplateSelector(Input);
		}

		public Indicators.SampleAtmTemplateSelector SampleAtmTemplateSelector(ISeries<double> input )
		{
			return indicator.SampleAtmTemplateSelector(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.SampleAtmTemplateSelector SampleAtmTemplateSelector()
		{
			return indicator.SampleAtmTemplateSelector(Input);
		}

		public Indicators.SampleAtmTemplateSelector SampleAtmTemplateSelector(ISeries<double> input )
		{
			return indicator.SampleAtmTemplateSelector(input);
		}
	}
}

#endregion
