// Coded by Chelsea Bell. chelsea.bell@ninjatrader.com
#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;

// Added
using System.Windows.Controls;
using NinjaTrader.Gui.Tools;
using System.Timers;

#endregion

namespace NinjaTrader.NinjaScript.Indicators
{
	public class CheckHotKeyAfterChartTraderButtonPressExample : Indicator
	{
		private System.Windows.Controls.RowDefinition	addedRow1, addedRow2;
		private Gui.Chart.ChartTab						chartTab;
		private Gui.Chart.Chart							chartWindow;
		private System.Windows.Controls.Grid			chartTraderGrid, chartTraderButtonsGrid, lowerButtonsGrid, upperButtonsGrid;
		private System.Windows.Controls.Button[]		buttonsArray;
		private bool									panelActive;
		private System.Windows.Controls.TabItem			tabItem;
		
		private Account myAccount;
		private ChartScale MyChartScale;
		
		private bool gButtonReadyToSubmit = false;
		private bool gHotKeyReadyToSubmit = false;	
		private bool gButtonNeedsNewBrush = false;
		
//		private Timer 	timerToCheck;
//		private Timer 	timerToWait;
//		private bool 	timerToWaitStarted 	= false;
		
		private System.Windows.Forms.Timer 	timerToCheck;
		private System.Windows.Forms.Timer 	timerToWait;
		private bool 	timerToWaitStarted 	= false;

		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description					= "CheckHotKeyAfterChartTraderButtonPressExample";
				Name						= "CheckHotKeyAfterChartTraderButtonPressExample";
				Calculate					= Calculate.OnBarClose;
				IsOverlay					= true;
				DisplayInDataBox			= false;
				PaintPriceMarkers			= false;
				
				AccountName					= "Sim101";
			}
			else if (State == State.Configure)
			{
				if (timerToCheck == null)
				{
					timerToCheck 		= new System.Windows.Forms.Timer();
					
					timerToCheck.Tick += new EventHandler(TimerToCheckEventProcessor);
					timerToCheck.Interval = 10;
					timerToCheck.Start();
				}
				
				if (timerToWait == null)
				{
					timerToWait 		= new System.Windows.Forms.Timer();
					timerToWait.Tick += new EventHandler(TimerToWaitEventProcessor);
					timerToWait.Interval = 250;
				}
			}
			else if (State == State.DataLoaded)
  			{
   				if (ChartControl != null)
					
    				ChartControl.MouseLeftButtonDown += LeftMouseDown;
				
				if (ChartControl != null)
					ChartPanel.MouseMove += ChartControl_MouseMove;	
				
				// Find our account
				lock (Account.All)
					myAccount = Account.All.FirstOrDefault(a => a.Name == AccountName);
				
//				timerToCheck = new System.Timers.Timer(10);
//		  		timerToCheck.Elapsed += TimerToCheckEventProcessor;
//				timerToCheck.Enabled = true;
				
//				timerToWait = new System.Timers.Timer(250);
//		  		timerToWait.Elapsed += TimerToWaitEventProcessor;
//				timerToWait.Enabled = true;				
   			}
			else if (State == State.Historical)
			{
				if (ChartControl != null)
				{
					ChartControl.Dispatcher.InvokeAsync(() =>
					{
						CreateWPFControls();
					});
				}
			}
			else if (State == State.Terminated)
			{
				if (ChartControl != null)
				{
					ChartControl.Dispatcher.InvokeAsync(() =>
					{
						DisposeWPFControls();
					});
				}
				
				if (ChartControl != null)
	     			ChartControl.MouseLeftButtonDown -= LeftMouseDown;
				
				if (ChartControl != null)
					ChartPanel.MouseMove -= ChartControl_MouseMove;
				
				if (timerToCheck != null)
					timerToCheck.Dispose();
				if (timerToWait != null)
					timerToWait.Dispose();
			}
		}

		protected void Button1Click(object sender, RoutedEventArgs e)
		{
			Draw.TextFixed(this, "infobox", "Button 1 Clicked", TextPosition.BottomLeft, Brushes.DarkOrange, new Gui.Tools.SimpleFont("Arial", 25), Brushes.Transparent, Brushes.Transparent, 100);
			ForceRefresh();
		}

		protected void Button2Click(object sender, RoutedEventArgs e)
		{
			gButtonReadyToSubmit = !gButtonReadyToSubmit;
			
			if (gButtonReadyToSubmit)
				buttonsArray[1].Content = "Rdy";
			else
				buttonsArray[1].Content = "Not Rdy";			
			
			Draw.TextFixed(this, "infobox", "Button 2 Clicked", TextPosition.BottomLeft, Brushes.DarkRed, new Gui.Tools.SimpleFont("Arial", 25), Brushes.Transparent, Brushes.Transparent, 100);
			ForceRefresh();
		}

		protected void Button3Click(object sender, RoutedEventArgs e)
		{
			Draw.TextFixed(this, "infobox", "Button 3 Clicked", TextPosition.BottomLeft, Brushes.DarkOrange, new Gui.Tools.SimpleFont("Arial", 25), Brushes.Transparent, Brushes.Transparent, 100);
			ForceRefresh();
		}

		protected void Button4Click(object sender, RoutedEventArgs e)
		{
			Draw.TextFixed(this, "infobox", "Button 4 Clicked", TextPosition.BottomLeft, Brushes.CadetBlue, new Gui.Tools.SimpleFont("Arial", 25), Brushes.Transparent, Brushes.Transparent, 100);
			ForceRefresh();
		}

		protected void CreateWPFControls()
		{
			chartWindow				= Window.GetWindow(ChartControl.Parent) as Gui.Chart.Chart;

			// if not added to a chart, do nothing
			if (chartWindow == null)
				return;

			// this is the entire chart trader area grid
			chartTraderGrid			= (chartWindow.FindFirst("ChartWindowChartTraderControl") as Gui.Chart.ChartTrader).Content as System.Windows.Controls.Grid;

			// this grid contains the existing chart trader buttons
			chartTraderButtonsGrid	= chartTraderGrid.Children[0] as System.Windows.Controls.Grid;

			// this grid is a grid i'm adding to a new row (at the bottom) in the grid that contains bid and ask prices and order controls (chartTraderButtonsGrid)
			upperButtonsGrid = new System.Windows.Controls.Grid();
			System.Windows.Controls.Grid.SetColumnSpan(upperButtonsGrid, 3);

			upperButtonsGrid.ColumnDefinitions.Add(new System.Windows.Controls.ColumnDefinition());
			upperButtonsGrid.ColumnDefinitions.Add(new System.Windows.Controls.ColumnDefinition() { Width = new GridLength((double)Application.Current.FindResource("MarginBase")) }); // separator column
			upperButtonsGrid.ColumnDefinitions.Add(new System.Windows.Controls.ColumnDefinition());

			// this grid is to organize stuff below
			lowerButtonsGrid = new System.Windows.Controls.Grid();
			System.Windows.Controls.Grid.SetColumnSpan(lowerButtonsGrid, 4);

			lowerButtonsGrid.ColumnDefinitions.Add(new System.Windows.Controls.ColumnDefinition());
			lowerButtonsGrid.ColumnDefinitions.Add(new System.Windows.Controls.ColumnDefinition() { Width = new GridLength((double)Application.Current.FindResource("MarginBase")) });
			lowerButtonsGrid.ColumnDefinitions.Add(new System.Windows.Controls.ColumnDefinition());

			// these rows will be added later, but we can create them now so they only get created once
			addedRow1	= new System.Windows.Controls.RowDefinition() { Height = new GridLength(31) };
			addedRow2	= new System.Windows.Controls.RowDefinition() { Height = new GridLength(40) };

			// this style (provided by NinjaTrader_MichaelM) gives the correct default minwidth (and colors) to make buttons appear like chart trader buttons
			Style basicButtonStyle	= Application.Current.FindResource("BasicEntryButton") as Style;

			// all of the buttons are basically the same so to save lines of code I decided to use a loop over an array
			buttonsArray = new System.Windows.Controls.Button[4];

			for (int i = 0; i < 4; ++i)
			{
				buttonsArray[i]	= new System.Windows.Controls.Button()
				{
					Content			= string.Format("MyButton{0}", i + 1),
					Height			= 30,
					Margin			= new Thickness(0,0,0,0),
					Padding			= new Thickness(0,0,0,0),
					Style			= basicButtonStyle
				};

				// change colors of the buttons if you'd like. i'm going to change the first and fourth.
				if (i % 3 != 0)
				{
					buttonsArray[i].Background	= Brushes.Gray;
					buttonsArray[i].BorderBrush	= Brushes.DimGray;
				}
			}

			buttonsArray[0].Click += Button1Click;
			buttonsArray[1].Click += Button2Click;
			buttonsArray[2].Click += Button3Click;
			buttonsArray[3].Click += Button4Click;

			System.Windows.Controls.Grid.SetColumn(buttonsArray[1], 2);
			// add button3 to the lower grid
			System.Windows.Controls.Grid.SetColumn(buttonsArray[2], 0);
			// add button4 to the lower grid
			System.Windows.Controls.Grid.SetColumn(buttonsArray[3], 2);
			for (int i = 0; i < 2; ++i)
				upperButtonsGrid.Children.Add(buttonsArray[i]);
			for (int i = 2; i < 4; ++i)
				lowerButtonsGrid.Children.Add(buttonsArray[i]);

			if (TabSelected())
				InsertWPFControls();

			chartWindow.MainTabControl.SelectionChanged += TabChangedHandler;
		}

		public void DisposeWPFControls()
		{
			if (chartWindow != null)
				chartWindow.MainTabControl.SelectionChanged -= TabChangedHandler;

			if (buttonsArray[0] != null)
				buttonsArray[0].Click -= Button1Click;
			if (buttonsArray[0] != null)
				buttonsArray[1].Click -= Button2Click;
			if (buttonsArray[0] != null)
				buttonsArray[2].Click -= Button3Click;
			if (buttonsArray[0] != null)
				buttonsArray[3].Click -= Button4Click;

			RemoveWPFControls();
		}
		
		public void InsertWPFControls()
		{
			if (panelActive)
				return;

			// add a new row (addedRow1) for upperButtonsGrid to the existing buttons grid
			chartTraderButtonsGrid.RowDefinitions.Add(addedRow1);
			// set our upper grid to that new panel
			System.Windows.Controls.Grid.SetRow(upperButtonsGrid, (chartTraderButtonsGrid.RowDefinitions.Count - 1));
			// and add it to the buttons grid
			chartTraderButtonsGrid.Children.Add(upperButtonsGrid);
			
			// add a new row (addedRow2) for our lowerButtonsGrid below the ask and bid prices and pnl display			
			chartTraderGrid.RowDefinitions.Add(addedRow2);
			System.Windows.Controls.Grid.SetRow(lowerButtonsGrid, (chartTraderGrid.RowDefinitions.Count - 1));
			chartTraderGrid.Children.Add(lowerButtonsGrid);

			panelActive = true;
		}

		protected override void OnBarUpdate() { }

		protected void RemoveWPFControls()
		{
			if (!panelActive)
				return;

			if (chartTraderButtonsGrid != null || upperButtonsGrid != null)
			{
				chartTraderButtonsGrid.Children.Remove(upperButtonsGrid);
				chartTraderButtonsGrid.RowDefinitions.Remove(addedRow1);
			}
			
			if (chartTraderButtonsGrid != null || lowerButtonsGrid != null)
			{
				chartTraderGrid.Children.Remove(lowerButtonsGrid);
				chartTraderGrid.RowDefinitions.Remove(addedRow2);
			}

			panelActive = false;
		}

		private bool TabSelected()
		{
			bool tabSelected = false;

			// loop through each tab and see if the tab this indicator is added to is the selected item
			foreach (System.Windows.Controls.TabItem tab in chartWindow.MainTabControl.Items)
				if ((tab.Content as Gui.Chart.ChartTab).ChartControl == ChartControl && tab == chartWindow.MainTabControl.SelectedItem)
					tabSelected = true;

			return tabSelected;
		}

		private void TabChangedHandler(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
		{
			if (e.AddedItems.Count <= 0)
				return;

			tabItem = e.AddedItems[0] as System.Windows.Controls.TabItem;
			if (tabItem == null)
				return;

			chartTab = tabItem.Content as Gui.Chart.ChartTab;
			if (chartTab == null)
				return;

			if (TabSelected())
				InsertWPFControls();
			else
				RemoveWPFControls();
		}
		
		protected void LeftMouseDown(object sender, MouseButtonEventArgs e)
		{
			if (gButtonReadyToSubmit && gHotKeyReadyToSubmit)
			{
				TriggerCustomEvent(o =>
				{
					int Y = ChartingExtensions.ConvertToVerticalPixels(e.GetPosition(ChartControl as IInputElement).Y, ChartControl.PresentationSource);
					
					double priceClicked = MyChartScale.GetValueByY(Y);
				
					Order limitOrder = null;
					Order stopOrder = null;

					if (priceClicked > Close[0])
					{
						limitOrder = myAccount.CreateOrder(Instrument, OrderAction.Sell, OrderType.Limit, OrderEntry.Manual, TimeInForce.Day, 1, priceClicked, 0, "", "limitOrder"+DateTime.Now.ToString(), DateTime.MaxValue, null);
						stopOrder  = myAccount.CreateOrder(Instrument, OrderAction.Buy, OrderType.StopMarket, OrderEntry.Manual, TimeInForce.Day, 1, 0, priceClicked, "", "stopOrder"+DateTime.Now.ToString(), DateTime.MaxValue, null);
					}
					else
					{
						limitOrder = myAccount.CreateOrder(Instrument, OrderAction.Buy, OrderType.Limit, OrderEntry.Manual, TimeInForce.Day, 1, priceClicked, 0, "", "limitOrder"+DateTime.Now.ToString(), DateTime.MaxValue, null);
						stopOrder  = myAccount.CreateOrder(Instrument, OrderAction.Sell, OrderType.StopMarket, OrderEntry.Manual, TimeInForce.Day, 1, 0, priceClicked, "", "stopOrder"+DateTime.Now.ToString(), DateTime.MaxValue, null);
					}
					
					myAccount.Submit(new[] { limitOrder, stopOrder });
				}, null);
				e.Handled = true;
			}
		}
		
		void ChartControl_MouseMove (object sender, System.Windows.Input.MouseEventArgs e)
		{

		}		
		
		private void TimerToWaitEventProcessor(Object myObject, EventArgs myEventArgs)
		{
			timerToWait.Stop();
			timerToWaitStarted = false;
		}
		
		private void TimerToCheckEventProcessor(Object myObject, EventArgs myEventArgs)
		{
			if (Keyboard.Modifiers == ModifierKeys.Alt && Keyboard.IsKeyDown(Key.A) && !timerToWaitStarted)
			{
				gHotKeyReadyToSubmit = true;
				gButtonNeedsNewBrush = true;
				
				timerToWait.Start();
				timerToWaitStarted = true;
			}
			else if (!timerToWaitStarted)
			{
				gHotKeyReadyToSubmit = false;
				gButtonNeedsNewBrush = true;
			}
			
			if (gButtonNeedsNewBrush)
			{
				ChartControl.Dispatcher.InvokeAsync((Action)(() =>
               	{
                    if (buttonsArray[1] != null && gHotKeyReadyToSubmit)
						buttonsArray[1].Background = Brushes.Yellow;
					else if (buttonsArray[1] != null && !gHotKeyReadyToSubmit)
						buttonsArray[1].Background = Brushes.Gray;
                }));
				
				gButtonNeedsNewBrush = false;
			}
		}
		
		protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
		{
			base.OnRender(chartControl, chartScale);
			
			MyChartScale = chartScale;
		}
		
		[TypeConverter(typeof(NinjaTrader.NinjaScript.AccountNameConverter))]
		public string AccountName { get; set; }
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private CheckHotKeyAfterChartTraderButtonPressExample[] cacheCheckHotKeyAfterChartTraderButtonPressExample;
		public CheckHotKeyAfterChartTraderButtonPressExample CheckHotKeyAfterChartTraderButtonPressExample()
		{
			return CheckHotKeyAfterChartTraderButtonPressExample(Input);
		}

		public CheckHotKeyAfterChartTraderButtonPressExample CheckHotKeyAfterChartTraderButtonPressExample(ISeries<double> input)
		{
			if (cacheCheckHotKeyAfterChartTraderButtonPressExample != null)
				for (int idx = 0; idx < cacheCheckHotKeyAfterChartTraderButtonPressExample.Length; idx++)
					if (cacheCheckHotKeyAfterChartTraderButtonPressExample[idx] != null &&  cacheCheckHotKeyAfterChartTraderButtonPressExample[idx].EqualsInput(input))
						return cacheCheckHotKeyAfterChartTraderButtonPressExample[idx];
			return CacheIndicator<CheckHotKeyAfterChartTraderButtonPressExample>(new CheckHotKeyAfterChartTraderButtonPressExample(), input, ref cacheCheckHotKeyAfterChartTraderButtonPressExample);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.CheckHotKeyAfterChartTraderButtonPressExample CheckHotKeyAfterChartTraderButtonPressExample()
		{
			return indicator.CheckHotKeyAfterChartTraderButtonPressExample(Input);
		}

		public Indicators.CheckHotKeyAfterChartTraderButtonPressExample CheckHotKeyAfterChartTraderButtonPressExample(ISeries<double> input )
		{
			return indicator.CheckHotKeyAfterChartTraderButtonPressExample(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.CheckHotKeyAfterChartTraderButtonPressExample CheckHotKeyAfterChartTraderButtonPressExample()
		{
			return indicator.CheckHotKeyAfterChartTraderButtonPressExample(Input);
		}

		public Indicators.CheckHotKeyAfterChartTraderButtonPressExample CheckHotKeyAfterChartTraderButtonPressExample(ISeries<double> input )
		{
			return indicator.CheckHotKeyAfterChartTraderButtonPressExample(input);
		}
	}
}

#endregion
