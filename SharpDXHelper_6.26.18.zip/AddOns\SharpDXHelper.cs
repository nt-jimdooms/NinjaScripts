#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.Gui.Tools;
#endregion

//This namespace holds Add ons in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript
{
	public class DXHelper
	{
		// Dictionary for keeping track of DX brushes made from user defined brushes.
		public Dictionary<string, DXMediaBrush> DXMBrushes;
		
		// Dictionaries for tracking Helper Managed Brushes and usage
		private Dictionary<string, DXMediaBrush> HelperManagedBrushes;
		private Dictionary<string, bool> HelperManagedBrushesUsed;
		
		// Timer to check how often our Helper Managed Brushes are used.
		private Timer 	timerToCheck;
		
		private Dictionary<string, SharpDX.Direct2D1.Bitmap> bitmapDictionary;
		private Dictionary<string, SharpDX.IO.NativeFileStream> fileStreamDictionary;
		private Dictionary<string, SharpDX.WIC.BitmapDecoder> bitmapDecoderDictionary;
		private Dictionary<string, SharpDX.WIC.FormatConverter> converterDictionary;
		private Dictionary<string, SharpDX.WIC.BitmapFrameDecode> frameDictionary;
		
		private List<string> bitmapList;
		
		// Constructor
		public DXHelper()
		{
			DXMBrushes = new Dictionary<string, DXMediaBrush>();
		}
		
		// Constructor for Helper Managed Brushes
		public DXHelper(bool AllowHelperManagedBrushes, ChartControl chartControl)
		{
			DXMBrushes = new Dictionary<string, DXMediaBrush>();
			
			if (AllowHelperManagedBrushes)
			{
				HelperManagedBrushes = new Dictionary<string, DXMediaBrush>();
				HelperManagedBrushesUsed = new Dictionary<string, bool>();
				
				chartControl.Dispatcher.InvokeAsync(new Action(() => 
				{
					timerToCheck 		= new Timer();
					
					timerToCheck.Tick += new EventHandler(TimerToCheckEventProcessor);
					timerToCheck.Interval = 1000*60*5;
					timerToCheck.Start();
				}));
				
				bitmapDictionary = new Dictionary<string, SharpDX.Direct2D1.Bitmap>();
				fileStreamDictionary = new Dictionary<string, SharpDX.IO.NativeFileStream>();
				bitmapDecoderDictionary = new Dictionary<string, SharpDX.WIC.BitmapDecoder>();
				converterDictionary = new Dictionary<string, SharpDX.WIC.FormatConverter>();
				frameDictionary = new  Dictionary<string, SharpDX.WIC.BitmapFrameDecode>();
				bitmapList = new List<string>();
			}
		}
		
		// Destructor
		public void Dispose()
		{
			if (timerToCheck != null)
			{
				timerToCheck.Stop();
  				timerToCheck.Tick -= new EventHandler(TimerToCheckEventProcessor);
				timerToCheck.Dispose();
			}
			
			DisposeBitmapResources();
		}
		
		#region User created brushes
		public void AddBrushes(string[] brushNames)
		{
			foreach (string brushName in brushNames)
        		DXMBrushes.Add(brushName, new DXMediaBrush());
		}
		
		public void UpdateBrush(SharpDX.Direct2D1.RenderTarget renderTarget, string brushName, Brush brush)
		{
			DXMBrushes[brushName].UpdateBrush(renderTarget, brush);
		}
		
		public void UpdateBrush(SharpDX.Direct2D1.RenderTarget renderTarget, string brushName, Brush brush, double opacity)
		{
			DXMBrushes[brushName].UpdateBrush(renderTarget, brush, opacity);
		}
        #endregion

        #region Helper created brushes

        private string GetBrushString(Brush brush)
        {
            string a = ((Color)brush.GetValue(SolidColorBrush.ColorProperty)).A.ToString();
            string r = ((Color)brush.GetValue(SolidColorBrush.ColorProperty)).R.ToString();
            string g = ((Color)brush.GetValue(SolidColorBrush.ColorProperty)).G.ToString();
            string b = ((Color)brush.GetValue(SolidColorBrush.ColorProperty)).B.ToString();
           
            return a + r + g + b;
        }

        private void HelperCheckAddBrush(SharpDX.Direct2D1.RenderTarget renderTarget, Brush brush)
		{
			bool foundBrush = false;

            string brushString = GetBrushString(brush);
			
			// Check if brush already exists
			foreach (string brushToFind in HelperManagedBrushes.Keys)
				if (brushToFind == brushString)
					foundBrush = true;

            if (!foundBrush)
			{
				// Brush was not found, add new brush
        		HelperManagedBrushes.Add(brushString, new DXMediaBrush());
				HelperManagedBrushes[brushString].UpdateBrush(renderTarget, brush, brush.Opacity * 100.0);
				
				// Add brush to activity dictionar and mark as used
				HelperManagedBrushesUsed.Add(brushString, true);
			}
			else
				HelperManagedBrushesUsed[brushString] = true;
			
		}
		
		private void HelperCheckUnusedBrushes()
		{
			if(HelperManagedBrushes == null || HelperManagedBrushesUsed == null)
				return;
			
			bool brushFound = false;
			bool brushUsed = false;
			string brushString = null;
			foreach (KeyValuePair<string, bool> item in HelperManagedBrushesUsed)
			{
    	    	if (item.Value == true)
				{
					brushFound = true;
					brushUsed = true;
					brushString = item.Key;	
				}
				else 
				{
					brushFound = true;
					brushUsed = false;
					brushString = item.Key;	
				}
			}
			
			if (brushFound && !brushUsed)
			{
				// Dispose and remove unused brushes
				HelperManagedBrushes[brushString].Dispose();
				HelperManagedBrushes.Remove(brushString);
				
				// Reomve unused brush from activity dictionary
				HelperManagedBrushesUsed.Remove(brushString);
			}
			else if (brushFound && brushUsed)
			{
				// Mark Brush as unused for next check
				HelperManagedBrushesUsed[brushString] = false;
			}
		}
		
		private void TimerToCheckEventProcessor(Object myObject, EventArgs myEventArgs)
		{
			HelperCheckUnusedBrushes();
		}
		#endregion
		
		public void RenderTargetChange(SharpDX.Direct2D1.RenderTarget renderTarget)
		{
			if (renderTarget == null || renderTarget.IsDisposed)
				return;
			
			if (DXMBrushes != null)
				foreach (KeyValuePair<string, DXMediaBrush> item in DXMBrushes)
        	    	item.Value.RenderTargetChange(renderTarget);
			
			if (HelperManagedBrushes != null)
				foreach (KeyValuePair<string, DXMediaBrush> item in HelperManagedBrushes)
        	    	item.Value.RenderTargetChange(renderTarget);
				
			DisposeBitmapResources();
			CreateBitmapResources(renderTarget);
		}
		
		#region DrawLine
		#region SharpDX Brushes
		/// <summary>
		/// Draws a line between two points.
		/// </summary>
		/// <param name="renderTarget">The hosting NinjaScript's RenderTarget</param>
		/// <param name="brush">A SharpDX Brush used for the line</param>
		/// <param name="startPoint">SharpDX Start Coordinate Point</param>
		/// <param name="endPoint">SharpDX End Coordinate Point</param>
		/// <param name="width">Line Width</param>
		/// <param name="strokeStyle">SharpDX StrokeStyle to use for line</param>
		/// <returns></returns>
		// Condense Line drawing code
		public void DrawLine(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.Brush brush, SharpDX.Vector2 startPoint, SharpDX.Vector2 endPoint, float width, SharpDX.Direct2D1.StrokeStyle strokeStyle)
		{
			// Draw the line
			renderTarget.DrawLine(startPoint, endPoint, brush, width, strokeStyle);
			
			// StrokeStyle is device-independant and does not need to be Disposed after each OnRender() or OnRenderTargetChanged() call, but is for good housekeeping and garbage collection
			strokeStyle.Dispose();
			strokeStyle = null;
		}
		
		/// <summary>
		/// Draws a line between two points.
		/// </summary>
		/// <param name="renderTarget">The hosting NinjaScript's RenderTarget</param>
		/// <param name="brush">A SharpDX Brush used for the line</param>
		/// <param name="x1">X Start Coordinate</param>
		/// <param name="y1">Y Start Coordinate</param>
		/// <param name="x2">X End Coordinate</param>
		/// <param name="y2">Y End Coordinate</param>
		/// <param name="width">Line Width</param>
		/// <param name="strokeStyle">StrokeStyle to use for line</param>
		/// <returns></returns>
		public void DrawLine(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.Brush brush, double x1, double y1, double x2, double y2, float width, SharpDX.Direct2D1.StrokeStyle strokeStyle)
		{			
			// Create Vector2 coordinates
			SharpDX.Vector2 startPoint 	= new System.Windows.Point(x1, y1).ToVector2();
			SharpDX.Vector2 endPoint 	= new System.Windows.Point(x2, y2).ToVector2();
			
			DrawLine(renderTarget, brush, startPoint, endPoint, width, strokeStyle);
			
			// StrokeStyle is device-independant and does not need to be Disposed after each OnRender() or OnRenderTargetChanged() call, but is for good housekeeping and garbage collection
			strokeStyle.Dispose();
			strokeStyle = null;
		}
		
		/// <summary>
		/// Draws a line between two points.
		/// </summary>
		/// <param name="renderTarget">The hosting NinjaScript's RenderTarget</param>
		/// <param name="brush">A SharpDX Brush used for the line</param>
		/// <param name="startPoint">Windows Point Start Coordinate pair</param>
		/// <param name="endPoint">Windows Point End Coordinate pair</param>
		/// <param name="width">Line Width</param>
		/// <param name="strokeStyle">StrokeStyle to use for line</param>
		/// <returns></returns>
		public void DrawLine(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.Brush brush, System.Windows.Point startPoint, System.Windows.Point endPoint, float width, SharpDX.Direct2D1.StrokeStyle strokeStyle)
		{
			// Create Vector2 coordinates
			SharpDX.Vector2 startPointDX 	= startPoint.ToVector2();
			SharpDX.Vector2 endPointDX 		= endPoint.ToVector2();
			
			DrawLine(renderTarget, brush, startPointDX, endPointDX, width, strokeStyle);
			
			// StrokeStyle is device-independant and does not need to be Disposed after each OnRender() or OnRenderTargetChanged() call, but is for good housekeeping and garbage collection
			strokeStyle.Dispose();
			strokeStyle = null;
		}		
		
		/// <summary>
		/// Draws a line between two points.
		/// </summary>
		/// <param name="renderTarget">The hosting NinjaScript's RenderTarget</param>
		/// <param name="brush">A SharpDX Brush used for the line</param>
		/// <param name="startPoint">SharpDX Start Coordinate pair</param>
		/// <param name="endPoint">SharpDX End Coordinate pair</param>
		/// <param name="width">Line Width</param>
		/// <param name="dashStyle">DashStyle to use for line</param>
		/// <returns></returns>
		public void DrawLine(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.Brush brush, SharpDX.Vector2 startPoint, SharpDX.Vector2 endPoint, float width, DashStyleHelper dashStyle)
		{
			// Create StrokeStyleProperties
			SharpDX.Direct2D1.StrokeStyleProperties ssProps = new SharpDX.Direct2D1.StrokeStyleProperties();
			
			switch (dashStyle)
			{
				case DashStyleHelper.Dash: 			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Dash; 		break;
				case DashStyleHelper.DashDot: 		ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.DashDot; 	break;
				case DashStyleHelper.DashDotDot:	ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.DashDotDot;	break;
				case DashStyleHelper.Dot:			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Dot;		break;
				case DashStyleHelper.Solid:			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Solid;		break;
				default: 							ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Solid;		break;
			}
			
			// Create StrokeStyle from StrokeStyleProperties
			SharpDX.Direct2D1.StrokeStyle strokeStyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, ssProps);
			
			DrawLine(renderTarget, brush, startPoint, endPoint, width, strokeStyle);
			
			// StrokeStyle is device-independant and does not need to be Disposed after each OnRender() or OnRenderTargetChanged() call, but is for good housekeeping and garbage collection
			strokeStyle.Dispose();
			strokeStyle = null;
		}
		
		/// <summary>
		/// Draws a line between two points.
		/// </summary>
		/// <param name="renderTarget">The hosting NinjaScript's RenderTarget</param>
		/// <param name="brush">A SharpDX Brush used for the line</param>
		/// <param name="startPoint">Windows Point Start Coordinate pair</param>
		/// <param name="endPoint">Windows Point End Coordinate pair</param>
		/// <param name="width">Line Width</param>
		/// <param name="dashStyle">DashStyle to use for line</param>
		/// <returns></returns>
		public void DrawLine(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.Brush brush, System.Windows.Point startPoint, System.Windows.Point endPoint, float width, DashStyleHelper dashStyle)
		{
			// Create Vector2 coordinates
			SharpDX.Vector2 startPointDX 	= startPoint.ToVector2();
			SharpDX.Vector2 endPointDX 		= endPoint.ToVector2();
			
			DrawLine(renderTarget, brush, startPointDX, endPointDX, width, dashStyle);
		}
		
		/// <summary>
		/// Draws a line between two points.
		/// </summary>
		/// <param name="renderTarget">The hosting NinjaScript's RenderTarget</param>
		/// <param name="brush">A SharpDX Brush used for the line</param>
		/// <param name="x1">X Start Coordinate</param>
		/// <param name="y1">Y Start Coordinate</param>
		/// <param name="x2">X End Coordinate</param>
		/// <param name="y2">Y End Coordinate</param>
		/// <param name="width">Line Width</param>
		/// <param name="dashStyle">DashStyle to use for line</param>
		/// <returns></returns>
		public void DrawLine(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.Brush brush, double x1, double y1, double x2, double y2, float width, DashStyleHelper dashStyle)
		{			
			// Create Vector2 coordinates
			SharpDX.Vector2 startPoint 	= new System.Windows.Point(x1, y1).ToVector2();
			SharpDX.Vector2 endPoint 	= new System.Windows.Point(x2, y2).ToVector2();
			
			DrawLine(renderTarget, brush, startPoint, endPoint, width, dashStyle);
		}
		#endregion
		
		#region DXMediaBrushes
		/// <summary>
		/// Draws a line between two points.
		/// </summary>
		/// <param name="renderTarget">The hosting NinjaScript's RenderTarget</param>
		/// <param name="brush">A DXMediaBrush used for the line</param>
		/// <param name="startPoint">SharpDX Start Coordinate Point</param>
		/// <param name="endPoint">SharpDX End Coordinate Point</param>
		/// <param name="width">Line Width</param>
		/// <param name="strokeStyle">SharpDX StrokeStyle to use for line</param>
		/// <returns></returns>
		// Condense Line drawing code
		public void DrawLine(SharpDX.Direct2D1.RenderTarget renderTarget, DXMediaBrush brush, SharpDX.Vector2 startPoint, SharpDX.Vector2 endPoint, float width, SharpDX.Direct2D1.StrokeStyle strokeStyle)
		{
			// Draw the line
			renderTarget.DrawLine(startPoint, endPoint, brush.DxBrush, width, strokeStyle);
			
			// StrokeStyle is device-independant and does not need to be Disposed after each OnRender() or OnRenderTargetChanged() call, but is for good housekeeping and garbage collection
			strokeStyle.Dispose();
			strokeStyle = null;
		}
		
		/// <summary>
		/// Draws a line between two points.
		/// </summary>
		/// <param name="renderTarget">The hosting NinjaScript's RenderTarget</param>
		/// <param name="brush">A DXMediaBrush used for the line</param>
		/// <param name="x1">X Start Coordinate</param>
		/// <param name="y1">Y Start Coordinate</param>
		/// <param name="x2">X End Coordinate</param>
		/// <param name="y2">Y End Coordinate</param>
		/// <param name="width">Line Width</param>
		/// <param name="strokeStyle">StrokeStyle to use for line</param>
		/// <returns></returns>
		public void DrawLine(SharpDX.Direct2D1.RenderTarget renderTarget, DXMediaBrush brush, double x1, double y1, double x2, double y2, float width, SharpDX.Direct2D1.StrokeStyle strokeStyle)
		{			
			// Create Vector2 coordinates
			SharpDX.Vector2 startPoint 	= new System.Windows.Point(x1, y1).ToVector2();
			SharpDX.Vector2 endPoint 	= new System.Windows.Point(x2, y2).ToVector2();
			
			DrawLine(renderTarget, brush, startPoint, endPoint, width, strokeStyle);
			
			// StrokeStyle is device-independant and does not need to be Disposed after each OnRender() or OnRenderTargetChanged() call, but is for good housekeeping and garbage collection
			strokeStyle.Dispose();
			strokeStyle = null;
		}
		
		/// <summary>
		/// Draws a line between two points.
		/// </summary>
		/// <param name="renderTarget">The hosting NinjaScript's RenderTarget</param>
		/// <param name="brush">A DXMediaBrush used for the line</param>
		/// <param name="startPoint">Windows Point Start Coordinate pair</param>
		/// <param name="endPoint">Windows Point End Coordinate pair</param>
		/// <param name="width">Line Width</param>
		/// <param name="strokeStyle">StrokeStyle to use for line</param>
		/// <returns></returns>
		// Condense Line drawing code
		public void DrawLine(SharpDX.Direct2D1.RenderTarget renderTarget, DXMediaBrush brush, System.Windows.Point startPoint, System.Windows.Point endPoint, float width, SharpDX.Direct2D1.StrokeStyle strokeStyle)
		{
			// Create Vector2 coordinates
			SharpDX.Vector2 startPointDX 	= startPoint.ToVector2();
			SharpDX.Vector2 endPointDX 		= endPoint.ToVector2();
			
			DrawLine(renderTarget, brush, startPointDX, endPointDX, width, strokeStyle);
			
			// StrokeStyle is device-independant and does not need to be Disposed after each OnRender() or OnRenderTargetChanged() call, but is for good housekeeping and garbage collection
			strokeStyle.Dispose();
			strokeStyle = null;
		}		
		
		/// <summary>
		/// Draws a line between two points.
		/// </summary>
		/// <param name="renderTarget">The hosting NinjaScript's RenderTarget</param>
		/// <param name="brush">A DXMediaBrush used for the line</param>
		/// <param name="startPoint">SharpDX Start Coordinate pair</param>
		/// <param name="endPoint">SharpDX End Coordinate pair</param>
		/// <param name="width">Line Width</param>
		/// <param name="dashStyle">DashStyle to use for line</param>
		/// <returns></returns>
		// Condense Line drawing code
		public void DrawLine(SharpDX.Direct2D1.RenderTarget renderTarget, DXMediaBrush brush, SharpDX.Vector2 startPoint, SharpDX.Vector2 endPoint, float width, DashStyleHelper dashStyle)
		{
			// Create StrokeStyleProperties
			SharpDX.Direct2D1.StrokeStyleProperties ssProps = new SharpDX.Direct2D1.StrokeStyleProperties();
			
			switch (dashStyle)
			{
				case DashStyleHelper.Dash: 			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Dash; 		break;
				case DashStyleHelper.DashDot: 		ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.DashDot; 	break;
				case DashStyleHelper.DashDotDot:	ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.DashDotDot;	break;
				case DashStyleHelper.Dot:			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Dot;		break;
				case DashStyleHelper.Solid:			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Solid;		break;
				default: 							ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Solid;		break;
			}
			
			// Create StrokeStyle from StrokeStyleProperties
			SharpDX.Direct2D1.StrokeStyle strokeStyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, ssProps);
			
			DrawLine(renderTarget, brush, startPoint, endPoint, width, strokeStyle);
			
			// StrokeStyle is device-independant and does not need to be Disposed after each OnRender() or OnRenderTargetChanged() call, but is for good housekeeping and garbage collection
			strokeStyle.Dispose();
			strokeStyle = null;
		}
		
		/// <summary>
		/// Draws a line between two points.
		/// </summary>
		/// <param name="renderTarget">The hosting NinjaScript's RenderTarget</param>
		/// <param name="brush">A DXMediaBrush used for the line</param>
		/// <param name="startPoint">Windows Point Start Coordinate pair</param>
		/// <param name="endPoint">Windows Point End Coordinate pair</param>
		/// <param name="width">Line Width</param>
		/// <param name="dashStyle">DashStyle to use for line</param>
		/// <returns></returns>
		// Condense Line drawing code
		public void DrawLine(SharpDX.Direct2D1.RenderTarget renderTarget, DXMediaBrush brush, System.Windows.Point startPoint, System.Windows.Point endPoint, float width, DashStyleHelper dashStyle)
		{
			// Create Vector2 coordinates
			SharpDX.Vector2 startPointDX 	= startPoint.ToVector2();
			SharpDX.Vector2 endPointDX 		= endPoint.ToVector2();
			
			DrawLine(renderTarget, brush, startPointDX, endPointDX, width, dashStyle);
		}
		
		/// <summary>
		/// Draws a line between two points.
		/// </summary>
		/// <param name="renderTarget">The hosting NinjaScript's RenderTarget</param>
		/// <param name="brush">A DXMediaBrush used for the line</param>
		/// <param name="x1">X Start Coordinate</param>
		/// <param name="y1">Y Start Coordinate</param>
		/// <param name="x2">X End Coordinate</param>
		/// <param name="y2">Y End Coordinate</param>
		/// <param name="width">Line Width</param>
		/// <param name="dashStyle">DashStyle to use for line</param>
		/// <returns></returns>
		public void DrawLine(SharpDX.Direct2D1.RenderTarget renderTarget, DXMediaBrush brush, double x1, double y1, double x2, double y2, float width, DashStyleHelper dashStyle)
		{			
			// Create Vector2 coordinates
			SharpDX.Vector2 startPoint 	= new System.Windows.Point(x1, y1).ToVector2();
			SharpDX.Vector2 endPoint 	= new System.Windows.Point(x2, y2).ToVector2();
			
			DrawLine(renderTarget, brush, startPoint, endPoint, width, dashStyle);
		}
		#endregion
		
		#region Dictionary Brushes
		/// <summary>
		/// Draws a line between two points.
		/// </summary>
		/// <param name="renderTarget">The hosting NinjaScript's RenderTarget</param>
		/// <param name="brush">A string key for a DXMediaBrush used for the line</param>
		/// <param name="startPoint">SharpDX Start Coordinate Point</param>
		/// <param name="endPoint">SharpDX End Coordinate Point</param>
		/// <param name="width">Line Width</param>
		/// <param name="strokeStyle">SharpDX StrokeStyle to use for line</param>
		/// <returns></returns>
		// Condense Line drawing code
		public void DrawLine(SharpDX.Direct2D1.RenderTarget renderTarget, string brush, SharpDX.Vector2 startPoint, SharpDX.Vector2 endPoint, float width, SharpDX.Direct2D1.StrokeStyle strokeStyle)
		{
			// Draw the line
			renderTarget.DrawLine(startPoint, endPoint, DXMBrushes[brush].DxBrush, width, strokeStyle);
			
			// StrokeStyle is device-independant and does not need to be Disposed after each OnRender() or OnRenderTargetChanged() call, but is for good housekeeping and garbage collection
			strokeStyle.Dispose();
			strokeStyle = null;
		}
		
		/// <summary>
		/// Draws a line between two points.
		/// </summary>
		/// <param name="renderTarget">The hosting NinjaScript's RenderTarget</param>
		/// <param name="brush">A string key for a DXMediaBrush used for the line</param>
		/// <param name="x1">X Start Coordinate</param>
		/// <param name="y1">Y Start Coordinate</param>
		/// <param name="x2">X End Coordinate</param>
		/// <param name="y2">Y End Coordinate</param>
		/// <param name="width">Line Width</param>
		/// <param name="strokeStyle">StrokeStyle to use for line</param>
		/// <returns></returns>
		public void DrawLine(SharpDX.Direct2D1.RenderTarget renderTarget, string brush, double x1, double y1, double x2, double y2, float width, SharpDX.Direct2D1.StrokeStyle strokeStyle)
		{			
			// Create Vector2 coordinates
			SharpDX.Vector2 startPoint 	= new System.Windows.Point(x1, y1).ToVector2();
			SharpDX.Vector2 endPoint 	= new System.Windows.Point(x2, y2).ToVector2();
			
			DrawLine(renderTarget, brush, startPoint, endPoint, width, strokeStyle);
			
			// StrokeStyle is device-independant and does not need to be Disposed after each OnRender() or OnRenderTargetChanged() call, but is for good housekeeping and garbage collection
			strokeStyle.Dispose();
			strokeStyle = null;
		}
		
		/// <summary>
		/// Draws a line between two points.
		/// </summary>
		/// <param name="renderTarget">The hosting NinjaScript's RenderTarget</param>
		/// <param name="brush">A string key for a DXMediaBrush used for the line</param>
		/// <param name="startPoint">Windows Point Start Coordinate pair</param>
		/// <param name="endPoint">Windows Point End Coordinate pair</param>
		/// <param name="width">Line Width</param>
		/// <param name="strokeStyle">StrokeStyle to use for line</param>
		/// <returns></returns>
		public void DrawLine(SharpDX.Direct2D1.RenderTarget renderTarget, string brush, System.Windows.Point startPoint, System.Windows.Point endPoint, float width, SharpDX.Direct2D1.StrokeStyle strokeStyle)
		{
			// Create Vector2 coordinates
			SharpDX.Vector2 startPointDX 	= startPoint.ToVector2();
			SharpDX.Vector2 endPointDX 		= endPoint.ToVector2();
			
			DrawLine(renderTarget, brush, startPointDX, endPointDX, width, strokeStyle);
			
			// StrokeStyle is device-independant and does not need to be Disposed after each OnRender() or OnRenderTargetChanged() call, but is for good housekeeping and garbage collection
			strokeStyle.Dispose();
			strokeStyle = null;
		}		
		
		/// <summary>
		/// Draws a line between two points.
		/// </summary>
		/// <param name="renderTarget">The hosting NinjaScript's RenderTarget</param>
		/// <param name="brush">A string key for a DXMediaBrush used for the line</param>
		/// <param name="startPoint">SharpDX Start Coordinate pair</param>
		/// <param name="endPoint">SharpDX End Coordinate pair</param>
		/// <param name="width">Line Width</param>
		/// <param name="dashStyle">DashStyle to use for line</param>
		/// <returns></returns>
		public void DrawLine(SharpDX.Direct2D1.RenderTarget renderTarget, string brush, SharpDX.Vector2 startPoint, SharpDX.Vector2 endPoint, float width, DashStyleHelper dashStyle)
		{
			// Create StrokeStyleProperties
			SharpDX.Direct2D1.StrokeStyleProperties ssProps = new SharpDX.Direct2D1.StrokeStyleProperties();
			
			switch (dashStyle)
			{
				case DashStyleHelper.Dash: 			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Dash; 		break;
				case DashStyleHelper.DashDot: 		ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.DashDot; 	break;
				case DashStyleHelper.DashDotDot:	ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.DashDotDot;	break;
				case DashStyleHelper.Dot:			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Dot;		break;
				case DashStyleHelper.Solid:			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Solid;		break;
				default: 							ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Solid;		break;
			}
			
			// Create StrokeStyle from StrokeStyleProperties
			SharpDX.Direct2D1.StrokeStyle strokeStyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, ssProps);
			
			DrawLine(renderTarget, brush, startPoint, endPoint, width, strokeStyle);
			
			// StrokeStyle is device-independant and does not need to be Disposed after each OnRender() or OnRenderTargetChanged() call, but is for good housekeeping and garbage collection
			strokeStyle.Dispose();
			strokeStyle = null;
		}
		
		/// <summary>
		/// Draws a line between two points.
		/// </summary>
		/// <param name="renderTarget">The hosting NinjaScript's RenderTarget</param>
		/// <param name="brush">A string key for a DXMediaBrush used for the line</param>
		/// <param name="startPoint">Windows Point Start Coordinate pair</param>
		/// <param name="endPoint">Windows Point End Coordinate pair</param>
		/// <param name="width">Line Width</param>
		/// <param name="dashStyle">DashStyle to use for line</param>
		/// <returns></returns>
		public void DrawLine(SharpDX.Direct2D1.RenderTarget renderTarget, string brush, System.Windows.Point startPoint, System.Windows.Point endPoint, float width, DashStyleHelper dashStyle)
		{
			// Create Vector2 coordinates
			SharpDX.Vector2 startPointDX 	= startPoint.ToVector2();
			SharpDX.Vector2 endPointDX 		= endPoint.ToVector2();
			
			DrawLine(renderTarget, brush, startPointDX, endPointDX, width, dashStyle);
		}
		
		/// <summary>
		/// Draws a line between two points.
		/// </summary>
		/// <param name="renderTarget">The hosting NinjaScript's RenderTarget</param>
		/// <param name="brush">A string key for a DXMediaBrush used for the line</param>
		/// <param name="x1">X Start Coordinate</param>
		/// <param name="y1">Y Start Coordinate</param>
		/// <param name="x2">X End Coordinate</param>
		/// <param name="y2">Y End Coordinate</param>
		/// <param name="width">Line Width</param>
		/// <param name="dashStyle">DashStyle to use for line</param>
		/// <returns></returns>
		public void DrawLine(SharpDX.Direct2D1.RenderTarget renderTarget, string brush, double x1, double y1, double x2, double y2, float width, DashStyleHelper dashStyle)
		{			
			// Create Vector2 coordinates
			SharpDX.Vector2 startPoint 	= new System.Windows.Point(x1, y1).ToVector2();
			SharpDX.Vector2 endPoint 	= new System.Windows.Point(x2, y2).ToVector2();
			
			DrawLine(renderTarget, brush, startPoint, endPoint, width, dashStyle);
		}
		#endregion
		
		#region Media Brushes
		/// <summary>
		/// Draws a line between two points.
		/// </summary>
		/// <param name="renderTarget">The hosting NinjaScript's RenderTarget</param>
		/// <param name="brush">A SharpDX Brush used for the line</param>
		/// <param name="startPoint">SharpDX Start Coordinate Point</param>
		/// <param name="endPoint">SharpDX End Coordinate Point</param>
		/// <param name="width">Line Width</param>
		/// <param name="strokeStyle">SharpDX StrokeStyle to use for line</param>
		/// <returns></returns>
		// Condense Line drawing code
		public void DrawLine(SharpDX.Direct2D1.RenderTarget renderTarget, Brush brush, SharpDX.Vector2 startPoint, SharpDX.Vector2 endPoint, float width, SharpDX.Direct2D1.StrokeStyle strokeStyle)
		{
			// Check if we have this brush and create it if not.
			HelperCheckAddBrush(renderTarget, brush);
			
			string brushString = GetBrushString(brush);
			
			// Draw the line
			renderTarget.DrawLine(startPoint, endPoint, HelperManagedBrushes[brushString].DxBrush, width, strokeStyle);
			
			// StrokeStyle is device-independant and does not need to be Disposed after each OnRender() or OnRenderTargetChanged() call, but is for good housekeeping and garbage collection
			strokeStyle.Dispose();
			strokeStyle = null;
		}
		
		/// <summary>
		/// Draws a line between two points.
		/// </summary>
		/// <param name="renderTarget">The hosting NinjaScript's RenderTarget</param>
		/// <param name="brush">A SharpDX Brush used for the line</param>
		/// <param name="x1">X Start Coordinate</param>
		/// <param name="y1">Y Start Coordinate</param>
		/// <param name="x2">X End Coordinate</param>
		/// <param name="y2">Y End Coordinate</param>
		/// <param name="width">Line Width</param>
		/// <param name="strokeStyle">StrokeStyle to use for line</param>
		/// <returns></returns>
		public void DrawLine(SharpDX.Direct2D1.RenderTarget renderTarget, Brush brush, double x1, double y1, double x2, double y2, float width, SharpDX.Direct2D1.StrokeStyle strokeStyle)
		{			
			// Create Vector2 coordinates
			SharpDX.Vector2 startPoint 	= new System.Windows.Point(x1, y1).ToVector2();
			SharpDX.Vector2 endPoint 	= new System.Windows.Point(x2, y2).ToVector2();
			
			DrawLine(renderTarget, brush, startPoint, endPoint, width, strokeStyle);
			
			// StrokeStyle is device-independant and does not need to be Disposed after each OnRender() or OnRenderTargetChanged() call, but is for good housekeeping and garbage collection
			strokeStyle.Dispose();
			strokeStyle = null;
		}
		
		/// <summary>
		/// Draws a line between two points.
		/// </summary>
		/// <param name="renderTarget">The hosting NinjaScript's RenderTarget</param>
		/// <param name="brush">A SharpDX Brush used for the line</param>
		/// <param name="startPoint">Windows Point Start Coordinate pair</param>
		/// <param name="endPoint">Windows Point End Coordinate pair</param>
		/// <param name="width">Line Width</param>
		/// <param name="strokeStyle">StrokeStyle to use for line</param>
		/// <returns></returns>
		public void DrawLine(SharpDX.Direct2D1.RenderTarget renderTarget, Brush brush, System.Windows.Point startPoint, System.Windows.Point endPoint, float width, SharpDX.Direct2D1.StrokeStyle strokeStyle)
		{
			// Create Vector2 coordinates
			SharpDX.Vector2 startPointDX 	= startPoint.ToVector2();
			SharpDX.Vector2 endPointDX 		= endPoint.ToVector2();
			
			DrawLine(renderTarget, brush, startPointDX, endPointDX, width, strokeStyle);
			
			// StrokeStyle is device-independant and does not need to be Disposed after each OnRender() or OnRenderTargetChanged() call, but is for good housekeeping and garbage collection
			strokeStyle.Dispose();
			strokeStyle = null;
		}		
		
		/// <summary>
		/// Draws a line between two points.
		/// </summary>
		/// <param name="renderTarget">The hosting NinjaScript's RenderTarget</param>
		/// <param name="brush">A SharpDX Brush used for the line</param>
		/// <param name="startPoint">SharpDX Start Coordinate pair</param>
		/// <param name="endPoint">SharpDX End Coordinate pair</param>
		/// <param name="width">Line Width</param>
		/// <param name="dashStyle">DashStyle to use for line</param>
		/// <returns></returns>
		public void DrawLine(SharpDX.Direct2D1.RenderTarget renderTarget, Brush brush, SharpDX.Vector2 startPoint, SharpDX.Vector2 endPoint, float width, DashStyleHelper dashStyle)
		{
			// Create StrokeStyleProperties
			SharpDX.Direct2D1.StrokeStyleProperties ssProps = new SharpDX.Direct2D1.StrokeStyleProperties();
			
			switch (dashStyle)
			{
				case DashStyleHelper.Dash: 			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Dash; 		break;
				case DashStyleHelper.DashDot: 		ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.DashDot; 	break;
				case DashStyleHelper.DashDotDot:	ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.DashDotDot;	break;
				case DashStyleHelper.Dot:			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Dot;		break;
				case DashStyleHelper.Solid:			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Solid;		break;
				default: 							ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Solid;		break;
			}
			
			// Create StrokeStyle from StrokeStyleProperties
			SharpDX.Direct2D1.StrokeStyle strokeStyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, ssProps);
			
			DrawLine(renderTarget, brush, startPoint, endPoint, width, strokeStyle);
			
			// StrokeStyle is device-independant and does not need to be Disposed after each OnRender() or OnRenderTargetChanged() call, but is for good housekeeping and garbage collection
			strokeStyle.Dispose();
			strokeStyle = null;
		}
		
		/// <summary>
		/// Draws a line between two points.
		/// </summary>
		/// <param name="renderTarget">The hosting NinjaScript's RenderTarget</param>
		/// <param name="brush">A SharpDX Brush used for the line</param>
		/// <param name="startPoint">Windows Point Start Coordinate pair</param>
		/// <param name="endPoint">Windows Point End Coordinate pair</param>
		/// <param name="width">Line Width</param>
		/// <param name="dashStyle">DashStyle to use for line</param>
		/// <returns></returns>
		public void DrawLine(SharpDX.Direct2D1.RenderTarget renderTarget, Brush brush, System.Windows.Point startPoint, System.Windows.Point endPoint, float width, DashStyleHelper dashStyle)
		{
			// Create Vector2 coordinates
			SharpDX.Vector2 startPointDX 	= startPoint.ToVector2();
			SharpDX.Vector2 endPointDX 		= endPoint.ToVector2();
			
			DrawLine(renderTarget, brush, startPointDX, endPointDX, width, dashStyle);
		}
		
		/// <summary>
		/// Draws a line between two points.
		/// </summary>
		/// <param name="renderTarget">The hosting NinjaScript's RenderTarget</param>
		/// <param name="brush">A SharpDX Brush used for the line</param>
		/// <param name="x1">X Start Coordinate</param>
		/// <param name="y1">Y Start Coordinate</param>
		/// <param name="x2">X End Coordinate</param>
		/// <param name="y2">Y End Coordinate</param>
		/// <param name="width">Line Width</param>
		/// <param name="dashStyle">DashStyle to use for line</param>
		/// <returns></returns>
		public void DrawLine(SharpDX.Direct2D1.RenderTarget renderTarget, Brush brush, double x1, double y1, double x2, double y2, float width, DashStyleHelper dashStyle)
		{			
			// Create Vector2 coordinates
			SharpDX.Vector2 startPoint 	= new System.Windows.Point(x1, y1).ToVector2();
			SharpDX.Vector2 endPoint 	= new System.Windows.Point(x2, y2).ToVector2();
			
			DrawLine(renderTarget, brush, startPoint, endPoint, width, dashStyle);
		}
		#endregion
		#endregion
		
		#region DrawString
		#region SharpDX Brushes
		public void DrawString(SharpDX.Direct2D1.RenderTarget renderTarget, ChartPanel chartPanel, string text, SimpleFont font, SharpDX.Direct2D1.Brush brush, double pointX, double pointY, SharpDX.Direct2D1.Brush areaBrush)
		{
			SharpDX.DirectWrite.TextFormat textFormat = font.ToDirectWriteTextFormat();
			SharpDX.DirectWrite.TextLayout textLayout =
			new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory,
				text, textFormat, chartPanel.X + chartPanel.W,
				textFormat.FontSize);
			SharpDX.Vector2 TextPlotPoint = new System.Windows.Point(pointX, pointY-textLayout.Metrics.Height/2).ToVector2();
			
			float newW = textLayout.Metrics.Width; 
            float newH = textLayout.Metrics.Height;
            SharpDX.RectangleF PLBoundRect = new SharpDX.RectangleF((float)pointX+2, (float)pointY-textLayout.Metrics.Height/2, newW+5, newH+2);
            renderTarget.FillRectangle(PLBoundRect, areaBrush);
			
			renderTarget.DrawTextLayout(TextPlotPoint, textLayout, brush, SharpDX.Direct2D1.DrawTextOptions.NoSnap);
			textLayout.Dispose();
			textFormat.Dispose();
		}
		#endregion
		
		#region DXMediaBrushes
		public void DrawString(SharpDX.Direct2D1.RenderTarget renderTarget, ChartPanel chartPanel, string text, SimpleFont font, DXMediaBrush brush, double pointX, double pointY, DXMediaBrush areaBrush)
		{
			DrawString(renderTarget, chartPanel, text, font, brush.DxBrush, pointX, pointY, areaBrush.DxBrush);
		}
		#endregion
		
		#region Dictionary Brushes
		public void DrawString(SharpDX.Direct2D1.RenderTarget renderTarget, ChartPanel chartPanel, string text, SimpleFont font, string brushName, double pointX, double pointY, string areaBrushName)
		{
			DrawString(renderTarget, chartPanel, text, font, DXMBrushes[brushName].DxBrush, pointX, pointY, DXMBrushes[areaBrushName].DxBrush);
		}
		#endregion
		
		#region Media Brushes
		public void DrawString(SharpDX.Direct2D1.RenderTarget renderTarget, ChartPanel chartPanel, string text, SimpleFont font, Brush brush, double pointX, double pointY, Brush areaBrush)
		{
			// Check if we have this brush and create it if not.
			HelperCheckAddBrush(renderTarget, brush);
			
			string brushString = GetBrushString(brush);
			string areaBrushString = GetBrushString(brush);
			
			SharpDX.DirectWrite.TextFormat textFormat = font.ToDirectWriteTextFormat();
			SharpDX.DirectWrite.TextLayout textLayout =
			new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory,
				text, textFormat, chartPanel.X + chartPanel.W,
				textFormat.FontSize);
			SharpDX.Vector2 TextPlotPoint = new System.Windows.Point(pointX, pointY-textLayout.Metrics.Height/2).ToVector2();
			
			float newW = textLayout.Metrics.Width; 
            float newH = textLayout.Metrics.Height;
            SharpDX.RectangleF PLBoundRect = new SharpDX.RectangleF((float)pointX+2, (float)pointY-textLayout.Metrics.Height/2, newW+5, newH+2);
            renderTarget.FillRectangle(PLBoundRect, HelperManagedBrushes[areaBrushString].DxBrush);
			
			renderTarget.DrawTextLayout(TextPlotPoint, textLayout, HelperManagedBrushes[brushString].DxBrush, SharpDX.Direct2D1.DrawTextOptions.NoSnap);
			textLayout.Dispose();
			textFormat.Dispose();
		}
		#endregion
		#endregion
		
		#region DrawEllipse
		#region SharpDX Brushes
		public void DrawEllipse(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.Ellipse ellipse, SharpDX.Direct2D1.Brush brush, float strokeWidth, SharpDX.Direct2D1.StrokeStyle strokeStyle)
		{
			renderTarget.DrawEllipse(ellipse, brush, strokeWidth, strokeStyle);
		}
		
		public void DrawEllipse(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.Ellipse ellipse, SharpDX.Direct2D1.Brush brush, float strokeWidth, DashStyleHelper dashStyle)
		{
			// Create StrokeStyleProperties
			SharpDX.Direct2D1.StrokeStyleProperties ssProps = new SharpDX.Direct2D1.StrokeStyleProperties();
			
			switch (dashStyle)
			{
				case DashStyleHelper.Dash: 			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Dash; 		break;
				case DashStyleHelper.DashDot: 		ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.DashDot; 	break;
				case DashStyleHelper.DashDotDot:	ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.DashDotDot;	break;
				case DashStyleHelper.Dot:			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Dot;		break;
				case DashStyleHelper.Solid:			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Solid;		break;
				default: 							ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Solid;		break;
			}
			
			// Create StrokeStyle from StrokeStyleProperties
			SharpDX.Direct2D1.StrokeStyle strokeStyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, ssProps);
			
			DrawEllipse(renderTarget, ellipse, brush, strokeWidth, strokeStyle);
			
			// StrokeStyle is device-independant and does not need to be Disposed after each OnRender() or OnRenderTargetChanged() call, but is for good housekeeping and garbage collection
			strokeStyle.Dispose();
			strokeStyle = null;			
		}
		
		public void DrawEllipse(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.Ellipse ellipse, SharpDX.Direct2D1.Brush brush, float strokeWidth)
		{
			// Create StrokeStyleProperties
			SharpDX.Direct2D1.StrokeStyleProperties ssProps = new SharpDX.Direct2D1.StrokeStyleProperties();
			
			// Set the StrokeStyle to solid
			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Solid;
			
			// Create StrokeStyle from StrokeStyleProperties
			SharpDX.Direct2D1.StrokeStyle strokeStyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, ssProps);
			
			DrawEllipse(renderTarget, ellipse, brush, strokeWidth, strokeStyle);
			
			// StrokeStyle is device-independant and does not need to be Disposed after each OnRender() or OnRenderTargetChanged() call, but is for good housekeeping and garbage collection
			strokeStyle.Dispose();
			strokeStyle = null;	
		}
		
		public void DrawEllipse(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.Ellipse ellipse, SharpDX.Direct2D1.Brush brush)
		{
			renderTarget.DrawEllipse(ellipse, brush);
		}
		
		public void DrawEllipse(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Vector2 point, float radiusX, float radiusY, SharpDX.Direct2D1.Brush brush)
		{
			DrawEllipse(renderTarget, new SharpDX.Direct2D1.Ellipse(point, radiusX, radiusY), brush);
		}
		
		public void DrawEllipse(SharpDX.Direct2D1.RenderTarget renderTarget, System.Windows.Point point, float radiusX, float radiusY, SharpDX.Direct2D1.Brush brush)
		{
			DrawEllipse(renderTarget, new SharpDX.Direct2D1.Ellipse(point.ToVector2(), radiusX, radiusY), brush);
		}
		
		public void DrawEllipse(SharpDX.Direct2D1.RenderTarget renderTarget, double x, double y, float radiusX, float radiusY, SharpDX.Direct2D1.Brush brush)
		{
			DrawEllipse(renderTarget, new SharpDX.Direct2D1.Ellipse(new SharpDX.Vector2(){ X = (float)x, Y = (float)y }, radiusX, radiusY), brush);
		}
		#endregion
		
		#region DXMediaBrushes
		public void DrawEllipse(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.Ellipse ellipse, DXMediaBrush brush, float strokeWidth, SharpDX.Direct2D1.StrokeStyle strokeStyle)
		{
			renderTarget.DrawEllipse(ellipse, brush.DxBrush, strokeWidth, strokeStyle);
		}
		
		public void DrawEllipse(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.Ellipse ellipse, DXMediaBrush brush, float strokeWidth, DashStyleHelper dashStyle)
		{
			// Create StrokeStyleProperties
			SharpDX.Direct2D1.StrokeStyleProperties ssProps = new SharpDX.Direct2D1.StrokeStyleProperties();
			
			switch (dashStyle)
			{
				case DashStyleHelper.Dash: 			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Dash; 		break;
				case DashStyleHelper.DashDot: 		ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.DashDot; 	break;
				case DashStyleHelper.DashDotDot:	ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.DashDotDot;	break;
				case DashStyleHelper.Dot:			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Dot;		break;
				case DashStyleHelper.Solid:			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Solid;		break;
				default: 							ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Solid;		break;
			}
			
			// Create StrokeStyle from StrokeStyleProperties
			SharpDX.Direct2D1.StrokeStyle strokeStyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, ssProps);
			
			DrawEllipse(renderTarget, ellipse, brush, strokeWidth, strokeStyle);
			
			// StrokeStyle is device-independant and does not need to be Disposed after each OnRender() or OnRenderTargetChanged() call, but is for good housekeeping and garbage collection
			strokeStyle.Dispose();
			strokeStyle = null;			
		}
		
		public void DrawEllipse(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.Ellipse ellipse, DXMediaBrush brush, float strokeWidth)
		{
			// Create StrokeStyleProperties
			SharpDX.Direct2D1.StrokeStyleProperties ssProps = new SharpDX.Direct2D1.StrokeStyleProperties();
			
			// Set the StrokeStyle to solid
			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Solid;
			
			// Create StrokeStyle from StrokeStyleProperties
			SharpDX.Direct2D1.StrokeStyle strokeStyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, ssProps);
			
			DrawEllipse(renderTarget, ellipse, brush, strokeWidth, strokeStyle);
			
			// StrokeStyle is device-independant and does not need to be Disposed after each OnRender() or OnRenderTargetChanged() call, but is for good housekeeping and garbage collection
			strokeStyle.Dispose();
			strokeStyle = null;	
		}
		
		public void DrawEllipse(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.Ellipse ellipse, DXMediaBrush brush)
		{
			renderTarget.DrawEllipse(ellipse, brush.DxBrush);
		}
		
		public void DrawEllipse(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Vector2 point, float radiusX, float radiusY, DXMediaBrush brush)
		{
			DrawEllipse(renderTarget, new SharpDX.Direct2D1.Ellipse(point, radiusX, radiusY), brush);
		}
		
		public void DrawEllipse(SharpDX.Direct2D1.RenderTarget renderTarget, System.Windows.Point point, float radiusX, float radiusY, DXMediaBrush brush)
		{
			DrawEllipse(renderTarget, new SharpDX.Direct2D1.Ellipse(point.ToVector2(), radiusX, radiusY), brush);
		}
		
		public void DrawEllipse(SharpDX.Direct2D1.RenderTarget renderTarget, double x, double y, float radiusX, float radiusY, DXMediaBrush brush)
		{
			DrawEllipse(renderTarget, new SharpDX.Direct2D1.Ellipse(new SharpDX.Vector2(){ X = (float)x, Y = (float)y }, radiusX, radiusY), brush);
		}
		#endregion
		
		#region Dictionary Brushes
		public void DrawEllipse(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.Ellipse ellipse, string brush, float strokeWidth, SharpDX.Direct2D1.StrokeStyle strokeStyle)
		{
			renderTarget.DrawEllipse(ellipse, DXMBrushes[brush].DxBrush, strokeWidth, strokeStyle);
		}
		
		public void DrawEllipse(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.Ellipse ellipse, string brush, float strokeWidth, DashStyleHelper dashStyle)
		{
			// Create StrokeStyleProperties
			SharpDX.Direct2D1.StrokeStyleProperties ssProps = new SharpDX.Direct2D1.StrokeStyleProperties();
			
			switch (dashStyle)
			{
				case DashStyleHelper.Dash: 			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Dash; 		break;
				case DashStyleHelper.DashDot: 		ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.DashDot; 	break;
				case DashStyleHelper.DashDotDot:	ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.DashDotDot;	break;
				case DashStyleHelper.Dot:			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Dot;		break;
				case DashStyleHelper.Solid:			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Solid;		break;
				default: 							ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Solid;		break;
			}
			
			// Create StrokeStyle from StrokeStyleProperties
			SharpDX.Direct2D1.StrokeStyle strokeStyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, ssProps);
			
			DrawEllipse(renderTarget, ellipse, brush, strokeWidth, strokeStyle);
			
			// StrokeStyle is device-independant and does not need to be Disposed after each OnRender() or OnRenderTargetChanged() call, but is for good housekeeping and garbage collection
			strokeStyle.Dispose();
			strokeStyle = null;			
		}
		
		public void DrawEllipse(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.Ellipse ellipse, string brush, float strokeWidth)
		{
			// Create StrokeStyleProperties
			SharpDX.Direct2D1.StrokeStyleProperties ssProps = new SharpDX.Direct2D1.StrokeStyleProperties();
			
			// Set the StrokeStyle to solid
			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Solid;
			
			// Create StrokeStyle from StrokeStyleProperties
			SharpDX.Direct2D1.StrokeStyle strokeStyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, ssProps);
			
			DrawEllipse(renderTarget, ellipse, brush, strokeWidth, strokeStyle);
			
			// StrokeStyle is device-independant and does not need to be Disposed after each OnRender() or OnRenderTargetChanged() call, but is for good housekeeping and garbage collection
			strokeStyle.Dispose();
			strokeStyle = null;	
		}
		
		public void DrawEllipse(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.Ellipse ellipse, string brush)
		{
			renderTarget.DrawEllipse(ellipse, DXMBrushes[brush].DxBrush);
		}
		
		public void DrawEllipse(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Vector2 point, float radiusX, float radiusY, string brush)
		{
			DrawEllipse(renderTarget, new SharpDX.Direct2D1.Ellipse(point, radiusX, radiusY), brush);
		}
		
		public void DrawEllipse(SharpDX.Direct2D1.RenderTarget renderTarget, System.Windows.Point point, float radiusX, float radiusY, string brush)
		{
			DrawEllipse(renderTarget, new SharpDX.Direct2D1.Ellipse(point.ToVector2(), radiusX, radiusY), brush);
		}
		
		public void DrawEllipse(SharpDX.Direct2D1.RenderTarget renderTarget, double x, double y, float radiusX, float radiusY, string brush)
		{
			DrawEllipse(renderTarget, new SharpDX.Direct2D1.Ellipse(new SharpDX.Vector2(){ X = (float)x, Y = (float)y }, radiusX, radiusY), brush);
		}
		#endregion
		
		#region Media Brushes
		public void DrawEllipse(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.Ellipse ellipse, Brush brush, float strokeWidth, SharpDX.Direct2D1.StrokeStyle strokeStyle)
		{
			// Check if we have this brush and create it if not.
			HelperCheckAddBrush(renderTarget, brush);
			
			string brushString = GetBrushString(brush);
			
			renderTarget.DrawEllipse(ellipse, HelperManagedBrushes[brushString].DxBrush, strokeWidth, strokeStyle);
		}
		
		public void DrawEllipse(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.Ellipse ellipse, Brush brush, float strokeWidth, DashStyleHelper dashStyle)
		{
			// Create StrokeStyleProperties
			SharpDX.Direct2D1.StrokeStyleProperties ssProps = new SharpDX.Direct2D1.StrokeStyleProperties();
			
			switch (dashStyle)
			{
				case DashStyleHelper.Dash: 			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Dash; 		break;
				case DashStyleHelper.DashDot: 		ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.DashDot; 	break;
				case DashStyleHelper.DashDotDot:	ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.DashDotDot;	break;
				case DashStyleHelper.Dot:			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Dot;		break;
				case DashStyleHelper.Solid:			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Solid;		break;
				default: 							ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Solid;		break;
			}
			
			// Create StrokeStyle from StrokeStyleProperties
			SharpDX.Direct2D1.StrokeStyle strokeStyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, ssProps);
			
			DrawEllipse(renderTarget, ellipse, brush, strokeWidth, strokeStyle);
			
			// StrokeStyle is device-independant and does not need to be Disposed after each OnRender() or OnRenderTargetChanged() call, but is for good housekeeping and garbage collection
			strokeStyle.Dispose();
			strokeStyle = null;			
		}
		
		public void DrawEllipse(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.Ellipse ellipse, Brush brush, float strokeWidth)
		{
			// Create StrokeStyleProperties
			SharpDX.Direct2D1.StrokeStyleProperties ssProps = new SharpDX.Direct2D1.StrokeStyleProperties();
			
			// Set the StrokeStyle to solid
			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Solid;
			
			// Create StrokeStyle from StrokeStyleProperties
			SharpDX.Direct2D1.StrokeStyle strokeStyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, ssProps);
			
			DrawEllipse(renderTarget, ellipse, brush, strokeWidth, strokeStyle);
			
			// StrokeStyle is device-independant and does not need to be Disposed after each OnRender() or OnRenderTargetChanged() call, but is for good housekeeping and garbage collection
			strokeStyle.Dispose();
			strokeStyle = null;	
		}
		
		public void DrawEllipse(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.Ellipse ellipse, Brush brush)
		{
			// Check if we have this brush and create it if not.
			HelperCheckAddBrush(renderTarget, brush);
			
			string brushString = GetBrushString(brush);
			
			renderTarget.DrawEllipse(ellipse, HelperManagedBrushes[brushString].DxBrush);
		}
		
		public void DrawEllipse(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Vector2 point, float radiusX, float radiusY, Brush brush)
		{
			DrawEllipse(renderTarget, new SharpDX.Direct2D1.Ellipse(point, radiusX, radiusY), brush);
		}
		
		public void DrawEllipse(SharpDX.Direct2D1.RenderTarget renderTarget, System.Windows.Point point, float radiusX, float radiusY, Brush brush)
		{
			DrawEllipse(renderTarget, new SharpDX.Direct2D1.Ellipse(point.ToVector2(), radiusX, radiusY), brush);
		}
		
		public void DrawEllipse(SharpDX.Direct2D1.RenderTarget renderTarget, double x, double y, float radiusX, float radiusY, Brush brush)
		{
			DrawEllipse(renderTarget, new SharpDX.Direct2D1.Ellipse(new SharpDX.Vector2(){ X = (float)x, Y = (float)y }, radiusX, radiusY), brush);
		}
		#endregion
		#endregion
		
		#region FillEllipse
		#region SharpDX Brushes
		public void FillEllipse(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.Ellipse ellipse, SharpDX.Direct2D1.Brush brush)
		{
			renderTarget.FillEllipse(ellipse, brush);
		}
		
		public void FillEllipse(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Vector2 point, float radiusX, float radiusY, SharpDX.Direct2D1.Brush brush)
		{
			FillEllipse(renderTarget, new SharpDX.Direct2D1.Ellipse(point, radiusX, radiusY), brush);
		}
		
		public void FillEllipse(SharpDX.Direct2D1.RenderTarget renderTarget, System.Windows.Point point, float radiusX, float radiusY, SharpDX.Direct2D1.Brush brush)
		{
			FillEllipse(renderTarget, new SharpDX.Direct2D1.Ellipse(point.ToVector2(), radiusX, radiusY), brush);
		}
		
		public void FillEllipse(SharpDX.Direct2D1.RenderTarget renderTarget, double x, double y, float radiusX, float radiusY, SharpDX.Direct2D1.Brush brush)
		{
			FillEllipse(renderTarget, new SharpDX.Direct2D1.Ellipse(new SharpDX.Vector2(){ X = (float)x, Y = (float)y }, radiusX, radiusY), brush);
		}
		#endregion
		
		#region DXMediaBrushes
		public void FillEllipse(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.Ellipse ellipse, DXMediaBrush brush)
		{
			renderTarget.FillEllipse(ellipse, brush.DxBrush);
		}
		
		public void FillEllipse(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Vector2 point, float radiusX, float radiusY, DXMediaBrush brush)
		{
			FillEllipse(renderTarget, new SharpDX.Direct2D1.Ellipse(point, radiusX, radiusY), brush);
		}
		
		public void FillEllipse(SharpDX.Direct2D1.RenderTarget renderTarget, System.Windows.Point point, float radiusX, float radiusY, DXMediaBrush brush)
		{
			FillEllipse(renderTarget, new SharpDX.Direct2D1.Ellipse(point.ToVector2(), radiusX, radiusY), brush);
		}
		
		public void FillEllipse(SharpDX.Direct2D1.RenderTarget renderTarget, double x, double y, float radiusX, float radiusY, DXMediaBrush brush)
		{
			FillEllipse(renderTarget, new SharpDX.Direct2D1.Ellipse(new SharpDX.Vector2(){ X = (float)x, Y = (float)y }, radiusX, radiusY), brush);
		}
		#endregion
		
		#region Dictionary Brushes
		public void FillEllipse(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.Ellipse ellipse, string brush)
		{
			renderTarget.FillEllipse(ellipse, DXMBrushes[brush].DxBrush);
		}
		
		public void FillEllipse(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Vector2 point, float radiusX, float radiusY, string brush)
		{
			FillEllipse(renderTarget, new SharpDX.Direct2D1.Ellipse(point, radiusX, radiusY), brush);
		}
		
		public void FillEllipse(SharpDX.Direct2D1.RenderTarget renderTarget, System.Windows.Point point, float radiusX, float radiusY, string brush)
		{
			FillEllipse(renderTarget, new SharpDX.Direct2D1.Ellipse(point.ToVector2(), radiusX, radiusY), brush);
		}
		
		public void FillEllipse(SharpDX.Direct2D1.RenderTarget renderTarget, double x, double y, float radiusX, float radiusY, string brush)
		{
			FillEllipse(renderTarget, new SharpDX.Direct2D1.Ellipse(new SharpDX.Vector2(){ X = (float)x, Y = (float)y }, radiusX, radiusY), brush);
		}
		#endregion
		
		#region Media Brushes
		public void FillEllipse(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.Ellipse ellipse, Brush brush)
		{
			// Check if we have this brush and create it if not.
			HelperCheckAddBrush(renderTarget, brush);
			
			string brushString = GetBrushString(brush);
			
			renderTarget.FillEllipse(ellipse, HelperManagedBrushes[brushString].DxBrush);
		}
		
		public void FillEllipse(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Vector2 point, float radiusX, float radiusY, Brush brush)
		{
			FillEllipse(renderTarget, new SharpDX.Direct2D1.Ellipse(point, radiusX, radiusY), brush);
		}
		
		public void FillEllipse(SharpDX.Direct2D1.RenderTarget renderTarget, System.Windows.Point point, float radiusX, float radiusY, Brush brush)
		{
			FillEllipse(renderTarget, new SharpDX.Direct2D1.Ellipse(point.ToVector2(), radiusX, radiusY), brush);
		}
		
		public void FillEllipse(SharpDX.Direct2D1.RenderTarget renderTarget, double x, double y, float radiusX, float radiusY, Brush brush)
		{
			FillEllipse(renderTarget, new SharpDX.Direct2D1.Ellipse(new SharpDX.Vector2(){ X = (float)x, Y = (float)y }, radiusX, radiusY), brush);
		}
		#endregion
		#endregion
		
		#region DrawRectangle
		#region SharpDX Brushes
		public void DrawRectangle(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.RectangleF rect, SharpDX.Direct2D1.Brush brush, float strokeWidth, DashStyleHelper dashStyle)
		{
			// Create StrokeStyleProperties
			SharpDX.Direct2D1.StrokeStyleProperties ssProps = new SharpDX.Direct2D1.StrokeStyleProperties();
			
			switch (dashStyle)
			{
				case DashStyleHelper.Dash: 			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Dash; 		break;
				case DashStyleHelper.DashDot: 		ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.DashDot; 	break;
				case DashStyleHelper.DashDotDot:	ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.DashDotDot;	break;
				case DashStyleHelper.Dot:			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Dot;		break;
				case DashStyleHelper.Solid:			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Solid;		break;
				default: 							ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Solid;		break;
			}
			
			// Create StrokeStyle from StrokeStyleProperties
			SharpDX.Direct2D1.StrokeStyle strokeStyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, ssProps);
			renderTarget.DrawRectangle(rect, brush, strokeWidth, strokeStyle);
		}
		
		public void DrawRectangle(SharpDX.Direct2D1.RenderTarget renderTarget, float x, float y, float width, float height, SharpDX.Direct2D1.Brush brush, float strokeWidth, DashStyleHelper dashStyle)
		{
			SharpDX.RectangleF rect = new SharpDX.RectangleF(x, y, width, height);
			
			DrawRectangle(renderTarget, rect, brush, strokeWidth, dashStyle);
		}
		
		public void DrawRectangle(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.RectangleF rect, SharpDX.Direct2D1.Brush brush, float strokeWidth, SharpDX.Direct2D1.StrokeStyle strokeStyle)
		{
			renderTarget.DrawRectangle(rect, brush, strokeWidth, strokeStyle);
		}
		
		public void DrawRectangle(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.RectangleF rect, SharpDX.Direct2D1.Brush brush, float strokeWidth)
		{
			renderTarget.DrawRectangle(rect, brush, strokeWidth);
		}
		
		public void DrawRectangle(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.RectangleF rect, SharpDX.Direct2D1.Brush brush)
		{
			renderTarget.DrawRectangle(rect, brush);
		}
		#endregion
		
		#region DXMediaBrushes
		public void DrawRectangle(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.RectangleF rect, DXMediaBrush brush, float strokeWidth, DashStyleHelper dashStyle)
		{
			// Create StrokeStyleProperties
			SharpDX.Direct2D1.StrokeStyleProperties ssProps = new SharpDX.Direct2D1.StrokeStyleProperties();
			
			switch (dashStyle)
			{
				case DashStyleHelper.Dash: 			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Dash; 		break;
				case DashStyleHelper.DashDot: 		ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.DashDot; 	break;
				case DashStyleHelper.DashDotDot:	ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.DashDotDot;	break;
				case DashStyleHelper.Dot:			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Dot;		break;
				case DashStyleHelper.Solid:			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Solid;		break;
				default: 							ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Solid;		break;
			}
			
			// Create StrokeStyle from StrokeStyleProperties
			SharpDX.Direct2D1.StrokeStyle strokeStyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, ssProps);
			renderTarget.DrawRectangle(rect, brush.DxBrush, strokeWidth, strokeStyle);
		}
		
		public void DrawRectangle(SharpDX.Direct2D1.RenderTarget renderTarget, float x, float y, float width, float height, DXMediaBrush brush, float strokeWidth, DashStyleHelper dashStyle)
		{
			SharpDX.RectangleF rect = new SharpDX.RectangleF(x, y, width, height);
			
			DrawRectangle(renderTarget, rect, brush.DxBrush, strokeWidth, dashStyle);
		}
		
		public void DrawRectangle(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.RectangleF rect, DXMediaBrush brush, float strokeWidth, SharpDX.Direct2D1.StrokeStyle strokeStyle)
		{
			renderTarget.DrawRectangle(rect, brush.DxBrush, strokeWidth, strokeStyle);
		}
		
		public void DrawRectangle(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.RectangleF rect, DXMediaBrush brush, float strokeWidth)
		{
			renderTarget.DrawRectangle(rect, brush.DxBrush, strokeWidth);
		}
		
		public void DrawRectangle(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.RectangleF rect, DXMediaBrush brush)
		{
			renderTarget.DrawRectangle(rect, brush.DxBrush);
		}
		#endregion
		
		#region Dictionary Brushes
		public void DrawRectangle(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.RectangleF rect, string brush, float strokeWidth, DashStyleHelper dashStyle)
		{
			// Create StrokeStyleProperties
			SharpDX.Direct2D1.StrokeStyleProperties ssProps = new SharpDX.Direct2D1.StrokeStyleProperties();
			
			switch (dashStyle)
			{
				case DashStyleHelper.Dash: 			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Dash; 		break;
				case DashStyleHelper.DashDot: 		ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.DashDot; 	break;
				case DashStyleHelper.DashDotDot:	ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.DashDotDot;	break;
				case DashStyleHelper.Dot:			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Dot;		break;
				case DashStyleHelper.Solid:			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Solid;		break;
				default: 							ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Solid;		break;
			}
			
			// Create StrokeStyle from StrokeStyleProperties
			SharpDX.Direct2D1.StrokeStyle strokeStyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, ssProps);
			renderTarget.DrawRectangle(rect, DXMBrushes[brush].DxBrush, strokeWidth, strokeStyle);
		}
		
		public void DrawRectangle(SharpDX.Direct2D1.RenderTarget renderTarget, float x, float y, float width, float height, string brush, float strokeWidth, DashStyleHelper dashStyle)
		{
			SharpDX.RectangleF rect = new SharpDX.RectangleF(x, y, width, height);
			
			DrawRectangle(renderTarget, rect, brush, strokeWidth, dashStyle);
		}
		
		public void DrawRectangle(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.RectangleF rect, string brush, float strokeWidth, SharpDX.Direct2D1.StrokeStyle strokeStyle)
		{
			renderTarget.DrawRectangle(rect, DXMBrushes[brush].DxBrush, strokeWidth, strokeStyle);
		}
		
		public void DrawRectangle(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.RectangleF rect, string brush, float strokeWidth)
		{
			renderTarget.DrawRectangle(rect, DXMBrushes[brush].DxBrush, strokeWidth);
		}
		
		public void DrawRectangle(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.RectangleF rect, string brush)
		{
			renderTarget.DrawRectangle(rect, DXMBrushes[brush].DxBrush);
		}
		#endregion
		
		#region Media Brushes
		public void DrawRectangle(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.RectangleF rect, Brush brush, float strokeWidth, DashStyleHelper dashStyle)
		{
			// Check if we have this brush and create it if not.
			HelperCheckAddBrush(renderTarget, brush);
			
			string brushString = GetBrushString(brush);
			
			// Create StrokeStyleProperties
			SharpDX.Direct2D1.StrokeStyleProperties ssProps = new SharpDX.Direct2D1.StrokeStyleProperties();
			
			switch (dashStyle)
			{
				case DashStyleHelper.Dash: 			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Dash; 		break;
				case DashStyleHelper.DashDot: 		ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.DashDot; 	break;
				case DashStyleHelper.DashDotDot:	ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.DashDotDot;	break;
				case DashStyleHelper.Dot:			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Dot;		break;
				case DashStyleHelper.Solid:			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Solid;		break;
				default: 							ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Solid;		break;
			}
			
			// Create StrokeStyle from StrokeStyleProperties
			SharpDX.Direct2D1.StrokeStyle strokeStyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, ssProps);
			renderTarget.DrawRectangle(rect, HelperManagedBrushes[brushString].DxBrush, strokeWidth, strokeStyle);
		}
		
		public void DrawRectangle(SharpDX.Direct2D1.RenderTarget renderTarget, float x, float y, float width, float height, Brush brush, float strokeWidth, DashStyleHelper dashStyle)
		{
			SharpDX.RectangleF rect = new SharpDX.RectangleF(x, y, width, height);
			
			DrawRectangle(renderTarget, rect, brush, strokeWidth, dashStyle);
		}
		
		public void DrawRectangle(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.RectangleF rect, Brush brush, float strokeWidth, SharpDX.Direct2D1.StrokeStyle strokeStyle)
		{
			// Check if we have this brush and create it if not.
			HelperCheckAddBrush(renderTarget, brush);
			
			string brushString = GetBrushString(brush);
			
			renderTarget.DrawRectangle(rect, HelperManagedBrushes[brushString].DxBrush, strokeWidth, strokeStyle);
		}
		
		public void DrawRectangle(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.RectangleF rect, Brush brush, float strokeWidth)
		{
			// Check if we have this brush and create it if not.
			HelperCheckAddBrush(renderTarget, brush);
			
			string brushString = GetBrushString(brush);
			
			renderTarget.DrawRectangle(rect, HelperManagedBrushes[brushString].DxBrush, strokeWidth);
		}
		
		public void DrawRectangle(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.RectangleF rect, Brush brush)
		{
			// Check if we have this brush and create it if not.
			HelperCheckAddBrush(renderTarget, brush);
			
			string brushString = GetBrushString(brush);
			
			renderTarget.DrawRectangle(rect, HelperManagedBrushes[brushString].DxBrush);
		}
		#endregion
		#endregion
		
		#region FillRectangle
		#region SharpDX Brushes
		public void FillRectangle(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.RectangleF rect, SharpDX.Direct2D1.Brush brush)
		{
			renderTarget.FillRectangle(rect, brush);
		}
		
		public void FillRectangle(SharpDX.Direct2D1.RenderTarget renderTarget, float x, float y, float width, float height, SharpDX.Direct2D1.Brush brush)
		{
			SharpDX.RectangleF rect = new SharpDX.RectangleF(x, y, width, height);
			
			FillRectangle(renderTarget, rect, brush);
		}
		#endregion
		
		#region DXMediaBrushes
		public void FillRectangle(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.RectangleF rect, DXMediaBrush brush)
		{
			renderTarget.FillRectangle(rect, brush.DxBrush);
		}
		
		public void FillRectangle(SharpDX.Direct2D1.RenderTarget renderTarget, float x, float y, float width, float height, DXMediaBrush brush)
		{
			SharpDX.RectangleF rect = new SharpDX.RectangleF(x, y, width, height);
			
			FillRectangle(renderTarget, rect, brush);
		}
		#endregion
		
		#region Dictionary Brushes
		public void FillRectangle(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.RectangleF rect, string brush)
		{
			renderTarget.FillRectangle(rect, DXMBrushes[brush].DxBrush);
		}
		
		public void FillRectangle(SharpDX.Direct2D1.RenderTarget renderTarget, float x, float y, float width, float height, string brush)
		{
			SharpDX.RectangleF rect = new SharpDX.RectangleF(x, y, width, height);
			
			FillRectangle(renderTarget, rect, brush);
		}
		#endregion
		
		#region Media Brushes
		public void FillRectangle(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.RectangleF rect, Brush brush)
		{
			// Check if we have this brush and create it if not.
			HelperCheckAddBrush(renderTarget, brush);
			
			string brushString = GetBrushString(brush);
			
			renderTarget.FillRectangle(rect, HelperManagedBrushes[brushString].DxBrush);
		}
		
		public void FillRectangle(SharpDX.Direct2D1.RenderTarget renderTarget, float x, float y, float width, float height, Brush brush)
		{
			SharpDX.RectangleF rect = new SharpDX.RectangleF(x, y, width, height);
			
			FillRectangle(renderTarget, rect, brush);
		}
		#endregion
		#endregion

		#region DrawRoundedRectangle
		#region SharpDX Brushes		
		public void DrawRoundedRectangle(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.RoundedRectangle rect, SharpDX.Direct2D1.Brush brush, float strokeWidth, DashStyleHelper dashStyle)
		{
			// Create StrokeStyleProperties
			SharpDX.Direct2D1.StrokeStyleProperties ssProps = new SharpDX.Direct2D1.StrokeStyleProperties();
			
			switch (dashStyle)
			{
				case DashStyleHelper.Dash: 			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Dash; 		break;
				case DashStyleHelper.DashDot: 		ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.DashDot; 	break;
				case DashStyleHelper.DashDotDot:	ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.DashDotDot;	break;
				case DashStyleHelper.Dot:			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Dot;		break;
				case DashStyleHelper.Solid:			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Solid;		break;
				default: 							ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Solid;		break;
			}
			
			// Create StrokeStyle from StrokeStyleProperties
			SharpDX.Direct2D1.StrokeStyle strokeStyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, ssProps);
			renderTarget.DrawRoundedRectangle(rect, brush, strokeWidth, strokeStyle);
		}
		
		public void DrawRoundedRectangle(SharpDX.Direct2D1.RenderTarget renderTarget, float x, float y, float width, float height, float radiusX, float radiusY, SharpDX.Direct2D1.Brush brush, float strokeWidth, DashStyleHelper dashStyle)
		{
			SharpDX.RectangleF rect = new SharpDX.RectangleF(x, y, width, height);
			
			SharpDX.Direct2D1.RoundedRectangle roundedRect = new SharpDX.Direct2D1.RoundedRectangle() { RadiusX = radiusX, RadiusY = radiusY, Rect = rect };
			
			DrawRoundedRectangle( renderTarget, roundedRect, brush, strokeWidth, dashStyle);
		}
		
		public void DrawRoundedRectangle(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.RectangleF rect, float radiusX, float radiusY, SharpDX.Direct2D1.Brush brush, float strokeWidth, DashStyleHelper dashStyle)
		{
			SharpDX.Direct2D1.RoundedRectangle roundedRect = new SharpDX.Direct2D1.RoundedRectangle() { RadiusX = radiusX, RadiusY = radiusY, Rect = rect };
			
			DrawRoundedRectangle( renderTarget, roundedRect, brush, strokeWidth, dashStyle);
		}
		
		public void DrawRoundedRectangle(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.RoundedRectangle rect, SharpDX.Direct2D1.Brush brush, float strokeWidth, SharpDX.Direct2D1.StrokeStyle strokeStyle)
		{
			renderTarget.DrawRoundedRectangle(rect, brush, strokeWidth, strokeStyle);
		}
		
		public void DrawRoundedRectangle(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.RoundedRectangle rect, SharpDX.Direct2D1.Brush brush, float strokeWidth)
		{
			renderTarget.DrawRoundedRectangle(rect, brush, strokeWidth);
		}
		
		public void DrawRoundedRectangle(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.RoundedRectangle rect, SharpDX.Direct2D1.Brush brush)
		{
			renderTarget.DrawRoundedRectangle(rect, brush);
		}
		#endregion
		
		#region DXMediaBrushes
		public void DrawRoundedRectangle(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.RoundedRectangle rect, DXMediaBrush brush, float strokeWidth, DashStyleHelper dashStyle)
		{
			// Create StrokeStyleProperties
			SharpDX.Direct2D1.StrokeStyleProperties ssProps = new SharpDX.Direct2D1.StrokeStyleProperties();
			
			switch (dashStyle)
			{
				case DashStyleHelper.Dash: 			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Dash; 		break;
				case DashStyleHelper.DashDot: 		ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.DashDot; 	break;
				case DashStyleHelper.DashDotDot:	ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.DashDotDot;	break;
				case DashStyleHelper.Dot:			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Dot;		break;
				case DashStyleHelper.Solid:			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Solid;		break;
				default: 							ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Solid;		break;
			}
			
			// Create StrokeStyle from StrokeStyleProperties
			SharpDX.Direct2D1.StrokeStyle strokeStyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, ssProps);
			renderTarget.DrawRoundedRectangle(rect, brush.DxBrush, strokeWidth, strokeStyle);
		}
		
		public void DrawRoundedRectangle(SharpDX.Direct2D1.RenderTarget renderTarget, float x, float y, float width, float height, float radiusX, float radiusY, DXMediaBrush brush, float strokeWidth, DashStyleHelper dashStyle)
		{
			SharpDX.RectangleF rect = new SharpDX.RectangleF(x, y, width, height);
			
			SharpDX.Direct2D1.RoundedRectangle roundedRect = new SharpDX.Direct2D1.RoundedRectangle() { RadiusX = radiusX, RadiusY = radiusY, Rect = rect };
			
			DrawRoundedRectangle( renderTarget, roundedRect, brush.DxBrush, strokeWidth, dashStyle);
		}
		
		public void DrawRoundedRectangle(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.RectangleF rect, float radiusX, float radiusY, DXMediaBrush brush, float strokeWidth, DashStyleHelper dashStyle)
		{
			SharpDX.Direct2D1.RoundedRectangle roundedRect = new SharpDX.Direct2D1.RoundedRectangle() { RadiusX = radiusX, RadiusY = radiusY, Rect = rect };
			
			DrawRoundedRectangle( renderTarget, roundedRect, brush.DxBrush, strokeWidth, dashStyle);
		}
		
		public void DrawRoundedRectangle(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.RoundedRectangle rect, DXMediaBrush brush, float strokeWidth, SharpDX.Direct2D1.StrokeStyle strokeStyle)
		{
			renderTarget.DrawRoundedRectangle(rect, brush.DxBrush, strokeWidth, strokeStyle);
		}
		
		public void DrawRoundedRectangle(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.RoundedRectangle rect, DXMediaBrush brush, float strokeWidth)
		{
			renderTarget.DrawRoundedRectangle(rect, brush.DxBrush, strokeWidth);
		}
		
		public void DrawRoundedRectangle(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.RoundedRectangle rect, DXMediaBrush brush)
		{
			renderTarget.DrawRoundedRectangle(rect, brush.DxBrush);
		}
		#endregion
		
		#region Dictionary Brushes
		public void DrawRoundedRectangle(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.RoundedRectangle rect, string brush, float strokeWidth, DashStyleHelper dashStyle)
		{
			// Create StrokeStyleProperties
			SharpDX.Direct2D1.StrokeStyleProperties ssProps = new SharpDX.Direct2D1.StrokeStyleProperties();
			
			switch (dashStyle)
			{
				case DashStyleHelper.Dash: 			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Dash; 		break;
				case DashStyleHelper.DashDot: 		ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.DashDot; 	break;
				case DashStyleHelper.DashDotDot:	ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.DashDotDot;	break;
				case DashStyleHelper.Dot:			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Dot;		break;
				case DashStyleHelper.Solid:			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Solid;		break;
				default: 							ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Solid;		break;
			}
			
			// Create StrokeStyle from StrokeStyleProperties
			SharpDX.Direct2D1.StrokeStyle strokeStyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, ssProps);
			renderTarget.DrawRoundedRectangle(rect, DXMBrushes[brush].DxBrush, strokeWidth, strokeStyle);
		}
		
		public void DrawRoundedRectangle(SharpDX.Direct2D1.RenderTarget renderTarget, float x, float y, float width, float height, float radiusX, float radiusY, string brush, float strokeWidth, DashStyleHelper dashStyle)
		{
			SharpDX.RectangleF rect = new SharpDX.RectangleF(x, y, width, height);
			
			SharpDX.Direct2D1.RoundedRectangle roundedRect = new SharpDX.Direct2D1.RoundedRectangle() { RadiusX = radiusX, RadiusY = radiusY, Rect = rect };
			
			DrawRoundedRectangle( renderTarget, roundedRect, brush, strokeWidth, dashStyle);
		}
		
		public void DrawRoundedRectangle(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.RectangleF rect, float radiusX, float radiusY, string brush, float strokeWidth, DashStyleHelper dashStyle)
		{
			SharpDX.Direct2D1.RoundedRectangle roundedRect = new SharpDX.Direct2D1.RoundedRectangle() { RadiusX = radiusX, RadiusY = radiusY, Rect = rect };
			
			DrawRoundedRectangle( renderTarget, roundedRect, brush, strokeWidth, dashStyle);
		}
		
		public void DrawRoundedRectangle(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.RoundedRectangle rect, string brush, float strokeWidth, SharpDX.Direct2D1.StrokeStyle strokeStyle)
		{
			renderTarget.DrawRoundedRectangle(rect, DXMBrushes[brush].DxBrush, strokeWidth, strokeStyle);
		}
		
		public void DrawRoundedRectangle(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.RoundedRectangle rect, string brush, float strokeWidth)
		{
			renderTarget.DrawRoundedRectangle(rect, DXMBrushes[brush].DxBrush, strokeWidth);
		}
		
		public void DrawRoundedRectangle(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.RoundedRectangle rect, string brush)
		{
			renderTarget.DrawRoundedRectangle(rect, DXMBrushes[brush].DxBrush);
		}
		#endregion
		
		#region Media Brushes		
		public void DrawRoundedRectangle(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.RoundedRectangle rect, Brush brush, float strokeWidth, DashStyleHelper dashStyle)
		{
			// Check if we have this brush and create it if not.
			HelperCheckAddBrush(renderTarget, brush);
			
			string brushString = GetBrushString(brush);
			
			// Create StrokeStyleProperties
			SharpDX.Direct2D1.StrokeStyleProperties ssProps = new SharpDX.Direct2D1.StrokeStyleProperties();
			
			switch (dashStyle)
			{
				case DashStyleHelper.Dash: 			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Dash; 		break;
				case DashStyleHelper.DashDot: 		ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.DashDot; 	break;
				case DashStyleHelper.DashDotDot:	ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.DashDotDot;	break;
				case DashStyleHelper.Dot:			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Dot;		break;
				case DashStyleHelper.Solid:			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Solid;		break;
				default: 							ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Solid;		break;
			}
			
			// Create StrokeStyle from StrokeStyleProperties
			SharpDX.Direct2D1.StrokeStyle strokeStyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, ssProps);
			renderTarget.DrawRoundedRectangle(rect, HelperManagedBrushes[brushString].DxBrush, strokeWidth, strokeStyle);
			
			strokeStyle.Dispose();
		}
		
		public void DrawRoundedRectangle(SharpDX.Direct2D1.RenderTarget renderTarget, float x, float y, float width, float height, float radiusX, float radiusY, Brush brush, float strokeWidth, DashStyleHelper dashStyle)
		{
			SharpDX.RectangleF rect = new SharpDX.RectangleF(x, y, width, height);
			
			SharpDX.Direct2D1.RoundedRectangle roundedRect = new SharpDX.Direct2D1.RoundedRectangle() { RadiusX = radiusX, RadiusY = radiusY, Rect = rect };
			
			DrawRoundedRectangle( renderTarget, roundedRect, brush, strokeWidth, dashStyle);
		}
		
		public void DrawRoundedRectangle(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.RectangleF rect, float radiusX, float radiusY, Brush brush, float strokeWidth, DashStyleHelper dashStyle)
		{
			SharpDX.Direct2D1.RoundedRectangle roundedRect = new SharpDX.Direct2D1.RoundedRectangle() { RadiusX = radiusX, RadiusY = radiusY, Rect = rect };
			
			DrawRoundedRectangle( renderTarget, roundedRect, brush, strokeWidth, dashStyle);
		}
		
		public void DrawRoundedRectangle(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.RoundedRectangle rect, Brush brush, float strokeWidth, SharpDX.Direct2D1.StrokeStyle strokeStyle)
		{
			// Check if we have this brush and create it if not.
			HelperCheckAddBrush(renderTarget, brush);
			
			string brushString = GetBrushString(brush);
			
			renderTarget.DrawRoundedRectangle(rect, HelperManagedBrushes[brushString].DxBrush, strokeWidth, strokeStyle);
		}
		
		public void DrawRoundedRectangle(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.RoundedRectangle rect, Brush brush, float strokeWidth)
		{
			// Check if we have this brush and create it if not.
			HelperCheckAddBrush(renderTarget, brush);
			
			string brushString = GetBrushString(brush);
			
			renderTarget.DrawRoundedRectangle(rect, HelperManagedBrushes[brushString].DxBrush, strokeWidth);
		}
		
		public void DrawRoundedRectangle(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.RoundedRectangle rect, Brush brush)
		{
			// Check if we have this brush and create it if not.
			HelperCheckAddBrush(renderTarget, brush);
			
			string brushString = GetBrushString(brush);
			
			renderTarget.DrawRoundedRectangle(rect, HelperManagedBrushes[brushString].DxBrush);
		}
		#endregion
		#endregion
		
		#region FillRoundedRectangle
		#region SharpDX Brushes
		public void FillRoundedRectangle(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.RoundedRectangle rect, SharpDX.Direct2D1.Brush brush)
		{
			renderTarget.FillRoundedRectangle(rect, brush);
		}
		
		public void FillRoundedRectangle(SharpDX.Direct2D1.RenderTarget renderTarget, float x, float y, float width, float height, float radiusX, float radiusY, SharpDX.Direct2D1.Brush brush)
		{
			SharpDX.RectangleF rect = new SharpDX.RectangleF(x, y, width, height);
			
			SharpDX.Direct2D1.RoundedRectangle roundedRect = new SharpDX.Direct2D1.RoundedRectangle() { RadiusX = radiusX, RadiusY = radiusY, Rect = rect };
			
			FillRoundedRectangle(renderTarget, roundedRect, brush);
		}
		
		public void FillRoundedRectangle(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.RectangleF rect, float radiusX, float radiusY, SharpDX.Direct2D1.Brush brush)
		{			
			SharpDX.Direct2D1.RoundedRectangle roundedRect = new SharpDX.Direct2D1.RoundedRectangle() { RadiusX = radiusX, RadiusY = radiusY, Rect = rect };
			
			FillRoundedRectangle(renderTarget, roundedRect, brush);
		}
		#endregion
		
		#region DXMediaBrushes
		public void FillRoundedRectangle(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.RoundedRectangle rect, DXMediaBrush brush)
		{
			renderTarget.FillRoundedRectangle(rect, brush.DxBrush);
		}
		
		public void FillRoundedRectangle(SharpDX.Direct2D1.RenderTarget renderTarget, float x, float y, float width, float height, float radiusX, float radiusY, DXMediaBrush brush)
		{
			SharpDX.RectangleF rect = new SharpDX.RectangleF(x, y, width, height);
			
			SharpDX.Direct2D1.RoundedRectangle roundedRect = new SharpDX.Direct2D1.RoundedRectangle() { RadiusX = radiusX, RadiusY = radiusY, Rect = rect };
			
			FillRoundedRectangle(renderTarget, roundedRect, brush);
		}
		
		public void FillRoundedRectangle(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.RectangleF rect, float radiusX, float radiusY, DXMediaBrush brush)
		{			
			SharpDX.Direct2D1.RoundedRectangle roundedRect = new SharpDX.Direct2D1.RoundedRectangle() { RadiusX = radiusX, RadiusY = radiusY, Rect = rect };
			
			FillRoundedRectangle(renderTarget, roundedRect, brush);
		}
		#endregion
		
		#region Dictionary Brushes
		public void FillRoundedRectangle(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.RoundedRectangle rect, float radiusX, float radiusY, string brush)
		{
			renderTarget.FillRoundedRectangle(rect, DXMBrushes[brush].DxBrush);
		}
		
		public void FillRoundedRectangle(SharpDX.Direct2D1.RenderTarget renderTarget, float x, float y, float width, float height, float radiusX, float radiusY, string brush)
		{
			SharpDX.RectangleF rect = new SharpDX.RectangleF(x, y, width, height);
			
			SharpDX.Direct2D1.RoundedRectangle roundedRect = new SharpDX.Direct2D1.RoundedRectangle() { RadiusX = radiusX, RadiusY = radiusY, Rect = rect };
			
			FillRoundedRectangle(renderTarget, roundedRect, DXMBrushes[brush].DxBrush);
		}
		
		public void FillRoundedRectangle(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.RectangleF rect, float radiusX, float radiusY, string brush)
		{			
			SharpDX.Direct2D1.RoundedRectangle roundedRect = new SharpDX.Direct2D1.RoundedRectangle() { RadiusX = radiusX, RadiusY = radiusY, Rect = rect };
			
			FillRoundedRectangle(renderTarget, roundedRect, DXMBrushes[brush].DxBrush);
		}
		#endregion
		
		#region Media Brushes
		public void FillRoundedRectangle(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.RoundedRectangle rect, Brush brush)
		{
			// Check if we have this brush and create it if not.
			HelperCheckAddBrush(renderTarget, brush);
			
			string brushString = GetBrushString(brush);
			
			renderTarget.FillRoundedRectangle(rect, HelperManagedBrushes[brushString].DxBrush);
		}
		
		public void FillRoundedRectangle(SharpDX.Direct2D1.RenderTarget renderTarget, float x, float y, float width, float height, float radiusX, float radiusY, Brush brush)
		{
			SharpDX.RectangleF rect = new SharpDX.RectangleF(x, y, width, height);
			
			SharpDX.Direct2D1.RoundedRectangle roundedRect = new SharpDX.Direct2D1.RoundedRectangle() { RadiusX = radiusX, RadiusY = radiusY, Rect = rect };
			
			FillRoundedRectangle(renderTarget, roundedRect, brush);
		}
		
		public void FillRoundedRectangle(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.RectangleF rect, float radiusX, float radiusY, Brush brush)
		{			
			SharpDX.Direct2D1.RoundedRectangle roundedRect = new SharpDX.Direct2D1.RoundedRectangle() { RadiusX = radiusX, RadiusY = radiusY, Rect = rect };
			
			FillRoundedRectangle(renderTarget, roundedRect, brush);
		}
		#endregion
		#endregion
		
		#region DrawGeometry
		#region SharpDX Brushes
		public void DrawGeometry(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.Geometry geometry, SharpDX.Direct2D1.Brush brush, float strokeWidth, SharpDX.Direct2D1.StrokeStyle strokeStyle)
		{
			renderTarget.DrawGeometry(geometry, brush, strokeWidth, strokeStyle);
			
			geometry.Dispose();
			strokeStyle.Dispose();
		}
		
		public void DrawGeometry(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.Geometry geometry, SharpDX.Direct2D1.Brush brush, float strokeWidth, DashStyleHelper dashStyle)
		{			
			// Create StrokeStyleProperties
			SharpDX.Direct2D1.StrokeStyleProperties ssProps = new SharpDX.Direct2D1.StrokeStyleProperties();
			
			switch (dashStyle)
			{
				case DashStyleHelper.Dash: 			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Dash; 		break;
				case DashStyleHelper.DashDot: 		ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.DashDot; 	break;
				case DashStyleHelper.DashDotDot:	ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.DashDotDot;	break;
				case DashStyleHelper.Dot:			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Dot;		break;
				case DashStyleHelper.Solid:			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Solid;		break;
				default: 							ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Solid;		break;
			}
			
			// Create StrokeStyle from StrokeStyleProperties
			SharpDX.Direct2D1.StrokeStyle strokeStyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, ssProps);
			DrawGeometry(renderTarget, geometry, brush, strokeWidth, strokeStyle);
			
			geometry.Dispose();
			strokeStyle.Dispose();
		}
		
		public void DrawGeometry(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.Geometry geometry, SharpDX.Direct2D1.Brush brush, DashStyleHelper dashStyle)
		{
			DrawGeometry(renderTarget, geometry, brush, 1f, dashStyle);
			
			geometry.Dispose();
		}
		
		public void DrawGeometry(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.Geometry geometry, SharpDX.Direct2D1.Brush brush)
		{
			DrawGeometry(renderTarget, geometry, brush, 1f, DashStyleHelper.Solid);
			
			geometry.Dispose();
		}
		
		public void DrawGeometry(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Vector2[] points, SharpDX.Direct2D1.Brush brush, float strokeWidth, SharpDX.Direct2D1.StrokeStyle strokeStyle)
		{						
			SharpDX.Direct2D1.PathGeometry geometry = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);	
			SharpDX.Direct2D1.GeometrySink sink = geometry.Open();
			
			sink.BeginFigure(points[0], new SharpDX.Direct2D1.FigureBegin());	
			
			for (int i = 1; i < points.GetLength(0); i++)
				sink.AddLine(points[i]);
			
			sink.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
			sink.Close();			
			
			DrawGeometry(renderTarget, geometry, brush, strokeWidth, strokeStyle);
			
			strokeStyle.Dispose();
			geometry.Dispose();
			sink.Dispose();
		}
		
		public void DrawGeometry(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Vector2[] points, SharpDX.Direct2D1.Brush brush, float strokeWidth, DashStyleHelper dashStyle)
		{						
			// Create StrokeStyleProperties
			SharpDX.Direct2D1.StrokeStyleProperties ssProps = new SharpDX.Direct2D1.StrokeStyleProperties();
			
			switch (dashStyle)
			{
				case DashStyleHelper.Dash: 			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Dash; 		break;
				case DashStyleHelper.DashDot: 		ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.DashDot; 	break;
				case DashStyleHelper.DashDotDot:	ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.DashDotDot;	break;
				case DashStyleHelper.Dot:			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Dot;		break;
				case DashStyleHelper.Solid:			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Solid;		break;
				default: 							ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Solid;		break;
			}
			
			// Create StrokeStyle from StrokeStyleProperties
			SharpDX.Direct2D1.StrokeStyle strokeStyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, ssProps);			
			
			DrawGeometry(renderTarget, points, brush, strokeWidth, strokeStyle);

			strokeStyle.Dispose();
		}
		
		public void DrawGeometry(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Vector2[] points, SharpDX.Direct2D1.Brush brush, float strokeWidth)
		{
			DrawGeometry(renderTarget, points, brush, strokeWidth, DashStyleHelper.Solid);
		}
		
		public void DrawGeometry(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Vector2[] points, SharpDX.Direct2D1.Brush brush, DashStyleHelper dashStyle)
		{
			DrawGeometry(renderTarget, points, brush, 1f, dashStyle);
		}
		
		public void DrawGeometry(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Vector2[] points, SharpDX.Direct2D1.Brush brush)
		{
			DrawGeometry(renderTarget, points, brush, 1f, DashStyleHelper.Solid);
		}
		#endregion
		
		#region DXMediaBrushes
		public void DrawGeometry(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.Geometry geometry, DXMediaBrush brush, float strokeWidth, SharpDX.Direct2D1.StrokeStyle strokeStyle)
		{
			renderTarget.DrawGeometry(geometry, brush.DxBrush, strokeWidth, strokeStyle);
			
			geometry.Dispose();
			strokeStyle.Dispose();
		}
		
		public void DrawGeometry(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.Geometry geometry, DXMediaBrush brush, float strokeWidth, DashStyleHelper dashStyle)
		{			
			// Create StrokeStyleProperties
			SharpDX.Direct2D1.StrokeStyleProperties ssProps = new SharpDX.Direct2D1.StrokeStyleProperties();
			
			switch (dashStyle)
			{
				case DashStyleHelper.Dash: 			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Dash; 		break;
				case DashStyleHelper.DashDot: 		ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.DashDot; 	break;
				case DashStyleHelper.DashDotDot:	ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.DashDotDot;	break;
				case DashStyleHelper.Dot:			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Dot;		break;
				case DashStyleHelper.Solid:			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Solid;		break;
				default: 							ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Solid;		break;
			}
			
			// Create StrokeStyle from StrokeStyleProperties
			SharpDX.Direct2D1.StrokeStyle strokeStyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, ssProps);
			DrawGeometry(renderTarget, geometry, brush, strokeWidth, strokeStyle);
			
			geometry.Dispose();
			strokeStyle.Dispose();
		}
		
		public void DrawGeometry(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.Geometry geometry, DXMediaBrush brush, DashStyleHelper dashStyle)
		{
			DrawGeometry(renderTarget, geometry, brush, 1f, dashStyle);
			
			geometry.Dispose();
		}
		
		public void DrawGeometry(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.Geometry geometry, DXMediaBrush brush)
		{
			DrawGeometry(renderTarget, geometry, brush, 1f, DashStyleHelper.Solid);
			
			geometry.Dispose();
		}
		
		public void DrawGeometry(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Vector2[] points, DXMediaBrush brush, float strokeWidth, SharpDX.Direct2D1.StrokeStyle strokeStyle)
		{						
			SharpDX.Direct2D1.PathGeometry geometry = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);	
			SharpDX.Direct2D1.GeometrySink sink = geometry.Open();
			
			sink.BeginFigure(points[0], new SharpDX.Direct2D1.FigureBegin());	
			
			for (int i = 1; i < points.GetLength(0); i++)
				sink.AddLine(points[i]);
			
			sink.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
			sink.Close();			
			
			DrawGeometry(renderTarget, geometry, brush, strokeWidth, strokeStyle);
			
			strokeStyle.Dispose();
			geometry.Dispose();
			sink.Dispose();
		}
		
		public void DrawGeometry(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Vector2[] points, DXMediaBrush brush, float strokeWidth, DashStyleHelper dashStyle)
		{						
			// Create StrokeStyleProperties
			SharpDX.Direct2D1.StrokeStyleProperties ssProps = new SharpDX.Direct2D1.StrokeStyleProperties();
			
			switch (dashStyle)
			{
				case DashStyleHelper.Dash: 			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Dash; 		break;
				case DashStyleHelper.DashDot: 		ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.DashDot; 	break;
				case DashStyleHelper.DashDotDot:	ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.DashDotDot;	break;
				case DashStyleHelper.Dot:			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Dot;		break;
				case DashStyleHelper.Solid:			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Solid;		break;
				default: 							ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Solid;		break;
			}
			
			// Create StrokeStyle from StrokeStyleProperties
			SharpDX.Direct2D1.StrokeStyle strokeStyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, ssProps);			
			
			DrawGeometry(renderTarget, points, brush, strokeWidth, strokeStyle);

			strokeStyle.Dispose();
		}
		
		public void DrawGeometry(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Vector2[] points, DXMediaBrush brush, float strokeWidth)
		{
			DrawGeometry(renderTarget, points, brush, strokeWidth, DashStyleHelper.Solid);
		}
		
		public void DrawGeometry(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Vector2[] points, DXMediaBrush brush, DashStyleHelper dashStyle)
		{
			DrawGeometry(renderTarget, points, brush, 1f, dashStyle);
		}
		
		public void DrawGeometry(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Vector2[] points, DXMediaBrush brush)
		{
			DrawGeometry(renderTarget, points, brush, 1f, DashStyleHelper.Solid);
		}
		#endregion
		
		#region Dictionary Brushes
		public void DrawGeometry(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.Geometry geometry, string brush, float strokeWidth, SharpDX.Direct2D1.StrokeStyle strokeStyle)
		{
			renderTarget.DrawGeometry(geometry, DXMBrushes[brush].DxBrush, strokeWidth, strokeStyle);
			
			geometry.Dispose();
			strokeStyle.Dispose();
		}
		
		public void DrawGeometry(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.Geometry geometry, string brush, float strokeWidth, DashStyleHelper dashStyle)
		{			
			// Create StrokeStyleProperties
			SharpDX.Direct2D1.StrokeStyleProperties ssProps = new SharpDX.Direct2D1.StrokeStyleProperties();
			
			switch (dashStyle)
			{
				case DashStyleHelper.Dash: 			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Dash; 		break;
				case DashStyleHelper.DashDot: 		ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.DashDot; 	break;
				case DashStyleHelper.DashDotDot:	ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.DashDotDot;	break;
				case DashStyleHelper.Dot:			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Dot;		break;
				case DashStyleHelper.Solid:			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Solid;		break;
				default: 							ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Solid;		break;
			}
			
			// Create StrokeStyle from StrokeStyleProperties
			SharpDX.Direct2D1.StrokeStyle strokeStyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, ssProps);
			DrawGeometry(renderTarget, geometry, brush, strokeWidth, strokeStyle);
			
			geometry.Dispose();
			strokeStyle.Dispose();
		}
		
		public void DrawGeometry(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.Geometry geometry, string brush, DashStyleHelper dashStyle)
		{
			DrawGeometry(renderTarget, geometry, brush, 1f, dashStyle);
			
			geometry.Dispose();
		}
		
		public void DrawGeometry(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.Geometry geometry, string brush)
		{
			DrawGeometry(renderTarget, geometry, brush, 1f, DashStyleHelper.Solid);
			
			geometry.Dispose();
		}
		
		public void DrawGeometry(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Vector2[] points, string brush, float strokeWidth, SharpDX.Direct2D1.StrokeStyle strokeStyle)
		{						
			SharpDX.Direct2D1.PathGeometry geometry = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);	
			SharpDX.Direct2D1.GeometrySink sink = geometry.Open();
			
			sink.BeginFigure(points[0], new SharpDX.Direct2D1.FigureBegin());	
			
			for (int i = 1; i < points.GetLength(0); i++)
				sink.AddLine(points[i]);
			
			sink.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
			sink.Close();			
			
			DrawGeometry(renderTarget, geometry, brush, strokeWidth, strokeStyle);
			
			strokeStyle.Dispose();
			geometry.Dispose();
			sink.Dispose();
		}
		
		public void DrawGeometry(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Vector2[] points, string brush, float strokeWidth, DashStyleHelper dashStyle)
		{						
			// Create StrokeStyleProperties
			SharpDX.Direct2D1.StrokeStyleProperties ssProps = new SharpDX.Direct2D1.StrokeStyleProperties();
			
			switch (dashStyle)
			{
				case DashStyleHelper.Dash: 			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Dash; 		break;
				case DashStyleHelper.DashDot: 		ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.DashDot; 	break;
				case DashStyleHelper.DashDotDot:	ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.DashDotDot;	break;
				case DashStyleHelper.Dot:			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Dot;		break;
				case DashStyleHelper.Solid:			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Solid;		break;
				default: 							ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Solid;		break;
			}
			
			// Create StrokeStyle from StrokeStyleProperties
			SharpDX.Direct2D1.StrokeStyle strokeStyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, ssProps);			
			
			DrawGeometry(renderTarget, points, brush, strokeWidth, strokeStyle);

			strokeStyle.Dispose();
		}
		
		public void DrawGeometry(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Vector2[] points, string brush, float strokeWidth)
		{
			DrawGeometry(renderTarget, points, brush, strokeWidth, DashStyleHelper.Solid);
		}
		
		public void DrawGeometry(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Vector2[] points, string brush, DashStyleHelper dashStyle)
		{
			DrawGeometry(renderTarget, points, brush, 1f, dashStyle);
		}
		
		public void DrawGeometry(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Vector2[] points, string brush)
		{
			DrawGeometry(renderTarget, points, brush, 1f, DashStyleHelper.Solid);
		}
		#endregion
		
		#region Media Brushes
		public void DrawGeometry(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.Geometry geometry, Brush brush, float strokeWidth, SharpDX.Direct2D1.StrokeStyle strokeStyle)
		{
			// Check if we have this brush and create it if not.
			HelperCheckAddBrush(renderTarget, brush);
			
			string brushString = GetBrushString(brush);
			
			renderTarget.DrawGeometry(geometry, HelperManagedBrushes[brushString].DxBrush, strokeWidth, strokeStyle);
			
			geometry.Dispose();
			strokeStyle.Dispose();
		}
		
		public void DrawGeometry(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.Geometry geometry, Brush brush, float strokeWidth, DashStyleHelper dashStyle)
		{			
			// Create StrokeStyleProperties
			SharpDX.Direct2D1.StrokeStyleProperties ssProps = new SharpDX.Direct2D1.StrokeStyleProperties();
			
			switch (dashStyle)
			{
				case DashStyleHelper.Dash: 			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Dash; 		break;
				case DashStyleHelper.DashDot: 		ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.DashDot; 	break;
				case DashStyleHelper.DashDotDot:	ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.DashDotDot;	break;
				case DashStyleHelper.Dot:			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Dot;		break;
				case DashStyleHelper.Solid:			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Solid;		break;
				default: 							ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Solid;		break;
			}
			
			// Create StrokeStyle from StrokeStyleProperties
			SharpDX.Direct2D1.StrokeStyle strokeStyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, ssProps);
			DrawGeometry(renderTarget, geometry, brush, strokeWidth, strokeStyle);
			
			geometry.Dispose();
			strokeStyle.Dispose();
		}
		
		public void DrawGeometry(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.Geometry geometry, Brush brush, DashStyleHelper dashStyle)
		{
			DrawGeometry(renderTarget, geometry, brush, 1f, dashStyle);
			
			geometry.Dispose();
		}
		
		public void DrawGeometry(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.Geometry geometry, Brush brush)
		{
			DrawGeometry(renderTarget, geometry, brush, 1f, DashStyleHelper.Solid);
			
			geometry.Dispose();
		}
		
		public void DrawGeometry(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Vector2[] points, Brush brush, float strokeWidth, SharpDX.Direct2D1.StrokeStyle strokeStyle)
		{						
			SharpDX.Direct2D1.PathGeometry geometry = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);	
			SharpDX.Direct2D1.GeometrySink sink = geometry.Open();
			
			sink.BeginFigure(points[0], new SharpDX.Direct2D1.FigureBegin());	
			
			for (int i = 1; i < points.GetLength(0); i++)
				sink.AddLine(points[i]);
			
			sink.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
			sink.Close();			
			
			DrawGeometry(renderTarget, geometry, brush, strokeWidth, strokeStyle);
			
			strokeStyle.Dispose();
			geometry.Dispose();
			sink.Dispose();
		}
		
		public void DrawGeometry(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Vector2[] points, Brush brush, float strokeWidth, DashStyleHelper dashStyle)
		{						
			// Create StrokeStyleProperties
			SharpDX.Direct2D1.StrokeStyleProperties ssProps = new SharpDX.Direct2D1.StrokeStyleProperties();
			
			switch (dashStyle)
			{
				case DashStyleHelper.Dash: 			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Dash; 		break;
				case DashStyleHelper.DashDot: 		ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.DashDot; 	break;
				case DashStyleHelper.DashDotDot:	ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.DashDotDot;	break;
				case DashStyleHelper.Dot:			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Dot;		break;
				case DashStyleHelper.Solid:			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Solid;		break;
				default: 							ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Solid;		break;
			}
			
			// Create StrokeStyle from StrokeStyleProperties
			SharpDX.Direct2D1.StrokeStyle strokeStyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, ssProps);			
			
			DrawGeometry(renderTarget, points, brush, strokeWidth, strokeStyle);

			strokeStyle.Dispose();
		}
		
		public void DrawGeometry(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Vector2[] points, Brush brush, float strokeWidth)
		{
			DrawGeometry(renderTarget, points, brush, strokeWidth, DashStyleHelper.Solid);
		}
		
		public void DrawGeometry(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Vector2[] points, Brush brush, DashStyleHelper dashStyle)
		{
			DrawGeometry(renderTarget, points, brush, 1f, dashStyle);
		}
		
		public void DrawGeometry(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Vector2[] points, Brush brush)
		{
			DrawGeometry(renderTarget, points, brush, 1f, DashStyleHelper.Solid);
		}
		#endregion
		#endregion
		
		#region FillGeometry
		#region SharpDX Brushes
		public void FillGeometry(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.Geometry geometry, SharpDX.Direct2D1.Brush brush, SharpDX.Direct2D1.Brush brushOpacity)
		{
			renderTarget.FillGeometry(geometry, brush, brushOpacity);
			
			geometry.Dispose();
		}
		
		public void FillGeometry(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.Geometry geometry, SharpDX.Direct2D1.Brush brush)
		{
			renderTarget.FillGeometry(geometry, brush);
			
			geometry.Dispose();
		}
		
		public void FillGeometry(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Vector2[] points, SharpDX.Direct2D1.Brush brush, SharpDX.Direct2D1.Brush brushOpacity)
		{						
			SharpDX.Direct2D1.PathGeometry geometry = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);	
			SharpDX.Direct2D1.GeometrySink sink = geometry.Open();
			
			sink.BeginFigure(points[0], new SharpDX.Direct2D1.FigureBegin());	
			
			for (int i = 1; i < points.GetLength(0); i++)
				sink.AddLine(points[i]);
			
			sink.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
			sink.Close();			
			
			FillGeometry(renderTarget, geometry, brush, brushOpacity);
			
			geometry.Dispose();
			sink.Dispose();
		}
		
		public void FillGeometry(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Vector2[] points, SharpDX.Direct2D1.Brush brush)
		{						
			SharpDX.Direct2D1.PathGeometry geometry = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);	
			SharpDX.Direct2D1.GeometrySink sink = geometry.Open();
			
			sink.BeginFigure(points[0], new SharpDX.Direct2D1.FigureBegin());	
			
			for (int i = 1; i < points.GetLength(0); i++)
				sink.AddLine(points[i]);
			
			sink.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
			sink.Close();			
			
			FillGeometry(renderTarget, geometry, brush);
			
			geometry.Dispose();
			sink.Dispose();
		}
		#endregion
		
		#region DXMediaBrushes
		public void FillGeometry(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.Geometry geometry, DXMediaBrush brush, DXMediaBrush brushOpacity)
		{
			renderTarget.FillGeometry(geometry, brush.DxBrush, brushOpacity.DxBrush);
			
			geometry.Dispose();
		}
		
		public void FillGeometry(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.Geometry geometry, DXMediaBrush brush)
		{
			renderTarget.FillGeometry(geometry, brush.DxBrush);
			
			geometry.Dispose();
		}
		
		public void DrawGeometry(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Vector2[] points, DXMediaBrush brush, DXMediaBrush brushOpacity)
		{						
			SharpDX.Direct2D1.PathGeometry geometry = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);	
			SharpDX.Direct2D1.GeometrySink sink = geometry.Open();
			
			sink.BeginFigure(points[0], new SharpDX.Direct2D1.FigureBegin());	
			
			for (int i = 1; i < points.GetLength(0); i++)
				sink.AddLine(points[i]);
			
			sink.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
			sink.Close();			
			
			FillGeometry(renderTarget, geometry, brush, brushOpacity);
			
			geometry.Dispose();
			sink.Dispose();
		}
		
		public void FillGeometry(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Vector2[] points, DXMediaBrush brush)
		{						
			SharpDX.Direct2D1.PathGeometry geometry = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);	
			SharpDX.Direct2D1.GeometrySink sink = geometry.Open();
			
			sink.BeginFigure(points[0], new SharpDX.Direct2D1.FigureBegin());	
			
			for (int i = 1; i < points.GetLength(0); i++)
				sink.AddLine(points[i]);
			
			sink.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
			sink.Close();			
			
			FillGeometry(renderTarget, geometry, brush);
			
			geometry.Dispose();
			sink.Dispose();
		}
		#endregion
		
		#region Dictionary Brushes
		public void FillGeometry(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.Geometry geometry, string brush, string brushOpacity)
		{
			renderTarget.FillGeometry(geometry, DXMBrushes[brush].DxBrush, DXMBrushes[brushOpacity].DxBrush);
			
			geometry.Dispose();
		}
		
		public void FillGeometry(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.Geometry geometry, string brush)
		{
			renderTarget.FillGeometry(geometry, DXMBrushes[brush].DxBrush);
			
			geometry.Dispose();
		}
		
		public void DrawGeometry(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Vector2[] points, string brush, string brushOpacity)
		{						
			SharpDX.Direct2D1.PathGeometry geometry = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);	
			SharpDX.Direct2D1.GeometrySink sink = geometry.Open();
			
			sink.BeginFigure(points[0], new SharpDX.Direct2D1.FigureBegin());	
			
			for (int i = 1; i < points.GetLength(0); i++)
				sink.AddLine(points[i]);
			
			sink.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
			sink.Close();			
			
			FillGeometry(renderTarget, geometry, brush, brushOpacity);
			
			geometry.Dispose();
			sink.Dispose();
		}
		
		public void FillGeometry(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Vector2[] points, string brush)
		{						
			SharpDX.Direct2D1.PathGeometry geometry = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);	
			SharpDX.Direct2D1.GeometrySink sink = geometry.Open();
			
			sink.BeginFigure(points[0], new SharpDX.Direct2D1.FigureBegin());	
			
			for (int i = 1; i < points.GetLength(0); i++)
				sink.AddLine(points[i]);
			
			sink.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
			sink.Close();			
			
			FillGeometry(renderTarget, geometry, brush);
			
			geometry.Dispose();
			sink.Dispose();
		}
		#endregion	
		
		#region Media Brushes
		public void FillGeometry(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.Geometry geometry, Brush brush, Brush brushOpacity)
		{
			// Check if we have this brush and create it if not.
			HelperCheckAddBrush(renderTarget, brush);
			HelperCheckAddBrush(renderTarget, brushOpacity);
			
			string brushString = GetBrushString(brush);
			string brushOpacityString = GetBrushString(brushOpacity);
			
			renderTarget.FillGeometry(geometry, HelperManagedBrushes[brushString].DxBrush, HelperManagedBrushes[brushOpacityString].DxBrush);
			
			geometry.Dispose();
		}
		
		public void FillGeometry(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.Geometry geometry, Brush brush)
		{
			// Check if we have this brush and create it if not.
			HelperCheckAddBrush(renderTarget, brush);
			
			string brushString = GetBrushString(brush);
			
			renderTarget.FillGeometry(geometry, HelperManagedBrushes[brushString].DxBrush);
			
			geometry.Dispose();
		}
		
		public void DrawGeometry(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Vector2[] points, Brush brush, Brush brushOpacity)
		{						
			SharpDX.Direct2D1.PathGeometry geometry = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);	
			SharpDX.Direct2D1.GeometrySink sink = geometry.Open();
			
			sink.BeginFigure(points[0], new SharpDX.Direct2D1.FigureBegin());	
			
			for (int i = 1; i < points.GetLength(0); i++)
				sink.AddLine(points[i]);
			
			sink.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
			sink.Close();			
			
			FillGeometry(renderTarget, geometry, brush, brushOpacity);
			
			geometry.Dispose();
			sink.Dispose();
		}
		
		public void FillGeometry(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Vector2[] points, Brush brush)
		{						
			SharpDX.Direct2D1.PathGeometry geometry = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);	
			SharpDX.Direct2D1.GeometrySink sink = geometry.Open();
			
			sink.BeginFigure(points[0], new SharpDX.Direct2D1.FigureBegin());	
			
			for (int i = 1; i < points.GetLength(0); i++)
				sink.AddLine(points[i]);
			
			sink.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
			sink.Close();			
			
			FillGeometry(renderTarget, geometry, brush);
			
			geometry.Dispose();
			sink.Dispose();
		}
		#endregion	
		#endregion
	
		#region DrawBitmap		
		private void DisposeBitmapResources()
		{
			foreach (KeyValuePair<string, SharpDX.Direct2D1.Bitmap> bitmap in bitmapDictionary)
				bitmap.Value.Dispose();
			foreach (KeyValuePair<string, SharpDX.IO.NativeFileStream> fileStream in fileStreamDictionary)
				fileStream.Value.Dispose();
			foreach (KeyValuePair<string, SharpDX.WIC.BitmapDecoder> bitmapDecoder in bitmapDecoderDictionary)
				bitmapDecoder.Value.Dispose();
			foreach (KeyValuePair<string, SharpDX.WIC.FormatConverter> converter in converterDictionary)
				converter.Value.Dispose();
			foreach (KeyValuePair<string, SharpDX.WIC.BitmapFrameDecode> frame in frameDictionary)
				frame.Value.Dispose();
			
			bitmapDictionary.Clear();
			fileStreamDictionary.Clear();
			bitmapDecoderDictionary.Clear();
			converterDictionary.Clear();
			frameDictionary.Clear();
		}
		
		private void CreateBitmapResources(SharpDX.Direct2D1.RenderTarget renderTarget)
		{
			foreach (string filePath in bitmapList)
			{
				fileStreamDictionary.Add(filePath, new SharpDX.IO.NativeFileStream(System.IO.Path.Combine(NinjaTrader.Core.Globals.UserDataDir, filePath), SharpDX.IO.NativeFileMode.Open, SharpDX.IO.NativeFileAccess.Read));
				
				bitmapDecoderDictionary.Add(filePath, new SharpDX.WIC.BitmapDecoder(Core.Globals.WicImagingFactory, fileStreamDictionary[filePath], SharpDX.WIC.DecodeOptions.CacheOnDemand));
				
				frameDictionary.Add(filePath, bitmapDecoderDictionary[filePath].GetFrame(0));
				
				converterDictionary.Add(filePath, new SharpDX.WIC.FormatConverter(Core.Globals.WicImagingFactory));
				converterDictionary[filePath].Initialize(frameDictionary[filePath], SharpDX.WIC.PixelFormat.Format32bppPRGBA);
				
				bitmapDictionary.Add(filePath, SharpDX.Direct2D1.Bitmap.FromWicBitmap(renderTarget, converterDictionary[filePath]));
			}
		}
		
		public void AddBitmap(SharpDX.Direct2D1.RenderTarget renderTarget, string filePath)
		{
			bitmapDictionary.Add(filePath, null);
			fileStreamDictionary.Add(filePath, null);
			bitmapDecoderDictionary.Add(filePath, null);
			converterDictionary.Add(filePath, null);
			frameDictionary.Add(filePath, null);
			
			bitmapList.Add(filePath);
		}
		
		public void DrawBitmap(SharpDX.Direct2D1.RenderTarget renderTarget, string filePath, SharpDX.RectangleF rect, float opacity, SharpDX.Direct2D1.BitmapInterpolationMode bitmapInterp)
		{
			renderTarget.DrawBitmap(bitmapDictionary[filePath], rect, opacity, bitmapInterp);
		}
		
		public void DrawBitmap(SharpDX.Direct2D1.RenderTarget renderTarget, string filePath, SharpDX.RectangleF rect, float opacity)
		{
			DrawBitmap(renderTarget, filePath, rect, opacity, SharpDX.Direct2D1.BitmapInterpolationMode.Linear);
		}
		
		public void DrawBitmap(SharpDX.Direct2D1.RenderTarget renderTarget, string filePath, SharpDX.RectangleF rect)
		{
			DrawBitmap(renderTarget, filePath, rect, 100, SharpDX.Direct2D1.BitmapInterpolationMode.Linear);
		}
		
		public void DrawBitmap(SharpDX.Direct2D1.RenderTarget renderTarget, string filePath, float x, float y, float width, float height, float opacity, SharpDX.Direct2D1.BitmapInterpolationMode bitmapInterp)
		{
			SharpDX.RectangleF rect = new SharpDX.RectangleF(x, y, width, height);
			
			renderTarget.DrawBitmap(bitmapDictionary[filePath], rect, opacity, bitmapInterp);
		}
		
		public void DrawBitmap(SharpDX.Direct2D1.RenderTarget renderTarget, string filePath, float x, float y, float width, float height, float opacity)
		{
			SharpDX.RectangleF rect = new SharpDX.RectangleF(x, y, width, height);
			
			DrawBitmap(renderTarget, filePath, rect, opacity, SharpDX.Direct2D1.BitmapInterpolationMode.Linear);
		}
		
		public void DrawBitmap(SharpDX.Direct2D1.RenderTarget renderTarget, string filePath, float x, float y, float width, float height)
		{
			SharpDX.RectangleF rect = new SharpDX.RectangleF(x, y, width, height);
			
			DrawBitmap(renderTarget, filePath, rect, 100, SharpDX.Direct2D1.BitmapInterpolationMode.Linear);
		}
		#endregion
	}
	
	// Our DX/Media Brush management class.
    public class DXMediaBrush
    {
		private System.Windows.Media.Brush mediaBrush;
		private SharpDX.Direct2D1.Brush dxBrush;
		private double opacity;

        public byte GetAlpha()
        {
            return ((Color)mediaBrush.GetValue(SolidColorBrush.ColorProperty)).A;
        }

        public byte GetRed()
        {
            return ((Color)mediaBrush.GetValue(SolidColorBrush.ColorProperty)).R;
        }

        public byte GetGreen()
        {
            return ((Color)mediaBrush.GetValue(SolidColorBrush.ColorProperty)).G;
        }

        public byte GetBlue()
        {
            return ((Color)mediaBrush.GetValue(SolidColorBrush.ColorProperty)).B;
        }

        private void SetOpacity(double newOpacity)
        {
            if (mediaBrush == null)
                return;
			
			// Force opcatity to be in bounds
			opacity = Math.Min(100.0, Math.Max(0, newOpacity));

			// Clone any Frozen brush so it can be modified
            if (mediaBrush.IsFrozen)
                mediaBrush = mediaBrush.Clone();

			// Set Opacity and freeze brush.
            mediaBrush.Opacity = opacity / 100.0;
            mediaBrush.Freeze();
        }
		
		public DXMediaBrush()
		{
			dxBrush = null;
			mediaBrush = null;
			opacity = 100.0;
		}
		
		public void Dispose()
		{
			if(dxBrush != null)
				dxBrush.Dispose();
		}
		
		/// <summary>
		/// Updates the Media Bursh and SharpDX Brush without changing opacity.
		/// </summary>
		/// <param name="owner">The hosting NinjaScript's RenderTarget</param>
		/// <param name="owner">The new Opacity to use</param>
		public void UpdateOpacity(SharpDX.Direct2D1.RenderTarget renderTarget, double newOpacity)
		{					
			UpdateBrush(renderTarget, mediaBrush, newOpacity);
		}
		
		/// <summary>
		/// Updates the Media Bursh and SharpDX Brush also changing opacity.
		/// </summary>
		/// <param name="owner">The hosting NinjaScript's RenderTarget</param>
		/// <param name="owner">The new Media Brush to use</param>
		/// <param name="owner">The new Opacity to use</param>
		public void UpdateBrush(SharpDX.Direct2D1.RenderTarget renderTarget, Brush newMediaBrush, double newOpacity)
        {					
			// Set Media Brush to brush passed
            mediaBrush = newMediaBrush;
			
			// Call SetOpacity() to clone, set opacity and freeze brush.
            SetOpacity(newOpacity);
			
			// Dispose DX Brushes and other Device Dependant resources
            if (dxBrush != null)
                dxBrush.Dispose();
			
			// Recreate DX Brushes and other Device Dependant Resources here, making sure RenderTarget is not null or IsDisposed
            if (renderTarget != null && !renderTarget.IsDisposed)
			{
				dxBrush = mediaBrush.ToDxBrush(renderTarget); 
			}
        }
		
		/// <summary>
		/// Updates the Media Bursh and SharpDX Brush without changing opacity.
		/// </summary>
		/// <param name="owner">The hosting NinjaScript's RenderTarget</param>
		/// <param name="owner">The new Media Brush to use</param>
		public void UpdateBrush(SharpDX.Direct2D1.RenderTarget renderTarget, Brush newMediaBrush)
        {				
			UpdateBrush(renderTarget, newMediaBrush, opacity);
        }
		
		/// <summary>
		/// Updates device dependent resources for when RenderTarget changes.
		/// </summary>
		/// <param name="renderTarget">The hosting NinjaScript's RenderTarget</param>
		public void RenderTargetChange(SharpDX.Direct2D1.RenderTarget renderTarget)
		{
			if (renderTarget == null || renderTarget.IsDisposed)
				return;
			
			if (dxBrush != null)
				dxBrush.Dispose();

			if (mediaBrush != null)
				dxBrush = mediaBrush.ToDxBrush(renderTarget);
		}
		
		/// <summary>
		/// Returns SharpDX Brush.
		/// </summary>
		public SharpDX.Direct2D1.Brush DxBrush
		{
			get { return dxBrush; }
		}
		
		/// <summary>
		/// Returns Windows Media Brush.
		/// </summary>
		/// 
        public System.Windows.Media.Brush MediaBrush
		{
			get { return mediaBrush; }
		}
		
		/// <summary>
		/// Returns Brush Opactiy.
		/// </summary>
		public double Opacity
		{
			get { return opacity; }
		}
    }
}
