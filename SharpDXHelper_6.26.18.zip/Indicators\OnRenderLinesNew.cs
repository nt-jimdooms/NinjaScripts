#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class OnRenderLinesNew : Indicator
	{	
		private DXMediaBrush BrushToUse, TransparentBrush;
		private DXHelper DXH;
		private Brush tempBrush;
		
		// Create Series<bool> to tell if we want to draw something for a particular bar
		private Series<bool> DrawSeries;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Indicator here.";
				Name										= "OnRenderLinesNew";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= true;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				
				// Set defaults for our properties, will be assigned to our DX/Media Brush in State.DataLoaded
				UserDefinedBrush							= Brushes.RoyalBlue;
				BrushToUseWidth								= 2;
				BrushToUseOpacity							= 100.0;
				BarsRequiredToPlot							= 0;
			}
			else if (State == State.DataLoaded)
			{
				// Create Series<bool> to tell if we want to draw something for a particular bar
				DrawSeries = new Series<bool>(this, MaximumBarsLookBack.Infinite);
				
				// Create a list of brush names for us to manage with  the helper class' "DXMediaBrush" Dictionary
				string[] brushes = new string[] { "BrushToUse" };
				
				// Create a temporary media brush that holds the User defined Brush with Opacity
				tempBrush = UserDefinedBrush.Clone();
				tempBrush.Opacity = BrushToUseOpacity / 100.0;
            	tempBrush.Freeze();
				
				// Create an instance of DXHelper, enable it to manage its own Media Brushes, and add our user defined media brushes to the DXMediaBrush dictionary
				if (ChartControl != null)
				{
					DXH = new DXHelper(true, ChartControl);
					DXH.AddBrushes(brushes);
					DXH.UpdateBrush(RenderTarget, "BrushToUse", UserDefinedBrush, BrushToUseOpacity);
				}
				
				// Create a DXMediaBrush
				BrushToUse = new DXMediaBrush();
				BrushToUse.UpdateBrush(RenderTarget, UserDefinedBrush, BrushToUseOpacity);
				
				// Create a DXMediaBrush for Transparency
				TransparentBrush = new DXMediaBrush();
				TransparentBrush.UpdateBrush(RenderTarget, Brushes.Transparent);
			}
			else if (State == State.Terminated)
			{
				if(DXH != null)
					DXH.Dispose();
			}
		}

		protected override void OnBarUpdate()
		{
			// Some condition that we would want to signal that we want to draw for that bar.
			if(Close[0] > Open[0])
				DrawSeries[0] = true;
			else
				DrawSeries[0] = false;		
		}
		
		protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
        {
			bool overlay = false;
			// Call base.OnRender() to ensure plots get rendered appropriately.
			base.OnRender(chartControl, chartScale);
			
            if (Bars == null || ChartControl == null)
                return;

			// Set AntiAlias mode for smoothing
			SharpDX.Direct2D1.AntialiasMode oldAntialiasMode = RenderTarget.AntialiasMode;
			RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.PerPrimitive;
			
			// Check if we are in hit test for chartScale lines to ignore mouse clicks
			if (!IsInHitTest)
			{
				double top = Instrument.MasterInstrument.RoundToTickSize(chartScale.GetValueByY(ChartPanel.Y));
				double bot = Instrument.MasterInstrument.RoundToTickSize(chartScale.GetValueByY(ChartPanel.H));
				double lastPos = chartScale.GetYByValue(bot-2*TickSize);
				int j = 0;
				for (double i = bot-TickSize; i <= top; i+=TickSize)
				{
					if (lastPos - chartScale.GetYByValue(i) > 1)
					{
						++j;
						DXH.DrawLine(RenderTarget,
									BrushToUse,
									ChartPanel.X,
									chartScale.GetYByValue(i),
									ChartPanel.W,
									chartScale.GetYByValue(i),
									BrushToUseWidth,
									(DashStyleHelper)(j%4));
						lastPos = chartScale.GetYByValue(i);
					}	
				}
			}
			
			// Limit Custom Rendering to ChartBars.FromIndex and ChartBars.ToIndex
            for (int idx = ChartBars.FromIndex; idx <= ChartBars.ToIndex; idx++)
            {
				// Reference Series objects with GetValueAt(idx). Only check FromIndex bar so we don't draw lines for multiple bars.
				if (DrawSeries.GetValueAt(idx))
				{
					// Set a bool for overlay drawing to be done last
					overlay = true;
					//  DXMBrush Dictionary Reference
					DXH.DrawLine(RenderTarget,
								"BrushToUse",
								ChartControl.GetXByBarIndex(ChartBars, idx)-0.5,
								chartScale.GetYByValue(Close.GetValueAt(idx))-0.5,
								ChartControl.GetXByBarIndex(ChartBars, idx)-0.5,
								chartScale.GetYByValue(Open.GetValueAt(idx))-0.5,
								(float)ChartControl.BarWidth*2,
								DashStyleHelper.Solid);
				}
			}
			
			// Draw items that should be overlayed once after drawing any per bar items
			if (overlay)
			{
				// Line 1 DXMediaBrush Dictionary Reference
				DXH.DrawLine(RenderTarget,
							BrushToUse,
							ChartPanel.X,
							ChartPanel.Y,
							ChartPanel.W,
							ChartPanel.H,
							BrushToUseWidth,
							DashStyleHelper.Solid);
				// Line 2 DXMediaBrush reference
				DXH.DrawLine(RenderTarget,
							BrushToUse,
							ChartPanel.X - 20,
							ChartPanel.Y,
							ChartPanel.W - 20,
							ChartPanel.H,
							BrushToUseWidth,
							DashStyleHelper.Dash);
				// Line 3 DXMediaBrush.DxBrush reference
				DXH.DrawLine(RenderTarget,
							BrushToUse.DxBrush,
							ChartPanel.X - 40,
							ChartPanel.Y,
							ChartPanel.W - 40,
							ChartPanel.H,
							BrushToUseWidth,
							DashStyleHelper.DashDot);
				// Line 4 Windows Media Brush reference
				DXH.DrawLine(RenderTarget,
							BrushToUse.MediaBrush,
							ChartPanel.X - 60,
							ChartPanel.Y,
							ChartPanel.W - 60,
							ChartPanel.H,
							BrushToUseWidth,
							DashStyleHelper.DashDotDot);
			}
			//Reset AntiAlias mode
			RenderTarget.AntialiasMode = oldAntialiasMode;
		}
		
		public override void OnRenderTargetChanged()
        {
			// Have the helper class dispose/recreate new SharpDX brushes
			if (DXH != null)
				DXH.RenderTargetChange(RenderTarget);
		
        	// Dispose and recreate our DX Brushes or other Device Dependant resources on RenderTarget changes
			// Any DXMediaBrush that we create on our own will need to be handled here.
			if (BrushToUse != null)
				BrushToUse.RenderTargetChange(RenderTarget);
			
			if (TransparentBrush != null)
				TransparentBrush.RenderTargetChange(RenderTarget);
        }

		#region Properties
		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name="UserDefinedBrush", Description="Color of down bars.", Order=1, GroupName="Parameters")]
		public Brush UserDefinedBrush
		{ get; set; }
		
		[Browsable(false)]
		public string UserDefinedBrushSerializable
		{
			get { return Serialize.BrushToString(UserDefinedBrush); }
			set { UserDefinedBrush = Serialize.StringToBrush(value); }
		}
		
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="BrushToUse width", Description="Width of lines.", Order=2, GroupName="Parameters")]
		public int BrushToUseWidth
		{ get; set; }
		
		[NinjaScriptProperty]
		[Range(0.0, 100.0)]
		[Display(Name="BrushToUse Opacity", Description="Opacity of lines.", Order=3, GroupName="Parameters")]
		public double BrushToUseOpacity
		{ get; set; }
		#endregion
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private OnRenderLinesNew[] cacheOnRenderLinesNew;
		public OnRenderLinesNew OnRenderLinesNew(Brush userDefinedBrush, int brushToUseWidth, double brushToUseOpacity)
		{
			return OnRenderLinesNew(Input, userDefinedBrush, brushToUseWidth, brushToUseOpacity);
		}

		public OnRenderLinesNew OnRenderLinesNew(ISeries<double> input, Brush userDefinedBrush, int brushToUseWidth, double brushToUseOpacity)
		{
			if (cacheOnRenderLinesNew != null)
				for (int idx = 0; idx < cacheOnRenderLinesNew.Length; idx++)
					if (cacheOnRenderLinesNew[idx] != null && cacheOnRenderLinesNew[idx].UserDefinedBrush == userDefinedBrush && cacheOnRenderLinesNew[idx].BrushToUseWidth == brushToUseWidth && cacheOnRenderLinesNew[idx].BrushToUseOpacity == brushToUseOpacity && cacheOnRenderLinesNew[idx].EqualsInput(input))
						return cacheOnRenderLinesNew[idx];
			return CacheIndicator<OnRenderLinesNew>(new OnRenderLinesNew(){ UserDefinedBrush = userDefinedBrush, BrushToUseWidth = brushToUseWidth, BrushToUseOpacity = brushToUseOpacity }, input, ref cacheOnRenderLinesNew);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.OnRenderLinesNew OnRenderLinesNew(Brush userDefinedBrush, int brushToUseWidth, double brushToUseOpacity)
		{
			return indicator.OnRenderLinesNew(Input, userDefinedBrush, brushToUseWidth, brushToUseOpacity);
		}

		public Indicators.OnRenderLinesNew OnRenderLinesNew(ISeries<double> input , Brush userDefinedBrush, int brushToUseWidth, double brushToUseOpacity)
		{
			return indicator.OnRenderLinesNew(input, userDefinedBrush, brushToUseWidth, brushToUseOpacity);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.OnRenderLinesNew OnRenderLinesNew(Brush userDefinedBrush, int brushToUseWidth, double brushToUseOpacity)
		{
			return indicator.OnRenderLinesNew(Input, userDefinedBrush, brushToUseWidth, brushToUseOpacity);
		}

		public Indicators.OnRenderLinesNew OnRenderLinesNew(ISeries<double> input , Brush userDefinedBrush, int brushToUseWidth, double brushToUseOpacity)
		{
			return indicator.OnRenderLinesNew(input, userDefinedBrush, brushToUseWidth, brushToUseOpacity);
		}
	}
}

#endregion
