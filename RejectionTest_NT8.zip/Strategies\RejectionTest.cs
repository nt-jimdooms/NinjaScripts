#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies
{
	public class RejectionTest : Strategy
	{
		private Order entryOrder;
		private Order entryOrder2;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Strategy here.";
				Name										= "RejectionTest";
				Calculate									= Calculate.OnBarClose;
				EntriesPerDirection							= 1;
				EntryHandling								= EntryHandling.UniqueEntries;
				IsExitOnSessionCloseStrategy				= true;
				ExitOnSessionCloseSeconds					= 30;
				IsFillLimitOnTouch							= false;
				MaximumBarsLookBack							= MaximumBarsLookBack.TwoHundredFiftySix;
				OrderFillResolution							= OrderFillResolution.Standard;
				Slippage									= 0;
				StartBehavior								= StartBehavior.WaitUntilFlat;
				TimeInForce									= TimeInForce.Gtc;
				TraceOrders									= false;
				RealtimeErrorHandling						= RealtimeErrorHandling.StopCancelCloseIgnoreRejects;
				StopTargetHandling							= StopTargetHandling.PerEntryExecution;
				BarsRequiredToTrade							= 20;
				// Disable this property for performance gains in Strategy Analyzer optimizations
				// See the Help Guide for additional information
				IsInstantiatedOnEachOptimizationIteration	= true;
			}
			else if (State == State.Realtime)
			{
				// one time only, as we transition from historical
			    // convert any old historical order object references
			    // to the new live order submitted to the real-time account
			    if (entryOrder != null)
			        entryOrder = GetRealtimeOrder(entryOrder);
				if (entryOrder2 != null)
			        entryOrder2 = GetRealtimeOrder(entryOrder2);
			}
		}

		protected override void OnBarUpdate()
		{
			if (State == State.Historical)
				return;
			
			if (Position.MarketPosition == MarketPosition.Flat && (entryOrder == null && entryOrder2 == null))
				EnterLongStopMarket(Low[0] - 10 * TickSize, "MyEntry");
		}
		
		protected override void OnOrderUpdate(Order order, double limitPrice, double stopPrice, int quantity, int filled, double averageFillPrice,
                                    OrderState orderState, DateTime time, ErrorCode error, string nativeError)
		{
			// Assign order in OnOrderUpdate() to ensure the assignment occurs when expected.
			// This is more reliable than assigning Order objects in OnBarUpdate,
			// as the assignment is not guaranteed to be complete if it is referenced immediately after submitting
			if (order.Name == "MyEntry")
			{
				entryOrder = order;
				 // Reset the entryOrder object to null if order was cancelled without any fill
                if (order.OrderState == OrderState.Cancelled && order.Filled == 0)
					entryOrder = null;
			}
			
			if (order.Name == "MyEntry2")
			{
				entryOrder2 = order;
				 // Reset the entryOrder2 object to null if order was cancelled without any fill
                if (order.OrderState == OrderState.Cancelled && order.Filled == 0)
					entryOrder2 = null;
			}

			if (entryOrder != null && entryOrder == order)
			{
				// Rejection handling
				if (order.OrderState == OrderState.Rejected)
				{
					// Order was rejected !!!!
					// Do something about it here
					entryOrder = null;
					EnterLong("MyEntry2");
				}
			}
		}
	}
}
