#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;

using System.Globalization;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class BrushEnum : Indicator
	{
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Indicator here.";
				Name										= "BrushEnum";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= true;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				
				EnumValue 		= MyEnum.Red;
			}
			else if (State == State.DataLoaded)
			{
				EnumChosenBrush = EnumToBrush(EnumValue);
			}
		}

		protected override void OnBarUpdate()
		{
			Draw.Dot(this, "tag", true, 0, High[0] + 5 * TickSize, EnumChosenBrush);
		}
		
		[TypeConverter(typeof(FriendlyEnumConverter))] // Converts the enum to string values
        [PropertyEditor("NinjaTrader.Gui.Tools.StringStandardValuesEditorKey")] // Enums normally automatically get a combo box, but we need to apply this specific editor so default value is automatically selected
        [Display(Name = "Friendly Enum", Order = 8, GroupName = "Use Case #4")]
        public MyEnum EnumValue
        { get; set; }
		
		private Brush EnumToBrush(MyEnum brushEnum)
		{
			string stringVal = brushEnum.ToString();
			if (stringVal == "Red")
				return Brushes.Red;
			if (stringVal == "Green")
				return Brushes.Green;
			if (stringVal == "Blue")
				return Brushes.Blue;
			
			return Brushes.Red;
		}
		
		private Brush EnumChosenBrush;
		
		public enum MyEnum
	    {
	        Red,
	        Green,
	        Blue
	    }

	    // Since this is only being applied to a specific property rather than the whole class,
	    // we don't need to inherit from IndicatorBaseConverter and we can just use a generic TypeConverter
	    public class FriendlyEnumConverter : TypeConverter
	    {
	        // Set the values to appear in the combo box
	        public override StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
	        {
	            List<string> values = new List<string>() { "Red", "Green", "Blue" };

	            return new StandardValuesCollection(values);
	        }

	        // map the value from "Friendly" string to MyEnum type
	        public override object ConvertFrom(ITypeDescriptorContext context, CultureInfo culture, object value)
	        {
	            string stringVal = value.ToString();
				
	            switch (stringVal)
	            {
	                case "Red":
	                return MyEnum.Red;
	                case "Green":
	                return MyEnum.Green;
	                case "Blue":
	                return MyEnum.Blue;
	            }
	            return MyEnum.Red;
	        }

	        // map the MyEnum type to "Friendly" string
	        public override object ConvertTo(ITypeDescriptorContext context, CultureInfo culture, object value, Type destinationType)
	        {
	            MyEnum stringVal = (MyEnum) Enum.Parse(typeof(MyEnum), value.ToString());
				
	            switch (stringVal)
	            {
	                case MyEnum.Red:
	                return "Red";
	                case MyEnum.Green:
	                return "Green";
	                case MyEnum.Blue:
	                return "Blue";
	            }
	            return Brushes.Transparent;
	        }

	        // required interface members needed to compile
	        public override bool CanConvertFrom(ITypeDescriptorContext context, Type sourceType)
	        { return true; }

	        public override bool CanConvertTo(ITypeDescriptorContext context, Type destinationType)
	        { return true; }

	        public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
	        { return true; }

	        public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
	        { return true; }
	    }
		
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private BrushEnum[] cacheBrushEnum;
		public BrushEnum BrushEnum()
		{
			return BrushEnum(Input);
		}

		public BrushEnum BrushEnum(ISeries<double> input)
		{
			if (cacheBrushEnum != null)
				for (int idx = 0; idx < cacheBrushEnum.Length; idx++)
					if (cacheBrushEnum[idx] != null &&  cacheBrushEnum[idx].EqualsInput(input))
						return cacheBrushEnum[idx];
			return CacheIndicator<BrushEnum>(new BrushEnum(), input, ref cacheBrushEnum);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.BrushEnum BrushEnum()
		{
			return indicator.BrushEnum(Input);
		}

		public Indicators.BrushEnum BrushEnum(ISeries<double> input )
		{
			return indicator.BrushEnum(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.BrushEnum BrushEnum()
		{
			return indicator.BrushEnum(Input);
		}

		public Indicators.BrushEnum BrushEnum(ISeries<double> input )
		{
			return indicator.BrushEnum(input);
		}
	}
}

#endregion
