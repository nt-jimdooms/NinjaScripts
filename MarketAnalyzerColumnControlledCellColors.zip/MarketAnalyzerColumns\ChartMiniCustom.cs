using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;
using System.Linq;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Gui;

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public class ChartMiniCustom : Gui.NinjaScript.MarketAnalyzerColumnRenderBase
	{
		private Brush	fillBrush;
		private Brush	color;
		private int		opacity;
		
		private Brush	textBrush;
		private Brush	color2;
		private int		opacity2;

		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description				= "Simple Example for rendering in a MarketAnalyzerColumn";
				Name					= "ChartMiniCustom";
				IsDataSeriesRequired	= false;
				Color					= Brushes.DimGray;
				Opacity					= 50;
				
				Color2					= Brushes.HotPink;
				Opacity2				= 100;
			}
		}

		public override string Format(double value)
		{
			return (value == double.MinValue ? string.Empty : Instrument.MasterInstrument.FormatPrice(value));
		}

		protected override void OnMarketData(Data.MarketDataEventArgs marketDataUpdate)
		{
			if (marketDataUpdate.IsReset)
				CurrentValue = double.MinValue;
			else if (marketDataUpdate.MarketDataType == Data.MarketDataType.Last)
				CurrentValue = marketDataUpdate.Price;
		}

		public override void OnRender(DrawingContext dc, System.Windows.Size renderSize)
		{
			List<LineSegment>		lineSegments	= new List<LineSegment>();

			if (fillBrush == null)
				fillBrush = new SolidColorBrush() { Color = (Color as SolidColorBrush).Color, Opacity = (double) Opacity / 100 };
				
			if (textBrush == null)
				textBrush = new SolidColorBrush() { Color = (Color2 as SolidColorBrush).Color, Opacity = (double) Opacity2 / 100 };
			
			// Draw something for the Background. DrawGeometry is used here, but DrawRect could be used instead.
			lineSegments.Add(new LineSegment(new System.Windows.Point(0, 0), true));
			lineSegments.Add(new LineSegment(new System.Windows.Point(0, renderSize.Height), true));
			lineSegments.Add(new LineSegment(new System.Windows.Point(renderSize.Width, renderSize.Height), true));
			lineSegments.Add(new LineSegment(new System.Windows.Point(renderSize.Width, 0), true));

			List<PathFigure> pathFiguresFill = new List<PathFigure>();
			pathFiguresFill.Add(new PathFigure(new System.Windows.Point(0, 0), lineSegments.ToArray(), true));
			PathGeometry pgFill = new PathGeometry(pathFiguresFill);
			dc.DrawGeometry(fillBrush, null, pgFill);
			
			// Draw Text since we are inheriting from Gui.NinjaScript.MarketAnalyzerColumnRenderBase
			dc.DrawText(new FormattedText(CurrentValue.ToString(), System.Globalization.CultureInfo.CurrentCulture, System.Windows.FlowDirection.LeftToRight , new Typeface("Arial"), 12, textBrush), new System.Windows.Point(0, 0));
		}

		#region Properties
		[XmlIgnore]
		[Display(Name = "BG Color", GroupName = "GuiPropertyCategoryVisual", Order = 10)]
		public Brush Color
		{
			get { return  color; }
			set { color = value; fillBrush = null; }
		}

		[Range(0, 100)]
		[Display(Name = "BG Opacity", GroupName = "GuiPropertyCategoryVisual", Order = 20)]
		public int Opacity
		{
			get { return opacity;}
			set { opacity = value; fillBrush = null; }
		}
		
		[XmlIgnore]
		[Display(Name = "Text Color", GroupName = "GuiPropertyCategoryVisual", Order = 30)]
		public Brush Color2
		{
			get { return  color2; }
			set { color2 = value; textBrush = null; }
		}

		[Range(0, 100)]
		[Display(Name = "Text Opacity", GroupName = "GuiPropertyCategoryVisual", Order = 40)]
		public int Opacity2
		{
			get { return opacity2;}
			set { opacity2 = value; textBrush = null; }
		}
		#endregion
	}
}
