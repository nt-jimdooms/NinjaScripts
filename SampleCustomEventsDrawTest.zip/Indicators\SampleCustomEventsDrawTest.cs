// Copyright (C) 2018, NinjaTrader LLC <www.ninjatrader.com>.
// NinjaTrader reserves the right to modify or overwrite this NinjaScript component with each release.

#region Using declarations
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

// Add this to the declarations. It allows for the use of ArrayLists. (Used in the Level II book creation process.)
using System.Collections.Generic;

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class SampleCustomEventsDrawTest : Indicator
	{	
		// Declare the WPF dispatcher timer
		private System.Timers.Timer myTimer;
		private int Counted;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description					= @"";
				Name						= "Sample custom events Draw Test";
				Calculate					= Calculate.OnBarClose;
				IsOverlay					= true;
				DisplayInDataBox			= true;
				DrawOnPricePanel			= true;
				DrawHorizontalGridLines		= true;
				DrawVerticalGridLines		= true;
				PaintPriceMarkers			= true;
				IsDataSeriesRequired		= true;
				ScaleJustification			= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Uncomment the below line if you wish to take advantage of CPU savings by suspending the indicator
				//when it is not in use. You should only do this if your indicator is not reliant on processing in
				//real-time and would process the same historically vs. real-time since all indicator functionality
				//will be paused when suspended (including alerts and outputs).
				//For more information, please see the Help Guide on IsSuspendedWhileInactive
				//IsSuspendedWhileInactive	= true;
			}
			else if (State == State.DataLoaded)
			{
				// Instantiates the timer and sets the interval to 1 seconds.
				myTimer = new System.Timers.Timer(1000);
		  		myTimer.Elapsed += TimerEventProcessor;
				myTimer.Enabled = true;
			}
			else if (State == State.Terminated)
			{
		  		// Stops the timer and removes the timer event handler
				if (myTimer != null)
				{
			  		myTimer.Enabled = false;
			  		myTimer.Elapsed -= TimerEventProcessor;
					myTimer = null;
				}
			}
		}

		protected override void OnBarUpdate()
		{
			DrawLabels();
		}
		
		// Timer's elapsed event handler. Called at every tick of 1000ms.
		private void TimerEventProcessor(Object myObject, EventArgs myEventArgs)
		{
			/* Important to use the TriggerCustomEvent() to ensure that NinjaScript indexes and pointers are correctly set.
			Do not process your code here. Process your code in the MyCustomHandler method. */
			TriggerCustomEvent(MyCustomHandler, 0, myTimer.Interval);
			Counted++;
		}
		
		private void MyCustomHandler(object state)
		{
			DrawLabels();
		}
		
		private void DrawLabels()
		{
			Draw.TextFixed(this, "tag", "CurrentBar: " + CurrentBar + " Counted: " + Counted, TextPosition.Center);
			ForceRefresh();
		}

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private SampleCustomEventsDrawTest[] cacheSampleCustomEventsDrawTest;
		public SampleCustomEventsDrawTest SampleCustomEventsDrawTest()
		{
			return SampleCustomEventsDrawTest(Input);
		}

		public SampleCustomEventsDrawTest SampleCustomEventsDrawTest(ISeries<double> input)
		{
			if (cacheSampleCustomEventsDrawTest != null)
				for (int idx = 0; idx < cacheSampleCustomEventsDrawTest.Length; idx++)
					if (cacheSampleCustomEventsDrawTest[idx] != null &&  cacheSampleCustomEventsDrawTest[idx].EqualsInput(input))
						return cacheSampleCustomEventsDrawTest[idx];
			return CacheIndicator<SampleCustomEventsDrawTest>(new SampleCustomEventsDrawTest(), input, ref cacheSampleCustomEventsDrawTest);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.SampleCustomEventsDrawTest SampleCustomEventsDrawTest()
		{
			return indicator.SampleCustomEventsDrawTest(Input);
		}

		public Indicators.SampleCustomEventsDrawTest SampleCustomEventsDrawTest(ISeries<double> input )
		{
			return indicator.SampleCustomEventsDrawTest(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.SampleCustomEventsDrawTest SampleCustomEventsDrawTest()
		{
			return indicator.SampleCustomEventsDrawTest(Input);
		}

		public Indicators.SampleCustomEventsDrawTest SampleCustomEventsDrawTest(ISeries<double> input )
		{
			return indicator.SampleCustomEventsDrawTest(input);
		}
	}
}

#endregion
