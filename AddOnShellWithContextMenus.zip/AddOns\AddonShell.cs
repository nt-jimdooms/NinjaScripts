#region Using Statements

using System;
using System.Windows;
using NinjaTrader.Core;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript;
using System.IO;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Xml.Linq;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using IInstrumentProvider = NinjaTrader.Gui.Tools.IInstrumentProvider;
#endregion

// 
// Copyright (C) 2015, NinjaTrader LLC <www.ninjatrader.com>.
// NinjaTrader reserves the right to modify or overwrite this NinjaScript component with each release.
//

namespace NinjaTrader.NinjaScript.AddOns
{
	/*
		* This is the Primary script in the set of scripts in this example, This script will be the first called script in NinjaTrader. 
     
		* Unlike other NinjaScript documents, Debugging in an addon can be done unsing the folling statement
		* Output.Process("SomeString", PrintTo.OutputTab1);
    */
	public class AddonShell : AddOnBase
    {
		//These variables will be used in checking if the current Addon already has a menu item, and also stores the new menu item to be added.
		private NTMenuItem existingMenuItems;
        private NTMenuItem newMenuItem;

        private void OnMenuItemClick(object sender, RoutedEventArgs e)
        {
            Globals.RandomDispatcher.InvokeAsync(new Action(() => new AddonShellWindow().Show()));
        }

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = "";
                Name = "AddonShell";
            }
        }

        protected override void OnWindowCreated(Window window)
        {
			/*
				* The following checks if the control center window is present.
				* If the control center is found, the MainMenu is checked for existing menu items with the same name as this addon. 
				* If no existing items are found, a new menu item is added for this addon. 
			*/
			ControlCenter controlCenter = window as ControlCenter;

            if (controlCenter == null)
                return;

            existingMenuItems = controlCenter.FindFirst("ControlCenterMenuItemNew") as NTMenuItem;

            if (existingMenuItems == null)
                return;

			// This is the new menu item to be created, this assigns the menu text and will be used to Add this item to the Main Menu. 
			newMenuItem = new NTMenuItem {Header = "Addon Shell", Style = Application.Current.TryFindResource("MainMenuItem") as Style};
			
            existingMenuItems.Items.Add(newMenuItem);
			// The new menu item will do nothing by its self, a click handler is added to complete the menu item and allow for clicks.
			newMenuItem.Click += OnMenuItemClick;
        }

        protected override void OnWindowDestroyed(Window window)
        {
			// This checks if there is not a menu item or if the destroyed window is not the control center.
			if (newMenuItem == null || !(window is ControlCenter) ||
					existingMenuItems == null ||
					!existingMenuItems.Items.Contains(newMenuItem))	
				return;

			// if the destroyed window was the control center, we clean up the click handler and remove the custom menu item and set it to null.
			newMenuItem.Click -= OnMenuItemClick;
			existingMenuItems.Items.Remove(newMenuItem);
			newMenuItem = null;
        }
	}

	public class AddonShellWindow : NTWindow, IWorkspacePersistence
	{
		/*
			* This is the constructor for the new NTWindow.
			* This document sets up the basic window before it gets displayed.
			* This also defines what TabPage will be used and the Window Factory that will be used in the window creation process.
			* This document is also where you would set Tab defaults like if this window will have a tab control, if the tabs are movable etc..
		*/
		public AddonShellWindow()
		{
			Caption = "Addon Shell Window";
			Width = 400;
			Height = 250;
			TabControl tabControl = new TabControl();
			TabControlManager.SetIsMovable(tabControl, true);
			TabControlManager.SetCanAddTabs(tabControl, true);
			TabControlManager.SetCanRemoveTabs(tabControl, true);
			TabControlManager.SetFactory(tabControl, new AddonShellWindowFactory());

			Content = tabControl;
			tabControl.AddNTTabPage(new AddonShellWindowTabPage());

			// This is a inline Window Loaded handler, once the window loads, if the WorkspaceOptions are not present,
			// a new WorkspaceOptions object is created for this window using its GUID.
			Loaded += (o, e) =>
			{
				if (WorkspaceOptions == null)
				{
					WorkspaceOptions = new WorkspaceOptions("AddonShellWindow" + Guid.NewGuid().ToString("N"), this);
				}
			};
		}

		public void Restore(XDocument document, XElement element)
		{
			// This is used for restoring the elements of the document with the workspace. 
			if (MainTabControl != null)
				MainTabControl.RestoreFromXElement(element);
		}

		public void Save(XDocument document, XElement element)
		{
			// This is used for saving the elements of the document with the workspace.
			if (MainTabControl != null)
				MainTabControl.SaveToXElement(element);
		}

		public WorkspaceOptions WorkspaceOptions { get; set; }
	}

	public class AddonShellWindowFactory : INTTabFactory
	{
		// This class is simply to return the correct new objects when CreateParentWindow() and CreateTabPage() are called.
		public NTWindow CreateParentWindow()
		{
			return new AddonShellWindow();
		}

		public NTTabPage CreateTabPage(string typeName, bool isNewWindow = false)
		{
			return new AddonShellWindowTabPage();
		}
	}

	public class AddonShellWindowTabPage : NTTabPage
	{
		/*
			* This is the constructor for the new NTTabPage.
		*/
		
		private MenuItem mySmaMenuItem;
		
		private void ChartControl_ContextMenuClosing(object sender, ContextMenuEventArgs e)
        {
            NinjaTrader.Code.Output.Process("my Close", PrintTo.OutputTab1);
			if(ContextMenu.Items.Contains(mySmaMenuItem)) ContextMenu.Items.Remove(mySmaMenuItem);
        }

        private void ChartControl_ContextMenuOpening(object sender, ContextMenuEventArgs e)
        {
            NinjaTrader.Code.Output.Process("my Open", PrintTo.OutputTab1);
			ContextMenu.Items.Add(mySmaMenuItem);
        }
		
		
		public AddonShellWindowTabPage()
		{			
			// the content of the page will go here.
			Content = LoadXaml();
			
			//mySmaMenuItem = new MenuItem { Header = "Test SMA Item" };
			
			//ContextMenuOpening += ChartControl_ContextMenuOpening;
            //ContextMenuClosing += ChartControl_ContextMenuClosing;
		}

		// Cleanup() is called when the script is ending, this is to remove used resources or event handlers. 
		public override void Cleanup()
		{
			//ContextMenuOpening -= ChartControl_ContextMenuOpening;
            //ContextMenuClosing -= ChartControl_ContextMenuClosing;
		}

		// This returns the default Tab Header text.
		protected override string GetHeaderPart(string variable)
		{
			return "Tab";
		}

		private DependencyObject LoadXaml()
		{
			try
			{
				Page page;
				FileStream fs = new FileStream(System.IO.Path.Combine(NinjaTrader.Core.Globals.UserDataDir, @"bin\Custom\AddOns\AddonShellTabContent.xaml"), FileMode.Open);
				page = (Page)XamlReader.Load(fs);

				DependencyObject pageContent = page.Content as DependencyObject;

				return pageContent;
			}
			catch (Exception)
			{
				return null;
			}
		}

		// These are used for when the workspace is Restoring or Saving.
		protected override void Restore(XElement element) { }
		protected override void Save(XElement element) { }
	}
}
 