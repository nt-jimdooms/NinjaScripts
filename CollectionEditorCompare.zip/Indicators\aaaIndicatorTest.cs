#region Using declarations
using NinjaTrader.Cbi;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.Data;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui;
using NinjaTrader.NinjaScript.DrawingTools;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows;
using System.Xml.Serialization;
using System;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	#region PercentWrapper Class
    // IMPORTANT
    // Structures used in custom PropertyEditor add-ons such as CollectionEditor
    // CANNOT be a nested type of another class
    // and MUST have a default constructor
    //
    // To display a custom collection to the GUI, we will reuse the NinjaTrader GUI Collection PropertyEditor
    // The NinjaTrader GUI Collection editor expects an ICloneable object.
    // Demonstration uses a double reference type, but this implementation can be expanded to more complex objects.
    // Another example of this can be found in the @PriceLevel.cs DrawingTool resource
    [CategoryDefaultExpanded(true)]
    public class PercentWrapper : NotifyPropertyChangedBase, ICloneable
    {
        // Parameterless constructor is needed for Clone and serialization
        public PercentWrapper() : this(0)
        {
        }

        public PercentWrapper(double value)
        {
            PercentageValue = value;
        }

        // Display attributes, XmlIgnore attributes, Browsable attributes, etc can be all applied to the object's properties as well.
        [Display(Name = "Value (in %)", GroupName = "Values")]
        public double PercentageValue
        { get; set; }

        // Cloned instance returned to the Collection editor with user defined value

		public object Clone()
		{
			PercentWrapper p  = new PercentWrapper();
			p.PercentageValue = PercentageValue;
			return p;
		}
		
		//Default value handling
		[Browsable(false)]
		public bool IsDefault { get; set; }
		
        // Customize the displays on the left side of the editor window
        public override string ToString()
        { return PercentageValue.ToString(CultureInfo.InvariantCulture) + " %"; }
		
		// Use Reflection to be able to copy properties to new instance
		public object AssemblyClone(Type t)
		{
			Assembly a 				= t.Assembly;
			object percentWrapper 	= a.CreateInstance(t.FullName);
			
			foreach (PropertyInfo p in t.GetProperties(BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance))
			{
				if (p.CanWrite)
					p.SetValue(percentWrapper, this.GetType().GetProperty(p.Name).GetValue(this), null);
			}
			
			return percentWrapper;
		}
    }
    #endregion
	
	public class aaaIndicatorTest : Indicator
	{
		private List<PercentWrapper> collectionDefaults = new List<PercentWrapper>()
		{
			new PercentWrapper(50) { IsDefault = true },
			new PercentWrapper(60) { IsDefault = true }
		};
		
		private Collection<PercentWrapper> myListValues;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Strategy here.";
				Name										= "aaaIndicatorTest";
				
				myListValues 	= new Collection<PercentWrapper>(collectionDefaults);
			}
			else if (State == State.Configure)
			{
			}
		}

		protected override void OnBarUpdate()
		{
			//Add your custom strategy logic here.
		}
		
		// Reflection to copy Collection to new assembly
		public override void CopyTo(NinjaScript ninjaScript)
		{
			base.CopyTo(ninjaScript);

			Type			newInstType					= ninjaScript.GetType();
			PropertyInfo	myListValuesPropertyInfo	= newInstType.GetProperty("MyListValues");
			
			if (myListValuesPropertyInfo == null)
				return;

			IList newInstMyListValues = myListValuesPropertyInfo.GetValue(ninjaScript) as IList;
			
			if (newInstMyListValues == null)
				return;

			// Since new instance could be past set defaults, clear any existing
			newInstMyListValues.Clear();
			
			foreach (PercentWrapper oldPercentWrapper in MyListValues)
			{
				try
				{
					object newInstance = oldPercentWrapper.AssemblyClone(Core.Globals.AssemblyRegistry.GetType(typeof(PercentWrapper).FullName));
					if (newInstance == null)
						continue;
					
					newInstMyListValues.Add(newInstance);
				}
				catch { }
			}
		}
		
		#region Collection Editor Properties

        // Note: All these DisplayAttribute properties are required
        // Prompt is used to set what displays in the property grid and during mouseover
		[XmlIgnore]
        [Display(Name = "List values", GroupName = "Use Case #5", Order = 9, Prompt = "1 value|{0} values|Add value...|Edit value...|Edit values...")]
        [PropertyEditor("NinjaTrader.Gui.Tools.CollectionEditor")] // Allows a pop-up to be used to add values to the collection, similar to Price Levels in Drawing Tools
		[SkipOnCopyTo(true)]
        public Collection<PercentWrapper> MyListValues
        {
			get 
			{
				return myListValues;
			}
			set
			{
				myListValues = new Collection<PercentWrapper>(value.ToList());
			}
		}

        // Serializer for the PercentWrappers Collection
        [Browsable(false)]
        public Collection<PercentWrapper> MyListValuesSerialize
        {
			get
			{
				//Remove actual defaults
				foreach(PercentWrapper pw in collectionDefaults.ToList())
				{
					PercentWrapper temp = MyListValues.FirstOrDefault(p => p.PercentageValue == pw.PercentageValue && p.IsDefault == true);
					
					if(temp != null)
						collectionDefaults.Remove(temp);
				}
				
				//Force user added values to not be defaults
				MyListValues.All(p => p.IsDefault = false);
				
				return MyListValues;
			}
			set
			{
				MyListValues = value;
			}
        }

        #endregion
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private aaaIndicatorTest[] cacheaaaIndicatorTest;
		public aaaIndicatorTest aaaIndicatorTest()
		{
			return aaaIndicatorTest(Input);
		}

		public aaaIndicatorTest aaaIndicatorTest(ISeries<double> input)
		{
			if (cacheaaaIndicatorTest != null)
				for (int idx = 0; idx < cacheaaaIndicatorTest.Length; idx++)
					if (cacheaaaIndicatorTest[idx] != null &&  cacheaaaIndicatorTest[idx].EqualsInput(input))
						return cacheaaaIndicatorTest[idx];
			return CacheIndicator<aaaIndicatorTest>(new aaaIndicatorTest(), input, ref cacheaaaIndicatorTest);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.aaaIndicatorTest aaaIndicatorTest()
		{
			return indicator.aaaIndicatorTest(Input);
		}

		public Indicators.aaaIndicatorTest aaaIndicatorTest(ISeries<double> input )
		{
			return indicator.aaaIndicatorTest(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.aaaIndicatorTest aaaIndicatorTest()
		{
			return indicator.aaaIndicatorTest(Input);
		}

		public Indicators.aaaIndicatorTest aaaIndicatorTest(ISeries<double> input )
		{
			return indicator.aaaIndicatorTest(input);
		}
	}
}

#endregion
