using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;

namespace NinjaTrader.NinjaScript.Indicators
{
	public class DetectMouseMoves : Indicator
	{
		private ChartScale ChartScale;
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Name = "DetectMouseMoves";
				Calculate = Calculate.OnPriceChange;
				IsOverlay = true;
				ScaleJustification = NinjaTrader.Gui.Chart.ScaleJustification.Right;
				IsSuspendedWhileInactive = true;
			}
			else if (State == State.DataLoaded)
			{				
				if (ChartControl != null)
				{
					ChartPanel.MouseMove += new System.Windows.Input.MouseEventHandler (ChartPanel_MouseMove);
				}
			}
			else if (State == State.Terminated)
			{
				if (ChartControl != null)
					ChartPanel.MouseMove -= new System.Windows.Input.MouseEventHandler (ChartPanel_MouseMove);
			}
		}

		protected override void OnBarUpdate() { }
		
		void ChartPanel_MouseMove (object sender, System.Windows.Input.MouseEventArgs e)
		{
			TriggerCustomEvent(o =>
    		{
				ClearOutputWindow();
				
				double curPosX = e.GetPosition(ChartPanel).X;
				double curPosY = e.GetPosition(ChartPanel).Y;
				double price = Instrument.MasterInstrument.RoundToTickSize(ChartScale.GetValueByY((float)curPosY));
				DateTime time = ChartControl.GetTimeByX((int)curPosX);
				
				Print(String.Format("X: {0} Y: {1}", curPosX, curPosY));
				Print(String.Format("PriceLevel: {0}", price));
				Print(String.Format("Time: {0}", time));
				Print(String.Format("Price Above Current Market Price: {0}", (price > Close[0])));
			}, null);
		}
		
		protected override void OnRender(NinjaTrader.Gui.Chart.ChartControl chartControl, NinjaTrader.Gui.Chart.ChartScale chartScale)
		{
			base.OnRender(chartControl, chartScale);
			
			ChartScale = chartScale;
		}
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private DetectMouseMoves[] cacheDetectMouseMoves;
		public DetectMouseMoves DetectMouseMoves()
		{
			return DetectMouseMoves(Input);
		}

		public DetectMouseMoves DetectMouseMoves(ISeries<double> input)
		{
			if (cacheDetectMouseMoves != null)
				for (int idx = 0; idx < cacheDetectMouseMoves.Length; idx++)
					if (cacheDetectMouseMoves[idx] != null &&  cacheDetectMouseMoves[idx].EqualsInput(input))
						return cacheDetectMouseMoves[idx];
			return CacheIndicator<DetectMouseMoves>(new DetectMouseMoves(), input, ref cacheDetectMouseMoves);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.DetectMouseMoves DetectMouseMoves()
		{
			return indicator.DetectMouseMoves(Input);
		}

		public Indicators.DetectMouseMoves DetectMouseMoves(ISeries<double> input )
		{
			return indicator.DetectMouseMoves(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.DetectMouseMoves DetectMouseMoves()
		{
			return indicator.DetectMouseMoves(Input);
		}

		public Indicators.DetectMouseMoves DetectMouseMoves(ISeries<double> input )
		{
			return indicator.DetectMouseMoves(input);
		}
	}
}

#endregion
