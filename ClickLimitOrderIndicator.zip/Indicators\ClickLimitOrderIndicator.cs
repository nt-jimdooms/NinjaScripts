#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class ClickLimitOrderIndicator : Indicator
	{
		private Account myAccount;
		private ChartScale MyChartScale;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Indicator here.";
				Name										= "ClickLimitOrderIndicator";
				Calculate									= Calculate.OnPriceChange;
				IsOverlay									= true;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				AccountName 								= "Sim101";
			}
		 	else if (State == State.DataLoaded)
  			{
   				if (ChartControl != null)
    				ChartControl.MouseLeftButtonDown += LeftMouseDown;
				
				if (ChartControl != null)
					ChartPanel.MouseMove += ChartControl_MouseMove;
				
				// Find our account
				lock (Account.All)
					myAccount = Account.All.FirstOrDefault(a => a.Name == AccountName);
   			}
   			else if (State == State.Terminated)
   			{
	    		if (ChartControl != null)
	     			ChartControl.MouseLeftButtonDown -= LeftMouseDown;
				
				if (ChartControl != null)
					ChartPanel.MouseMove -= ChartControl_MouseMove;
   			}
		}
		
		protected override void OnBarUpdate()
		{
			
		}
		
		protected void LeftMouseDown(object sender, MouseButtonEventArgs e)
		{
			TriggerCustomEvent(o =>
			{
				int Y = ChartingExtensions.ConvertToVerticalPixels(e.GetPosition(ChartControl as IInputElement).Y, ChartControl.PresentationSource);
				
				double priceClicked = MyChartScale.GetValueByY(Y);
			
				Order limitOrder = null;

				if (priceClicked > Close[0])
					limitOrder = myAccount.CreateOrder(Instrument, OrderAction.Sell, OrderType.Limit, TimeInForce.Day, 1, priceClicked, 0, "", "limitOrder"+DateTime.Now.ToString(), null);
				else
					limitOrder = myAccount.CreateOrder(Instrument, OrderAction.Buy, OrderType.Limit, TimeInForce.Day, 1, priceClicked, 0, "", "limitOrder"+DateTime.Now.ToString(), null);
				
				myAccount.Submit(new[] { limitOrder });
			}, null);
			e.Handled = true;
		}
		
		void ChartControl_MouseMove (object sender, System.Windows.Input.MouseEventArgs e)
		{

		}
		
		protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
		{
			base.OnRender(chartControl, chartScale);
			
			MyChartScale = chartScale;
		}
		
		[TypeConverter(typeof(NinjaTrader.NinjaScript.AccountNameConverter))]
		public string AccountName { get; set; }
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ClickLimitOrderIndicator[] cacheClickLimitOrderIndicator;
		public ClickLimitOrderIndicator ClickLimitOrderIndicator()
		{
			return ClickLimitOrderIndicator(Input);
		}

		public ClickLimitOrderIndicator ClickLimitOrderIndicator(ISeries<double> input)
		{
			if (cacheClickLimitOrderIndicator != null)
				for (int idx = 0; idx < cacheClickLimitOrderIndicator.Length; idx++)
					if (cacheClickLimitOrderIndicator[idx] != null &&  cacheClickLimitOrderIndicator[idx].EqualsInput(input))
						return cacheClickLimitOrderIndicator[idx];
			return CacheIndicator<ClickLimitOrderIndicator>(new ClickLimitOrderIndicator(), input, ref cacheClickLimitOrderIndicator);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ClickLimitOrderIndicator ClickLimitOrderIndicator()
		{
			return indicator.ClickLimitOrderIndicator(Input);
		}

		public Indicators.ClickLimitOrderIndicator ClickLimitOrderIndicator(ISeries<double> input )
		{
			return indicator.ClickLimitOrderIndicator(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ClickLimitOrderIndicator ClickLimitOrderIndicator()
		{
			return indicator.ClickLimitOrderIndicator(Input);
		}

		public Indicators.ClickLimitOrderIndicator ClickLimitOrderIndicator(ISeries<double> input )
		{
			return indicator.ClickLimitOrderIndicator(input);
		}
	}
}

#endregion
