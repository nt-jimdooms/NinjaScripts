#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies
{
	public class ATRDistancedStopExample : Strategy
	{
		private ATR ATR1;
		

		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Strategy here.";
				Name										= "ATRDistancedStopExample";
				Calculate									= Calculate.OnBarClose;
				EntriesPerDirection							= 1;
				EntryHandling								= EntryHandling.AllEntries;
				IsExitOnSessionCloseStrategy				= true;
				ExitOnSessionCloseSeconds					= 30;
				IsFillLimitOnTouch							= false;
				MaximumBarsLookBack							= MaximumBarsLookBack.TwoHundredFiftySix;
				OrderFillResolution							= OrderFillResolution.Standard;
				Slippage									= 0;
				StartBehavior								= StartBehavior.WaitUntilFlat;
				TimeInForce									= TimeInForce.Gtc;
				TraceOrders									= false;
				RealtimeErrorHandling						= RealtimeErrorHandling.StopCancelClose;
				StopTargetHandling							= StopTargetHandling.PerEntryExecution;
				BarsRequiredToTrade							= 20;
				// Disable this property for performance gains in Strategy Analyzer optimizations
				// See the Help Guide for additional information
				IsInstantiatedOnEachOptimizationIteration	= true;
				Percent					= 1;
			}
			else if (State == State.Configure)
			{
				AddDataSeries(Data.BarsPeriodType.Day, 1);
			}
			else if (State == State.DataLoaded)
			{				
				ATR1				= ATR(Closes[1], 1);
			}
		}

		protected override void OnBarUpdate()
		{
			if (BarsInProgress != 0) 
				return;

			if (CurrentBars[0] < 1
			|| CurrentBars[1] < 1)
				return;

			 // Set 1
			if (Position.MarketPosition == MarketPosition.Long)
			{
				ExitLongStopMarket(Convert.ToInt32(DefaultQuantity), (Position.AveragePrice - ((ATR1[0] * Percent) )) , "", "");
			}
			
		}

		#region Properties
		[NinjaScriptProperty]
		[Range(0.1, double.MaxValue)]
		[Display(Name="Percent", Order=1, GroupName="Parameters")]
		public double Percent
		{ get; set; }
		#endregion

	}
}

#region Wizard settings, neither change nor remove
/*@
<?xml version="1.0"?>
<ScriptProperties xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <Calculate>OnBarClose</Calculate>
  <ConditionalActions>
    <ConditionalAction>
      <Actions>
        <WizardAction>
          <Children />
          <IsExpanded>false</IsExpanded>
          <IsSelected>true</IsSelected>
          <Name>Exit long position by a stop order</Name>
          <OffsetType>Arithmetic</OffsetType>
          <ActionProperties>
            <DashStyle>Solid</DashStyle>
            <DivideTimePrice>false</DivideTimePrice>
            <Id />
            <File />
            <IsAutoScale>false</IsAutoScale>
            <IsSimulatedStop>false</IsSimulatedStop>
            <IsStop>false</IsStop>
            <LogLevel>Information</LogLevel>
            <Mode>Currency</Mode>
            <OffsetType>Currency</OffsetType>
            <Priority>Medium</Priority>
            <Quantity>
              <DefaultValue>0</DefaultValue>
              <IsInt>true</IsInt>
              <BindingValue xsi:type="xsd:string">DefaultQuantity</BindingValue>
              <DynamicValue>
                <Children />
                <IsExpanded>false</IsExpanded>
                <IsSelected>false</IsSelected>
                <Name>Default order quantity</Name>
                <OffsetType>Arithmetic</OffsetType>
                <AssignedCommand>
                  <Command>DefaultQuantity</Command>
                  <Parameters />
                </AssignedCommand>
                <BarsAgo>0</BarsAgo>
                <CurrencyType>Currency</CurrencyType>
                <Date>2021-11-30T14:25:19.7760675</Date>
                <DayOfWeek>Sunday</DayOfWeek>
                <EndBar>0</EndBar>
                <ForceSeriesIndex>false</ForceSeriesIndex>
                <LookBackPeriod>0</LookBackPeriod>
                <MarketPosition>Long</MarketPosition>
                <Period>0</Period>
                <ReturnType>Number</ReturnType>
                <StartBar>0</StartBar>
                <State>Undefined</State>
                <Time>0001-01-01T00:00:00</Time>
              </DynamicValue>
              <IsLiteral>false</IsLiteral>
              <LiveValue xsi:type="xsd:string">DefaultQuantity</LiveValue>
            </Quantity>
            <ServiceName />
            <ScreenshotPath />
            <SoundLocation />
            <StopPrice>
              <DefaultValue>0</DefaultValue>
              <IsInt>false</IsInt>
              <BindingValue xsi:type="xsd:string">(Position.AveragePrice - ((ATR(&lt;Primary&gt; (Daily), 1)[0] * Percent) )) </BindingValue>
              <DynamicValue>
                <Children />
                <IsExpanded>false</IsExpanded>
                <IsSelected>true</IsSelected>
                <Name>Average position price</Name>
                <OffsetType>Arithmetic</OffsetType>
                <AssignedCommand>
                  <Command>Position.AveragePrice</Command>
                  <Parameters>
                    <string>OffsetBuilder</string>
                  </Parameters>
                </AssignedCommand>
                <BarsAgo>0</BarsAgo>
                <CurrencyType>Currency</CurrencyType>
                <Date>2021-11-30T14:25:44.0530601</Date>
                <DayOfWeek>Sunday</DayOfWeek>
                <EndBar>0</EndBar>
                <ForceSeriesIndex>false</ForceSeriesIndex>
                <LookBackPeriod>0</LookBackPeriod>
                <MarketPosition>Long</MarketPosition>
                <OffsetBuilder>
                  <ConditionOffset>
                    <IsSetEnabled>false</IsSetEnabled>
                    <OffsetValue>0</OffsetValue>
                    <OffsetOperator>Subtract</OffsetOperator>
                    <OffsetType>Arithmetic</OffsetType>
                  </ConditionOffset>
                  <Offset>
                    <DefaultValue>0</DefaultValue>
                    <IsInt>false</IsInt>
                    <BindingValue xsi:type="xsd:string">(ATR(&lt;Primary&gt; (Daily), 1)[0] * Percent) </BindingValue>
                    <DynamicValue>
                      <Children />
                      <IsExpanded>false</IsExpanded>
                      <IsSelected>true</IsSelected>
                      <Name>ATR</Name>
                      <OffsetType>Arithmetic</OffsetType>
                      <AssignedCommand>
                        <Command>ATR</Command>
                        <Parameters>
                          <string>AssociatedIndicator</string>
                          <string>BarsAgo</string>
                          <string>OffsetBuilder</string>
                        </Parameters>
                      </AssignedCommand>
                      <AssociatedIndicator>
                        <AcceptableSeries>Indicator DataSeries CustomSeries DefaultSeries</AcceptableSeries>
                        <CustomProperties>
                          <item>
                            <key>
                              <string>Period</string>
                            </key>
                            <value>
                              <anyType xsi:type="NumberBuilder">
                                <LiveValue xsi:type="xsd:string">1</LiveValue>
                                <BindingValue xsi:type="xsd:string">1</BindingValue>
                                <DefaultValue>0</DefaultValue>
                                <IsInt>true</IsInt>
                                <IsLiteral>true</IsLiteral>
                              </anyType>
                            </value>
                          </item>
                        </CustomProperties>
                        <IndicatorHolder>
                          <IndicatorName>ATR</IndicatorName>
                          <Plots>
                            <Plot>
                              <IsOpacityVisible>false</IsOpacityVisible>
                              <BrushSerialize>&lt;SolidColorBrush xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"&gt;#FF008B8B&lt;/SolidColorBrush&gt;</BrushSerialize>
                              <DashStyleHelper>Solid</DashStyleHelper>
                              <Opacity>100</Opacity>
                              <Width>1</Width>
                              <AutoWidth>false</AutoWidth>
                              <Max>1.7976931348623157E+308</Max>
                              <Min>-1.7976931348623157E+308</Min>
                              <Name>ATR</Name>
                              <PlotStyle>Line</PlotStyle>
                            </Plot>
                          </Plots>
                        </IndicatorHolder>
                        <IsExplicitlyNamed>false</IsExplicitlyNamed>
                        <IsPriceTypeLocked>false</IsPriceTypeLocked>
                        <PlotOnChart>false</PlotOnChart>
                        <PriceType>Close</PriceType>
                        <SeriesType>Indicator</SeriesType>
                        <HostedDataSeries>
                          <AcceptableSeries>Indicator DataSeries CustomSeries DefaultSeries</AcceptableSeries>
                          <CustomProperties />
                          <DataSeries>
                            <InstrumentName>&lt;Primary&gt;</InstrumentName>
                            <PriceBasedOn xsi:nil="true" />
                            <SameAsPrimary>true</SameAsPrimary>
                            <Type>Day</Type>
                            <Value>1</Value>
                          </DataSeries>
                          <IsExplicitlyNamed>false</IsExplicitlyNamed>
                          <IsPriceTypeLocked>false</IsPriceTypeLocked>
                          <PlotOnChart>false</PlotOnChart>
                          <PriceType>Close</PriceType>
                          <SeriesType>DataSeries</SeriesType>
                        </HostedDataSeries>
                      </AssociatedIndicator>
                      <BarsAgo>0</BarsAgo>
                      <CurrencyType>Currency</CurrencyType>
                      <Date>2021-11-30T14:31:56.825716</Date>
                      <DayOfWeek>Sunday</DayOfWeek>
                      <EndBar>0</EndBar>
                      <ForceSeriesIndex>false</ForceSeriesIndex>
                      <LookBackPeriod>0</LookBackPeriod>
                      <MarketPosition>Long</MarketPosition>
                      <OffsetBuilder>
                        <ConditionOffset>
                          <IsSetEnabled>false</IsSetEnabled>
                          <OffsetValue>0</OffsetValue>
                          <OffsetOperator>Multiply</OffsetOperator>
                          <OffsetType>Arithmetic</OffsetType>
                        </ConditionOffset>
                        <Offset>
                          <DefaultValue>0</DefaultValue>
                          <IsInt>false</IsInt>
                          <BindingValue xsi:type="xsd:string">Percent</BindingValue>
                          <DynamicValue>
                            <Children />
                            <IsExpanded>false</IsExpanded>
                            <IsSelected>true</IsSelected>
                            <Name>Percent</Name>
                            <OffsetType>Arithmetic</OffsetType>
                            <AssignedCommand>
                              <Command>Percent</Command>
                              <Parameters />
                            </AssignedCommand>
                            <BarsAgo>0</BarsAgo>
                            <CurrencyType>Currency</CurrencyType>
                            <Date>2021-11-30T14:35:29.3418479</Date>
                            <DayOfWeek>Sunday</DayOfWeek>
                            <EndBar>0</EndBar>
                            <ForceSeriesIndex>false</ForceSeriesIndex>
                            <LookBackPeriod>0</LookBackPeriod>
                            <MarketPosition>Long</MarketPosition>
                            <Period>0</Period>
                            <ReturnType>Number</ReturnType>
                            <StartBar>0</StartBar>
                            <State>Undefined</State>
                            <Time>0001-01-01T00:00:00</Time>
                          </DynamicValue>
                          <IsLiteral>false</IsLiteral>
                          <LiveValue xsi:type="xsd:string">Percent</LiveValue>
                        </Offset>
                      </OffsetBuilder>
                      <Period>0</Period>
                      <ReturnType>Series</ReturnType>
                      <StartBar>0</StartBar>
                      <State>Undefined</State>
                      <Time>0001-01-01T00:00:00</Time>
                    </DynamicValue>
                    <IsLiteral>false</IsLiteral>
                    <LiveValue xsi:type="xsd:string">(ATR(&lt;Primary&gt; (Daily), 1)[0] * Percent) </LiveValue>
                  </Offset>
                </OffsetBuilder>
                <Period>0</Period>
                <ReturnType>Number</ReturnType>
                <StartBar>0</StartBar>
                <State>Undefined</State>
                <Time>0001-01-01T00:00:00</Time>
              </DynamicValue>
              <IsLiteral>false</IsLiteral>
              <LiveValue xsi:type="xsd:string">(Position.AveragePrice - ((ATR(&lt;Primary&gt; (Daily), 1)[0] * Percent) )) </LiveValue>
            </StopPrice>
            <TextPosition>BottomLeft</TextPosition>
            <VariableDateTime>2021-11-30T14:35:58.0572992</VariableDateTime>
            <VariableBool>false</VariableBool>
          </ActionProperties>
          <ActionType>ExitStop</ActionType>
          <Command>
            <Command>ExitLongStopMarket</Command>
            <Parameters>
              <string>quantity</string>
              <string>stopPrice</string>
              <string>signalName</string>
              <string>fromEntrySignal</string>
            </Parameters>
          </Command>
        </WizardAction>
      </Actions>
      <ActiveAction>
        <Children />
        <IsExpanded>false</IsExpanded>
        <IsSelected>true</IsSelected>
        <Name>Exit long position by a stop order</Name>
        <OffsetType>Arithmetic</OffsetType>
        <ActionProperties>
          <DashStyle>Solid</DashStyle>
          <DivideTimePrice>false</DivideTimePrice>
          <Id />
          <File />
          <IsAutoScale>false</IsAutoScale>
          <IsSimulatedStop>false</IsSimulatedStop>
          <IsStop>false</IsStop>
          <LogLevel>Information</LogLevel>
          <Mode>Currency</Mode>
          <OffsetType>Currency</OffsetType>
          <Priority>Medium</Priority>
          <Quantity>
            <DefaultValue>0</DefaultValue>
            <IsInt>true</IsInt>
            <BindingValue xsi:type="xsd:string">DefaultQuantity</BindingValue>
            <DynamicValue>
              <Children />
              <IsExpanded>false</IsExpanded>
              <IsSelected>false</IsSelected>
              <Name>Default order quantity</Name>
              <OffsetType>Arithmetic</OffsetType>
              <AssignedCommand>
                <Command>DefaultQuantity</Command>
                <Parameters />
              </AssignedCommand>
              <BarsAgo>0</BarsAgo>
              <CurrencyType>Currency</CurrencyType>
              <Date>2021-11-30T14:25:19.7760675</Date>
              <DayOfWeek>Sunday</DayOfWeek>
              <EndBar>0</EndBar>
              <ForceSeriesIndex>false</ForceSeriesIndex>
              <LookBackPeriod>0</LookBackPeriod>
              <MarketPosition>Long</MarketPosition>
              <Period>0</Period>
              <ReturnType>Number</ReturnType>
              <StartBar>0</StartBar>
              <State>Undefined</State>
              <Time>0001-01-01T00:00:00</Time>
            </DynamicValue>
            <IsLiteral>false</IsLiteral>
            <LiveValue xsi:type="xsd:string">DefaultQuantity</LiveValue>
          </Quantity>
          <ServiceName />
          <ScreenshotPath />
          <SoundLocation />
          <StopPrice>
            <DefaultValue>0</DefaultValue>
            <IsInt>false</IsInt>
            <BindingValue xsi:type="xsd:string">(Position.AveragePrice - ((ATR(Close, 1)[0] * Percent) )) </BindingValue>
            <DynamicValue>
              <Children />
              <IsExpanded>false</IsExpanded>
              <IsSelected>true</IsSelected>
              <Name>Average position price</Name>
              <OffsetType>Arithmetic</OffsetType>
              <AssignedCommand>
                <Command>Position.AveragePrice</Command>
                <Parameters>
                  <string>OffsetBuilder</string>
                </Parameters>
              </AssignedCommand>
              <BarsAgo>0</BarsAgo>
              <CurrencyType>Currency</CurrencyType>
              <Date>2021-11-30T14:25:44.0530601</Date>
              <DayOfWeek>Sunday</DayOfWeek>
              <EndBar>0</EndBar>
              <ForceSeriesIndex>false</ForceSeriesIndex>
              <LookBackPeriod>0</LookBackPeriod>
              <MarketPosition>Long</MarketPosition>
              <OffsetBuilder>
                <ConditionOffset>
                  <IsSetEnabled>false</IsSetEnabled>
                  <OffsetValue>0</OffsetValue>
                  <OffsetOperator>Subtract</OffsetOperator>
                  <OffsetType>Arithmetic</OffsetType>
                </ConditionOffset>
                <Offset>
                  <DefaultValue>0</DefaultValue>
                  <IsInt>false</IsInt>
                  <BindingValue xsi:type="xsd:string">(ATR(&lt;Primary&gt; (Daily), 1)[0] * Percent) </BindingValue>
                  <DynamicValue>
                    <Children />
                    <IsExpanded>false</IsExpanded>
                    <IsSelected>true</IsSelected>
                    <Name>ATR</Name>
                    <OffsetType>Arithmetic</OffsetType>
                    <AssignedCommand>
                      <Command>ATR</Command>
                      <Parameters>
                        <string>AssociatedIndicator</string>
                        <string>BarsAgo</string>
                        <string>OffsetBuilder</string>
                      </Parameters>
                    </AssignedCommand>
                    <AssociatedIndicator>
                      <AcceptableSeries>Indicator DataSeries CustomSeries DefaultSeries</AcceptableSeries>
                      <CustomProperties>
                        <item>
                          <key>
                            <string>Period</string>
                          </key>
                          <value>
                            <anyType xsi:type="NumberBuilder">
                              <LiveValue xsi:type="xsd:string">1</LiveValue>
                              <BindingValue xsi:type="xsd:string">1</BindingValue>
                              <DefaultValue>0</DefaultValue>
                              <IsInt>true</IsInt>
                              <IsLiteral>true</IsLiteral>
                            </anyType>
                          </value>
                        </item>
                      </CustomProperties>
                      <IndicatorHolder>
                        <IndicatorName>ATR</IndicatorName>
                        <Plots>
                          <Plot>
                            <IsOpacityVisible>false</IsOpacityVisible>
                            <BrushSerialize>&lt;SolidColorBrush xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"&gt;#FF008B8B&lt;/SolidColorBrush&gt;</BrushSerialize>
                            <DashStyleHelper>Solid</DashStyleHelper>
                            <Opacity>100</Opacity>
                            <Width>1</Width>
                            <AutoWidth>false</AutoWidth>
                            <Max>1.7976931348623157E+308</Max>
                            <Min>-1.7976931348623157E+308</Min>
                            <Name>ATR</Name>
                            <PlotStyle>Line</PlotStyle>
                          </Plot>
                        </Plots>
                      </IndicatorHolder>
                      <IsExplicitlyNamed>false</IsExplicitlyNamed>
                      <IsPriceTypeLocked>false</IsPriceTypeLocked>
                      <PlotOnChart>false</PlotOnChart>
                      <PriceType>Close</PriceType>
                      <SeriesType>Indicator</SeriesType>
                      <HostedDataSeries>
                        <AcceptableSeries>Indicator DataSeries CustomSeries DefaultSeries</AcceptableSeries>
                        <CustomProperties />
                        <DataSeries>
                          <InstrumentName>&lt;Primary&gt;</InstrumentName>
                          <PriceBasedOn xsi:nil="true" />
                          <SameAsPrimary>true</SameAsPrimary>
                          <Type>Day</Type>
                          <Value>1</Value>
                        </DataSeries>
                        <IsExplicitlyNamed>false</IsExplicitlyNamed>
                        <IsPriceTypeLocked>false</IsPriceTypeLocked>
                        <PlotOnChart>false</PlotOnChart>
                        <PriceType>Close</PriceType>
                        <SeriesType>DataSeries</SeriesType>
                      </HostedDataSeries>
                    </AssociatedIndicator>
                    <BarsAgo>0</BarsAgo>
                    <CurrencyType>Currency</CurrencyType>
                    <Date>2021-11-30T14:31:56.825716</Date>
                    <DayOfWeek>Sunday</DayOfWeek>
                    <EndBar>0</EndBar>
                    <ForceSeriesIndex>false</ForceSeriesIndex>
                    <LookBackPeriod>0</LookBackPeriod>
                    <MarketPosition>Long</MarketPosition>
                    <OffsetBuilder>
                      <ConditionOffset>
                        <IsSetEnabled>false</IsSetEnabled>
                        <OffsetValue>0</OffsetValue>
                        <OffsetOperator>Multiply</OffsetOperator>
                        <OffsetType>Arithmetic</OffsetType>
                      </ConditionOffset>
                      <Offset>
                        <DefaultValue>0</DefaultValue>
                        <IsInt>false</IsInt>
                        <BindingValue xsi:type="xsd:string">Percent</BindingValue>
                        <DynamicValue>
                          <Children />
                          <IsExpanded>false</IsExpanded>
                          <IsSelected>true</IsSelected>
                          <Name>Percent</Name>
                          <OffsetType>Arithmetic</OffsetType>
                          <AssignedCommand>
                            <Command>Percent</Command>
                            <Parameters />
                          </AssignedCommand>
                          <BarsAgo>0</BarsAgo>
                          <CurrencyType>Currency</CurrencyType>
                          <Date>2021-11-30T14:35:29.3418479</Date>
                          <DayOfWeek>Sunday</DayOfWeek>
                          <EndBar>0</EndBar>
                          <ForceSeriesIndex>false</ForceSeriesIndex>
                          <LookBackPeriod>0</LookBackPeriod>
                          <MarketPosition>Long</MarketPosition>
                          <Period>0</Period>
                          <ReturnType>Number</ReturnType>
                          <StartBar>0</StartBar>
                          <State>Undefined</State>
                          <Time>0001-01-01T00:00:00</Time>
                        </DynamicValue>
                        <IsLiteral>false</IsLiteral>
                        <LiveValue xsi:type="xsd:string">Percent</LiveValue>
                      </Offset>
                    </OffsetBuilder>
                    <Period>0</Period>
                    <ReturnType>Series</ReturnType>
                    <StartBar>0</StartBar>
                    <State>Undefined</State>
                    <Time>0001-01-01T00:00:00</Time>
                  </DynamicValue>
                  <IsLiteral>false</IsLiteral>
                  <LiveValue xsi:type="xsd:string">(ATR(Close, 1)[0] * Percent) </LiveValue>
                </Offset>
              </OffsetBuilder>
              <Period>0</Period>
              <ReturnType>Number</ReturnType>
              <StartBar>0</StartBar>
              <State>Undefined</State>
              <Time>0001-01-01T00:00:00</Time>
            </DynamicValue>
            <IsLiteral>false</IsLiteral>
            <LiveValue xsi:type="xsd:string">(Position.AveragePrice - ((ATR(Close, 1)[0] * Percent) )) </LiveValue>
          </StopPrice>
          <TextPosition>BottomLeft</TextPosition>
          <VariableDateTime>2021-11-30T14:35:58.0572992</VariableDateTime>
          <VariableBool>false</VariableBool>
        </ActionProperties>
        <ActionType>ExitStop</ActionType>
        <Command>
          <Command>ExitLongStopMarket</Command>
          <Parameters>
            <string>quantity</string>
            <string>stopPrice</string>
            <string>signalName</string>
            <string>fromEntrySignal</string>
          </Parameters>
        </Command>
      </ActiveAction>
      <AnyOrAll>All</AnyOrAll>
      <Conditions>
        <WizardConditionGroup>
          <AnyOrAll>Any</AnyOrAll>
          <Conditions>
            <WizardCondition>
              <LeftItem xsi:type="WizardConditionItem">
                <Children />
                <IsExpanded>false</IsExpanded>
                <IsSelected>true</IsSelected>
                <Name>Current market position</Name>
                <OffsetType>Arithmetic</OffsetType>
                <AssignedCommand>
                  <Command>Position.MarketPosition</Command>
                  <Parameters />
                </AssignedCommand>
                <BarsAgo>0</BarsAgo>
                <CurrencyType>Currency</CurrencyType>
                <Date>2021-11-30T14:36:25.388477</Date>
                <DayOfWeek>Sunday</DayOfWeek>
                <EndBar>0</EndBar>
                <ForceSeriesIndex>false</ForceSeriesIndex>
                <LookBackPeriod>0</LookBackPeriod>
                <MarketPosition>Long</MarketPosition>
                <Period>0</Period>
                <ReturnType>MarketData</ReturnType>
                <StartBar>0</StartBar>
                <State>Undefined</State>
                <Time>0001-01-01T00:00:00</Time>
              </LeftItem>
              <Lookback>1</Lookback>
              <Operator>Equals</Operator>
              <RightItem xsi:type="WizardConditionItem">
                <Children />
                <IsExpanded>false</IsExpanded>
                <IsSelected>true</IsSelected>
                <Name>Market position</Name>
                <OffsetType>Arithmetic</OffsetType>
                <AssignedCommand>
                  <Command>MarketPosition.{0}</Command>
                  <Parameters>
                    <string>MarketPosition</string>
                  </Parameters>
                </AssignedCommand>
                <BarsAgo>0</BarsAgo>
                <CurrencyType>Currency</CurrencyType>
                <Date>2021-11-30T14:36:25.3994321</Date>
                <DayOfWeek>Sunday</DayOfWeek>
                <EndBar>0</EndBar>
                <ForceSeriesIndex>false</ForceSeriesIndex>
                <LookBackPeriod>0</LookBackPeriod>
                <MarketPosition>Long</MarketPosition>
                <Period>0</Period>
                <ReturnType>MarketData</ReturnType>
                <StartBar>0</StartBar>
                <State>Undefined</State>
                <Time>0001-01-01T00:00:00</Time>
              </RightItem>
            </WizardCondition>
          </Conditions>
          <IsGroup>false</IsGroup>
          <DisplayName>Position.MarketPosition = MarketPosition.Long</DisplayName>
        </WizardConditionGroup>
      </Conditions>
      <SetName>Set 1</SetName>
      <SetNumber>1</SetNumber>
    </ConditionalAction>
  </ConditionalActions>
  <CustomSeries />
  <DataSeries>
    <DataSeriesProperties>
      <InstrumentName>&lt;Primary&gt;</InstrumentName>
      <PriceBasedOn xsi:nil="true" />
      <SameAsPrimary>true</SameAsPrimary>
      <Type>Day</Type>
      <Value>1</Value>
    </DataSeriesProperties>
  </DataSeries>
  <Description>Enter the description for your new custom Strategy here.</Description>
  <DisplayInDataBox>true</DisplayInDataBox>
  <DrawHorizontalGridLines>true</DrawHorizontalGridLines>
  <DrawOnPricePanel>true</DrawOnPricePanel>
  <DrawVerticalGridLines>true</DrawVerticalGridLines>
  <EntriesPerDirection>1</EntriesPerDirection>
  <EntryHandling>AllEntries</EntryHandling>
  <ExitOnSessionClose>true</ExitOnSessionClose>
  <ExitOnSessionCloseSeconds>30</ExitOnSessionCloseSeconds>
  <FillLimitOrdersOnTouch>false</FillLimitOrdersOnTouch>
  <InputParameters>
    <InputParameter>
      <Default>1</Default>
      <Description />
      <Name>Percent</Name>
      <Minimum>0.1</Minimum>
      <Type>double</Type>
    </InputParameter>
  </InputParameters>
  <IsTradingHoursBreakLineVisible>true</IsTradingHoursBreakLineVisible>
  <IsInstantiatedOnEachOptimizationIteration>true</IsInstantiatedOnEachOptimizationIteration>
  <MaximumBarsLookBack>TwoHundredFiftySix</MaximumBarsLookBack>
  <MinimumBarsRequired>20</MinimumBarsRequired>
  <OrderFillResolution>Standard</OrderFillResolution>
  <OrderFillResolutionValue>1</OrderFillResolutionValue>
  <OrderFillResolutionType>Minute</OrderFillResolutionType>
  <OverlayOnPrice>false</OverlayOnPrice>
  <PaintPriceMarkers>true</PaintPriceMarkers>
  <PlotParameters />
  <RealTimeErrorHandling>StopCancelClose</RealTimeErrorHandling>
  <ScaleJustification>Right</ScaleJustification>
  <ScriptType>Strategy</ScriptType>
  <Slippage>0</Slippage>
  <StartBehavior>WaitUntilFlat</StartBehavior>
  <StopsAndTargets />
  <StopTargetHandling>PerEntryExecution</StopTargetHandling>
  <TimeInForce>Gtc</TimeInForce>
  <TraceOrders>false</TraceOrders>
  <UseOnAddTradeEvent>false</UseOnAddTradeEvent>
  <UseOnAuthorizeAccountEvent>false</UseOnAuthorizeAccountEvent>
  <UseAccountItemUpdate>false</UseAccountItemUpdate>
  <UseOnCalculatePerformanceValuesEvent>true</UseOnCalculatePerformanceValuesEvent>
  <UseOnConnectionEvent>false</UseOnConnectionEvent>
  <UseOnDataPointEvent>true</UseOnDataPointEvent>
  <UseOnFundamentalDataEvent>false</UseOnFundamentalDataEvent>
  <UseOnExecutionEvent>false</UseOnExecutionEvent>
  <UseOnMouseDown>true</UseOnMouseDown>
  <UseOnMouseMove>true</UseOnMouseMove>
  <UseOnMouseUp>true</UseOnMouseUp>
  <UseOnMarketDataEvent>false</UseOnMarketDataEvent>
  <UseOnMarketDepthEvent>false</UseOnMarketDepthEvent>
  <UseOnMergePerformanceMetricEvent>false</UseOnMergePerformanceMetricEvent>
  <UseOnNextDataPointEvent>true</UseOnNextDataPointEvent>
  <UseOnNextInstrumentEvent>true</UseOnNextInstrumentEvent>
  <UseOnOptimizeEvent>true</UseOnOptimizeEvent>
  <UseOnOrderUpdateEvent>false</UseOnOrderUpdateEvent>
  <UseOnPositionUpdateEvent>false</UseOnPositionUpdateEvent>
  <UseOnRenderEvent>true</UseOnRenderEvent>
  <UseOnRestoreValuesEvent>false</UseOnRestoreValuesEvent>
  <UseOnShareEvent>true</UseOnShareEvent>
  <UseOnWindowCreatedEvent>false</UseOnWindowCreatedEvent>
  <UseOnWindowDestroyedEvent>false</UseOnWindowDestroyedEvent>
  <Variables />
  <Name>ATRDistancedStopExample</Name>
</ScriptProperties>
@*/
#endregion
