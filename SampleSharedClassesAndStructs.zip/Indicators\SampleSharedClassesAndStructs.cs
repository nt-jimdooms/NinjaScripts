#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class SampleSharedClassesAndStructs : Indicator
	{
		// Create instances of the exposed Class and Struct
		public SharedClass	myClass;
		public SharedStruct myStruct;
		public Tuple<string, double, double, double, double> SharedTuple;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Indicator here.";
				Name										= "SampleSharedClassesAndStructs";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
			}
			else if (State == State.DataLoaded)
			{
				// Create instances of the exposed Class and Struct
				myClass					= new SharedClass();
				myStruct				= new SharedStruct();
				
				// Set an initial value
				myClass.ClassInt = 1;
				myStruct.StructInt = 1;
			}
		}

		protected override void OnBarUpdate()
		{
			// Perform some local modification of our exposed variables in our public Struct and Class.
			myClass.ClassInt++;
			myStruct.StructInt++;
			SharedTuple = Tuple.Create(this.Name, Open[0], High[0], Low[0], Close[0]);
		}
		
		#region Properties
		
		// Create public Classes and Structs with public members for external modification
		[Browsable(false)]
		public struct SharedStruct  
		{  
		    public int StructInt;   
		} 
		
		[Browsable(false)]
        public class SharedClass
        {
			public int ClassInt;
        }
		
		#endregion
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private SampleSharedClassesAndStructs[] cacheSampleSharedClassesAndStructs;
		public SampleSharedClassesAndStructs SampleSharedClassesAndStructs()
		{
			return SampleSharedClassesAndStructs(Input);
		}

		public SampleSharedClassesAndStructs SampleSharedClassesAndStructs(ISeries<double> input)
		{
			if (cacheSampleSharedClassesAndStructs != null)
				for (int idx = 0; idx < cacheSampleSharedClassesAndStructs.Length; idx++)
					if (cacheSampleSharedClassesAndStructs[idx] != null &&  cacheSampleSharedClassesAndStructs[idx].EqualsInput(input))
						return cacheSampleSharedClassesAndStructs[idx];
			return CacheIndicator<SampleSharedClassesAndStructs>(new SampleSharedClassesAndStructs(), input, ref cacheSampleSharedClassesAndStructs);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.SampleSharedClassesAndStructs SampleSharedClassesAndStructs()
		{
			return indicator.SampleSharedClassesAndStructs(Input);
		}

		public Indicators.SampleSharedClassesAndStructs SampleSharedClassesAndStructs(ISeries<double> input )
		{
			return indicator.SampleSharedClassesAndStructs(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.SampleSharedClassesAndStructs SampleSharedClassesAndStructs()
		{
			return indicator.SampleSharedClassesAndStructs(Input);
		}

		public Indicators.SampleSharedClassesAndStructs SampleSharedClassesAndStructs(ISeries<double> input )
		{
			return indicator.SampleSharedClassesAndStructs(input);
		}
	}
}

#endregion
