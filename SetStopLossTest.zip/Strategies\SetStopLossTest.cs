#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies
{
	public class SetStopLossTest : Strategy
	{
		private double riskAmount = 5000;
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Strategy here.";
				Name										= "SetStopLossTest";
				Calculate									= Calculate.OnBarClose;
				EntriesPerDirection							= 3;
			}
			else if (State == State.DataLoaded)
			{
				ClearOutputWindow();
				SetStopLoss(CalculationMode.Currency, riskAmount);
			}
		}

		protected override void OnBarUpdate()
		{
			if (State == State.Historical)
				return;
			EnterLong(2);
		}
		
		protected override void OnExecutionUpdate(Cbi.Execution execution, string executionId, double price, int quantity, 
			Cbi.MarketPosition marketPosition, string orderId, DateTime time)
		{
			Print(String.Format("ExecutionUpdate: Average Entry Price: {0} Position Size: {1} Stop Level for 5000 Currency: {2}",
				Position.AveragePrice,
				Position.Quantity,
				(Position.AveragePrice - ((riskAmount / Instrument.MasterInstrument.PointValue) / Position.Quantity))));
		}
		
		protected override void OnOrderUpdate(Cbi.Order order, double limitPrice, double stopPrice, 
			int quantity, int filled, double averageFillPrice, 
			Cbi.OrderState orderState, DateTime time, Cbi.ErrorCode error, string comment)
		{
			if (order.Name == "Stop loss" && order.OrderState == OrderState.Accepted)
			{
				Print("Order Update: " + order.StopPrice);
			}
		}
	}
}
