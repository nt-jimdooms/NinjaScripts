#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class DivergenceSpotterV2 : Indicator
	{
		
		private DivergenceSpotter_IndicatorType indicatorType; // Default setting for IndicatorType
        private int fastPeriod; // Default setting for FastPeriod
        private int slowPeriod; // Default setting for SlowPeriod
        private int signalPeriod; // Default setting for SignalPeriod
		private int lookbackPeriod; //If "0", then lookback to first instance of indicator crossing 0 line
											//if ">0", then lookback only that amount of bars
		private int barSensitivity; //small values increase divergences, large values decrease
										  //ideal value is 50% of lookbackPeriod
		private int bkgopacity;
		private int LastSignal;
		private int BarOfLastSignal;

		// User defined variables (add any user defined variables below)
		private int bardiff, i;
		private bool DoneSearching, RunInit;
		private Brush StripeBackgroundColor;
		private Series<double> TheIndicator;
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Indicator here.";
				Name										= "DivergenceSpotterV2";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= true;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				
				indicatorType = DivergenceSpotter_IndicatorType.MFI; // Default setting for IndicatorType
		        fastPeriod = 12; // Default setting for FastPeriod
		        slowPeriod = 26; // Default setting for SlowPeriod
		        signalPeriod = 9; // Default setting for SignalPeriod
				lookbackPeriod = 0; //If "0", then lookback to first instance of indicator crossing 0 line
													//if ">0", then lookback only that amount of bars
				barSensitivity=3; //small values increase divergences, large values decrease
												  //ideal value is 50% of lookbackPeriod
				bkgopacity = 25;
				LastSignal = 0;
				BarOfLastSignal=-10;

				// User defined variables (add any user defined variables below)
				bardiff=0;
				DoneSearching = true; 
				RunInit=true;
				
				AddPlot(new Stroke(Brushes.Blue, 2), PlotStyle.Dot, "BuySignal");
				AddPlot(new Stroke(Brushes.DeepPink, 2), PlotStyle.Dot, "SellSignal");
			}
			else if (State == State.Configure)
			{
				if(RunInit && ChartControl != null)
				{
					RunInit=false;
					IsAutoScale = false;
				}
			}
			else if (State == State.DataLoaded)
			{
				TheIndicator = new Series<double>(this, MaximumBarsLookBack.Infinite);
			}
		}

		protected override void OnBarUpdate()
		{

			if(RunInit) return;
			int LowestBarIndexPossible = Math.Max(fastPeriod,Math.Max(slowPeriod,lookbackPeriod));
			if(CurrentBar < 1+LowestBarIndexPossible) return;
			if(indicatorType == DivergenceSpotter_IndicatorType.MACD) TheIndicator[0] = MACD(fastPeriod,slowPeriod,signalPeriod)[0];
			else if(indicatorType == DivergenceSpotter_IndicatorType.TRIX) TheIndicator[0] = TRIX(slowPeriod,signalPeriod)[0];
			else if(indicatorType == DivergenceSpotter_IndicatorType.StochFastK) TheIndicator[0] = StochasticsFast(slowPeriod, fastPeriod).K[0]-50.0;
			else if(indicatorType == DivergenceSpotter_IndicatorType.StochRSI) TheIndicator[0] = StochRSI(fastPeriod)[0]-0.5;
			else if(indicatorType == DivergenceSpotter_IndicatorType.CCI) TheIndicator[0] = CCI(fastPeriod)[0];
			else if(indicatorType == DivergenceSpotter_IndicatorType.BOP) TheIndicator[0] = BOP(fastPeriod)[0];
			else if(indicatorType == DivergenceSpotter_IndicatorType.CMO) TheIndicator[0] = CMO(fastPeriod)[0];
			else if(indicatorType == DivergenceSpotter_IndicatorType.ChaikinMoneyFlow) TheIndicator[0] = ChaikinMoneyFlow(fastPeriod)[0];
			else if(indicatorType == DivergenceSpotter_IndicatorType.Momentum) TheIndicator[0] = Momentum(fastPeriod)[0];
			else if(indicatorType == DivergenceSpotter_IndicatorType.MFI) TheIndicator[0] = MFI(fastPeriod)[0];
			else if(indicatorType == DivergenceSpotter_IndicatorType.RSI) TheIndicator[0] = RSI(fastPeriod,signalPeriod)[0]-50; //signalPeriod is here, but is ignored in the divergence calc
			else if(indicatorType == DivergenceSpotter_IndicatorType.ROC) TheIndicator[0] = ROC(fastPeriod)[0];
            else if (indicatorType == DivergenceSpotter_IndicatorType.StochSlowD) TheIndicator[0] = Stochastics(slowPeriod, fastPeriod, signalPeriod).D[0] - 50;
            else if (indicatorType == DivergenceSpotter_IndicatorType.StochFastD) TheIndicator[0] = StochasticsFast(slowPeriod, fastPeriod).D[0] - 50;
			else return;
			
			double Hprice = double.MinValue;
			double Lprice = High[0];
			double Hindicator = TheIndicator[0];
			double Lindicator = TheIndicator[0];
			int HPriceBar = -1;
			int LPriceBar = -1;
			int LIndicatorBar = -1;
			int HIndicatorBar = -1;
			i=1;
			DoneSearching=false;
			while(!DoneSearching)
			{	if(High[i]>Hprice) //a new high in price was found, record it
				{	Hprice = High[i];
					HPriceBar = i; //this is the bar number of the highest price in the lookbackPeriod
				}
			 	if(Low[i]<Lprice) //a new low in price was found, record it
				{	Lprice = Low[i];
					LPriceBar = i;//this is the bar number of the lowest price in the lookbackPeriod
				}
				if(TheIndicator[i]>Hindicator) //a new high in the indicator was found, record it
				{	Hindicator = TheIndicator[i];
					HIndicatorBar = i;//this is the bar number of the highest indicator value in the lookbackPeriod
				}
				if(TheIndicator[i]<Lindicator) //a new low in the indicator was found, record it
				{	Lindicator = TheIndicator[i];
					LIndicatorBar = i;//this is the bar number of the lowest indicator value in the lookbackPeriod
				}
				i++;

				if(i>CurrentBar-LowestBarIndexPossible-1) DoneSearching=true; //limit of search reached
				if(lookbackPeriod==0)//then find the last time the indicator crossed the "0" line
				{	if(TheIndicator[i] * TheIndicator[i+1] < 0.0) DoneSearching=true;}
				else //terminate the search when i has exceeded the lookbackPeriod
				{	if(i > lookbackPeriod) DoneSearching=true;}
			}

			SellSignal[0] = 0;
			BuySignal[0] = 0;
			BackBrush = null;
			if(CurrentBar - BarOfLastSignal > 10) LastSignal=0;
			if(TheIndicator[0]>0) //look for sell divergence since Indicator is above ZERO
			{	bardiff = HIndicatorBar-HPriceBar; //How many bars separated the highs?
				if(bardiff>barSensitivity) {
					SellSignal[0] = Low[0]-Math.Max((High[0]-Low[0])/2,5*TickSize);
					if(LastSignal!=-1 && bkgopacity>0) BackBrush = new SolidColorBrush(Color.FromArgb((byte)Math.Round(255.0*bkgopacity/10,0),255,51,153));
					LastSignal = -1;
					BarOfLastSignal = CurrentBar;
				}
			} else //look for Buy divergence since Indicator is below ZERO
			{	bardiff = LIndicatorBar-LPriceBar; //How many bars separated the lows?
				if(bardiff>barSensitivity) {
					BuySignal[0] = High[0]+Math.Max((High[0]-Low[0])/2,5*TickSize);
					if(LastSignal!=1 && bkgopacity>0) BackBrush = new SolidColorBrush(Color.FromArgb((byte)Math.Round(255.0*bkgopacity/10,0),0,0,255));
					LastSignal = 1;
					BarOfLastSignal = CurrentBar;
				}
			}
		}

		#region Properties

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> BuySignal
		{
			get { return Values[0]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> SellSignal
		{
			get { return Values[1]; }
		}

        [Description("Select the oscillator")]
        [Category("Parameters")]
		[NinjaScriptProperty]
        public DivergenceSpotter_IndicatorType IndicatorType
        {
            get { return indicatorType; }
            set { indicatorType = value; }
        }

        [Description("Used on all indicators, and is the %K value in Stochs")]
        [Category("Parameters")]
		[NinjaScriptProperty]
        public int PeriodFast
        {
            get { return fastPeriod; }
            set { fastPeriod = Math.Max(1, value); }
        }

        [Description("Used on MACD and as the %D value in Stochs")]
        [Category("Parameters")]
		[NinjaScriptProperty]
        public int PeriodSlow
        {
            get { return slowPeriod; }
            set { slowPeriod = Math.Max(1, value); }
        }

        [Description("Used on the MACD indicator and the StochSlowD")]
        [Category("Parameters")]
		[NinjaScriptProperty]
        public int PeriodSignal
        {
            get { return signalPeriod; }
            set { signalPeriod = Math.Max(1, value); }
        }

		[Description("Determines how far back to look for divergence, a '0' value means since the last crossing of the Zero line")]
        [Category("Parameters")]
		[NinjaScriptProperty]
        public int LookbackPeriod
        {
            get { return lookbackPeriod; }
            set { lookbackPeriod = Math.Max(0, value); }
        }
		[Description("Low values look for tighter matchups, high values look for loose peaks matchup")]
        [Category("Parameters")]
		[NinjaScriptProperty]
        public int BarSensitivity
        {
            get { return barSensitivity; }
            set { barSensitivity = Math.Max(1, value); }
        }

		[XmlIgnore()]
		[Description("Opacity of background colors ('0' to disengage background colorizing)")]
		[Category("Visual background")]
		[NinjaScriptProperty]
		public int Opacity
		{
			get { return bkgopacity; }
			set { bkgopacity = Math.Min(10,Math.Max(0,value)); }
		}
		#endregion

	}
}

    	public enum DivergenceSpotter_IndicatorType
        {   MACD=1,
			TRIX=2,
            CCI=3,
            BOP=4,
            CMO=5,
            ChaikinMoneyFlow=6,
            Momentum=7,
            MFI=8,
            RSI=9,
            ROC=10,
            StochSlowD=11,
            StochFastD=12,
            StochFastK=13,
            StochRSI=14
        }

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private DivergenceSpotterV2[] cacheDivergenceSpotterV2;
		public DivergenceSpotterV2 DivergenceSpotterV2(DivergenceSpotter_IndicatorType indicatorType, int periodFast, int periodSlow, int periodSignal, int lookbackPeriod, int barSensitivity, int opacity)
		{
			return DivergenceSpotterV2(Input, indicatorType, periodFast, periodSlow, periodSignal, lookbackPeriod, barSensitivity, opacity);
		}

		public DivergenceSpotterV2 DivergenceSpotterV2(ISeries<double> input, DivergenceSpotter_IndicatorType indicatorType, int periodFast, int periodSlow, int periodSignal, int lookbackPeriod, int barSensitivity, int opacity)
		{
			if (cacheDivergenceSpotterV2 != null)
				for (int idx = 0; idx < cacheDivergenceSpotterV2.Length; idx++)
					if (cacheDivergenceSpotterV2[idx] != null && cacheDivergenceSpotterV2[idx].IndicatorType == indicatorType && cacheDivergenceSpotterV2[idx].PeriodFast == periodFast && cacheDivergenceSpotterV2[idx].PeriodSlow == periodSlow && cacheDivergenceSpotterV2[idx].PeriodSignal == periodSignal && cacheDivergenceSpotterV2[idx].LookbackPeriod == lookbackPeriod && cacheDivergenceSpotterV2[idx].BarSensitivity == barSensitivity && cacheDivergenceSpotterV2[idx].Opacity == opacity && cacheDivergenceSpotterV2[idx].EqualsInput(input))
						return cacheDivergenceSpotterV2[idx];
			return CacheIndicator<DivergenceSpotterV2>(new DivergenceSpotterV2(){ IndicatorType = indicatorType, PeriodFast = periodFast, PeriodSlow = periodSlow, PeriodSignal = periodSignal, LookbackPeriod = lookbackPeriod, BarSensitivity = barSensitivity, Opacity = opacity }, input, ref cacheDivergenceSpotterV2);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.DivergenceSpotterV2 DivergenceSpotterV2(DivergenceSpotter_IndicatorType indicatorType, int periodFast, int periodSlow, int periodSignal, int lookbackPeriod, int barSensitivity, int opacity)
		{
			return indicator.DivergenceSpotterV2(Input, indicatorType, periodFast, periodSlow, periodSignal, lookbackPeriod, barSensitivity, opacity);
		}

		public Indicators.DivergenceSpotterV2 DivergenceSpotterV2(ISeries<double> input , DivergenceSpotter_IndicatorType indicatorType, int periodFast, int periodSlow, int periodSignal, int lookbackPeriod, int barSensitivity, int opacity)
		{
			return indicator.DivergenceSpotterV2(input, indicatorType, periodFast, periodSlow, periodSignal, lookbackPeriod, barSensitivity, opacity);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.DivergenceSpotterV2 DivergenceSpotterV2(DivergenceSpotter_IndicatorType indicatorType, int periodFast, int periodSlow, int periodSignal, int lookbackPeriod, int barSensitivity, int opacity)
		{
			return indicator.DivergenceSpotterV2(Input, indicatorType, periodFast, periodSlow, periodSignal, lookbackPeriod, barSensitivity, opacity);
		}

		public Indicators.DivergenceSpotterV2 DivergenceSpotterV2(ISeries<double> input , DivergenceSpotter_IndicatorType indicatorType, int periodFast, int periodSlow, int periodSignal, int lookbackPeriod, int barSensitivity, int opacity)
		{
			return indicator.DivergenceSpotterV2(input, indicatorType, periodFast, periodSlow, periodSignal, lookbackPeriod, barSensitivity, opacity);
		}
	}
}

#endregion
