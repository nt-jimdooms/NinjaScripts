#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private SMA2[] cacheSMA2;

		
		public SMA2 SMA2(int period)
		{
			return SMA2(Input, period);
		}


		
		public SMA2 SMA2(ISeries<double> input, int period)
		{
			if (cacheSMA2 != null)
				for (int idx = 0; idx < cacheSMA2.Length; idx++)
					if (cacheSMA2[idx].Period == period && cacheSMA2[idx].EqualsInput(input))
						return cacheSMA2[idx];
			return CacheIndicator<SMA2>(new SMA2(){ Period = period }, input, ref cacheSMA2);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.SMA2 SMA2(int period)
		{
			return indicator.SMA2(Input, period);
		}


		
		public Indicators.SMA2 SMA2(ISeries<double> input , int period)
		{
			return indicator.SMA2(input, period);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.SMA2 SMA2(int period)
		{
			return indicator.SMA2(Input, period);
		}


		
		public Indicators.SMA2 SMA2(ISeries<double> input , int period)
		{
			return indicator.SMA2(input, period);
		}

	}
}

#endregion
