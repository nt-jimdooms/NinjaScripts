#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies
{
	public class OnEachTickTest : Strategy
	{
		private MACD mac;
		private bool usePrevBarsAgo;
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Strategy here.";
				Name										= "OnEachTickTest";
				Calculate									= Calculate.OnEachTick;
				EntriesPerDirection							= 1;
				EntryHandling								= EntryHandling.AllEntries;
				IsExitOnSessionCloseStrategy				= true;
				ExitOnSessionCloseSeconds					= 30;
				IsFillLimitOnTouch							= false;
				MaximumBarsLookBack							= MaximumBarsLookBack.TwoHundredFiftySix;
				OrderFillResolution							= OrderFillResolution.Standard;
				Slippage									= 0;
				StartBehavior								= StartBehavior.WaitUntilFlat;
				TimeInForce									= TimeInForce.Gtc;
				TraceOrders									= false;
				RealtimeErrorHandling						= RealtimeErrorHandling.StopCancelClose;
				StopTargetHandling							= StopTargetHandling.PerEntryExecution;
				BarsRequiredToTrade							= 20;
				// Disable this property for performance gains in Strategy Analyzer optimizations
				// See the Help Guide for additional information
				IsInstantiatedOnEachOptimizationIteration	= true;
				
				IsOverlay = false;
				
				AddPlot(Brushes.Orange, "MACD Value");
			}
			else if (State == State.DataLoaded)
			{
				mac = MACD(12, 16, 9);
			}
		}

		protected override void OnBarUpdate()
		{
			if (Calculate == Calculate.OnBarClose || (State == State.Historical && !Bars.IsTickReplay))
			{
				Value[0] = mac[0];
				usePrevBarsAgo = false;
			}
			else
			{
				Value[1] = mac[1];
				usePrevBarsAgo = true;
			}
			
			if(usePrevBarsAgo && IsFirstTickOfBar)
			{
				if(Position.MarketPosition == MarketPosition.Long)
					ExitLong();
				if(mac[1] < 0)
					EnterLong();
			}
			else if (!usePrevBarsAgo)
			{
				if(Position.MarketPosition == MarketPosition.Long)
					ExitLong();
				if(mac[0] < 0)
					EnterLong();
			}
				
		}
	}
}
