#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.Gui.Tools;
#endregion

// The MySharedMethodsAddonExample is created 3 times for the addons, indicators, and strategies namespaces.
// This script uses the same class name 3 times instead of different class names to demonstrate that the namespace keeps these classes separate.
namespace NinjaTrader.NinjaScript.AddOns
{
	public class MyTimerReconnectAddOn : NinjaTrader.NinjaScript.AddOnBase
	{
		private System.Timers.Timer myTimer;
		private string connectionName;
		
		private void TimerEventProcessor(Object myObject, EventArgs myEventArgs)
		{
			Connect(connectionName);
			
			myTimer.Enabled = false;
			
			// Stops the timer and removes the timer event handler
			if (myTimer != null)
			{
		  		myTimer.Enabled = false;
		  		myTimer.Elapsed -= TimerEventProcessor;
				myTimer = null;
			}
		}
		
		private Connection Connect(string connectionName)
		{
			try
			{
				ConnectOptions connectOptions = null;
				List<ConnectOptions> connectionOptionList = null;

				// copy list of connection options
				lock (Core.Globals.ConnectOptions)
					connectionOptionList = Core.Globals.ConnectOptions.ToList();

				// Get the configured account connection
				connectOptions = connectionOptionList.FirstOrDefault(o => o.Name == connectionName);

				if (connectOptions == null)
				{
					return null;
				}

				// If connection is not already connected, connect.
				lock (Connection.Connections)
				{
					if (Connection.Connections.FirstOrDefault(c => c.Options.Name == connectionName) != null)
						return null;
				}

				Connection connect = Connection.Connect(connectOptions);

				// Only return connection if successfully connected
				if (connect.Status == ConnectionStatus.Connected)
					return connect;
				else
					return null;
			}
			catch (Exception error)
			{
				return null;
			}
		}
		
		public MyTimerReconnectAddOn(string conName)
		{
			connectionName = conName;
			// Instantiates the timer and sets the interval to 1 seconds.
			myTimer = new System.Timers.Timer(1000);
	  		myTimer.Elapsed += TimerEventProcessor;
			myTimer.Enabled = true;
		}
	}
}

