#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class OverlayPlotter : Indicator
	{
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Indicator here.";
				Name										= "OverlayPlotter";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= true;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				AddPlot(Brushes.Orange, "PlotA");
				AddPlot(Brushes.OliveDrab, "PlotB");
			}
			else if (State == State.Configure)
			{
			}
		}

		protected override void OnBarUpdate()
		{
			Print(this.Name + " " + Time[0]);
		}

		#region Properties

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> PlotA
		{
			get { return Values[0]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> PlotB
		{
			get { return Values[1]; }
		}
		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private OverlayPlotter[] cacheOverlayPlotter;
		public OverlayPlotter OverlayPlotter()
		{
			return OverlayPlotter(Input);
		}

		public OverlayPlotter OverlayPlotter(ISeries<double> input)
		{
			if (cacheOverlayPlotter != null)
				for (int idx = 0; idx < cacheOverlayPlotter.Length; idx++)
					if (cacheOverlayPlotter[idx] != null &&  cacheOverlayPlotter[idx].EqualsInput(input))
						return cacheOverlayPlotter[idx];
			return CacheIndicator<OverlayPlotter>(new OverlayPlotter(), input, ref cacheOverlayPlotter);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.OverlayPlotter OverlayPlotter()
		{
			return indicator.OverlayPlotter(Input);
		}

		public Indicators.OverlayPlotter OverlayPlotter(ISeries<double> input )
		{
			return indicator.OverlayPlotter(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.OverlayPlotter OverlayPlotter()
		{
			return indicator.OverlayPlotter(Input);
		}

		public Indicators.OverlayPlotter OverlayPlotter(ISeries<double> input )
		{
			return indicator.OverlayPlotter(input);
		}
	}
}

#endregion
