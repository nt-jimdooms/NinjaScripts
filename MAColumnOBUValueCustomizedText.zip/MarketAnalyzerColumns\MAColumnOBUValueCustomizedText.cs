#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion

//This namespace holds MarketAnalyzerColumns in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public class MAColumnOBUValueCustomizedText : MarketAnalyzerColumn
	{
        private Indicators.SMA OUL;
		private string currentText;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Market Analyzer Column here.";
				Name										= "MAColumnOBUValueCustomizedText";
				Calculate									= Calculate.OnBarClose;
				DataType = typeof(string);
                               
            }
			else if (State == State.Configure)
			{
                OUL = SMA(20);
            }
		}

        protected override void OnBarUpdate()
        {
			if (Close[0] > OUL[0])
                currentText = "SUP: " + Bars.Instrument.MasterInstrument.FormatPrice(OUL[0]);
            else if (Close[0] <= OUL[0])
                currentText = "RES: " + Bars.Instrument.MasterInstrument.FormatPrice(OUL[0]);
			
			CurrentValue = OUL[0];
        }
		
		public override string Format(double value)
		{
			return currentText;
		}
    }
}
