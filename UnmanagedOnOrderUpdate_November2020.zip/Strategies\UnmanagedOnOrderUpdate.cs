#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies
{
	public class UnmanagedOnOrderUpdate : Strategy
	{
		private Order  shortEntry          = null;
        private Order  longEntry           = null;
        private Order  targetLong          = null;
        private Order  targetShort         = null;
        private Order  stopLossShort       = null;
        private Order  stopLossLong        = null;
		private string oco;
		
		private Position _CalculatedPosition; // Since this example fakes OnExecutionUpdate, Strategy Position Updates are handled in this script.
		private int _runningQuantity;
		
		private bool longSubmitted, shortSubmitted;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Strategy here.";
				Name										= "UnmanagedTemplate NT8 OnOrderUpdateOnly";
				Calculate									= Calculate.OnBarClose;
				EntriesPerDirection							= 1;
				EntryHandling								= EntryHandling.AllEntries;
				IsExitOnSessionCloseStrategy				= true;
				ExitOnSessionCloseSeconds					= 30;
				IsFillLimitOnTouch							= false;
				MaximumBarsLookBack							= MaximumBarsLookBack.TwoHundredFiftySix;
				OrderFillResolution							= OrderFillResolution.Standard;
				Slippage									= 0;
				StartBehavior								= StartBehavior.WaitUntilFlat;
				TimeInForce									= TimeInForce.Gtc;
				TraceOrders									= true;
				RealtimeErrorHandling						= RealtimeErrorHandling.StopCancelClose;
				StopTargetHandling							= StopTargetHandling.PerEntryExecution;
				BarsRequiredToTrade							= 20;
				IsUnmanaged 								= true;
				IsAdoptAccountPositionAware 				= true;
				// Disable this property for performance gains in Strategy Analyzer optimizations
				// See the Help Guide for additional information
				IsInstantiatedOnEachOptimizationIteration	= true;
			}
			else if (State == State.Configure)
			{
				AddDataSeries(BarsPeriodType.Tick, 1);
				
				_CalculatedPosition = new Position();
				_CalculatedPosition.MarketPosition = MarketPosition.Flat;
				_CalculatedPosition.Quantity = 0;
				_runningQuantity = 0;
			}
			else if (State == State.Realtime)
			{
                // convert any old historical order object references
                // to the new live order submitted to the real-time account
			    if (shortEntry != null)
			        shortEntry = GetRealtimeOrder(shortEntry);
				if (longEntry != null)
			        longEntry = GetRealtimeOrder(longEntry);
				if (targetLong != null)
			        targetLong = GetRealtimeOrder(targetLong);
				if (targetShort != null)
			        targetShort = GetRealtimeOrder(targetShort);
				if (stopLossShort != null)
			        stopLossShort = GetRealtimeOrder(stopLossShort);
				if (stopLossLong != null)
			        stopLossLong = GetRealtimeOrder(stopLossLong);
			}
		}

		protected override void OnBarUpdate()
		{
			if (BarsInProgress != 0)
				return;
			
			if (State == State.Historical)
				return;
			
			// Submit OCO entry limit orders if we currently don't have an entry order open
            if (longEntry == null && shortEntry == null && 
				_CalculatedPosition.MarketPosition == MarketPosition.Flat)
            {
                /* The entry orders objects will take on a unique ID from our SubmitOrderUnmanaged() that we can use
                later for order identification purposes in the OnOrderUpdate() and OnExecution() methods. */
				if (State == State.Historical)
					oco = DateTime.Now.ToString() + CurrentBar + "entry";
				else
					oco = GetAtmStrategyUniqueId() + "entry";
				
				if (shortEntry == null)
                	SubmitOrderUnmanaged(1, OrderAction.SellShort, OrderType.Limit, 100, High[0]+40*TickSize, 0, oco, "Short limit entry");
 				if (longEntry == null)
                	SubmitOrderUnmanaged(1, OrderAction.Buy, OrderType.Limit, 100, Low[0]-40*TickSize, 0,  oco, "Long limit entry");
            }
		}
		
		private void InlineExecutionUpdate(Order order, double AvgFillPrice, int quantity, MarketPosition marketPosition, string orderId)
		{
			// 1. Submit Targets and Stops based on filled Entry Order
			// 2. Set Order groups back to null once an associated Target or Stop is completely filled
			
			// Submit profit target and stop loss based off of entry order
			if (longEntry != null && longEntry == order)
            {
                if (order.OrderState == OrderState.Filled
                    || order.OrderState == OrderState.PartFilled
                    || (order.OrderState == OrderState.Cancelled && order.Filled > 0))
                {   
					if (stopLossLong == null && targetLong == null && !longSubmitted)
                    {
						if (State == State.Historical)
							oco = DateTime.Now.ToString() + CurrentBar + "LongExits";
						else
							oco = GetAtmStrategyUniqueId() + "LongExits";
						longSubmitted = true;
						
						SubmitOrderUnmanaged(1, OrderAction.Sell, OrderType.StopMarket, order.Filled, 0, order.AverageFillPrice - 40 * TickSize, oco, "StopLossLong");
						SubmitOrderUnmanaged(1, OrderAction.Sell, OrderType.Limit, order.Filled, order.AverageFillPrice + 80 * TickSize, 0, oco, "TargetLong");
					}
					else
					{
						ChangeOrder(stopLossLong, order.Filled, 0, order.AverageFillPrice - 40 * TickSize);
						ChangeOrder(targetLong, order.Filled, order.AverageFillPrice + 80 * TickSize, 0); 
					}
                }
            }          
            if (shortEntry != null && shortEntry == order)
            {              
                if (order.OrderState == OrderState.Filled
                    || order.OrderState == OrderState.PartFilled
                    || (order.OrderState == OrderState.Cancelled && order.Filled > 0))
                {                  
                    if (stopLossLong == null && targetLong == null && !shortSubmitted)
					{
						if (State == State.Historical)
							oco = DateTime.Now.ToString() + CurrentBar + "ShortExits";
						else
							oco = GetAtmStrategyUniqueId() + "ShortExits";
						shortSubmitted = true;
						
						SubmitOrderUnmanaged(1, OrderAction.BuyToCover, OrderType.StopMarket, order.Filled, 0, order.AverageFillPrice + 40 * TickSize, oco, "StopLossShort");
						SubmitOrderUnmanaged(1, OrderAction.BuyToCover, OrderType.Limit, order.Filled, order.AverageFillPrice - 80 * TickSize, 0, oco, "TargetShort");
					}
					else
					{
						ChangeOrder(stopLossShort, order.Filled, 0, order.AverageFillPrice + 40 * TickSize);
						ChangeOrder(targetShort, order.Filled, order.AverageFillPrice - 80 * TickSize, 0); 
					}
                }
            }
             
            // Reset our stop target and entry Order objects after our position is closed.
            if ((stopLossLong != null && stopLossLong == order) || (targetLong != null && targetLong == order))
            {
                if (order.OrderState == OrderState.Filled)
                {
                    stopLossLong = null;
                    targetLong = null;
					longEntry = null;
					longSubmitted = false;
                }
            }
            if ((stopLossShort != null && stopLossShort == order) || (targetShort != null && targetShort == order))
            {
                if (order.OrderState == OrderState.Filled)
                {
                    stopLossShort = null;
                    targetShort = null;
					shortEntry = null;
					shortSubmitted = false;
                }
            }
		}
		
		
		protected override void OnOrderUpdate(Order order, double limitPrice, double stopPrice, int quantity, int filled, double averageFillPrice, OrderState orderState, DateTime time, ErrorCode error, string nativeError)
        {
			// 1. Assign Order objects
			// 2. Handle cancels and set Order objects to null
			// 3. Calculate Strategy Position from filled entry orders
			// 4. Handle OnExecutionUpdate events from Filled and PartFilled orders
			
  			// Assign and update Order objects
  			// This is more reliable than assigning Order objects in OnBarUpdate, as the assignment is not guaranteed to be complete if it is referenced immediately after submitting
  			if (order.Name == "Short limit entry")
      			shortEntry = order;
			else if (order.Name == "Long limit entry")
      			longEntry = order;
			else if (order.Name == "StopLossLong")
      			stopLossLong = order;
			else if (order.Name == "TargetLong")
      			targetLong = order;
			else if (order.Name == "StopLossShort")
      			stopLossShort = order;
			else if (order.Name == "TargetShort")
      			targetShort = order;			
			
            if (longEntry != null && longEntry == order)
            {  
                // Reset the longEntry Order object to null if order was cancelled without any fill
                if (order.OrderState == OrderState.Cancelled && order.Filled == 0)
                {
                    longEntry = null;
                }
            }
             
            if (shortEntry != null && shortEntry == order)
            {  
                // Reset the shortEntry Order object to null if order was cancelled without any fill
                if (order.OrderState == OrderState.Cancelled && order.Filled == 0)
                {
                    shortEntry = null;
                }
            }
            
			// Set Target and Stop Order objects to null. Setting to null does not cancel, but we can expect OCO to cancel the orders.
            if ((targetLong != null && targetLong == order)
                ||(stopLossLong != null && stopLossLong == order)
                ||(targetShort != null && targetShort == order)
                ||(stopLossShort != null && stopLossShort == order)
                )
            {  
                if (order.OrderState == OrderState.Cancelled && order.Filled == 0)
                {
                    targetLong = stopLossLong = targetShort = stopLossShort = null;
                }
            }
			
			// Set running quantity to equal the sum of total filled entry orders, entry orders will be set back to null when the target/stop fill
			_runningQuantity = (longEntry != null ? longEntry.Filled : 0) - (shortEntry != null ? shortEntry.Filled : 0);
			
			if (_runningQuantity > 0)
			{
				_CalculatedPosition.Quantity = _runningQuantity;
				_CalculatedPosition.MarketPosition = MarketPosition.Long;
			}
			else if (_runningQuantity < 0)
			{
				_CalculatedPosition.Quantity = -_runningQuantity;
				_CalculatedPosition.MarketPosition = MarketPosition.Short;
			}
			else
			{
				_CalculatedPosition.Quantity = 0;
				_CalculatedPosition.MarketPosition = MarketPosition.Flat;
			}
			
			// Handle "OnExecutionUpdate" events based on Order fills and partial fills
			if (order.OrderState == OrderState.Filled || order.OrderState == OrderState.PartFilled)
			{
				InlineExecutionUpdate(order, order.AverageFillPrice, order.Filled, order.IsLong ? MarketPosition.Long : MarketPosition.Short, order.OrderId);
			}             
        }
	}
}
