// 
// Copyright (C) 2016, NinjaTrader LLC <www.ninjatrader.com>.
// NinjaTrader reserves the right to modify or overwrite this NinjaScript component with each release.
//
#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
#endregion

namespace NinjaTrader.NinjaScript.DrawingTools
{
	// I will not go into details on how these INotifyPropertyChanged members work
	// -> https://msdn.microsoft.com/en-us/library/system.componentmodel.inotifypropertychanged(v=vs.110).aspx
	public class SamplePropertyChangedDrawingTool : Line, INotifyPropertyChanged
	{
		// these are just two examples of properties you could track
		// ...  you could do what is demonstrated below with any property of the drawing tool
		private DrawingState drawingStateSpy;
		private bool selectedSpy;
		
		/// <summary>
		/// Used to track drawing state and notify when changed
		/// </summary>
		[Browsable(false)]
		public DrawingState DrawingStateSpy
		{
			get { return drawingStateSpy; }
			set
			{
				// only notify if value has actually changed (optional buffering))
				if (value == drawingStateSpy) return;
				drawingStateSpy = value;
				DoPropertyChanged("DrawingStateSpy");
			}
		}
		/// <summary>
		/// Used to track drawing selected bool and notify when changed
		/// </summary>
		[Browsable(false)]
		public bool IsSelectedSpy
		{
			get { return selectedSpy; }
			set
			{
				// only notify if value has actually changed (optional buffering))
				if (value == selectedSpy) return;
				selectedSpy = value;
				DoPropertyChanged("IsSelectedSpy");
			}
		}
		
		// this event will be subscribed from the indicator and updated anytime those properties call DoPropertyChanged
		public event PropertyChangedEventHandler PropertyChanged;
		
		// send the property name to the event so you can detect which property changed
		protected void DoPropertyChanged(string propertyName)
		{
			PropertyChangedEvent(new PropertyChangedEventArgs(propertyName));
		}
		
		// propagate drawing tools PropertyChanged to the indicator
		protected void PropertyChangedEvent(PropertyChangedEventArgs e)
		{
			if (PropertyChanged != null)
				PropertyChanged(this, e);
			IsLocked = true;
		}

		// set your "spy" properties where you see fit...
		// here we went with OnMouseDown which will update our "spy's" with the values set in the base's method
		public override void OnMouseDown(ChartControl chartControl, ChartPanel chartPanel, ChartScale chartScale,
			ChartAnchor dataPoint)
		{
			// don't forget to call dat base tho
			base.OnMouseDown(chartControl, chartPanel, chartScale, dataPoint);

			// Note: there is some optional buffering in the "spy" setters 
			// used to only notify when value has actually changed
			IsSelectedSpy = IsSelected;
			DrawingStateSpy = DrawingState;
			
		}	

		protected override void OnStateChange()
		{
			// don't forget to call dat base tho
			base.OnStateChange();
			if (State == State.SetDefaults)
			{
				Name = "Sample Property Changed";
			}
		}
	}
}
