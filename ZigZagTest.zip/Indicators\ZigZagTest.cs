#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class ZigZagTest : Indicator
	{
		private ZigZag	ZigZag1;
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Indicator here.";
				Name										= "ZigZagTest";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= true;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
			}
			else if (State == State.DataLoaded)
			{
				ZigZag1 = ZigZag(DeviationType.Points, 0.05, true);
			}
		}

		protected override void OnBarUpdate()
		{			
			if (CurrentBar < 100)
				return;
				
//			for(int k=1;k<5;k++)    /// fill the Arrays of Highs and Lows
//			{
//				if (ZigZag1.LowBar(0, k, 100) > 0)
//					Print(String.Format("{0} ZigZag.LowBar: {1} Low: {2}", k, ZigZag1.LowBar(0, k, 100), Low[ZigZag1.LowBar(0, k, 100)]));
//				if (ZigZag1.LowBar(0, k, 100) > 0)
//					Print(String.Format("{0} ZigZag.HighBar: {1} High: {2}", k, ZigZag1.HighBar(0, k, 100), High[ZigZag1.HighBar(0, k, 100)]));
//			}
		}
		
		protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
		{
			base.OnRender(chartControl, chartScale);
			
			ClearOutputWindow();
			
			TriggerCustomEvent(o =>
			{
				int idx = CurrentBar - ChartBars.ToIndex < 0 ? 0 : CurrentBar - ChartBars.ToIndex - 1;
				
				if (idx < 0) idx = 0;
				
				Print("Last Lows");
				
				for(int k=1;k<15;k++)
					if (ZigZag1.LowBar(idx, k, 100) > 0)
						Print(String.Format("{0} ZigZag.LowBar: {1} Price: {2}", k, ZigZag1.LowBar(idx, k, 100), Low[ZigZag1.LowBar(idx, k, 100)]));
				
				Print("");
					
				Print("Last Highs");
				for(int k=1;k<15;k++)
					if (ZigZag1.HighBar(idx, k, 100) > 0)
						Print(String.Format("{0} ZigZag.HighBar: {1} Price: {2}", k, ZigZag1.HighBar(idx, k, 100), High[ZigZag1.HighBar(idx, k, 100)]));
			}, null);
			
		}
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ZigZagTest[] cacheZigZagTest;
		public ZigZagTest ZigZagTest()
		{
			return ZigZagTest(Input);
		}

		public ZigZagTest ZigZagTest(ISeries<double> input)
		{
			if (cacheZigZagTest != null)
				for (int idx = 0; idx < cacheZigZagTest.Length; idx++)
					if (cacheZigZagTest[idx] != null &&  cacheZigZagTest[idx].EqualsInput(input))
						return cacheZigZagTest[idx];
			return CacheIndicator<ZigZagTest>(new ZigZagTest(), input, ref cacheZigZagTest);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ZigZagTest ZigZagTest()
		{
			return indicator.ZigZagTest(Input);
		}

		public Indicators.ZigZagTest ZigZagTest(ISeries<double> input )
		{
			return indicator.ZigZagTest(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ZigZagTest ZigZagTest()
		{
			return indicator.ZigZagTest(Input);
		}

		public Indicators.ZigZagTest ZigZagTest(ISeries<double> input )
		{
			return indicator.ZigZagTest(input);
		}
	}
}

#endregion
