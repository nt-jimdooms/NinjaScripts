//
// Copyright (C) 2021, NinjaTrader LLC <www.ninjatrader.com>.
// NinjaTrader reserves the right to modify or overwrite this NinjaScript component with each release.
//
#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds strategies in this folder and is required. Do not change it.
namespace NinjaTrader.NinjaScript.Strategies
{
	public class SampleMACrossoverDemo : Strategy
	{
		private SMA smaFast;
		private SMA smaSlow;
		
		private bool waitingToCancel = false;
		private bool waitingToReverseToLong = false;
		private bool waitingToReverseToShort = false;
		
		
		private Order entryOrder = null; // This variable holds an object representing our entry order
        private Order stopOrder = null; // This variable holds an object representing our stop loss order
        private Order targetOrder = null; // This variable holds an object representing our profit target order
        private int sumFilled = 0; // This variable tracks the quantities of each execution making up the entry order

		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description	= NinjaTrader.Custom.Resource.NinjaScriptStrategyDescriptionSampleMACrossOver;
				Name		= "SampleMACrossoverDemo";
				Fast		= 10;
				Slow		= 25;
				// This strategy has been designed to take advantage of performance gains in Strategy Analyzer optimizations
				// See the Help Guide for additional information
				IsInstantiatedOnEachOptimizationIteration = false;
			}
			else if (State == State.DataLoaded)
			{
				smaFast = SMA(Fast);
				smaSlow = SMA(Slow);

				smaFast.Plots[0].Brush = Brushes.Goldenrod;
				smaSlow.Plots[0].Brush = Brushes.SeaGreen;

				AddChartIndicator(smaFast);
				AddChartIndicator(smaSlow);
			}
			else if (State == State.Realtime)
            {
                // one time only, as we transition from historical
                // convert any old historical order object references
                // to the new live order submitted to the real-time account
                if (entryOrder != null)
                    entryOrder = GetRealtimeOrder(entryOrder);
                if (stopOrder != null)
                    stopOrder = GetRealtimeOrder(stopOrder);
                if (targetOrder != null)
                    targetOrder = GetRealtimeOrder(targetOrder);
            }
		}

		protected override void OnBarUpdate()
		{
			if (CurrentBar < BarsRequiredToTrade)
				return;

			if (Position.MarketPosition == MarketPosition.Flat)
			{
				if (CrossAbove(smaFast, smaSlow, 1))
				{
					EnterLong("LongEntry");
				}
				else if (CrossBelow(smaFast, smaSlow, 1))
				{
					EnterShort("ShortEntry");
				}
			}
			else if (Position.MarketPosition == MarketPosition.Long && !waitingToCancel)
			{
				if (CrossBelow(smaFast, smaSlow, 1))
				{
					waitingToCancel = true;
					waitingToReverseToShort = true;
					
					if (targetOrder != null)
						CancelOrder(targetOrder);
					if (stopOrder != null)
						CancelOrder(stopOrder);						
				}
			}
			else if (Position.MarketPosition == MarketPosition.Short && !waitingToCancel)
			{
				if (CrossAbove(smaFast, smaSlow, 1))
				{
					waitingToCancel = true;
					waitingToReverseToLong = true;
					
					if (targetOrder != null)
						CancelOrder(targetOrder);
					if (stopOrder != null)
						CancelOrder(stopOrder);
					
				}
			}
		}
		
		private void CheckReversal()
		{
			if (waitingToReverseToShort)
			{
				waitingToCancel = false;
				waitingToReverseToShort = false;
				ExitLong("Close Before Reversal", "LongEntry");
			}
			
			if (waitingToReverseToLong)
			{
				waitingToCancel = false;
				waitingToReverseToLong = false;
				ExitShort("Close Before Reversal", "ShortEntry");
			}
		}
	
		
		protected override void OnOrderUpdate(Order order, double limitPrice, double stopPrice, int quantity, int filled, double averageFillPrice, OrderState orderState, DateTime time, ErrorCode error, string nativeError)
		{
            if (order.Name == "LongEntry" || order.Name == "ShortEntry")
            {
                entryOrder = order;

                // Reset the entryOrder object to null if order was cancelled without any fill
                if (order.OrderState == OrderState.Cancelled && order.Filled == 0)
                {
                    entryOrder = null;
                    sumFilled = 0;
                }
            }
			else if (order.Name == "StopLong" || order.Name == "StopShort")
			{
				stopOrder = order;

                // Reset the stopOrder object to null if order was cancelled without any fill
                if (order.OrderState == OrderState.Cancelled && order.Filled == 0)
                {
                    stopOrder = null;
					
					// Check if Target and Stop are null (we set them to null when cancelled) and check if we want to reverse. This is when we can exit.
					
					CheckReversal();
                }
			}
			else if (order.Name == "TargetLong" || order.Name == "TargetShort")
			{
				targetOrder = order;

                // Check if Target and Stop are null (we set them to null when cancelled) and check if we want to reverse. This is when we can exit.
				
                if (order.OrderState == OrderState.Cancelled && order.Filled == 0)
                {
                    targetOrder = null;
					
					// Check if Target and Stop are null (we set them to null when cancelled) and check if we want to reverse. This is when we can exit.
					
					CheckReversal();
                }
			}
		}
		
		protected override void OnExecutionUpdate(Execution execution, string executionId, double price, int quantity, MarketPosition marketPosition, string orderId, DateTime time)
		{
			// This code handles the reversal. Instead of using a bool, we look for the specific signal name and check the direction of the execution to determine if it was a long or short trade.
			if (execution.Name == "Close Before Reversal")
			{
				if (execution.MarketPosition == MarketPosition.Long)
				{
					EnterLong("LongEntry");
				}
				else if (execution.MarketPosition == MarketPosition.Short)
				{
					EnterShort("ShortEntry");
				}
			}
			
			// This code submits the target and stop
			if (entryOrder != null && entryOrder == execution.Order)
            {
				double targetPrice = 0;
				double stopPrice = 0;
				
				string fromEntrySignalName = execution.Name;
				string targetSignalName = "";
				string stopSignalName = "";
				
				// Check if this was a long or short entry and give the correct price
				if (execution.MarketPosition == MarketPosition.Long)
				{
					stopPrice = execution.Order.AverageFillPrice - 40 * TickSize;
					targetPrice = execution.Order.AverageFillPrice + 80 * TickSize;
					
					targetSignalName = "TargetLong";
					stopSignalName = "StopLong";
				}
				else if (execution.MarketPosition == MarketPosition.Short)
				{
					stopPrice = execution.Order.AverageFillPrice + 40 * TickSize;
					targetPrice = execution.Order.AverageFillPrice - 80 * TickSize;
					
					targetSignalName = "TargetShort";
					stopSignalName = "StopShort";
				}
				
                if (execution.Order.OrderState == OrderState.Filled || execution.Order.OrderState == OrderState.PartFilled || (execution.Order.OrderState == OrderState.Cancelled && execution.Order.Filled > 0))
                {
                    // We sum the quantities of each execution making up the entry order
                    sumFilled += execution.Quantity;
					
					// Target and Stop for Long
					if (execution.MarketPosition == MarketPosition.Long)
					{
						// Submit exit orders for partial fills
	                    if (execution.Order.OrderState == OrderState.PartFilled)
	                    {
	                        stopOrder = ExitLongStopMarket(0, true, execution.Order.Filled, stopPrice, stopSignalName, fromEntrySignalName);
	                        targetOrder = ExitLongLimit(0, true, execution.Order.Filled, targetPrice, targetSignalName, fromEntrySignalName);
	                    }
	                    // Update our exit order quantities once orderstate turns to filled and we have seen execution quantities match order quantities
	                    else if (execution.Order.OrderState == OrderState.Filled && sumFilled == execution.Order.Filled)
	                    {
	                        // Stop-Loss order for OrderState.Filled
	                        stopOrder = ExitLongStopMarket(0, true, execution.Order.Filled, stopPrice, stopSignalName, fromEntrySignalName);
	                        targetOrder = ExitLongLimit(0, true, execution.Order.Filled, targetPrice, targetSignalName, fromEntrySignalName);
	                    }
					}
					// Target and Stop for Short
					else if (execution.MarketPosition == MarketPosition.Short)
					{
						// Submit exit orders for partial fills
	                    if (execution.Order.OrderState == OrderState.PartFilled)
	                    {
	                        stopOrder = ExitShortStopMarket(0, true, execution.Order.Filled, stopPrice, stopSignalName, fromEntrySignalName);
	                        targetOrder = ExitShortLimit(0, true, execution.Order.Filled, targetPrice, targetSignalName, fromEntrySignalName);
	                    }
	                    // Update our exit order quantities once orderstate turns to filled and we have seen execution quantities match order quantities
	                    else if (execution.Order.OrderState == OrderState.Filled && sumFilled == execution.Order.Filled)
	                    {
	                        // Stop-Loss order for OrderState.Filled
	                        stopOrder = ExitShortStopMarket(0, true, execution.Order.Filled, stopPrice, stopSignalName, fromEntrySignalName);
	                        targetOrder = ExitShortLimit(0, true, execution.Order.Filled, targetPrice, targetSignalName, fromEntrySignalName);
	                    }
					}

                    // Resets the entryOrder object and the sumFilled counter to null / 0 after the order has been filled
                    if (execution.Order.OrderState != OrderState.PartFilled && sumFilled == execution.Order.Filled)
                    {
                        entryOrder = null;
                        sumFilled = 0;
                    }
                }
            }
			
			// Reset our stop order and target orders' Order objects after our position is closed. (1st Entry)
            if ((stopOrder != null && stopOrder == execution.Order) || (targetOrder != null && targetOrder == execution.Order))
            {
                if (execution.Order.OrderState == OrderState.Filled || execution.Order.OrderState == OrderState.PartFilled)
                {
                    stopOrder = null;
                    targetOrder = null;
					
					waitingToCancel = false;
                }
            }
		}

		#region Properties
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Fast", GroupName = "NinjaScriptStrategyParameters", Order = 0)]
		public int Fast
		{ get; set; }

		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Slow", GroupName = "NinjaScriptStrategyParameters", Order = 1)]
		public int Slow
		{ get; set; }
		#endregion
	}
}
