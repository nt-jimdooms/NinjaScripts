#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class StrokeStyleTest : Indicator
	{
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Indicator here.";
				Name										= "StrokeStyleTest";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= true;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				MyDashStyleHelper = DashStyleHelper.Dot;
			}
			else if (State == State.Configure)
			{
			}
		}

		protected override void OnBarUpdate()
		{
			//Add your custom indicator logic here.
		}
		
		protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
		{
			SharpDX.Direct2D1.Brush myBrush = Brushes.RoyalBlue.ToDxBrush(RenderTarget);
			
			DrawLine(RenderTarget, myBrush, new SharpDX.Vector2(ChartPanel.X, ChartPanel.Y), new SharpDX.Vector2(ChartPanel.X + ChartPanel.W, ChartPanel.Y + ChartPanel.H), 10, MyDashStyleHelper);
			
			myBrush.Dispose();
		}
		
		public void DrawLine(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.Brush brush, SharpDX.Vector2 startPoint, SharpDX.Vector2 endPoint, float width, SharpDX.Direct2D1.StrokeStyle strokeStyle)
		{
			// Draw the line
			renderTarget.DrawLine(startPoint, endPoint, brush, width, strokeStyle);
		}
		
		public void DrawLine(SharpDX.Direct2D1.RenderTarget renderTarget, SharpDX.Direct2D1.Brush brush, SharpDX.Vector2 startPoint, SharpDX.Vector2 endPoint, float width, DashStyleHelper dashStyle)
		{
			// Create StrokeStyleProperties
			SharpDX.Direct2D1.StrokeStyleProperties ssProps = new SharpDX.Direct2D1.StrokeStyleProperties();
			
			switch (dashStyle)
			{
				case DashStyleHelper.Dash: 			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Dash; 		break;
				case DashStyleHelper.DashDot: 		ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.DashDot; 	break;
				case DashStyleHelper.DashDotDot:	ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.DashDotDot;	break;
				case DashStyleHelper.Dot:			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Dot;		break;
				case DashStyleHelper.Solid:			ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Solid;		break;
				default: 							ssProps.DashStyle = SharpDX.Direct2D1.DashStyle.Solid;		break;
			}
			
			// Create StrokeStyle from StrokeStyleProperties
			SharpDX.Direct2D1.StrokeStyle strokeStyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, ssProps);
			
			DrawLine(renderTarget, brush, startPoint, endPoint, width, strokeStyle);
			
			// StrokeStyle is device-independant and does not need to be Disposed after each OnRender() or OnRenderTargetChanged() call, but is for good housekeeping and garbage collection
			strokeStyle.Dispose();
			strokeStyle = null;
		}
		
		public DashStyleHelper MyDashStyleHelper
		{ get; set; }
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private StrokeStyleTest[] cacheStrokeStyleTest;
		public StrokeStyleTest StrokeStyleTest()
		{
			return StrokeStyleTest(Input);
		}

		public StrokeStyleTest StrokeStyleTest(ISeries<double> input)
		{
			if (cacheStrokeStyleTest != null)
				for (int idx = 0; idx < cacheStrokeStyleTest.Length; idx++)
					if (cacheStrokeStyleTest[idx] != null &&  cacheStrokeStyleTest[idx].EqualsInput(input))
						return cacheStrokeStyleTest[idx];
			return CacheIndicator<StrokeStyleTest>(new StrokeStyleTest(), input, ref cacheStrokeStyleTest);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.StrokeStyleTest StrokeStyleTest()
		{
			return indicator.StrokeStyleTest(Input);
		}

		public Indicators.StrokeStyleTest StrokeStyleTest(ISeries<double> input )
		{
			return indicator.StrokeStyleTest(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.StrokeStyleTest StrokeStyleTest()
		{
			return indicator.StrokeStyleTest(Input);
		}

		public Indicators.StrokeStyleTest StrokeStyleTest(ISeries<double> input )
		{
			return indicator.StrokeStyleTest(input);
		}
	}
}

#endregion
