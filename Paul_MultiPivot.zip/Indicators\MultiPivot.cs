#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
using SharpDX.DirectWrite;
using NinjaTrader.Core;
#endregion

public enum PivotType
{
	Camarilla,
	Fibonacci,
	FloorTrader,
	Woodies,
}

public enum DataType
{
	IntradayData,
	DailyBars
}
//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	// MultiPivots 10/31/17 version 1.0.0.
	//
	// Note: Calculate mode is set to OnEachTick however all processing is done on FirstTickOfBar, this is the 
	// same as calculate.OnBarClose but allows plots to match the current bar.  Leave as OneachTick for the best experience.
	// Note: with the addition of ticks/$, processing does occur on each tick.
	
	// Support/resistance option for real time only as it calculates on the current bar to set the rectangle on the pivot.
	
	
		public class MultiPivot : Indicator
	{
		#region Variables

		private bool	displayerror	=	false	;	//	Flag to display error message on screen and evntually remove	
		private bool 	[] Res						;	// Array of bools to indicate pivot is acting as support or resistance
		private double 	[] pivots					;	// Array to hold pivots, used for support/resistance.
		private string 	[] 	label					;	// Arrat to hold pivot labels for support/resistance rectangles
		private string  letterType 		= 	""		;	// String to hold pivot type letters		
		private int		sessionCount  	= 	0		;	//	used for Intraday data

		
		private double	_low, _high;
		
		private	double	yO				=	0.0		;	// 	Yesterdays Open
		private double 	yH 				= 	0.0		; 	//	Yesterdays High
		private double 	yL 				= 	0.0		; 	//	Yesterdays Low
		private double 	yC 				= 	0.0		; 	//	Yesterdays Close	
		
		private double [] myArray;
		private int [] lastTouch;
		private double	DollarsPerTick	= 	0.0		;
		
		private Brush	supportcolor	=	Brushes.Green;	//
		private Brush	resistancecolor	=	Brushes.Red	;	//	
		
		private PlotStyle [] MyPS;
		
		private System.Windows.TextAlignment myTextAlign;
		
		private	Gui.Tools.SimpleFont	textFontta;
		
		#endregion
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description					= @"Enter the description for your new custom Indicator here.";
				Name						= "MultiPivot";
				Calculate					= Calculate.OnEachTick;
				IsOverlay					= true;
				DisplayInDataBox			= true;
				DrawOnPricePanel			= true;
				DrawHorizontalGridLines		= true;
				DrawVerticalGridLines		= true;
				PaintPriceMarkers			= true;
				ScaleJustification			= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				IsAutoScale					= false;
				IsSuspendedWhileInactive	= false;
				
				AddPlot (new Stroke (Brushes.Gold, DashStyleHelper.Solid, 2), PlotStyle.Line, "R4");
				AddPlot (new Stroke (Brushes.Purple, DashStyleHelper.Solid, 1),  PlotStyle.Line, "R3");
				AddPlot (new Stroke (Brushes.Blue, DashStyleHelper.Solid, 1), PlotStyle.Line, "R2");
				AddPlot (new Stroke (Brushes.Green, DashStyleHelper.Solid, 1), PlotStyle.Line, "R1");
				AddPlot (new Stroke (Brushes.Goldenrod, DashStyleHelper.Solid, 1), PlotStyle.Line, "S1");
				AddPlot (new Stroke (Brushes.Firebrick, DashStyleHelper.Solid, 1), PlotStyle.Line, "S2");
				AddPlot (new Stroke (Brushes.DarkGray, DashStyleHelper.Solid, 1), PlotStyle.Line, "S3");
				AddPlot (new Stroke (Brushes.SteelBlue, DashStyleHelper.Solid, 2), PlotStyle.Line, "S4");
				AddPlot (new Stroke (Brushes.Red, DashStyleHelper.Solid, 2), PlotStyle.Line, "PP");
				AddPlot (new Stroke (Brushes.Green, DashStyleHelper.Solid, 1), PlotStyle.Line, "YH");
				AddPlot (new Stroke (Brushes.IndianRed, DashStyleHelper.Solid, 1), PlotStyle.Line, "YL");
				AddPlot (new Stroke (Brushes.SlateGray, DashStyleHelper.Solid, 1), PlotStyle.Line, "YC");			
												
				TextFontta 					= new Gui.Tools.SimpleFont("Arial", 10);
				MyPT						= PivotType.FloorTrader;
				MyDT						= DataType.DailyBars;					
				myTextAlign 				= System.Windows.TextAlignment.Center;
				SupresBox					= false;
				ConnectLines				= true;
				ShowPivotTypeLabel			= false;
				Opacity						= 50;
				BarsBack					= 1;
				ShowDistanceAway			= false;
				ShowDPT						= false;
				Clearance					= 2;
				ShowBasis					= false; // display basis data on left side of chart, when true
				BasisTextLocation			= TextPosition.BottomLeft;
			}
			else if (State == State.Configure)
			{
				Res 	= new bool [12] {true, true, true, true, true, true, true, true, true, true, true, true};
				pivots	= new double [12];
				label	= new string[12] {"R4", "R3", "R2", "R1", "PP", "S1", "S2", "S3", "S4", "YH", "YL", "YC"};
				MyPS	= new PlotStyle[12];
				AddDataSeries(BarsPeriodType.Day, 1);
				
				if (ShowDistanceAway)
				{
					myArray = new double [12];
					lastTouch = new int[12];
				}											
			}
			else if (State == State.DataLoaded)
			{
				for (int i = 0; i < 12; i++)
				{
					//if (Plots[i].PlotStyle == PlotStyle.Hash)
					{
						MyPS[i] = Plots[i].PlotStyle;
					}
					Print ("Plotstyle saved "+i+"  "+MyPS[i]);
				}
				
			  	if (!ConnectLines)
				{
					for (int i = 0; i < 12; i++)
					{
						Plots[i].PlotStyle = PlotStyle.Hash;
					}			
				}
				else 
				{
					for (int i = 0; i < 12; i++)
					{
						Plots[i].PlotStyle = MyPS[i];
					}						
				}				
				if (ShowDPT)
				{
					DollarsPerTick = Bars.Instrument.MasterInstrument.PointValue * TickSize;
				}
				
				if (ShowPivotTypeLabel)
				{
					if (MyPT == PivotType.Camarilla)
						letterType = " cp";
					else if (MyPT == PivotType.Fibonacci)
						letterType = " fib";
					else if (MyPT == PivotType.FloorTrader)
						letterType = " ftp";
					else
						letterType = " wp";
				}
				else
					letterType ="";		
				
				if (!BarsArray[0].BarsType.IsIntraday)
					Draw.TextFixed(this, "error1", "MultiPivot works on Intraday data only, please change chart bars to less than daily bars", 
					TextPosition.BottomRight);					
			}						
		}

		protected override void OnBarUpdate()
		{	
			if (BarsInProgress != 0 || CurrentBars[1] < 0) return; 	// return on 1st bar or if called by daily bars
			
			if (IsFirstTickOfBar)
			{
				if (Bars.IsFirstBarOfSession)
				{
					PivotsCalc();  									// Determine and set first bar pivots of the session
				}
				else  												// if not first bar of session then just copy previous pivot values on first tick of bar	
				{
					PP[0] = PP[1];
					YH[0] = YH[1];
					YL[0] = YL[1];
					YC[0] = YC[1];					
					R3[0] = R3[1];
					R2[0] = R2[1];
					R1[0] = R1[1];					
					S3[0] = S3[1];
					S2[0] = S2[1];
					S1[0] = S1[1];
					
					if (MyPT == PivotType.Camarilla || MyPT == PivotType.Woodies)
					{
						S4[0] = S4[1];
						R4[0] = R4[1];
					}
				}
			
				if (SupresBox)
					supres();										// draw S/R rectangles 				
			}//  only happens on first of bar
			
			
			
			// happens on each tick
			
			if (ShowDistanceAway)
			{
				myArray[0] = Instrument.MasterInstrument.RoundToTickSize((R4[0] - Close[0]) / TickSize) * (ShowDPT ? DollarsPerTick : 1);
				myArray[1] = Instrument.MasterInstrument.RoundToTickSize((R3[0] - Close[0]) / TickSize) * (ShowDPT ? DollarsPerTick : 1);
				myArray[2] = Instrument.MasterInstrument.RoundToTickSize((R2[0] - Close[0]) / TickSize) * (ShowDPT ? DollarsPerTick : 1);
				myArray[3] = Instrument.MasterInstrument.RoundToTickSize((R1[0] - Close[0]) / TickSize) * (ShowDPT ? DollarsPerTick : 1);
				myArray[4] = Instrument.MasterInstrument.RoundToTickSize((S1[0] - Close[0]) / TickSize) * (ShowDPT ? DollarsPerTick : 1);
				myArray[5] = Instrument.MasterInstrument.RoundToTickSize((S2[0] - Close[0]) / TickSize) * (ShowDPT ? DollarsPerTick : 1);
				myArray[6] = Instrument.MasterInstrument.RoundToTickSize((S3[0] - Close[0]) / TickSize) * (ShowDPT ? DollarsPerTick : 1);
				myArray[7] = Instrument.MasterInstrument.RoundToTickSize((S4[0] - Close[0]) / TickSize) * (ShowDPT ? DollarsPerTick : 1);
				myArray[8] = Instrument.MasterInstrument.RoundToTickSize((PP[0] - Close[0]) / TickSize) * (ShowDPT ? DollarsPerTick : 1);
				myArray[9] = Instrument.MasterInstrument.RoundToTickSize((YH[0] - Close[0]) / TickSize) * (ShowDPT ? DollarsPerTick : 1);
				myArray[10] = Instrument.MasterInstrument.RoundToTickSize((YL[0] - Close[0]) / TickSize) * (ShowDPT ? DollarsPerTick : 1);
				myArray[11] = Instrument.MasterInstrument.RoundToTickSize((YC[0] - Close[0]) / TickSize) * (ShowDPT ? DollarsPerTick : 1);
			}
		}  // end OnBarUpdate
		
		#region pivots calc
		
		private void PivotsCalc() 				// called on firtsbar of session && firstTick of that bar
		{
			if (MyDT == DataType.IntradayData)
			{	
				sessionCount++; 				// Increment session count
				
				if (sessionCount < 2) 
							return;  			// Don't try to process very first day
				
				//  Otherwise collect the prior day values needed.
				yO	= PriorDayOHLC().PriorOpen[0];
				yH 	= PriorDayOHLC().PriorHigh[0];
				yL	= PriorDayOHLC().PriorLow[0];
				yC	= PriorDayOHLC().PriorClose[0];  // will always be last close of session
			}
			else  // use daily bars
			{
				yO = Opens[1][0];
				yH = Highs[1][0];
				yL = Lows[1][0];
				yC = Closes[1][0];  // would be settlement price, depends on data feed										
			}	
			
			if (ShowBasis)
			{
				string myText = "MultiPivots: "+MyPT+" Pivot type."+"\nbased on:";
				if (MyDT == DataType.IntradayData)
				{
					Draw.TextFixed (this, "test", myText+" "+MyDT.ToString()+"\nYsO: "+yO+"\nYsH: "+yH+"\nYsL: "+yL+"\nYC: "+yC, BasisTextLocation,(ChartControl != null ? ChartControl.Properties.AxisPen.Brush : Brushes.DimGray), TextFontta, Brushes.Transparent, Brushes.Transparent, 10);
				}
				else
					Draw.TextFixed (this, "test", myText+" "+MyDT.ToString()+"\nYDO: "+yO+"\nYDH: "+yH+"\nYDL: "+yL+"\nYDC: "+yC, BasisTextLocation,(ChartControl != null ? ChartControl.Properties.AxisPen.Brush : Brushes.DimGray), TextFontta, Brushes.Transparent, Brushes.Transparent, 10);
			}
			else
				RemoveDrawObject("test");
					
			// first determine the pivots inputs and calculate the main pivot PP (for most pivots)
			PP[0] = ((yH+yL+yC)/3)	;	
			YH[0] = (yH)	;	//Plot Yesterdays High level
			YL[0] = (yL)	;	// Plot Yesterdays Low level
			YC[0] = (yC)	;	// Plot Yesterdays Close Level		
										
			switch (MyPT)
			{
				case PivotType.Camarilla:
				{
					R4[0]	= ((1.1*(yH-yL)/2)+yC);
					R3[0] 	= ((1.1*(yH-yL)/4)+yC);
					R2[0] 	= ((1.1*(yH-yL)/6)+yC);
					R1[0] 	= ((1.1*(yH-yL)/12)+yC);			
					S1[0] 	= (yC-(1.1*(yH-yL)/12));
					S2[0] 	= (yC-(1.1*(yH-yL)/6));
					S3[0] 	= (yC-(1.1*(yH-yL)/4));
					S4[0] 	= (yC-(1.1*(yH-yL)/2));	
					break;
				}	
				case PivotType.Fibonacci:
				{
					S1[0] 	= PP[0] - ((yH-yL) * 0.38200);
					S2[0] 	= PP[0] - ((yH-yL) * 0.61800);
					S3[0] 	= PP[0] - (yH-yL);
					R1[0] 	= PP[0] + ((yH-yL) * 0.38200);
					R2[0] 	= PP[0] + ((yH-yL) * 0.61800);
					R3[0] 	= PP[0] + (yH-yL);
					break;
				}						
				case PivotType.FloorTrader:
				{
					S1[0]	= 2 * PP[0] - yH;
					S2[0]	= PP[0] - (yH-yL);
					S3[0]	= PP[0] - 2 * (yH - yL);
					R1[0]	= 2 * PP[0] - yL;
					R2[0]	= PP[0] + (yH-yL);					
					R3[0]	= PP[0] + 2 * (yH - yL);	
					break;
				}
				case PivotType.Woodies:
				{
					PP[0] 	= ((yH +yL+ (Open[0] * 2)) / 4);  // set PP differently for woodies
					R1[0] 	= 2 * PP[0] - yL;
					R2[0] 	= PP[0] + (yH - yL);
					R3[0] 	= yH + 2 * (PP[0] - yL);
					R4[0] 	= R3[0] + (yH -yL);
					S1[0] 	= 2 * PP[0] - yH;
					S2[0] 	= PP[0] - (yH-yL);
					S3[0] 	= yL - 2 * (yH-PP[0]);
					S4[0] 	= S3[0] - (yH-yL);
					break;
					}
				} // end switch								
		}  // end private void PivotsCalc () 
		#endregion

		#region support-resistance option
		
		private void supres()
		{									
				if (Bars.IsFirstBarOfSession)  // populate array on first bar
				{
					pivots[0] 	= R4[0];
					pivots[1] 	= R3[0];
					pivots[2] 	= R2[0];
					pivots[3] 	= R1[0];
					pivots[4] 	= PP[0];
					pivots[5] 	= S1[0];
					pivots[6] 	= S2[0];
					pivots[7] 	= S3[0];
					pivots[8] 	= S4[0];
					pivots[9] 	= YH[0];
					pivots[10] 	= YL[0];
					pivots[11] 	= YC[0];
				}
				
				if (CurrentBar + 2 < Bars.Count) return;  // only process on realtime
				
				_low 	= Low[0];
				_high 	= High[0];
				
				for (int i = 0; i < 12; i++)  // loop to process all 12 pivots, determine if should be support or resistance
				{
					if (_low > pivots[i] + Clearance * TickSize)
					{
						Res[i] = false;
					}
					if (_high < pivots[i] - Clearance * TickSize)
					{
						Res[i] = true;
					}
					
					if ((MyPT == PivotType.Camarilla || MyPT == PivotType.Woodies) ||  
						((MyPT == PivotType.FloorTrader|| MyPT == PivotType.Fibonacci) && (i != 0 || i != 8)))
					{
						Draw.Rectangle(this, label[i], false, 0, (Res[i] ? pivots[i] + Clearance * TickSize : pivots[i] - Clearance * TickSize), 
							BarsBack , pivots[i], Brushes.Transparent, (Res[i] ? resistancecolor : supportcolor), Opacity);
					}
				}		
			} // privae void supres
		#endregion
		
		
		#region drawlabels
		
		protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
		{
			base.OnRender(chartControl, chartScale);
			// Set text to chart label color and font
			TextFormat	textFormat			= TextFontta.ToDirectWriteTextFormat();  //was: chartControl.Properties.LabelFont.ToDirectWriteTextFormat();
			
			// Loop through each Plot Values on the chart		
			for (int seriesCount = 0; seriesCount < Values.Length; seriesCount++)
			{
				if ((seriesCount == 0 || seriesCount == 7) && ((MyPT == PivotType.FloorTrader || MyPT == PivotType.Fibonacci)))
					continue;
				
				double	y					= -1;
				double	startX				= -1;
				int		lastBarPainted		= ChartBars.ToIndex-1;  
				Plot	plot				= Plots[seriesCount];

				startX		= chartControl.GetXByBarIndex(ChartBars, lastBarPainted + 2);  // +1 to place to the right of the plot
				double val	= Values[seriesCount].GetValueAt(lastBarPainted);  
				y			= chartScale.GetYByValue(val) - (textFormat.FontSize / 2)-1;  // adjust this value for vertical height.  -8 moves up 8 pixels
									
				Point startPoint	= new Point(startX, y);
				//TextLayout textLayout = new TextLayout(Globals.DirectWriteFactory, plot.Name+letterType, textFormat,textFormat.FontSize+80 , textFormat.FontSize);  // adjust 40 when using large fonts or longer text
				TextLayout textLayout = new TextLayout(Globals.DirectWriteFactory, plot.Name+letterType+(ShowDistanceAway ? "\n"+(ShowDPT ? "$ " : " ")
					+myArray[seriesCount].ToString("N0"):""), textFormat,textFormat.FontSize+80 , textFormat.FontSize); 
				
				RenderTarget.DrawTextLayout(startPoint.ToVector2(), textLayout, plot.BrushDX);
				textLayout.Dispose();
			}
			textFormat.Dispose();
		}	
		
		#endregion
			
		
		#region Properties

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> R4
		{
			get { return Values[0]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> R3
		{
			get { return Values[1]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> R2
		{
			get { return Values[2]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> R1
		{
			get { return Values[3]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> S1
		{
			get { return Values[4]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> S2
		{
			get { return Values[5]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> S3
		{
			get { return Values[6]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> S4
		{
			get { return Values[7]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> PP
		{
			get { return Values[8]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> YH
		{
			get { return Values[9]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> YL
		{
			get { return Values[10]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> YC
		{
			get { return Values[11]; }
		}
		
		
		[Display(Name	= "Show + or - 2 tic Box",
		Description		= "Set true to show colored sup/res box around pivots lines",
		GroupName		= "Support/Resistance",
		Order			= 1)]
		public bool SupresBox
		{ get; set; }	
		
		[Range(1, int.MaxValue)]
		[Display(Name = "Size of clearance window, ticks", 
		GroupName = "Support/Resistance", 
		Order = 2)]
		public int Clearance
		{ get; set; }		
		
		[Range(1, int.MaxValue)]
		[Display(Name = "Opacity of Sup/res box", 
		GroupName = "Support/Resistance", 
		Order = 4)]
		public int Opacity
		{ get; set; }
		
		[Range(1, int.MaxValue)]
		[Display(Name = "Bars back to show S/R", 
		GroupName = "Support/Resistance", 
		Order = 3)]
		public int BarsBack
		{ get; set; }
	
		
		[Display(Name	= "Pivot Label Font",
		Description		= "select font, style, size to display on chart",
		GroupName		= "Display",
		Order			= 1)]
		public Gui.Tools.SimpleFont TextFontta
		{ get; set; }
		
		[Display(Name="Show ticks away", Description=" Displays number of ticks the pivot is from current price", Order=2, GroupName="Display")]
		public bool ShowDistanceAway
		{ get; set; }	
		
		[Display(Name="Show $dollars away", Description=" Displays the dollars away the pivot is from current price", Order=3, GroupName="Display")]
		public bool ShowDPT
		{ get; set; }		
		
		[Display(Name="Connect session lines", Description="", Order=2, GroupName="Plot display")]
		public bool ConnectLines
		{ get; set; }	
		
		[NinjaScriptProperty]		
		[Display(Name="Pivot Type", Description="Select from the type of pivots to use", Order=1, GroupName="Pivots")]
		public PivotType MyPT
		{ get; set; }	
		
		[NinjaScriptProperty]
		[Display(Name="Pivot Data type", Description=" Use daily bars or intraday data", Order=2, GroupName="Pivots")]
		public DataType MyDT
		{ get; set; }	
		
		[Display(Name="Display basisdata/info on chart", Description="", Order=3, GroupName="Pivots")]
		public bool ShowBasis
		{ get; set; }	
		
		[Display(Name="Chart location for basis data/info", Description="", Order=4, GroupName="Pivots")]
		public TextPosition BasisTextLocation
		{ get; set; }			
		
		[Display(Name="Display pivot type label", Description=" When showing multiple pivot type, turn this on to distinguish between types", Order=3, GroupName="Plot display")]
		public bool ShowPivotTypeLabel
		{ get; set; }			
		
		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private MultiPivot[] cacheMultiPivot;
		public MultiPivot MultiPivot(PivotType myPT, DataType myDT)
		{
			return MultiPivot(Input, myPT, myDT);
		}

		public MultiPivot MultiPivot(ISeries<double> input, PivotType myPT, DataType myDT)
		{
			if (cacheMultiPivot != null)
				for (int idx = 0; idx < cacheMultiPivot.Length; idx++)
					if (cacheMultiPivot[idx] != null && cacheMultiPivot[idx].MyPT == myPT && cacheMultiPivot[idx].MyDT == myDT && cacheMultiPivot[idx].EqualsInput(input))
						return cacheMultiPivot[idx];
			return CacheIndicator<MultiPivot>(new MultiPivot(){ MyPT = myPT, MyDT = myDT }, input, ref cacheMultiPivot);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.MultiPivot MultiPivot(PivotType myPT, DataType myDT)
		{
			return indicator.MultiPivot(Input, myPT, myDT);
		}

		public Indicators.MultiPivot MultiPivot(ISeries<double> input , PivotType myPT, DataType myDT)
		{
			return indicator.MultiPivot(input, myPT, myDT);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.MultiPivot MultiPivot(PivotType myPT, DataType myDT)
		{
			return indicator.MultiPivot(Input, myPT, myDT);
		}

		public Indicators.MultiPivot MultiPivot(ISeries<double> input , PivotType myPT, DataType myDT)
		{
			return indicator.MultiPivot(input, myPT, myDT);
		}
	}
}

#endregion
