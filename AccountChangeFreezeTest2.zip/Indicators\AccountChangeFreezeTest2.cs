#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class AccountChangeFreezeTest2 : Indicator
	{
		private bool RunOnce;
		private int testCaseInput;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Indicator here.";
				Name										= "AccountChangeFreezeTest2";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				testCaseInput = 101;
				RunOnce = false;
			}
			else if (State == State.Configure)
			{
			}
		}

		protected override void OnBarUpdate()
		{
			if (!RunOnce && State == State.Realtime)
			{
				// Retrieve the account
				string accountName = "Sim101";
				Account account = null;
				if (string.IsNullOrEmpty(accountName) == false)
				   lock (Account.All) account = Account.All.FirstOrDefault(a => a.Name == accountName);
				if (account == null) { Print(string.Format("The specified account [{0}] could not be retrieved from the system.", accountName)); return; }


				// Find the first working entry order on the chart.
				Order order = null;
				for (int i = 0; i < account.Orders.Count; i++)
				{
				   order = account.Orders[i];
				   if (order.OrderType == OrderType.Limit && order.OrderState == OrderState.Working)
				   {
				      Print(string.Format("Found active order [{0}]", order.ToString()));
				      break;
				   }
				}
				if (order == null) { Print("No active entry Limit order could be found."); return; }


				// We found our order. Update the quantity and submit.
				//int newQuantity = int.Parse(testCaseInput);
				order.QuantityChanged = 0;


				Print(string.Format("Updating order [{0}] with new position size of {1} for account {2}", order.Id, testCaseInput, account.Name));
				try
				{
				   account.Change(new Order[] { order });
				}
				catch (Exception ex)
				{
				   Print(string.Format(" Exception occurred changing the order; Message: [{0}]", ex.Message));
				}
				finally
				{
				   Print("Change complete.");
				}
				RunOnce = true;
			
			}
		}
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private AccountChangeFreezeTest2[] cacheAccountChangeFreezeTest2;
		public AccountChangeFreezeTest2 AccountChangeFreezeTest2()
		{
			return AccountChangeFreezeTest2(Input);
		}

		public AccountChangeFreezeTest2 AccountChangeFreezeTest2(ISeries<double> input)
		{
			if (cacheAccountChangeFreezeTest2 != null)
				for (int idx = 0; idx < cacheAccountChangeFreezeTest2.Length; idx++)
					if (cacheAccountChangeFreezeTest2[idx] != null &&  cacheAccountChangeFreezeTest2[idx].EqualsInput(input))
						return cacheAccountChangeFreezeTest2[idx];
			return CacheIndicator<AccountChangeFreezeTest2>(new AccountChangeFreezeTest2(), input, ref cacheAccountChangeFreezeTest2);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.AccountChangeFreezeTest2 AccountChangeFreezeTest2()
		{
			return indicator.AccountChangeFreezeTest2(Input);
		}

		public Indicators.AccountChangeFreezeTest2 AccountChangeFreezeTest2(ISeries<double> input )
		{
			return indicator.AccountChangeFreezeTest2(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.AccountChangeFreezeTest2 AccountChangeFreezeTest2()
		{
			return indicator.AccountChangeFreezeTest2(Input);
		}

		public Indicators.AccountChangeFreezeTest2 AccountChangeFreezeTest2(ISeries<double> input )
		{
			return indicator.AccountChangeFreezeTest2(input);
		}
	}
}

#endregion
