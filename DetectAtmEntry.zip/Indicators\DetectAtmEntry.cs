#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class DetectAtmEntry : Indicator
	{
		private Account myAcct;
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Indicator here.";
				Name										= "DetectAtmEntry";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
			}
			else if (State == State.DataLoaded)
			{
				lock (Account.All)

              	myAcct = Account.All.FirstOrDefault(a => a.Name == "Sim101");
				myAcct.OrderUpdate += OnOrderUpdate;
			}
			else if (State == State.Terminated)
			{
				if(myAcct != null)
					myAcct.OrderUpdate -= OnOrderUpdate;
			}
		}

		protected override void OnBarUpdate()
		{
			//Add your custom indicator logic here.
		}
		
		private void OnOrderUpdate(object sender, OrderEventArgs e)
		{
			if (e.Order.Name == "Entry" && e.OrderState == OrderState.Filled)
			{
				AtmStrategy atmStrategy;
				StrategyBase stratbase;
				stratbase = e.Order.GetOwnerStrategy() ?? null;
				
				atmStrategy = stratbase as AtmStrategy;
				if (atmStrategy != null)
					Print("Entry order submitted for: " + atmStrategy.Template);
			}
		}
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private DetectAtmEntry[] cacheDetectAtmEntry;
		public DetectAtmEntry DetectAtmEntry()
		{
			return DetectAtmEntry(Input);
		}

		public DetectAtmEntry DetectAtmEntry(ISeries<double> input)
		{
			if (cacheDetectAtmEntry != null)
				for (int idx = 0; idx < cacheDetectAtmEntry.Length; idx++)
					if (cacheDetectAtmEntry[idx] != null &&  cacheDetectAtmEntry[idx].EqualsInput(input))
						return cacheDetectAtmEntry[idx];
			return CacheIndicator<DetectAtmEntry>(new DetectAtmEntry(), input, ref cacheDetectAtmEntry);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.DetectAtmEntry DetectAtmEntry()
		{
			return indicator.DetectAtmEntry(Input);
		}

		public Indicators.DetectAtmEntry DetectAtmEntry(ISeries<double> input )
		{
			return indicator.DetectAtmEntry(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.DetectAtmEntry DetectAtmEntry()
		{
			return indicator.DetectAtmEntry(Input);
		}

		public Indicators.DetectAtmEntry DetectAtmEntry(ISeries<double> input )
		{
			return indicator.DetectAtmEntry(input);
		}
	}
}

#endregion
