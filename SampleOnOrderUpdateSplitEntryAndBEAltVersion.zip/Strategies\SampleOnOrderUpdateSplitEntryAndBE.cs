// 
// Copyright (C) 2015, NinjaTrader LLC <www.ninjatrader.com>.
// NinjaTrader reserves the right to modify or overwrite this NinjaScript component with each release.
//
#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

// This namespace holds all strategies and is required. Do not change it.
namespace NinjaTrader.NinjaScript.Strategies
{
	public class SampleOnOrderUpdateSplitEntryAndBE : Strategy
	{
		private Order entryOrder						= null; // This variable holds an object representing our entry order
		private Order stopOrder                         = null; // This variable holds an object representing our stop loss order
		private Order targetOrder                       = null; // This variable holds an object representing our profit target order
		
		private Order entryOrder2						= null; // This variable holds an object representing our entry order
		private Order stopOrder2                        = null; // This variable holds an object representing our stop loss order
		private Order targetOrder2                      = null; // This variable holds an object representing our profit target order

		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description								= @"Sample Using OnOrderUpdate() and OnExecution() methods to submit protective orders";
				Name                                    = "SampleOnOrderUpdateSplitEntryAndBE";
				Calculate                               = Calculate.OnBarClose;
				EntriesPerDirection                     = 2;
				EntryHandling                           = EntryHandling.AllEntries;
				IsExitOnSessionCloseStrategy            = true;
				ExitOnSessionCloseSeconds               = 30;
				IsFillLimitOnTouch                      = false;
				MaximumBarsLookBack                     = MaximumBarsLookBack.TwoHundredFiftySix;
				OrderFillResolution                     = OrderFillResolution.Standard;
				Slippage                                = 0;
				StartBehavior                           = StartBehavior.WaitUntilFlat;
				TimeInForce                             = TimeInForce.Gtc;
				TraceOrders                             = true;
				RealtimeErrorHandling                   = RealtimeErrorHandling.StopCancelClose;
				StopTargetHandling                      = StopTargetHandling.PerEntryExecution;
				BarsRequiredToTrade                     = 20;
			}
			else if (State == State.Realtime)
			{
				// one time only, as we transition from historical
			    // convert any old historical order object references
			    // to the new live order submitted to the real-time account
			    if (entryOrder != null)
			        entryOrder = GetRealtimeOrder(entryOrder);
				if (stopOrder != null)
			        stopOrder = GetRealtimeOrder(stopOrder);
				if (targetOrder != null)
			        targetOrder = GetRealtimeOrder(targetOrder);
			}
		}

		protected override void OnBarUpdate()
		{
			//if (State == State.Historical)
			//	return;
			
			// Submit an entry market order if we currently don't have an entry order open and are past the BarsRequiredToTrade bars amount
			if (entryOrder == null && entryOrder2 == null && CurrentBar > BarsRequiredToTrade)
			{
				/* Enter Long. We will assign the resulting Order object to entryOrder in OnOrderUpdate() */
				EnterLong(1, "MyEntry");
				EnterLong(1, "MyEntry2");
			}
		}

		protected override void OnOrderUpdate(Order order, double limitPrice, double stopPrice, int quantity, int filled, double averageFillPrice, OrderState orderState, DateTime time, ErrorCode error, string nativeError)
		{
			// Handle entry orders here. The entryOrder object allows us to identify that the order that is calling the OnOrderUpdate() method is the entry order.
			// Assign entryOrder in OnOrderUpdate() to ensure the assignment occurs when expected.
            // This is more reliable than assigning Order objects in OnBarUpdate, as the assignment is not gauranteed to be complete if it is referenced immediately after submitting
			if (order.Name == "MyEntry")
    		{	
        		entryOrder = order;

                // Reset the entryOrder object to null if order was cancelled without any fill
                if (order.OrderState == OrderState.Cancelled && order.Filled == 0)
					entryOrder = null;
			}
			
			if (order.Name == "MyEntry2")
    		{	
        		entryOrder2 = order;

                // Reset the entryOrder object to null if order was cancelled without any fill
                if (order.OrderState == OrderState.Cancelled && order.Filled == 0)
					entryOrder2 = null;
			}
			
			if (order.Name == "MyTarget")
    		{	
        		targetOrder = order;

                if (order.OrderState == OrderState.Cancelled && order.Filled == 0)
					targetOrder = null;
			}
			
			if (order.Name == "MyStop")
    		{	
        		stopOrder = order;

                if (order.OrderState == OrderState.Cancelled && order.Filled == 0)
					stopOrder = null;
			}
			
			if (order.Name == "MyTarget2")
    		{	
        		targetOrder2 = order;

                if (order.OrderState == OrderState.Cancelled && order.Filled == 0)
					targetOrder2 = null;
			}
			
			if (order.Name == "MyStop2")
    		{	
        		stopOrder2 = order;

                if (order.OrderState == OrderState.Cancelled && order.Filled == 0)
					stopOrder2 = null;
			}
			
			if (order.Name == "Exit on session close" && order.OrderState == OrderState.Filled)
			{
				entryOrder = null;
				entryOrder2 = null;
				targetOrder = null;
				targetOrder2 = null;
				stopOrder = null;
				stopOrder2 = null;
			}
		}

		protected override void OnExecutionUpdate(Execution execution, string executionId, double price, int quantity, MarketPosition marketPosition, string orderId, DateTime time)
		{
			/* We advise monitoring OnExecution to trigger submission of stop/target orders instead of OnOrderUpdate() since OnExecution() is called after OnOrderUpdate()
			which ensures your strategy has received the execution which is used for internal signal tracking. */
			if (entryOrder != null && entryOrder == execution.Order)
			{
				if (execution.Order.OrderState == OrderState.Filled || execution.Order.OrderState == OrderState.PartFilled || (execution.Order.OrderState == OrderState.Cancelled && execution.Order.Filled > 0))
				{
					// Stop-Loss order 4 ticks below our entry price
					ExitLongStopMarket(0, true, execution.Order.Filled, execution.Order.AverageFillPrice - 4 * TickSize, "MyStop", "MyEntry");

					// Target order 8 ticks above our entry price
					ExitLongLimit(0, true, execution.Order.Filled, execution.Order.AverageFillPrice + 8 * TickSize, "MyTarget", "MyEntry");
				}
			}
			
			if (entryOrder2 != null && entryOrder2 == execution.Order)
			{
				if (execution.Order.OrderState == OrderState.Filled || execution.Order.OrderState == OrderState.PartFilled || (execution.Order.OrderState == OrderState.Cancelled && execution.Order.Filled > 0))
				{
					// Stop-Loss order 4 ticks below our entry price
					ExitLongStopMarket(0, true, execution.Order.Filled, execution.Order.AverageFillPrice - 100 * TickSize, "MyStop2", "MyEntry2");

					// Target order 8 ticks above our entry price
					ExitLongLimit(0, true, execution.Order.Filled, execution.Order.AverageFillPrice + 80 * TickSize, "MyTarget2", "MyEntry2");
				}
			}

			// Reset our stop order and target orders' Order objects after our position is closed.
			if ((stopOrder != null && stopOrder == execution.Order) || (targetOrder != null && targetOrder == execution.Order))
			{
				if (execution.Order.OrderState == OrderState.Filled || execution.Order.OrderState == OrderState.PartFilled)
				{
					// Move stopOrder2 to BreakEven
					if (targetOrder == execution.Order)
					{
						ExitLongStopMarket(0, true, entryOrder2.Quantity, entryOrder2.AverageFillPrice, "MyStop2", "MyEntry2");
					}
										
					stopOrder = null;
					targetOrder = null;
					entryOrder = null;
				}
			}
			
			// Reset our stop order and target orders' Order objects after our position is closed.
			if ((stopOrder2 != null && stopOrder2 == execution.Order) || (targetOrder2 != null && targetOrder2 == execution.Order))
			{
				if (execution.Order.OrderState == OrderState.Filled || execution.Order.OrderState == OrderState.PartFilled)
				{
					stopOrder2 = null;
					targetOrder2 = null;
					entryOrder2 = null;
				}
			}
		}

		protected override void OnPositionUpdate(Position position, double averagePrice, int quantity, MarketPosition marketPosition)
		{
			// Print our current position to the lower right hand corner of the chart
			Draw.TextFixed(this, "MyTag", position.ToString(), TextPosition.BottomRight, false, "");
		}

		#region Properties
		#endregion
	}
}