#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;

using System.Windows.Controls.WpfPropertyGrid;
using System.Windows.Markup;
#endregion

using NinjaTrader.NinjaScript.AddOns; // Our DXMediaBrush and DXHelper classes reside in the AddOn namespace.

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators.MyNamespace
{
	public class CustomFolderPickerTestIndicator : Indicator
	{			
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Demonstration script using the SharpDXHelper class for managed custom rendering";
				Name										= "CustomFolderPickerTestIndicator";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= true;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
			}
		}

		protected override void OnBarUpdate()
		{
			
		}
		
		[NinjaScriptProperty]
		[PropertyEditor("NinjaTrader.NinjaScript.Indicators.MyNamespace.CustomFolderPicker")]
		[Display(Name="Folder Path", Description="", Order=1)]
		public string FolderPath
		{ get; set; }
	}
	
	public class CustomFolderPicker : PropertyEditor
	{
		public CustomFolderPicker()
		{
			InlineTemplate = CreateTemplate();
		}

		DataTemplate CreateTemplate()
		{
			const string xamlTemplate = 
@"
<DataTemplate >
	  <Grid>
		<Grid.ColumnDefinitions>
		  <ColumnDefinition Width=""30""/>
          <ColumnDefinition Width=""*""/>
		</Grid.ColumnDefinitions>

	<Button Grid.Column=""0"" Content=""..."" Padding=""0"" Margin=""0""
			  HorizontalAlignment=""Stretch"" VerticalAlignment=""Stretch""
			  HorizontalContentAlignment=""Center""
			  MinWidth=""30""
			  Width=""30""
			  MaxWidth=""30""
			  Command =""pg:PropertyEditorCommands.ShowDialogEditor""
			  CommandParameter=""{Binding}"" />

		<TextBox Grid.Column=""1"" 
				 Text=""{Binding StringValue}"" 
				 ToolTip=""{Binding Value}""/>

	
	  </Grid>
	</DataTemplate>
";


			ParserContext context = new ParserContext();
			context.XmlnsDictionary.Add("", "http://schemas.microsoft.com/winfx/2006/xaml/presentation");
			context.XmlnsDictionary.Add("x", "http://schemas.microsoft.com/winfx/2006/xaml");
			context.XmlnsDictionary.Add("pg", "http://schemas.denisvuyka.wordpress.com/wpfpropertygrid");
			DataTemplate template = (DataTemplate)XamlReader.Parse(xamlTemplate, context);
			return template;
		}

		public override void ClearValue(PropertyItemValue propertyValue, IInputElement commandSource)
		{
			if (propertyValue == null || propertyValue.IsReadOnly)
			{
				return;
			}
			propertyValue.StringValue = string.Empty;
		}

		public override void ShowDialog(PropertyItemValue propertyValue, IInputElement commandSource)
		{
			PropertyGrid propGrid = commandSource as PropertyGrid;
			string lastPath = propertyValue.StringValue;
			if (propGrid == null) return;

			System.Windows.Forms.FolderBrowserDialog  folderBrowserDialog = new System.Windows.Forms.FolderBrowserDialog();
			folderBrowserDialog.ShowDialog();

			propertyValue.StringValue = folderBrowserDialog.SelectedPath != String.Empty ? folderBrowserDialog.SelectedPath : lastPath; // change this string and compile, the ui does not see this change
			propGrid.DoReload();
			propGrid.RaiseEvent(new PropertyValueChangedEventArgs(PropertyGrid.PropertyValueChangedEvent, propertyValue.ParentProperty, ""));
		}
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private MyNamespace.CustomFolderPickerTestIndicator[] cacheCustomFolderPickerTestIndicator;
		public MyNamespace.CustomFolderPickerTestIndicator CustomFolderPickerTestIndicator(string folderPath)
		{
			return CustomFolderPickerTestIndicator(Input, folderPath);
		}

		public MyNamespace.CustomFolderPickerTestIndicator CustomFolderPickerTestIndicator(ISeries<double> input, string folderPath)
		{
			if (cacheCustomFolderPickerTestIndicator != null)
				for (int idx = 0; idx < cacheCustomFolderPickerTestIndicator.Length; idx++)
					if (cacheCustomFolderPickerTestIndicator[idx] != null && cacheCustomFolderPickerTestIndicator[idx].FolderPath == folderPath && cacheCustomFolderPickerTestIndicator[idx].EqualsInput(input))
						return cacheCustomFolderPickerTestIndicator[idx];
			return CacheIndicator<MyNamespace.CustomFolderPickerTestIndicator>(new MyNamespace.CustomFolderPickerTestIndicator(){ FolderPath = folderPath }, input, ref cacheCustomFolderPickerTestIndicator);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.MyNamespace.CustomFolderPickerTestIndicator CustomFolderPickerTestIndicator(string folderPath)
		{
			return indicator.CustomFolderPickerTestIndicator(Input, folderPath);
		}

		public Indicators.MyNamespace.CustomFolderPickerTestIndicator CustomFolderPickerTestIndicator(ISeries<double> input , string folderPath)
		{
			return indicator.CustomFolderPickerTestIndicator(input, folderPath);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.MyNamespace.CustomFolderPickerTestIndicator CustomFolderPickerTestIndicator(string folderPath)
		{
			return indicator.CustomFolderPickerTestIndicator(Input, folderPath);
		}

		public Indicators.MyNamespace.CustomFolderPickerTestIndicator CustomFolderPickerTestIndicator(ISeries<double> input , string folderPath)
		{
			return indicator.CustomFolderPickerTestIndicator(input, folderPath);
		}
	}
}

#endregion
