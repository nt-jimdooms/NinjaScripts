#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class PropTest : Indicator
	{
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Indicator here.";
				Name										= "PropTest";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
			}
			else if (State == State.Configure)
			{
			}
		}

		protected override void OnBarUpdate()
		{
			//Add your custom indicator logic here.
		}
		
		
		private string _LongSignal;

		public class SoundOptions : TypeConverter
		{
			public override StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
			{
				if (context == null)
				{ return null; }

				System.Collections.ArrayList list = new System.Collections.ArrayList();
				System.IO.DirectoryInfo dir = new System.IO.DirectoryInfo(Core.Globals.InstallDir + @"\sounds\");
				System.IO.FileInfo[] files = dir.GetFiles("*.wav");

				foreach (System.IO.FileInfo file in files)
				{ list.Add(file.Name); }

				return new TypeConverter.StandardValuesCollection(list);
				}

				public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
				{ return true; }
			}

			[NinjaScriptProperty]
			[TypeConverter(typeof(SoundOptions))]
			[Display(Name = "Long Signal", Order = 1, GroupName = "Sounds", Description = "Assigned sound for LONG signals")]
			public string LongSignal {
			get { return _LongSignal; }
			set { _LongSignal = value; }
		}
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private PropTest[] cachePropTest;
		public PropTest PropTest(string longSignal)
		{
			return PropTest(Input, longSignal);
		}

		public PropTest PropTest(ISeries<double> input, string longSignal)
		{
			if (cachePropTest != null)
				for (int idx = 0; idx < cachePropTest.Length; idx++)
					if (cachePropTest[idx] != null && cachePropTest[idx].LongSignal == longSignal && cachePropTest[idx].EqualsInput(input))
						return cachePropTest[idx];
			return CacheIndicator<PropTest>(new PropTest(){ LongSignal = longSignal }, input, ref cachePropTest);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.PropTest PropTest(string longSignal)
		{
			return indicator.PropTest(Input, longSignal);
		}

		public Indicators.PropTest PropTest(ISeries<double> input , string longSignal)
		{
			return indicator.PropTest(input, longSignal);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.PropTest PropTest(string longSignal)
		{
			return indicator.PropTest(Input, longSignal);
		}

		public Indicators.PropTest PropTest(ISeries<double> input , string longSignal)
		{
			return indicator.PropTest(input, longSignal);
		}
	}
}

#endregion
