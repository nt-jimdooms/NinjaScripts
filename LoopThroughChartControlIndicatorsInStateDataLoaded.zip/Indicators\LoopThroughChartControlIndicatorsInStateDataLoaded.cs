#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class LoopThroughChartControlIndicatorsInStateDataLoaded : Indicator
	{
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Indicator here.";
				Name										= "LoopThroughChartControlIndicatorsInStateDataLoaded";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
			}
			else if (State == State.DataLoaded)
			{
				foreach (var window in NinjaTrader.Core.Globals.AllWindows)
			    {
			        //check if the found window is a Chart window, if not continue looking
			        if (!(window is NinjaTrader.Gui.Chart.Chart)) continue;

			        window.Dispatcher.InvokeAsync(new Action(() =>
			        {
			            //try to cast as a Chart, if it fails it will be null
			            var foundChart = window as NinjaTrader.Gui.Chart.Chart;
						
						// make sure we found a chart
			            if (foundChart == null) return;
						
						// make sure the found chart is the owner window
						if (foundChart != this.Owner as NinjaTrader.Gui.Chart.Chart) return;
						
						// Instantiate indicator collection
						ChartObjectCollection<NinjaTrader.Gui.NinjaScript.IndicatorRenderBase> indicatorCollection = foundChart.ActiveChartControl.Indicators;
						
						// Loop through indicators in collection
						foreach (Indicator indi in indicatorCollection)
							Print(indi.Name);
						
					}));
					
				}
			}
		}

		protected override void OnBarUpdate()
		{
			
		}
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private LoopThroughChartControlIndicatorsInStateDataLoaded[] cacheLoopThroughChartControlIndicatorsInStateDataLoaded;
		public LoopThroughChartControlIndicatorsInStateDataLoaded LoopThroughChartControlIndicatorsInStateDataLoaded()
		{
			return LoopThroughChartControlIndicatorsInStateDataLoaded(Input);
		}

		public LoopThroughChartControlIndicatorsInStateDataLoaded LoopThroughChartControlIndicatorsInStateDataLoaded(ISeries<double> input)
		{
			if (cacheLoopThroughChartControlIndicatorsInStateDataLoaded != null)
				for (int idx = 0; idx < cacheLoopThroughChartControlIndicatorsInStateDataLoaded.Length; idx++)
					if (cacheLoopThroughChartControlIndicatorsInStateDataLoaded[idx] != null &&  cacheLoopThroughChartControlIndicatorsInStateDataLoaded[idx].EqualsInput(input))
						return cacheLoopThroughChartControlIndicatorsInStateDataLoaded[idx];
			return CacheIndicator<LoopThroughChartControlIndicatorsInStateDataLoaded>(new LoopThroughChartControlIndicatorsInStateDataLoaded(), input, ref cacheLoopThroughChartControlIndicatorsInStateDataLoaded);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.LoopThroughChartControlIndicatorsInStateDataLoaded LoopThroughChartControlIndicatorsInStateDataLoaded()
		{
			return indicator.LoopThroughChartControlIndicatorsInStateDataLoaded(Input);
		}

		public Indicators.LoopThroughChartControlIndicatorsInStateDataLoaded LoopThroughChartControlIndicatorsInStateDataLoaded(ISeries<double> input )
		{
			return indicator.LoopThroughChartControlIndicatorsInStateDataLoaded(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.LoopThroughChartControlIndicatorsInStateDataLoaded LoopThroughChartControlIndicatorsInStateDataLoaded()
		{
			return indicator.LoopThroughChartControlIndicatorsInStateDataLoaded(Input);
		}

		public Indicators.LoopThroughChartControlIndicatorsInStateDataLoaded LoopThroughChartControlIndicatorsInStateDataLoaded(ISeries<double> input )
		{
			return indicator.LoopThroughChartControlIndicatorsInStateDataLoaded(input);
		}
	}
}

#endregion
