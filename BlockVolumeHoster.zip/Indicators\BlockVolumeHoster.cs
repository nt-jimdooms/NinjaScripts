#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class BlockVolumeHoster : Indicator
	{
		private BlockVolume BlockVolume1;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Indicator here.";
				Name										= "BlockVolumeHoster";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
			}
			else if (State == State.Configure)
			{
				AddDataSeries(BarsPeriodType.Tick, 1);
			}
			else if (State == State.DataLoaded)
			{
				BlockVolume1 = BlockVolume(5, CountType.Volume);
			}
		}

		protected override void OnBarUpdate()
		{
			if (BarsInProgress == 0)
			{
			      // Print the close of the cumulative delta bar with a delta type of Bid Ask and with a Session period
			      Print("Delta Close: " + BlockVolume1.Value[0]);
			}
			else if (BarsInProgress == 1)
			{
			      // We have to update the secondary series of the hosted indicator to make sure the values we get in BarsInProgress == 0 are in sync
			      BlockVolume1.Update(BlockVolume1.BarsArray[1].Count - 1, 1);
			}
		}
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private BlockVolumeHoster[] cacheBlockVolumeHoster;
		public BlockVolumeHoster BlockVolumeHoster()
		{
			return BlockVolumeHoster(Input);
		}

		public BlockVolumeHoster BlockVolumeHoster(ISeries<double> input)
		{
			if (cacheBlockVolumeHoster != null)
				for (int idx = 0; idx < cacheBlockVolumeHoster.Length; idx++)
					if (cacheBlockVolumeHoster[idx] != null &&  cacheBlockVolumeHoster[idx].EqualsInput(input))
						return cacheBlockVolumeHoster[idx];
			return CacheIndicator<BlockVolumeHoster>(new BlockVolumeHoster(), input, ref cacheBlockVolumeHoster);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.BlockVolumeHoster BlockVolumeHoster()
		{
			return indicator.BlockVolumeHoster(Input);
		}

		public Indicators.BlockVolumeHoster BlockVolumeHoster(ISeries<double> input )
		{
			return indicator.BlockVolumeHoster(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.BlockVolumeHoster BlockVolumeHoster()
		{
			return indicator.BlockVolumeHoster(Input);
		}

		public Indicators.BlockVolumeHoster BlockVolumeHoster(ISeries<double> input )
		{
			return indicator.BlockVolumeHoster(input);
		}
	}
}

#endregion
