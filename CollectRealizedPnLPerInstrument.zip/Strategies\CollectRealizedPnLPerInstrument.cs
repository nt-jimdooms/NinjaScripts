#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies
{
	public class CollectRealizedPnLPerInstrument : Strategy
	{
		private double pnlES, pnlCL, pnlNQ;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Strategy here.";
				Name										= "CollectRealizedPnLPerInstrument";
				Calculate									= Calculate.OnBarClose;
				EntriesPerDirection							= 3;
				EntryHandling								= EntryHandling.AllEntries;
				IsExitOnSessionCloseStrategy				= true;
				ExitOnSessionCloseSeconds					= 30;
				IsFillLimitOnTouch							= false;
				MaximumBarsLookBack							= MaximumBarsLookBack.TwoHundredFiftySix;
				OrderFillResolution							= OrderFillResolution.Standard;
				Slippage									= 0;
				StartBehavior								= StartBehavior.WaitUntilFlat;
				TimeInForce									= TimeInForce.Gtc;
				TraceOrders									= false;
				RealtimeErrorHandling						= RealtimeErrorHandling.StopCancelClose;
				StopTargetHandling							= StopTargetHandling.PerEntryExecution;
				BarsRequiredToTrade							= 20;
				// Disable this property for performance gains in Strategy Analyzer optimizations
				// See the Help Guide for additional information
				IsInstantiatedOnEachOptimizationIteration	= true;
			}
			else if (State == State.Configure)
			{
				AddDataSeries("ES 03-20");
				AddDataSeries("CL 02-20");
				AddDataSeries("NQ 03-20");
				
				SetProfitTarget(CalculationMode.Ticks, 10);
				SetStopLoss(CalculationMode.Ticks, 10);
			}
		}

		protected override void OnBarUpdate()
		{
			if (BarsInProgress == 0)
			{
				pnlES = pnlCL = pnlNQ = 0;
				
				foreach (Trade trade in SystemPerformance.AllTrades)
				{
					if (trade.Entry.Instrument.FullName == BarsArray[1].Instrument.FullName)
						pnlES += trade.ProfitCurrency;
						
					if (trade.Entry.Instrument.FullName == BarsArray[2].Instrument.FullName)
						pnlCL += trade.ProfitCurrency;
					
					if (trade.Entry.Instrument.FullName == BarsArray[3].Instrument.FullName)
						pnlNQ += trade.ProfitCurrency;
				}
				ClearOutputWindow();
				Print(String.Format("PnL ES: {0} PnL CL: {1} PnL NQ: {2} Total: {3}", pnlES, pnlCL, pnlNQ, (pnlES + pnlCL + pnlNQ))); 
			}
			else if (BarsInProgress == 1)
			{
				if (Position.MarketPosition == MarketPosition.Flat)
					EnterLong();
			}
			else if (BarsInProgress == 2)
			{
				if (Position.MarketPosition == MarketPosition.Flat)
					EnterLong();
			}
			else if (BarsInProgress == 3)
			{
				if (Position.MarketPosition == MarketPosition.Flat)
					EnterLong();
			}
		}
	}
}
