#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class IsSuspendedWhileInactiveTestFalse : Indicator
	{
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Indicator here.";
				Name										= "IsSuspendedWhileInactiveTestFalse";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= false;
				AddPlot(Brushes.White, "MyPlot");
			}
			else if (State == State.Configure)
			{
			}
		}

		protected override void OnBarUpdate()
		{
			Value[0] = Close[0];
			
			if (State == State.Historical)
				return;
			
			if (CurrentBar == Bars.Count - 2)
				Print("Active Bar Update");
			else
				Print("Catching up to Bars.Count");
		}
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private IsSuspendedWhileInactiveTestFalse[] cacheIsSuspendedWhileInactiveTestFalse;
		public IsSuspendedWhileInactiveTestFalse IsSuspendedWhileInactiveTestFalse()
		{
			return IsSuspendedWhileInactiveTestFalse(Input);
		}

		public IsSuspendedWhileInactiveTestFalse IsSuspendedWhileInactiveTestFalse(ISeries<double> input)
		{
			if (cacheIsSuspendedWhileInactiveTestFalse != null)
				for (int idx = 0; idx < cacheIsSuspendedWhileInactiveTestFalse.Length; idx++)
					if (cacheIsSuspendedWhileInactiveTestFalse[idx] != null &&  cacheIsSuspendedWhileInactiveTestFalse[idx].EqualsInput(input))
						return cacheIsSuspendedWhileInactiveTestFalse[idx];
			return CacheIndicator<IsSuspendedWhileInactiveTestFalse>(new IsSuspendedWhileInactiveTestFalse(), input, ref cacheIsSuspendedWhileInactiveTestFalse);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.IsSuspendedWhileInactiveTestFalse IsSuspendedWhileInactiveTestFalse()
		{
			return indicator.IsSuspendedWhileInactiveTestFalse(Input);
		}

		public Indicators.IsSuspendedWhileInactiveTestFalse IsSuspendedWhileInactiveTestFalse(ISeries<double> input )
		{
			return indicator.IsSuspendedWhileInactiveTestFalse(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.IsSuspendedWhileInactiveTestFalse IsSuspendedWhileInactiveTestFalse()
		{
			return indicator.IsSuspendedWhileInactiveTestFalse(Input);
		}

		public Indicators.IsSuspendedWhileInactiveTestFalse IsSuspendedWhileInactiveTestFalse(ISeries<double> input )
		{
			return indicator.IsSuspendedWhileInactiveTestFalse(input);
		}
	}
}

#endregion
