#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class HighlightChartPanels : Indicator
	{
		private List<double> Xs, Ys, Hs, Ws;
		private int ChartPanelHighlighted = int.MaxValue;
		
		ControlTemplate 		template;
		FrameworkElementFactory borderElement, borderElement2;
		Style 					borderStyle1, borderStyle2;
		Trigger 				trigger1;
		Setter					setter1;
		DataTrigger 			dt1;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Indicator here.";
				Name										= "HighlightChartPanels";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
			}
			else if (State == State.Realtime)
			{
				Xs = new List<double>();
				Ys = new List<double>();
				Hs = new List<double>();
				Ws = new List<double>();
				
				if (ChartControl != null)
				{
					ChartControl.MouseMove += new System.Windows.Input.MouseEventHandler (ChartControl_MouseMove);
				}
				
				foreach (var window in NinjaTrader.Core.Globals.AllWindows)
				{
					//check if the found window is a Chart window, if not continue looking
					if (!(window is NinjaTrader.Gui.Chart.Chart)) continue;

					window.Dispatcher.BeginInvoke(new Action(() =>
					{
						//try to cast as a Chart, if it fails it will be null
						var foundChart = window as NinjaTrader.Gui.Chart.Chart; 
						if (foundChart == null) return;
						
						foreach (NinjaTrader.Gui.Chart.ChartPanel panel in foundChart.ActiveChartControl.ChartPanels)
						{
							template 											  = new ControlTemplate(typeof(ChartPanel));

							borderElement 										  = new FrameworkElementFactory(typeof(Border));
							
							borderElement.SetValue(Border.NameProperty, 			"outerBorder");
							borderElement.SetValue(Border.BackgroundProperty, 		Brushes.Transparent);
							borderElement.SetValue(Border.BorderThicknessProperty, 	new Thickness(3));
							borderElement.SetValue(Border.CornerRadiusProperty, 	new CornerRadius(0));
							borderElement.SetValue(Border.MarginProperty, 			new Thickness(0));

							borderStyle1 										  = new Style(typeof(Border));
							trigger1 											  = new Trigger() { Property = Border.IsMouseOverProperty, Value = true };
							setter1 											  = new Setter()  { Property = Border.BorderBrushProperty, Value = Brushes.Gold };
							trigger1.Setters.Add(setter1);
							borderStyle1.Triggers.Add(trigger1);
							borderElement.SetValue(Border.StyleProperty, borderStyle1);


							borderElement2 										  = new FrameworkElementFactory(typeof(Border));

							borderStyle2 										  = new Style(typeof(Border));
							DataTrigger dt1 									  = new DataTrigger() { Binding = new Binding("IsMouseOver") { ElementName = "outerBorder" }, Value=true };
							borderStyle2.Triggers.Add(dt1);
							borderElement2.SetValue(Border.StyleProperty, borderStyle2);
							
							
							borderElement.AppendChild(borderElement2);
							template.VisualTree = borderElement;
							panel.Template = template;
							
							
							//Print("X: " + panel.X + " Y: " + panel.Y + " W: " + panel.W + " H: " + panel.H);
							Xs.Add((double)panel.X);
							Ys.Add((double)panel.Y);
							Hs.Add((double)panel.H);
							Ws.Add((double)panel.W);
						}
					}));
				}
			}
			else if (State == State.Terminated)
			{
				if (ChartControl != null)
				{
					ChartControl.MouseMove -= new System.Windows.Input.MouseEventHandler (ChartControl_MouseMove);
				}
			}
		}
		
		void ChartControl_MouseMove (object sender, System.Windows.Input.MouseEventArgs e)
		{
			if(ChartControl == null)
				return;
			
			double curPosX = e.GetPosition(ChartControl).X;
			double curPosY = e.GetPosition(ChartControl).Y;
			
			for(int i = 0; i < Xs.Count; i++)
			{				
				if(curPosY > Ys[i] && curPosY < Ys[i] + Hs[i] && ChartPanelHighlighted != i)
				{
					ChartPanelHighlighted = i;
					Print(ChartPanelHighlighted);
				}
			}
		}

		protected override void OnBarUpdate()
		{
			//Add your custom indicator logic here.
		}
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private HighlightChartPanels[] cacheHighlightChartPanels;
		public HighlightChartPanels HighlightChartPanels()
		{
			return HighlightChartPanels(Input);
		}

		public HighlightChartPanels HighlightChartPanels(ISeries<double> input)
		{
			if (cacheHighlightChartPanels != null)
				for (int idx = 0; idx < cacheHighlightChartPanels.Length; idx++)
					if (cacheHighlightChartPanels[idx] != null &&  cacheHighlightChartPanels[idx].EqualsInput(input))
						return cacheHighlightChartPanels[idx];
			return CacheIndicator<HighlightChartPanels>(new HighlightChartPanels(), input, ref cacheHighlightChartPanels);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.HighlightChartPanels HighlightChartPanels()
		{
			return indicator.HighlightChartPanels(Input);
		}

		public Indicators.HighlightChartPanels HighlightChartPanels(ISeries<double> input )
		{
			return indicator.HighlightChartPanels(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.HighlightChartPanels HighlightChartPanels()
		{
			return indicator.HighlightChartPanels(Input);
		}

		public Indicators.HighlightChartPanels HighlightChartPanels(ISeries<double> input )
		{
			return indicator.HighlightChartPanels(input);
		}
	}
}

#endregion
