#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class CaptureDrawObjectsPlot : Indicator
	{
		private Dictionary<DrawingTool, double> CapturedDrawObjects;
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description							= @"Capture DrawObjects when the script sees a relavant click on the ChartPanel";
				Name								= "CaptureDrawObjectsPlot";
				Calculate							= Calculate.OnPriceChange;
				IsOverlay							= true;
				DisplayInDataBox					= false;
				DrawOnPricePanel					= true;
				ScaleJustification					= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				AddPlot(Brushes.Orange, "MyPlot");
			}
			else if (State == State.Historical)
			{
				Plots[0].PlotStyle = PlotStyle.HLine;
				CapturedDrawObjects = new Dictionary<DrawingTool, double>();
				
				if (ChartControl != null)
					ChartPanel.MouseLeftButtonDown += MouseClicked;
			}
			else if (State == State.Terminated)
			{
				if (ChartControl != null)
					ChartPanel.MouseLeftButtonDown -= MouseClicked;
			}
		}

		protected override void OnBarUpdate() { }
				
		protected void MouseClicked(object sender, MouseButtonEventArgs e)
		{			
			foreach (dynamic draw in DrawObjects.ToList())
			{
				CapturedDrawObjects.Clear();
				
			    if (draw.ToString().Equals("NinjaTrader.NinjaScript.DrawingTools.HorizontalLine"))
			    {
			       if (draw != null)
			            foreach (dynamic anchor in draw.Anchors)
						{
							if (!CapturedDrawObjects.ContainsKey(draw))
							{
								TriggerCustomEvent(o =>
    							{
									Values[0][1] = anchor.Price;
									Values[0][0] = anchor.Price;
									Plots[0].Width = draw.Stroke.Width;
									draw.ZOrderType = DrawingToolZOrder.AlwaysDrawnFirst;
								}, null);
							}
						}
			    }
			}
			
			foreach (dynamic draw in CapturedDrawObjects.Keys)
			{
				Print(CapturedDrawObjects[draw]);
			}
			
			e.Handled = true;
		}
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private CaptureDrawObjectsPlot[] cacheCaptureDrawObjectsPlot;
		public CaptureDrawObjectsPlot CaptureDrawObjectsPlot()
		{
			return CaptureDrawObjectsPlot(Input);
		}

		public CaptureDrawObjectsPlot CaptureDrawObjectsPlot(ISeries<double> input)
		{
			if (cacheCaptureDrawObjectsPlot != null)
				for (int idx = 0; idx < cacheCaptureDrawObjectsPlot.Length; idx++)
					if (cacheCaptureDrawObjectsPlot[idx] != null &&  cacheCaptureDrawObjectsPlot[idx].EqualsInput(input))
						return cacheCaptureDrawObjectsPlot[idx];
			return CacheIndicator<CaptureDrawObjectsPlot>(new CaptureDrawObjectsPlot(), input, ref cacheCaptureDrawObjectsPlot);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.CaptureDrawObjectsPlot CaptureDrawObjectsPlot()
		{
			return indicator.CaptureDrawObjectsPlot(Input);
		}

		public Indicators.CaptureDrawObjectsPlot CaptureDrawObjectsPlot(ISeries<double> input )
		{
			return indicator.CaptureDrawObjectsPlot(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.CaptureDrawObjectsPlot CaptureDrawObjectsPlot()
		{
			return indicator.CaptureDrawObjectsPlot(Input);
		}

		public Indicators.CaptureDrawObjectsPlot CaptureDrawObjectsPlot(ISeries<double> input )
		{
			return indicator.CaptureDrawObjectsPlot(input);
		}
	}
}

#endregion
