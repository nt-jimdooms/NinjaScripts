#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class GlobalLineTest : Indicator
	{
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Indicator here.";
				Name										= "GlobalLineTest";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
			}
			else if (State == State.Configure)
			{
			}
		}

		protected override void OnBarUpdate()
		{
			Draw.Line(this, "MyGlobalLineTag", true, CurrentBar, Close[0], 0, Close[0], true, null);
		}
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private GlobalLineTest[] cacheGlobalLineTest;
		public GlobalLineTest GlobalLineTest()
		{
			return GlobalLineTest(Input);
		}

		public GlobalLineTest GlobalLineTest(ISeries<double> input)
		{
			if (cacheGlobalLineTest != null)
				for (int idx = 0; idx < cacheGlobalLineTest.Length; idx++)
					if (cacheGlobalLineTest[idx] != null &&  cacheGlobalLineTest[idx].EqualsInput(input))
						return cacheGlobalLineTest[idx];
			return CacheIndicator<GlobalLineTest>(new GlobalLineTest(), input, ref cacheGlobalLineTest);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.GlobalLineTest GlobalLineTest()
		{
			return indicator.GlobalLineTest(Input);
		}

		public Indicators.GlobalLineTest GlobalLineTest(ISeries<double> input )
		{
			return indicator.GlobalLineTest(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.GlobalLineTest GlobalLineTest()
		{
			return indicator.GlobalLineTest(Input);
		}

		public Indicators.GlobalLineTest GlobalLineTest(ISeries<double> input )
		{
			return indicator.GlobalLineTest(input);
		}
	}
}

#endregion
