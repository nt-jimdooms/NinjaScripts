//
// Copyright (C) 2020, NinjaTrader LLC <www.ninjatrader.com>
// NinjaTrader reserves the right to modify or overwrite this NinjaScript component
// Coded by NinjaTrader_Jesse
//
#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Linq;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Code;
using NinjaTrader.Data;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript;
#endregion

//This namespace holds GUI items and is required.
namespace NinjaTrader.Gui.NinjaScript
{
	//A custom object for use with the DataGrid
	public class MyCustomObject
	{
		public string Name { get; set; }
	}

	// A viewmodel is used for binding, this also allows you to implement INotifyPropertyChanged for live updates to the UI when data changes.
	public class MyCustomViewModel : INotifyPropertyChanged
	{
		private string testText;

		public ICommand TestCommand { get; set; }

		public MyCustomViewModel()
		{
			TestText = "Bound Text";
			TestCommand = new RelayCommand(Button_Click);
		}

		public string TestText
		{
			get { return testText; }
			set
			{
				testText = value;
				OnPropertyChanged();
			}
		}

		private void Button_Click(object sender)
		{
			TestText = "Clicked " + sender;
			Output.Process("Clicked " + sender.ToString(), PrintTo.OutputTab1);
		}

		public event PropertyChangedEventHandler PropertyChanged;

		protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
		{
			var handler = PropertyChanged;
			if (handler != null)
				handler(this, new PropertyChangedEventArgs(propertyName));
		}
	}

	public class MVVMExampleAddonTabPage : NTTabPage
	{
		public MVVMExampleAddonTabPage()
		{
			MyCustomViewModel viewModel	= new MyCustomViewModel();
			DataContext					= viewModel;
			Content						= LoadXAML();
			TabName						= "@INSTRUMENT_FULL";
		}

		private DependencyObject LoadXAML()
		{
			try
			{
				using (System.IO.Stream assemblyResourceStream = GetManifestResourceStream("AddOns.WindowFrameworkExamples.MVVMAddonExampleTabPage.xaml"))
				{
					if (assemblyResourceStream == null)
						return null;

					System.IO.StreamReader streamReader	= new System.IO.StreamReader(assemblyResourceStream);
					Page page							= System.Windows.Markup.XamlReader.Load(streamReader.BaseStream) as Page;
					FrameworkElement pageContent		= null;

					if (page != null)
					{
						pageContent	= page.Content as FrameworkElement;

						if (pageContent != null)
						{
							DataGrid testDataGrid = LogicalTreeHelper.FindLogicalNode(pageContent, "TestDataGrid") as DataGrid;
							if (testDataGrid != null)
							{
								testDataGrid.Items.Add(new MyCustomObject { Name = "Test1" });
								testDataGrid.Items.Add(new MyCustomObject { Name = "Test2" });
								testDataGrid.Items.Add(new MyCustomObject { Name = "Test3" });
								testDataGrid.Items.Add(new MyCustomObject { Name = "Test4" });
								testDataGrid.Items.Add(new MyCustomObject { Name = "Test5" });
							}
						}
					}
					return pageContent;
				}
			}
			catch (Exception ex)
			{
				Code.Output.Process(ex.ToString(), PrintTo.OutputTab1);
				return null;
			}
		}

		#region Default tab overrides
		// NTTabPage member. Required to determine the text for the tab header name
		protected override string GetHeaderPart(string variable)
		{
			return variable;
		}

		// Called by TabControl when tab is being removed or window is closed
		public override void Cleanup()
		{
			// Unsubscribe and cleanup any remaining resources we may still have open
			base.Cleanup();
		}

		// NTTabPage member. Required for restoring elements from workspace
		protected override void Restore(XElement element)
		{
			if (element == null)
				return;
		}

		// NTTabPage member. Required for storing elements to workspace
		protected override void Save(XElement element)
		{
			if (element == null)
				return;
		}
		#endregion
	}

	#region AddonFrameworkClasses
	public class MVVMExampleAddon : AddOnBase
	{
		private NTMenuItem		ccNewMenu, newWindowMenuItem, subMenu;

		// Same as other NS objects. However there's a difference: this event could be called in any thread
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description		= "Example AddOn demonstrating MVVM concepts";
				Name			= "MVVM Addon Example";
			}
		}

		// Will be called as a new NTWindow is created. It will be called in the thread of that window
		protected override void OnWindowCreated(Window window)
		{
			/*
				* The following checks if the window created was the Control Center
				* If the window is the control center, the Control Center -> New menu is found by AutomationId with .FindFirst()
				* If the New menu is found, a menu item to open our addon is added
			*/
			ControlCenter controlCenter = window as ControlCenter;

            if (controlCenter == null)
                return;

            ccNewMenu	= controlCenter.FindFirst("ControlCenterMenuItemNew") as NTMenuItem;

            if (ccNewMenu == null)
                return;
			
			#region OptionalSubmenu
			// Optionally, we can create a sub-menu in the Control Center New menu with the automationId WindowFrameWorkExamplesMenuItem
			if (controlCenter.FindFirst("WindowFrameworkExamplesMenuItem") as NTMenuItem == null)
			{
				subMenu = new NTMenuItem { Header = "Window Framework Examples", Style = Application.Current.TryFindResource("MainMenuItem") as Style };

				// set an automationId on our submenu to identify it
				System.Windows.Automation.AutomationProperties.SetAutomationId(subMenu, "WindowFrameworkExamplesMenuItem");

				// Add the submenu to the Control Center -> New menu
				ccNewMenu.Items.Add(subMenu);
			}

			// Or add to an existing submenu if one exists with this automationid, to add multiple addons to the same submenu
			else
			{
				subMenu = controlCenter.FindFirst("WindowFrameworkExamplesMenuItem") as NTMenuItem;
			}
			#endregion

			// This is this menu item that actually opens the addon shell window. The Header is the menu item text
			newWindowMenuItem		= new NTMenuItem {
				Header	= "MVVM Example",
				Style	= Application.Current.TryFindResource("MainMenuItem") as Style
			};
			// A click handler is added to open our addon window when the menu item is clicked
			newWindowMenuItem.Click	+= OnMenuItemClick;

			// Add the menu item that opens the window to the sub menu instead of directly to the New menu
			subMenu.Items.Add(newWindowMenuItem);

			// If not using a submenu within the Control Center -> New menu, add the new menuitem directly to the Control Center New menu instead of the subMenu
			//ccNewMenu.Items.Add(addonShellWindowMenuItem);
		}

		// Will be called as a new NTWindow is destroyed. It will be called in the thread of that window
		protected override void OnWindowDestroyed(Window window)
		{
			// This checks if there is not a menu item or if the destroyed window is not the control center.
			if (newWindowMenuItem == null || !(window is ControlCenter) ||
					ccNewMenu == null ||
					!ccNewMenu.Items.Contains(subMenu))
				return;

			// remove the click handler
			newWindowMenuItem.Click	-= OnMenuItemClick;

			// remove the addon window menu item
			subMenu.Items.Remove(newWindowMenuItem);
			newWindowMenuItem = null;

			// if the submenu is empty, remove it as well
			if (subMenu.Items.Count < 1)
			{
				ccNewMenu.Items.Remove(subMenu);
				subMenu	= null;
			}
		}

		// Open our AddOn's window when the menu item is clicked on
		private void OnMenuItemClick(object sender, RoutedEventArgs e)
		{
			Core.Globals.RandomDispatcher.BeginInvoke(new Action(() => new MVVMAddonExampleWindow().Show()));
		}
	}

	public class MVVMExampleAddonWindowFactory : INTTabFactory
	{
		// INTTabFactory member. Required to create parent window
		public NTWindow CreateParentWindow()
		{
			return new MVVMAddonExampleWindow();
		}

		// INTTabFactory member. Required to create tabs
		public NTTabPage CreateTabPage(string typeName, bool isTrue)
		{
			return new MVVMExampleAddonTabPage();
		}
	}

	public class MVVMAddonExampleWindow : NTWindow, IWorkspacePersistence
	{
		public MVVMAddonExampleWindow()
		{
			TabControl tc = new TabControl();
			TabControlManager.SetIsMovable(tc, true);
			TabControlManager.SetCanAddTabs(tc, true);
			TabControlManager.SetCanRemoveTabs(tc, true);
			TabControlManager.SetFactory(tc, new MVVMExampleAddonWindowFactory());

			Caption		= "MVVM Addon Example ";
			Width		= 400;
			Height		= 300;
			Content		= tc;

			tc.AddNTTabPage(new MVVMExampleAddonTabPage());

			Loaded += (o, e) =>
			{
				if (WorkspaceOptions == null)
					WorkspaceOptions = new WorkspaceOptions("MVVMExampleAddon-" + Guid.NewGuid().ToString("N"), this);
			};
		}

		public void Restore(XDocument document, XElement element)
		{
			if (MainTabControl != null)
				MainTabControl.RestoreFromXElement(element);
		}

		public void Save(XDocument document, XElement element)
		{
			if (MainTabControl != null)
				MainTabControl.SaveToXElement(element);
		}

		public WorkspaceOptions WorkspaceOptions
		{ get; set; }
	}

	#endregion
}