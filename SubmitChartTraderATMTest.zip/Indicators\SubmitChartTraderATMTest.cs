#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class SubmitChartTraderATMTest : Indicator
	{
		private Account Account;
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Indicator here.";
				Name										= "SubmitChartTraderATMTest";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				
				AccountName = "Sim101";
			}
			else if (State == State.DataLoaded)
			{
				lock (Account.All)
					Account = Account.All.FirstOrDefault(a => a.Name == AccountName);
			}
		}
		
		private Order stopOrder = null;

		protected override void OnBarUpdate()
		{
			if (State == State.Historical)
				return;
			
			ChartControl.Dispatcher.InvokeAsync((Action)(() =>
			{
				Print(ChartControl.OwnerChart.ChartTrader.AtmStrategy.Template);
				Print(ChartControl.OwnerChart.ChartTrader.Quantity);
				
				TriggerCustomEvent(o =>
				{
					if (stopOrder != null)
					{
						Account.Cancel(new [] { stopOrder });
						stopOrder = null;
					}

					stopOrder = Account.CreateOrder(Instrument, OrderAction.Buy, OrderType.StopMarket, TimeInForce.Day, ChartControl.OwnerChart.ChartTrader.Quantity, 0, High[0] + 10 * TickSize, string.Empty, "Entry", null);

					// Submits our entry order with the ATM strategy named "myAtmStrategyName"
					NinjaTrader.NinjaScript.AtmStrategy.StartAtmStrategy(ChartControl.OwnerChart.ChartTrader.AtmStrategy.Template, stopOrder);
					Account.Submit(new[] { stopOrder });
				}, null);
			}));
		}
	
		[TypeConverter(typeof(NinjaTrader.NinjaScript.AccountNameConverter))]
		public string AccountName { get; set; }
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private SubmitChartTraderATMTest[] cacheSubmitChartTraderATMTest;
		public SubmitChartTraderATMTest SubmitChartTraderATMTest()
		{
			return SubmitChartTraderATMTest(Input);
		}

		public SubmitChartTraderATMTest SubmitChartTraderATMTest(ISeries<double> input)
		{
			if (cacheSubmitChartTraderATMTest != null)
				for (int idx = 0; idx < cacheSubmitChartTraderATMTest.Length; idx++)
					if (cacheSubmitChartTraderATMTest[idx] != null &&  cacheSubmitChartTraderATMTest[idx].EqualsInput(input))
						return cacheSubmitChartTraderATMTest[idx];
			return CacheIndicator<SubmitChartTraderATMTest>(new SubmitChartTraderATMTest(), input, ref cacheSubmitChartTraderATMTest);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.SubmitChartTraderATMTest SubmitChartTraderATMTest()
		{
			return indicator.SubmitChartTraderATMTest(Input);
		}

		public Indicators.SubmitChartTraderATMTest SubmitChartTraderATMTest(ISeries<double> input )
		{
			return indicator.SubmitChartTraderATMTest(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.SubmitChartTraderATMTest SubmitChartTraderATMTest()
		{
			return indicator.SubmitChartTraderATMTest(Input);
		}

		public Indicators.SubmitChartTraderATMTest SubmitChartTraderATMTest(ISeries<double> input )
		{
			return indicator.SubmitChartTraderATMTest(input);
		}
	}
}

#endregion
