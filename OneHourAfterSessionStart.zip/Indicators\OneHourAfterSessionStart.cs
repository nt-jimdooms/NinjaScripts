#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class OneHourAfterSessionStart : Indicator
	{
		SessionIterator sessionIterator;
		private DateTime nextHour;
		private bool doOnce = true;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Indicator here.";
				Name										= "OneHourAfterSessionStart";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
			}
			else if (State == State.Configure)
			{
				AddDataSeries(null, new BarsPeriod { BarsPeriodType = BarsPeriodType.Minute, Value = 1440 }, "CME US Index Futures RTH");
			}				
			else if (State == State.Historical)
			{
				// instantiate SessionIterator with primary data series.
				//sessionIterator = new SessionIterator(Bars);
				
				// instantiate SessionIterator with secondary data series.
				sessionIterator = new SessionIterator(BarsArray[1]);
			}
		}

		protected override void OnBarUpdate()
		{
			// Only process on primary data series.
			if (BarsInProgress != 0)
				return;
			 // on new bars session, find the next trading session
			if (Bars.IsFirstBarOfSession)
			{
				// use the current bar time to calculate the next session
				sessionIterator.GetNextSession(Time[0], true);

				Print("The current session start time is " + sessionIterator.ActualSessionBegin);
				
				nextHour = sessionIterator.ActualSessionBegin.AddHours(1);
				Print("+ One Hour: " + nextHour);
				doOnce = true;
			}
			
			if (Time[0] >= nextHour && doOnce)
			{
				Print("Next Hour");
				doOnce = false;
			}
		}
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private OneHourAfterSessionStart[] cacheOneHourAfterSessionStart;
		public OneHourAfterSessionStart OneHourAfterSessionStart()
		{
			return OneHourAfterSessionStart(Input);
		}

		public OneHourAfterSessionStart OneHourAfterSessionStart(ISeries<double> input)
		{
			if (cacheOneHourAfterSessionStart != null)
				for (int idx = 0; idx < cacheOneHourAfterSessionStart.Length; idx++)
					if (cacheOneHourAfterSessionStart[idx] != null &&  cacheOneHourAfterSessionStart[idx].EqualsInput(input))
						return cacheOneHourAfterSessionStart[idx];
			return CacheIndicator<OneHourAfterSessionStart>(new OneHourAfterSessionStart(), input, ref cacheOneHourAfterSessionStart);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.OneHourAfterSessionStart OneHourAfterSessionStart()
		{
			return indicator.OneHourAfterSessionStart(Input);
		}

		public Indicators.OneHourAfterSessionStart OneHourAfterSessionStart(ISeries<double> input )
		{
			return indicator.OneHourAfterSessionStart(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.OneHourAfterSessionStart OneHourAfterSessionStart()
		{
			return indicator.OneHourAfterSessionStart(Input);
		}

		public Indicators.OneHourAfterSessionStart OneHourAfterSessionStart(ISeries<double> input )
		{
			return indicator.OneHourAfterSessionStart(input);
		}
	}
}

#endregion
