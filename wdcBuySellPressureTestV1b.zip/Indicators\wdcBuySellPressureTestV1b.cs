//
// Copyright (C) 2018, NinjaTrader LLC <www.ninjatrader.com>.
// NinjaTrader reserves the right to modify or overwrite this NinjaScript component with each release.
//
#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

public enum wdcBuySellPressureTestV1b_ProcessType
{
	OnBarUpdate_OBU,
	OnMarketData_OMD
}

//This namespace holds indicators in this folder and is required. Do not change it.
namespace NinjaTrader.NinjaScript.Indicators
{
	/// <summary>
	/// Indicates the current buying or selling pressure as a perecentage.
	/// This is a tick by tick indicator. If 'Calculate on bar close' is true, the indicator values will always be 100.
	/// </summary>
	public class wdcBuySellPressureTestV1b : Indicator
	{
		private double		omdBuys;
		private double 		omdSells;
		private double		omdTotalVol;
		
		private double		obuBuys;
		private double 		obuSells;
		private double		obuTotalVol;	
		private bool		obuResetVolume;
		
		private int 		activeBar 	= -1;
		private bool		DoOnce 		= true;		

		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description			= NinjaTrader.Custom.Resource.NinjaScriptIndicatorDescriptionBuySellPressure;
				Name				= "wdcBuySellPressureTestV1b";
				BarsRequiredToPlot	= 1;
				Calculate			= Calculate.OnEachTick;
				DrawOnPricePanel	= false;
				IsOverlay			= false;
				
				ProcessType			= wdcBuySellPressureTestV1b_ProcessType.OnMarketData_OMD;

				AddPlot(Brushes.DarkCyan, "omdBuyPressure");	// Plot 0
				AddPlot(Brushes.Crimson, "omdSellPressure");	// Plot 1
				
				AddPlot(Brushes.DarkCyan, "obuBuyPressure");	// Plot 2
				AddPlot(Brushes.Crimson, "obuSellPressure");	// Plot 3
				
				Plots[2].DashStyleHelper = DashStyleHelper.Dash;
				Plots[3].DashStyleHelper = DashStyleHelper.Dash;				

				AddLine(Brushes.DimGray, 75, "BuyLine");
				AddLine(Brushes.DimGray, 25, "SellLine");
			}
			else if (State == State.Configure)
			{		
				if (ProcessType == wdcBuySellPressureTestV1b_ProcessType.OnBarUpdate_OBU)
				{				
                	AddDataSeries(BarsPeriodType.Tick, 1);	
				}	
			}	
			else if (State == State.Historical)
			{
				if (ProcessType == wdcBuySellPressureTestV1b_ProcessType.OnMarketData_OMD)
				{					
					if (Calculate != Calculate.OnEachTick)
					{
						Draw.TextFixed(this, "NinjaScriptInfo", string.Format(NinjaTrader.Custom.Resource.NinjaScriptOnBarCloseError, Name), TextPosition.BottomRight);
						Log(string.Format(NinjaTrader.Custom.Resource.NinjaScriptOnBarCloseError, Name), LogLevel.Error);
					}
				}	
			}
		}

		protected override void OnMarketData(MarketDataEventArgs e)
		{
			if(e.MarketDataType == MarketDataType.Last)
			{
				if (e.Price >= e.Ask)
				{
					omdBuys += e.Volume;
				}
				else if (e.Price <= e.Bid)
				{
					omdSells += e.Volume;
				}
			}
		}
		private bool barClosed = false;

		protected override void OnBarUpdate()
		{
			if (CurrentBars[0] < activeBar || CurrentBars[0] <= BarsRequiredToPlot)
				return;
			
			if (DoOnce && State == State.Realtime)
			{	
				Draw.VerticalLine(this, "Start", 0, Brushes.Goldenrod, DashStyleHelper.Dash, 2);	
				DoOnce = false;
			}				
			
			if (BarsInProgress == 0)
			{	
				if (ProcessType == wdcBuySellPressureTestV1b_ProcessType.OnMarketData_OMD)
				{	
					//-------------------------------------------------
					// OnMarketData (OMD) BuySellPressure
					//-------------------------------------------------				
					// New Bar has been formed
					// - Assign last volume counted to the prior bar
					// - Reset volume count for new bar
					if (CurrentBar != activeBar)
					{
						omdBuyPressure[1] = (omdBuys / (omdBuys + omdSells)) * 100;
						omdSellPressure[1] = (omdSells / (omdBuys + omdSells)) * 100;
						omdBuys = 1;
						omdSells = 1;
						activeBar = CurrentBar;
					}

					omdBuyPressure[0] = (omdBuys / (omdBuys + omdSells)) * 100;
					omdSellPressure[0] = (omdSells / (omdBuys + omdSells)) * 100;
					omdTotalVol = omdBuys + omdSells;		
					
					obuBuyPressure.Reset();
					obuSellPressure.Reset();
				}	
				else if (ProcessType == wdcBuySellPressureTestV1b_ProcessType.OnBarUpdate_OBU)
				{
					// Signal bar closed. BIP1 will iterate this closing tick after BIP0 sees the closing tick, so we will accumulate on BIP1.
					if(CurrentBar != activeBar)
					{
						barClosed= true;				
						activeBar = CurrentBar;
					}
				}	
				
				Draw.TextFixed(this, "Calculate", "Calculate: " + Calculate.ToString(), TextPosition.BottomLeft);
			}
			else if (ProcessType == wdcBuySellPressureTestV1b_ProcessType.OnBarUpdate_OBU && BarsInProgress == 1)
			{
				//-------------------------------------------------
				// OnBarUpdate (OBU) BuySellPressure
				//-------------------------------------------------	
				double 	price	= Close[0];
				long 	volume	= (long) Volume[0];					
				
				// Our bar has just closed. Update the previuous plot value to the completed plot value
				if(barClosed)
				{
					barClosed = false;
					obuBuyPressure[1] = (obuBuys / (obuBuys + obuSells)) * 100;
					obuSellPressure[1] = (obuSells / (obuBuys + obuSells)) * 100;
					// Reset obuBuys and obuSells
					obuBuys = 1;
					obuSells = 1;	
				}
				
				// Accumulate volume
				if (price >= Bars.GetAsk(CurrentBar))
				{	
					obuBuys += volume;
				}	
				else if (price <= Bars.GetBid(CurrentBar))
				{	
					obuSells += volume;
				}
				
				obuBuyPressure[0] = (obuBuys / (obuBuys + obuSells)) * 100;
				obuSellPressure[0] = (obuSells / (obuBuys + obuSells)) * 100;
			}			
		}

		#region Properties
		[NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "ProcessType", GroupName = "NinjaScriptParameters", Order = 0)]
		public wdcBuySellPressureTestV1b_ProcessType ProcessType
		{ get; set; }
		
		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> omdBuyPressure
		{
			get { return Values[0]; }
		}

		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> omdSellPressure
		{
			get { return Values[1]; }
		}
		
		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> obuBuyPressure
		{
			get { return Values[2]; }
		}

		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> obuSellPressure
		{
			get { return Values[3]; }
		}
		
		#endregion
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private wdcBuySellPressureTestV1b[] cachewdcBuySellPressureTestV1b;
		public wdcBuySellPressureTestV1b wdcBuySellPressureTestV1b(wdcBuySellPressureTestV1b_ProcessType processType)
		{
			return wdcBuySellPressureTestV1b(Input, processType);
		}

		public wdcBuySellPressureTestV1b wdcBuySellPressureTestV1b(ISeries<double> input, wdcBuySellPressureTestV1b_ProcessType processType)
		{
			if (cachewdcBuySellPressureTestV1b != null)
				for (int idx = 0; idx < cachewdcBuySellPressureTestV1b.Length; idx++)
					if (cachewdcBuySellPressureTestV1b[idx] != null && cachewdcBuySellPressureTestV1b[idx].ProcessType == processType && cachewdcBuySellPressureTestV1b[idx].EqualsInput(input))
						return cachewdcBuySellPressureTestV1b[idx];
			return CacheIndicator<wdcBuySellPressureTestV1b>(new wdcBuySellPressureTestV1b(){ ProcessType = processType }, input, ref cachewdcBuySellPressureTestV1b);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.wdcBuySellPressureTestV1b wdcBuySellPressureTestV1b(wdcBuySellPressureTestV1b_ProcessType processType)
		{
			return indicator.wdcBuySellPressureTestV1b(Input, processType);
		}

		public Indicators.wdcBuySellPressureTestV1b wdcBuySellPressureTestV1b(ISeries<double> input , wdcBuySellPressureTestV1b_ProcessType processType)
		{
			return indicator.wdcBuySellPressureTestV1b(input, processType);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.wdcBuySellPressureTestV1b wdcBuySellPressureTestV1b(wdcBuySellPressureTestV1b_ProcessType processType)
		{
			return indicator.wdcBuySellPressureTestV1b(Input, processType);
		}

		public Indicators.wdcBuySellPressureTestV1b wdcBuySellPressureTestV1b(ISeries<double> input , wdcBuySellPressureTestV1b_ProcessType processType)
		{
			return indicator.wdcBuySellPressureTestV1b(input, processType);
		}
	}
}

#endregion
