#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies
{
	public class OrderFlowCumulativeDeltaCheckMultipleInstruments : Strategy
	{
		private OrderFlowCumulativeDelta OrderFlowCumulativeDelta1;
		
		private OrderFlowCumulativeDelta OrderFlowCumulativeDelta2;
		private OrderFlowCumulativeDelta OrderFlowCumulativeDelta3;
		private OrderFlowCumulativeDelta OrderFlowCumulativeDelta4;
		private OrderFlowCumulativeDelta OrderFlowCumulativeDelta5;

		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Strategy here.";
				Name										= "OrderFlowCumulativeDeltaCheckMultipleInstruments";
				Calculate									= Calculate.OnEachTick;
				EntriesPerDirection							= 1;
				EntryHandling								= EntryHandling.AllEntries;
				IsExitOnSessionCloseStrategy				= true;
				ExitOnSessionCloseSeconds					= 30;
				IsFillLimitOnTouch							= false;
				MaximumBarsLookBack							= MaximumBarsLookBack.TwoHundredFiftySix;
				OrderFillResolution							= OrderFillResolution.Standard;
				Slippage									= 0;
				StartBehavior								= StartBehavior.WaitUntilFlat;
				TimeInForce									= TimeInForce.Gtc;
				TraceOrders									= false;
				RealtimeErrorHandling						= RealtimeErrorHandling.StopCancelClose;
				StopTargetHandling							= StopTargetHandling.PerEntryExecution;
				BarsRequiredToTrade							= 20;
				// Disable this property for performance gains in Strategy Analyzer optimizations
				// See the Help Guide for additional information
				IsInstantiatedOnEachOptimizationIteration	= true;
			}
			else if (State == State.Configure)
			{
				AddDataSeries("NQ 06-19", Data.BarsPeriodType.Minute, 1, Data.MarketDataType.Last); 	// CurrentBars[1]
				AddDataSeries("NQ 06-19", Data.BarsPeriodType.Tick, 1, Data.MarketDataType.Last);		// CurrentBars[2]
				AddDataSeries("YM 06-19", Data.BarsPeriodType.Minute, 1, Data.MarketDataType.Last);		// CurrentBars[3]
				AddDataSeries("YM 06-19", Data.BarsPeriodType.Tick, 1, Data.MarketDataType.Last);		// CurrentBars[4]
				AddDataSeries("ES 06-19", Data.BarsPeriodType.Minute, 1, Data.MarketDataType.Last);		// CurrentBars[5]
				AddDataSeries("ES 06-19", Data.BarsPeriodType.Tick, 1, Data.MarketDataType.Last);		// CurrentBars[6]
				AddDataSeries("RTY 06-19", Data.BarsPeriodType.Minute, 1, Data.MarketDataType.Last);	// CurrentBars[7]
				AddDataSeries("RTY 06-19", Data.BarsPeriodType.Tick, 1, Data.MarketDataType.Last);		// CurrentBars[8]
				AddDataSeries("FDAX 06-19", Data.BarsPeriodType.Minute, 1, Data.MarketDataType.Last);	// CurrentBars[9]
				AddDataSeries("FDAX 06-19", Data.BarsPeriodType.Tick, 1, Data.MarketDataType.Last);		// CurrentBars[10]
			}
			else if (State == State.DataLoaded)
			{				
				OrderFlowCumulativeDelta1				= OrderFlowCumulativeDelta(Closes[1], NinjaTrader.NinjaScript.Indicators.CumulativeDeltaType.UpDownTick, NinjaTrader.NinjaScript.Indicators.CumulativeDeltaPeriod.Bar, 0);
				OrderFlowCumulativeDelta2				= OrderFlowCumulativeDelta(Closes[3], NinjaTrader.NinjaScript.Indicators.CumulativeDeltaType.UpDownTick, NinjaTrader.NinjaScript.Indicators.CumulativeDeltaPeriod.Bar, 0);
				OrderFlowCumulativeDelta3				= OrderFlowCumulativeDelta(Closes[5], NinjaTrader.NinjaScript.Indicators.CumulativeDeltaType.UpDownTick, NinjaTrader.NinjaScript.Indicators.CumulativeDeltaPeriod.Bar, 0);
				OrderFlowCumulativeDelta4				= OrderFlowCumulativeDelta(Closes[7], NinjaTrader.NinjaScript.Indicators.CumulativeDeltaType.UpDownTick, NinjaTrader.NinjaScript.Indicators.CumulativeDeltaPeriod.Bar, 0);
				OrderFlowCumulativeDelta5				= OrderFlowCumulativeDelta(Closes[9], NinjaTrader.NinjaScript.Indicators.CumulativeDeltaType.UpDownTick, NinjaTrader.NinjaScript.Indicators.CumulativeDeltaPeriod.Bar, 0);
			}
		}

		protected override void OnBarUpdate()
		{
			if (BarsInProgress != 0) 
				return;

			// We check each additional 1 minute data series to ensure that the strategy waits until all data series have data before calculating.
			if (CurrentBars[0] < 1 || CurrentBars[1] < 1 || CurrentBars[3] < 1 || CurrentBars[5] < 1 || CurrentBars[7] < 1 || CurrentBars[9] < 1)
				return;

			 // Set 1
			if ((OrderFlowCumulativeDelta1.DeltaClose[0] < 0)
				 && (OrderFlowCumulativeDelta2.DeltaClose[0] < 0)
				 && (OrderFlowCumulativeDelta3.DeltaClose[0] < 0)
				 && (OrderFlowCumulativeDelta4.DeltaClose[0] < 0)
				 && (OrderFlowCumulativeDelta5.DeltaClose[0] < 0))
			{
				EnterShort(Convert.ToInt32(DefaultQuantity), "");
			}
			
			 // Set 2
			if ((OrderFlowCumulativeDelta1.DeltaClose[0] > 0)
				 && (OrderFlowCumulativeDelta2.DeltaClose[0] > 0)
				 && (OrderFlowCumulativeDelta3.DeltaClose[0] > 0)
				 && (OrderFlowCumulativeDelta4.DeltaClose[0] > 0)
				 && (OrderFlowCumulativeDelta5.DeltaClose[0] > 0))
			{
				EnterLong(Convert.ToInt32(DefaultQuantity), "");
			}
			
		}
	}
}
