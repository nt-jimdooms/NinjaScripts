#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class BidAskVolumeAtWicksVolumetricExample : Indicator
	{
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Indicator here.";
				Name										= "BidAskVolumeAtWicksVolumetricExample";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
			}
			else if (State == State.Configure)
			{
			}
		}

		protected override void OnBarUpdate()
		{
			if (Bars == null)
          		return;

	        NinjaTrader.NinjaScript.BarsTypes.VolumetricBarsType barsType = Bars.BarsSeries.BarsType as    
	        NinjaTrader.NinjaScript.BarsTypes.VolumetricBarsType;
	       
	        if (barsType == null)
	          return;

	 
			if (Close[0] < Open[0] && Low[0] < Close[0])
			{
				Print("=========================================================================");
				Print("Down Bar: " + CurrentBar + " has Low wick");
				
				for (double price = Low[0]; price < Close[0]; price += TickSize)
				{
					Print(String.Format("Bid Bolume for {0}: {1}", price, barsType.Volumes[CurrentBar].GetBidVolumeForPrice(price)));
					Print(String.Format("Ask Volume for {0}: {1}", price, barsType.Volumes[CurrentBar].GetAskVolumeForPrice(price)));
				}
			}
			
			if (Close[0] < Open[0] && High[0] > Open[0])
			{
				Print("=========================================================================");
				Print("Down Bar: " + CurrentBar + " has High wick");
				
				for (double price = High[0]; price > Open[0]; price -= TickSize)
				{
					Print(String.Format("Bid Bolume for {0}: {1}", price, barsType.Volumes[CurrentBar].GetBidVolumeForPrice(price)));
					Print(String.Format("Ask Volume for {0}: {1}", price, barsType.Volumes[CurrentBar].GetAskVolumeForPrice(price)));
				}
			}
		}
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private BidAskVolumeAtWicksVolumetricExample[] cacheBidAskVolumeAtWicksVolumetricExample;
		public BidAskVolumeAtWicksVolumetricExample BidAskVolumeAtWicksVolumetricExample()
		{
			return BidAskVolumeAtWicksVolumetricExample(Input);
		}

		public BidAskVolumeAtWicksVolumetricExample BidAskVolumeAtWicksVolumetricExample(ISeries<double> input)
		{
			if (cacheBidAskVolumeAtWicksVolumetricExample != null)
				for (int idx = 0; idx < cacheBidAskVolumeAtWicksVolumetricExample.Length; idx++)
					if (cacheBidAskVolumeAtWicksVolumetricExample[idx] != null &&  cacheBidAskVolumeAtWicksVolumetricExample[idx].EqualsInput(input))
						return cacheBidAskVolumeAtWicksVolumetricExample[idx];
			return CacheIndicator<BidAskVolumeAtWicksVolumetricExample>(new BidAskVolumeAtWicksVolumetricExample(), input, ref cacheBidAskVolumeAtWicksVolumetricExample);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.BidAskVolumeAtWicksVolumetricExample BidAskVolumeAtWicksVolumetricExample()
		{
			return indicator.BidAskVolumeAtWicksVolumetricExample(Input);
		}

		public Indicators.BidAskVolumeAtWicksVolumetricExample BidAskVolumeAtWicksVolumetricExample(ISeries<double> input )
		{
			return indicator.BidAskVolumeAtWicksVolumetricExample(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.BidAskVolumeAtWicksVolumetricExample BidAskVolumeAtWicksVolumetricExample()
		{
			return indicator.BidAskVolumeAtWicksVolumetricExample(Input);
		}

		public Indicators.BidAskVolumeAtWicksVolumetricExample BidAskVolumeAtWicksVolumetricExample(ISeries<double> input )
		{
			return indicator.BidAskVolumeAtWicksVolumetricExample(input);
		}
	}
}

#endregion
