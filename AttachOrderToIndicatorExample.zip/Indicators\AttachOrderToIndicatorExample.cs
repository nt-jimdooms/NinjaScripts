// Coded by Chelsea Bell. chelsea.bell@ninjatrader.com
#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class AttachOrderToIndicatorExample : Indicator
	{
		System.Windows.Controls.Grid chartTraderGrid;	
		System.Windows.Controls.Grid chartTraderButtonsGrid;
		System.Windows.Controls.Grid chartTraderNewButtonsGrid;
		System.Windows.Controls.Button newButton1;
		private bool doitonce = true;
		private bool myStop = false, myLimit = false;
		private Account account;
		private bool changeTheOrder = false, IndieFound = false;
		private List<NinjaTrader.Gui.NinjaScript.IndicatorRenderBase> indicatorCollection;
		private Order myOrder = null;
		private double IndieValue;
		


		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description							= @"Enter the description for your new custom Indicator here.";
				Name								= "AttachOrderToIndicatorExample";
				Calculate							= Calculate.OnEachTick;
				IsOverlay							= true;
				DisplayInDataBox					= true;
				DrawOnPricePanel					= true;
				DrawHorizontalGridLines				= true;
				DrawVerticalGridLines				= true;
				PaintPriceMarkers					= true;
				ScaleJustification					= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				IsSuspendedWhileInactive			= true;
				IndieName							= "SMA";
			}
			else if (State == State.Historical)
			{				
				Dispatcher.Invoke((Action)(() =>
				{
					chartTraderGrid				= (Window.GetWindow(ChartControl.Parent).FindFirst("ChartWindowChartTraderControl") as ChartTrader).Content as System.Windows.Controls.Grid;
					chartTraderButtonsGrid		= chartTraderGrid.Children[0] as System.Windows.Controls.Grid;
					chartTraderNewButtonsGrid	= new System.Windows.Controls.Grid();

					chartTraderGrid.Children.Add(chartTraderNewButtonsGrid);

					// add a new space for our custom grid below the ask and bid prices
					chartTraderGrid.RowDefinitions.Add(new System.Windows.Controls.RowDefinition()
					{
						Height = new GridLength(45)
					});

					System.Windows.Controls.Grid.SetRow(chartTraderNewButtonsGrid, 7);

					newButton1 = new System.Windows.Controls.Button()
					{
						Background = Brushes.Gray,
						BorderBrush = Brushes.DimGray,
						Content = "Move Order",
						Height = 30
					};

					newButton1.Click += Button1Click;
					System.Windows.Automation.AutomationProperties.SetAutomationId(newButton1, "newButton1");
					chartTraderButtonsGrid.Children.Add(newButton1);
					System.Windows.Controls.Grid.SetRow(newButton1, 12);
				}));				
			}			
			else if (State == State.DataLoaded)
			{	
				
				// Find our Sim101 account
		        lock (Account.All)
		              account = Account.All.FirstOrDefault(a => a.Name == "Sim101");

		        // Subscribe to account item and order updates
		        if (account != null)
				{
					account.OrderUpdate 		+= OnOrderUpdate;
				}
			
			}
			else if (State == State.Terminated)
			{
				Dispatcher.Invoke((Action)(() =>
				{
					if (newButton1 != null)
					{
						newButton1.Click -= Button1Click;
						chartTraderButtonsGrid.Children.Remove(newButton1);
					}
				}));

				// Make sure to unsubscribe to the account item subscription
        		if (account != null)
				{
					account.OrderUpdate 		-= OnOrderUpdate;
				}
			}
		}
	
		protected void Button1Click(object sender, RoutedEventArgs e)
		{			
			if (!IndieFound)
				return;

			foreach (Order order in account.Orders)
			{	
				if (order.Instrument.FullName.ToString() == Instrument.FullName && (order.OrderState == OrderState.Accepted || order.OrderState == OrderState.Working))
				{						
					if (myOrder == null)
					{
						myOrder = order;
						changeTheOrder = true;  // bool to trigger in OnBarUpdate to keep order tied to indicator price
						
						if (myOrder.IsLimit)
						{
							myLimit = true;
							myStop = false;
						}
						else if (myOrder.IsStopLimit || myOrder.IsStopMarket)
						{
							myLimit = false;
							myStop = true;
						}	
					}
				}				
			}						
		}
		
	    private void OnOrderUpdate(object sender, OrderEventArgs e)
	    {			
			if (e.Order == myOrder && Order.IsTerminalState(myOrder.OrderState))
    				myOrder = null;
		}
		

		protected override void OnBarUpdate() 
		{ 
			if (State == State.Historical)
				return;
			lock(ChartControl.Indicators)
				indicatorCollection = ChartControl.Indicators.ToList();
 
			int pointer = 0;  // adjusts the indicator values pointer
			
  			foreach (NinjaTrader.Gui.NinjaScript.IndicatorRenderBase indicator in indicatorCollection)
  			{
				if(indicator.Calculate != Calculate.OnBarClose)
				{
					pointer = 0;
				}
				else
				{
					pointer = -1;
				}
				
				if (indicator.Panel == this.Panel || indicator.Panel == 0)  // process each indicator in this panel
				{
					if (indicator.State == State.Realtime)
					{
						for (int seriesCount = 0; seriesCount <  indicator.Values.Length ; seriesCount++)
						{
							if (indicator.Name == IndieName)
							{
								IndieValue = indicator.Values[seriesCount].GetValueAt(ChartBars.ToIndex + pointer);
								IndieFound = true;
							}
						}
					}
				}
  			}
			
				
			if (IndieFound)
			{
				Draw.TextFixed(this,"Test","\n\n"+ IndieName+" = "+IndieValue.ToString("n2"), TextPosition.TopRight);
			}
			else
				Draw.TextFixed(this, "Test", "***ERROR*** Indicator not found,\ncheck spelling, make sure it is on chart", TextPosition.Center);
			
			if (IndieFound && changeTheOrder && myOrder != null && (myStop || myLimit))
			{	
				if (myStop)
				{
					myOrder.StopPriceChanged = IndieValue;  // continue to adjust on each tick
				}
				else
				{
					myOrder.LimitPriceChanged = IndieValue;
				}
				
				account.Change(new [] {myOrder});
			}
			
		}
		
#region Properties
		
		[NinjaScriptProperty]
		[Display(Name="Indicator Name?", Order=1, GroupName="Parameters")]
		public string IndieName
		{ get; set; }
		
#endregion		
		
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private AttachOrderToIndicatorExample[] cacheAttachOrderToIndicatorExample;
		public AttachOrderToIndicatorExample AttachOrderToIndicatorExample(string indieName)
		{
			return AttachOrderToIndicatorExample(Input, indieName);
		}

		public AttachOrderToIndicatorExample AttachOrderToIndicatorExample(ISeries<double> input, string indieName)
		{
			if (cacheAttachOrderToIndicatorExample != null)
				for (int idx = 0; idx < cacheAttachOrderToIndicatorExample.Length; idx++)
					if (cacheAttachOrderToIndicatorExample[idx] != null && cacheAttachOrderToIndicatorExample[idx].IndieName == indieName && cacheAttachOrderToIndicatorExample[idx].EqualsInput(input))
						return cacheAttachOrderToIndicatorExample[idx];
			return CacheIndicator<AttachOrderToIndicatorExample>(new AttachOrderToIndicatorExample(){ IndieName = indieName }, input, ref cacheAttachOrderToIndicatorExample);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.AttachOrderToIndicatorExample AttachOrderToIndicatorExample(string indieName)
		{
			return indicator.AttachOrderToIndicatorExample(Input, indieName);
		}

		public Indicators.AttachOrderToIndicatorExample AttachOrderToIndicatorExample(ISeries<double> input , string indieName)
		{
			return indicator.AttachOrderToIndicatorExample(input, indieName);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.AttachOrderToIndicatorExample AttachOrderToIndicatorExample(string indieName)
		{
			return indicator.AttachOrderToIndicatorExample(Input, indieName);
		}

		public Indicators.AttachOrderToIndicatorExample AttachOrderToIndicatorExample(ISeries<double> input , string indieName)
		{
			return indicator.AttachOrderToIndicatorExample(input, indieName);
		}
	}
}

#endregion
