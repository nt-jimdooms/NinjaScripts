#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies
{
	[TypeConverter("NinjaTrader.NinjaScript.Strategies.StrategyPropertyGridModConverter")]
	public class StrategyPropertyGridMod : Strategy
	{
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Strategy here.";
				Name										= "StrategyPropertyGridMod";
				Calculate									= Calculate.OnBarClose;
				EntriesPerDirection							= 1;
				EntryHandling								= EntryHandling.AllEntries;
				IsExitOnSessionCloseStrategy				= true;
				ExitOnSessionCloseSeconds					= 30;
				IsFillLimitOnTouch							= false;
				MaximumBarsLookBack							= MaximumBarsLookBack.TwoHundredFiftySix;
				OrderFillResolution							= OrderFillResolution.Standard;
				Slippage									= 0;
				StartBehavior								= StartBehavior.WaitUntilFlat;
				TimeInForce									= TimeInForce.Gtc;
				TraceOrders									= false;
				RealtimeErrorHandling						= RealtimeErrorHandling.StopCancelClose;
				StopTargetHandling							= StopTargetHandling.PerEntryExecution;
				BarsRequiredToTrade							= 20;
				// Disable this property for performance gains in Strategy Analyzer optimizations
				// See the Help Guide for additional information
				IsInstantiatedOnEachOptimizationIteration	= true;
				
				ShowHideToggle 	= false;
                ReadOnlyToggle 	= true;
				
                ToggleValue1 	= 1;
                ToggleValue2 	= 4;
                ReadOnlyInt 	= 10;
                ReadOnlyDouble 	= .25;
				
				Period = 1;
			}
			else if (State == State.Configure)
			{
			}
		}

		protected override void OnBarUpdate()
		{
			if (BarsInProgress != 0) 
				return;

			ExitLong(Convert.ToInt32(DefaultQuantity), "", "");
		}

		#region Properties
		//[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name = "Period", Order = 0, GroupName = "CustomCategory")]
		public int Period
		{ get; set; }
		
		#region Use Case #1: Show/hide properties based on secondary input

		//[NinjaScriptProperty]
        [RefreshProperties(RefreshProperties.All)] // Needed to refresh the property grid when the value changes
        [Display(Name = "Toggle show/hide", Order = 1, GroupName = "Use Case #1")]
        public bool ShowHideToggle
        { get; set; }

		//[NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name = "Toggle value #1", Order = 2, GroupName = "Use Case #1")]
        public int ToggleValue1
        { get; set; }

		//[NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name = "Toggle value #2", Order = 3, GroupName = "Use Case #1")]
        public int ToggleValue2
        { get; set; }

        #endregion

        #region Use Case #2: Disable/enable properties based on secondary input
		//[NinjaScriptProperty]
        [RefreshProperties(RefreshProperties.All)] // Needed to refresh the property grid when the value changes
        [Display(Name = "Toggle read only", Order = 1, GroupName = "Use Case #2")]
        public bool ReadOnlyToggle
        { get; set; }

		//[NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name = "Read only int", Order = 2, GroupName = "Use Case #2")]
        public int ReadOnlyInt
        { get; set; }

		//[NinjaScriptProperty]
        [Range(0, double.MaxValue)]
        [Display(Name = "Read only double", Order = 3, GroupName = "Use Case #2")]
        public double ReadOnlyDouble
        { get; set; }

        #endregion
		#endregion

	}
	
	 #region Use Case #1/#2: Show/hide properties based on secondary input & Disable/enable properties based on secondary input

    // This custom TypeConverter is applied ot the entire strategy object and handles two of our use cases
    // IMPORTANT: Inherit from IndicatorBaseConverter so we get default NinjaTrader property handling logic
    // IMPORTANT: Not doing this will completely break the property grids!
    // If targeting a "Strategy", use the "StrategyBaseConverter" base type instead
    public class StrategyPropertyGridModConverter : StrategyBaseConverter // or StrategyBaseConverter
    {
        public override PropertyDescriptorCollection GetProperties(ITypeDescriptorContext context, object component, Attribute[] attrs)
        {
			
            // we need the strategy instance which actually exists on the grid
            StrategyPropertyGridMod strategy = component as StrategyPropertyGridMod;

            // base.GetProperties ensures we have all the properties (and associated property grid editors)
            // NinjaTrader internal logic determines for a given strategy
            PropertyDescriptorCollection propertyDescriptorCollection = base.GetPropertiesSupported(context)
                                                                        ? base.GetProperties(context, component, attrs)
                                                                        : TypeDescriptor.GetProperties(component, attrs);

            if (strategy == null || propertyDescriptorCollection == null)
                return propertyDescriptorCollection;


            #region Use Case #1: Show/hide properties based on secondary input

            // These two values are will be shown/hidden (toggled) based on "ShowHideToggle" bool value
            PropertyDescriptor toggleValue1 = propertyDescriptorCollection["ToggleValue1"];
            PropertyDescriptor toggleValue2 = propertyDescriptorCollection["ToggleValue2"];

            // This removes the following properties from the grid to start off with
            propertyDescriptorCollection.Remove(toggleValue1);
            propertyDescriptorCollection.Remove(toggleValue2);

            // Now that We've removed the default property descriptors, we can decide if they need to be re-added
            // If "ShowHideToggle" is set to true, re-add these values to the property collection
            if (strategy.ShowHideToggle)
            {
                propertyDescriptorCollection.Add(toggleValue1);
                propertyDescriptorCollection.Add(toggleValue2);
            }

            // otherwise, nothing else to do since they were already removed

            #endregion

            #region Use Case #2: Disable/enable properties based on secondary input

            // These two values are will be disabled/enabled (grayed out) based on the strategy's "ShowHideToggle" bool value
            // The PropertyDescriptor type does not contain our desired custom behavior, so we must implement that ourselves
            PropertyDescriptor readOnlyInt = propertyDescriptorCollection["ReadOnlyInt"];
            PropertyDescriptor readOnlyDouble = propertyDescriptorCollection["ReadOnlyDouble"];

            // We must first remove the default implentation of the property (which does not yet contain our custom behavior)
            // Otherwise we would have two versions of the same property on the grid which is not desired
            propertyDescriptorCollection.Remove(readOnlyInt);
            propertyDescriptorCollection.Remove(readOnlyDouble);

            // This custom "ReadOnlyDescriptor" property descriptor (defined in the class below) toggles read-only mode based on a property in the strategy
            // So re-assign them from a "PropertyDescriptor" to new "ReadOnlyDescriptor" which handles our custom action
            readOnlyInt = new ReadOnlyDescriptor(strategy, readOnlyInt);
            readOnlyDouble = new ReadOnlyDoubleDescriptor(strategy, readOnlyDouble);

            // This re-adds the properties to the grid under their new "ReadOnlyDescriptor" type behavior
            propertyDescriptorCollection.Add(readOnlyInt);
            propertyDescriptorCollection.Add(readOnlyDouble);

            #endregion

            return propertyDescriptorCollection;
        }

        // Important: This must return true otherwise the type convetor will not be called
        public override bool GetPropertiesSupported(ITypeDescriptorContext context)
        { return true; }
    }

    // This is a custom PropertyDescriptor class which will handle setting our desired properties to read only
    public class ReadOnlyDescriptor : PropertyDescriptor
    {
        // Need the instance on the property grid to check the show/hide toggle value
        private StrategyPropertyGridMod strategyInstance;

        private PropertyDescriptor property;

        // The base instance constructor helps store the default Name and Attributes (Such as DisplayAttribute.Name, .GroupName, .Order)
        // Otherwise those details would be lost when we converted the PropertyDescriptor to the new custom ReadOnlyDescriptor
        public ReadOnlyDescriptor(StrategyPropertyGridMod strategy, PropertyDescriptor propertyDescriptor) : base(propertyDescriptor.Name, propertyDescriptor.Attributes.OfType<Attribute>().ToArray())
        {
            strategyInstance = strategy;
            property = propertyDescriptor;
        }

        // Stores the current value of the property on the strategy
        public override object GetValue(object component)
        {
            StrategyPropertyGridMod targetInstance = component as StrategyPropertyGridMod;
            
			if (targetInstance == null)
                return null;
			
            switch (property.Name)
            {
                case "ReadOnlyInt":
                	return targetInstance.ReadOnlyInt;
            }
            return null;
        }

        // Updates the current value of the property on the strategy
        public override void SetValue(object component, object value)
        {
            StrategyPropertyGridMod targetInstance = component as StrategyPropertyGridMod;
            
			if (targetInstance == null)
                return;

            switch (property.Name)
            {
                case "ReadOnlyInt":
                    targetInstance.ReadOnlyInt = (int) value;
                    break;
            }
        }

        // set the PropertyDescriptor to "read only" based on the strategy instance input
        public override bool IsReadOnly
        { get { return strategyInstance.ReadOnlyToggle; } }

        // IsReadOnly is the relevant interface member we need to use to obtain our desired custom behavior
        // but applying a custom property descriptor requires having to handle a bunch of other operations as well.
        // I.e., the below methods and properties are required to be implemented, otherwise it won't compile.
        public override bool CanResetValue(object component)
        { return true; }

        public override Type ComponentType
        { get { return typeof(StrategyPropertyGridMod); } }

        public override Type PropertyType
        { get { return typeof(int); } }

        public override void ResetValue(object component)
        { }

        public override bool ShouldSerializeValue(object component)
        { return true; }
    }

    // This is a custom PropertyDescriptor class which will handle setting our desired properties to read only
    public class ReadOnlyDoubleDescriptor : PropertyDescriptor
    {
        // Need the instance on the property grid to check the show/hide toggle value
        private StrategyPropertyGridMod strategyInstance;

        private PropertyDescriptor property;

        // The base instance constructor helps store the default Name and Attributes (Such as DisplayAttribute.Name, .GroupName, .Order)
        // Otherwise those details would be lost when we converted the PropertyDescriptor to the new custom ReadOnlyDescriptor
        public ReadOnlyDoubleDescriptor(StrategyPropertyGridMod strategy, PropertyDescriptor propertyDescriptor) : base(propertyDescriptor.Name, propertyDescriptor.Attributes.OfType<Attribute>().ToArray())
        {
            strategyInstance = strategy;
            property = propertyDescriptor;
        }

        // Stores the current value of the property on the strategy
        public override object GetValue(object component)
        {
            StrategyPropertyGridMod targetInstance = component as StrategyPropertyGridMod;
            
			if (targetInstance == null)
                return null;
			
            switch (property.Name)
            {
                case "ReadOnlyDouble":
                    return targetInstance.ReadOnlyDouble;
            }
            return null;
        }

        // Updates the current value of the property on the strategy
        public override void SetValue(object component, object value)
        {
            StrategyPropertyGridMod targetInstance = component as StrategyPropertyGridMod;
            
			if (targetInstance == null)
                return;

            switch (property.Name)
            {
                case "ReadOnlyDouble":
                    targetInstance.ReadOnlyDouble = (double)value;
                    break;
            }
        }

        // set the PropertyDescriptor to "read only" based on the strategy instance input
        public override bool IsReadOnly
        { get { return strategyInstance.ReadOnlyToggle; } }

        // IsReadOnly is the relevant interface member we need to use to obtain our desired custom behavior
        // but applying a custom property descriptor requires having to handle a bunch of other operations as well.
        // I.e., the below methods and properties are required to be implemented, otherwise it won't compile.
        public override bool CanResetValue(object component)
        { return true; }

        public override Type ComponentType
        { get { return typeof(StrategyPropertyGridMod); } }

        public override Type PropertyType
        { get { return typeof(double); } }

        public override void ResetValue(object component)
        { }

        public override bool ShouldSerializeValue(object component)
        { return true; }
    }
    #endregion
}
