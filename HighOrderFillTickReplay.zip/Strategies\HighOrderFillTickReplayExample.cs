#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies
{
	public class HighOrderFillTickReplayExample : Strategy
	{
		private int EntryCount;
		private int BarSubmitted;
		private bool UseHighOrderFill = false;
		private Order MyOrder = null;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Strategy here.";
				Name										= "HighOrderFillTickReplayExample";
				EntriesPerDirection							= 1;
				EntryHandling								= EntryHandling.AllEntries;
				IsExitOnSessionCloseStrategy				= true;
				ExitOnSessionCloseSeconds					= 30;
				IsFillLimitOnTouch							= false;
				MaximumBarsLookBack							= MaximumBarsLookBack.TwoHundredFiftySix;
				Slippage									= 0;
				StartBehavior								= StartBehavior.WaitUntilFlat;
				TimeInForce									= TimeInForce.Gtc;
				TraceOrders									= true;
				RealtimeErrorHandling						= RealtimeErrorHandling.StopCancelClose;
				StopTargetHandling							= StopTargetHandling.PerEntryExecution;
				BarsRequiredToTrade							= 0;
				// Disable this property for performance gains in Strategy Analyzer optimizations
				// See the Help Guide for additional information
				IsInstantiatedOnEachOptimizationIteration	= true;
				
				Calculate									= Calculate.OnEachTick;
			}
			else if (State == State.Configure)
			{
				if (UseHighOrderFill)
					AddDataSeries(BarsPeriodType.Tick, 1);
			}
			else if (State == State.DataLoaded)
			{
				EntryCount = 0;
				Print("");
			}
		}

		protected override void OnBarUpdate()
		{
			int BIP = (UseHighOrderFill || OrderFillResolution == OrderFillResolution.High) ? 1 : 0;
			int BarsAgo = Calculate == Calculate.OnBarClose ? 0 : 1;
			
			// Only process on the primary data series
			if (BarsInProgress != 0)
				return;	
			
			// Entry Condition
			if (Close[BarsAgo] > Open[BarsAgo] && Position.MarketPosition == MarketPosition.Flat && MyOrder == null && IsFirstTickOfBar)
			{				
				// Submit order to BIP 1 for intrabar granularity, Submit to the primary data series for standard fill resolution.
				// If not specified, the order will be submitted to the BIP index in which the method was called
				EnterLongLimit(BIP, ((BIP == 1) || Bars.IsTickReplay), 1, Close[BarsAgo]-5 *TickSize, "MyEntry"+EntryCount.ToString());
			}
			//else if (((BIP == 1) || Bars.IsTickReplay ) && CurrentBar > BarSubmitted + 2 && IsFirstTickOfBar && MyOrder != null)
			//{
			//	CancelOrder(MyOrder);
			//}
			else if (((BIP == 1) || Bars.IsTickReplay ) /*&& CurrentBar > BarSubmitted + 2*/ && IsFirstTickOfBar && MyOrder != null)
			{
				CancelOrder(MyOrder);
			}
			
			// Exit Condition
			if (BarsSinceEntryExecution(BIP, "MyEntry"+(EntryCount-1).ToString(), 0) >= 1  && Position.MarketPosition == MarketPosition.Long)			
			{
				// Submit order to BIP 1 for intrabar granularity, Submit to the primary data series for standard fill resolution.
				// If not specified, the order will be submitted to the BIP index in which the method was called
				ExitLong(BIP, 1, "MyExit"+(EntryCount-1).ToString(), "MyEntry"+(EntryCount-1).ToString());
			}
				
		}
		
		protected override void OnExecutionUpdate(Execution execution, string executionId, double price, int quantity, MarketPosition marketPosition, string orderId, DateTime time)
		{
			Print(execution.Order.Name + " Time: " + time + " " + CurrentBar);
			
			if(execution.Order.Name == "MyEntry"+EntryCount.ToString())
				EntryCount++;
		}
		
			
		protected override void OnOrderUpdate(Cbi.Order order, double limitPrice, double stopPrice,
                                    int quantity, int filled, double averageFillPrice,
                                    Cbi.OrderState orderState, DateTime time, Cbi.ErrorCode error, string comment)
		{
			// Assign Order object
			if (order.Name == "MyEntry"+EntryCount.ToString())
			{
				MyOrder = order;
				BarSubmitted = CurrentBar;
			}
			
			// Set Order to null when filled or cancelled.
			if (MyOrder != null && MyOrder == order)
			{
				if (order.OrderState == OrderState.Cancelled || order.OrderState == OrderState.Filled )
				{
					MyOrder = null;
				}
			}
		}
	}
}
