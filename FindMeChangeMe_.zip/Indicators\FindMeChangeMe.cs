#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class FindMeChangeMe : Indicator
	{		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description							= @"Demonstrates how to capture a mouse click and adjust for DPI settings properly";
				Name								= "FindMeChangeMe";
				Calculate							= Calculate.OnBarClose;
				IsOverlay							= true;
				DisplayInDataBox					= false;
				DrawOnPricePanel					= true;
				ScaleJustification					= NinjaTrader.Gui.Chart.ScaleJustification.Right;
			}
			else if (State == State.Historical)
			{
				if (ChartControl != null)
					ChartPanel.MouseLeftButtonDown += MouseClicked;
			}
			else if (State == State.Terminated)
			{
				if (ChartControl != null)
					ChartPanel.MouseLeftButtonDown -= MouseClicked;
			}
		}

		protected override void OnBarUpdate() 
		{
			Draw.TextFixed(this, "tag", "InitialText", TextPosition.Center);
		}
				
		protected void MouseClicked(object sender, MouseButtonEventArgs e)
		{
			foreach (var window in NinjaTrader.Core.Globals.AllWindows)
            {
                //check if the found window is a Chart window, if not continue looking
                if (!(window is NinjaTrader.Gui.Chart.Chart)) continue;

                window.Dispatcher.InvokeAsync(new Action(() =>
                {
                    //try to cast as a Chart, if it fails it will be null
                    var foundChart = window as NinjaTrader.Gui.Chart.Chart;
                    if (foundChart == null) return;
					
					foreach (Indicator myIndi in foundChart.ActiveChartControl.Indicators)
                    {
						if (myIndi.Name == this.Name)
						{
							(myIndi as FindMeChangeMe).UpdateText("Text Updated");
						}
					}
                    
                }));
            }
		}
		
		public void UpdateText(string text)
		{
			Draw.TextFixed(this, "tag", text, TextPosition.Center);
			
			if (ChartControl != null)
				ChartControl.InvalidateVisual();
		}
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private FindMeChangeMe[] cacheFindMeChangeMe;
		public FindMeChangeMe FindMeChangeMe()
		{
			return FindMeChangeMe(Input);
		}

		public FindMeChangeMe FindMeChangeMe(ISeries<double> input)
		{
			if (cacheFindMeChangeMe != null)
				for (int idx = 0; idx < cacheFindMeChangeMe.Length; idx++)
					if (cacheFindMeChangeMe[idx] != null &&  cacheFindMeChangeMe[idx].EqualsInput(input))
						return cacheFindMeChangeMe[idx];
			return CacheIndicator<FindMeChangeMe>(new FindMeChangeMe(), input, ref cacheFindMeChangeMe);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.FindMeChangeMe FindMeChangeMe()
		{
			return indicator.FindMeChangeMe(Input);
		}

		public Indicators.FindMeChangeMe FindMeChangeMe(ISeries<double> input )
		{
			return indicator.FindMeChangeMe(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.FindMeChangeMe FindMeChangeMe()
		{
			return indicator.FindMeChangeMe(Input);
		}

		public Indicators.FindMeChangeMe FindMeChangeMe(ISeries<double> input )
		{
			return indicator.FindMeChangeMe(input);
		}
	}
}

#endregion
