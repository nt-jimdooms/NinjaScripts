#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class SortMedianExample : Indicator
	{
		private Series<double> low;
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Indicator here.";
				Name										= "SortMedianExample";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				
				AddPlot(Brushes.Orange, "LowAvg");
			}
			else if (State == State.DataLoaded)
			{
				low = new Series<double>(this, MaximumBarsLookBack.Infinite);
			}
		}

		protected override void OnBarUpdate()
		{
			low[0] = Low[0];
			
			if(CurrentBar < 1)
				return;
			
			bool repeat = true;
			while (repeat)
			{
				bool sorted = true;
				for (int i = 0; i < CurrentBar; i++)
				{
					if (low[i+1] < low[i])
					{
						double temp = low[i];
						low[i] = low[i+1];
						low[i+1] = temp;
						
						sorted = false;
					}		
				}
				if(!sorted)
					repeat = true;
				else
					repeat = false;
			}
			Value[0] = low[Convert.ToInt32(CurrentBar/2)];
		}
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private SortMedianExample[] cacheSortMedianExample;
		public SortMedianExample SortMedianExample()
		{
			return SortMedianExample(Input);
		}

		public SortMedianExample SortMedianExample(ISeries<double> input)
		{
			if (cacheSortMedianExample != null)
				for (int idx = 0; idx < cacheSortMedianExample.Length; idx++)
					if (cacheSortMedianExample[idx] != null &&  cacheSortMedianExample[idx].EqualsInput(input))
						return cacheSortMedianExample[idx];
			return CacheIndicator<SortMedianExample>(new SortMedianExample(), input, ref cacheSortMedianExample);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.SortMedianExample SortMedianExample()
		{
			return indicator.SortMedianExample(Input);
		}

		public Indicators.SortMedianExample SortMedianExample(ISeries<double> input )
		{
			return indicator.SortMedianExample(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.SortMedianExample SortMedianExample()
		{
			return indicator.SortMedianExample(Input);
		}

		public Indicators.SortMedianExample SortMedianExample(ISeries<double> input )
		{
			return indicator.SortMedianExample(input);
		}
	}
}

#endregion
