// Coded by Chelsea Bell. chelsea.bell@ninjatrader.com
#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

namespace NinjaTrader.NinjaScript.Indicators
{
	public class ChartTraderCustomButtonsExampleTestDispatcher : Indicator
	{
		private System.Windows.Controls.RowDefinition	addedRow1, addedRow2, addedRow3, addedRow4;
		private Gui.Chart.ChartTab						chartTab;
		private Gui.Chart.Chart							chartWindow;
		private System.Windows.Controls.Grid			chartTraderGrid, chartTraderButtonsGrid, lowerButtonsGrid, lowerButtonsGrid2, lowerButtonsGrid3, upperButtonsGrid;
		private System.Windows.Controls.Button[]		buttonsArray;
		private bool									panelActive;
		private System.Windows.Controls.TabItem			tabItem;
		
		private Account account;

		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description					= @"Demonstrates adding buttons to Chart Trader";
				Name						= "ChartTraderCustomButtonsExampleTestDispatcher";
				Calculate					= Calculate.OnBarClose;
				IsOverlay					= true;
				DisplayInDataBox			= false;
				PaintPriceMarkers			= false;
			}
			else if (State == State.Historical)
			{
				lock (Account.All)
					account = Account.All.FirstOrDefault(a => a.Name == AccountName);

				// Subscribe to account item updates
				if (account != null)
				{
					account.AccountItemUpdate += OnAccountItemUpdate;
				}
				
				if (ChartControl != null)
				{
					ChartControl.Dispatcher.InvokeAsync(() =>
					{
						CreateWPFControls();
					});
				}
			}
			else if (State == State.Terminated)
			{
				if (ChartControl != null)
				{
					ChartControl.Dispatcher.InvokeAsync(() =>
					{
						DisposeWPFControls();
					});
				}
				
				// Make sure to unsubscribe to the account item subscription
        		if (account != null)
				{
            		account.AccountItemUpdate -= OnAccountItemUpdate;
				}
			}
		}
		
		// This method is fired on any change of an account value
	    private void OnAccountItemUpdate(object sender, AccountItemEventArgs e)
		{
			if (e.AccountItem == AccountItem.RealizedProfitLoss)
			{
				if (ChartControl != null)
				{
					// add some text to the UserControlCollection through the ChartControls dispatcher
					ChartControl.Dispatcher.InvokeAsync(new Action(() => {
						buttonsArray[0].Content = e.Value;
					}));
				}
			}
		}

		protected void Button1Click(object sender, RoutedEventArgs e)
		{
			Draw.TextFixed(this, "infobox", "Button 1 Clicked", TextPosition.BottomLeft, Brushes.Green, new Gui.Tools.SimpleFont("Arial", 25), Brushes.Transparent, Brushes.Transparent, 100);
			// refresh the chart so that the text box will appear on the next render pass even if there is no incoming data
			ForceRefresh();
		}

		protected void Button2Click(object sender, RoutedEventArgs e)
		{
			Draw.TextFixed(this, "infobox", "Button 2 Clicked", TextPosition.BottomLeft, Brushes.DarkRed, new Gui.Tools.SimpleFont("Arial", 25), Brushes.Transparent, Brushes.Transparent, 100);
			ForceRefresh();
		}

		protected void Button3Click(object sender, RoutedEventArgs e)
		{
			Draw.TextFixed(this, "infobox", "Button 3 Clicked", TextPosition.BottomLeft, Brushes.DarkOrange, new Gui.Tools.SimpleFont("Arial", 25), Brushes.Transparent, Brushes.Transparent, 100);
			ForceRefresh();
		}

		protected void Button4Click(object sender, RoutedEventArgs e)
		{
			Draw.TextFixed(this, "infobox", "Button 4 Clicked", TextPosition.BottomLeft, Brushes.CadetBlue, new Gui.Tools.SimpleFont("Arial", 25), Brushes.Transparent, Brushes.Transparent, 100);
			ForceRefresh();
		}

		protected void CreateWPFControls()
		{
			chartWindow				= Window.GetWindow(ChartControl.Parent) as Gui.Chart.Chart;

			// if not added to a chart, do nothing
			if (chartWindow == null)
				return;

			// this is the entire chart trader area grid
			chartTraderGrid			= (chartWindow.FindFirst("ChartWindowChartTraderControl") as Gui.Chart.ChartTrader).Content as System.Windows.Controls.Grid;

			// this grid contains the existing chart trader buttons
			chartTraderButtonsGrid	= chartTraderGrid.Children[0] as System.Windows.Controls.Grid;

			// this grid is a grid i'm adding to a new row (at the bottom) in the grid that contains bid and ask prices and order controls (chartTraderButtonsGrid)
			upperButtonsGrid = new System.Windows.Controls.Grid();
			System.Windows.Controls.Grid.SetColumnSpan(upperButtonsGrid, 3);

			upperButtonsGrid.ColumnDefinitions.Add(new System.Windows.Controls.ColumnDefinition());
			upperButtonsGrid.ColumnDefinitions.Add(new System.Windows.Controls.ColumnDefinition() { Width = new GridLength((double)Application.Current.FindResource("MarginBase")) }); // separator column
			upperButtonsGrid.ColumnDefinitions.Add(new System.Windows.Controls.ColumnDefinition());

			// this grid is to organize stuff below
			lowerButtonsGrid = new System.Windows.Controls.Grid();
			System.Windows.Controls.Grid.SetColumnSpan(lowerButtonsGrid, 4);

			lowerButtonsGrid.ColumnDefinitions.Add(new System.Windows.Controls.ColumnDefinition());
			lowerButtonsGrid.ColumnDefinitions.Add(new System.Windows.Controls.ColumnDefinition() { Width = new GridLength((double)Application.Current.FindResource("MarginBase")) });
			lowerButtonsGrid.ColumnDefinitions.Add(new System.Windows.Controls.ColumnDefinition());
			
			// this grid is to organize stuff below
			lowerButtonsGrid2 = new System.Windows.Controls.Grid();
			System.Windows.Controls.Grid.SetColumnSpan(lowerButtonsGrid2, 5);

			lowerButtonsGrid2.ColumnDefinitions.Add(new System.Windows.Controls.ColumnDefinition());
			lowerButtonsGrid2.ColumnDefinitions.Add(new System.Windows.Controls.ColumnDefinition() { Width = new GridLength((double)Application.Current.FindResource("MarginBase")) });
			lowerButtonsGrid2.ColumnDefinitions.Add(new System.Windows.Controls.ColumnDefinition());
			
			// this grid is to organize stuff below
			lowerButtonsGrid3 = new System.Windows.Controls.Grid();
			System.Windows.Controls.Grid.SetColumnSpan(lowerButtonsGrid3, 6);

			lowerButtonsGrid3.ColumnDefinitions.Add(new System.Windows.Controls.ColumnDefinition());
			lowerButtonsGrid3.ColumnDefinitions.Add(new System.Windows.Controls.ColumnDefinition() { Width = new GridLength((double)Application.Current.FindResource("MarginBase")) });
			lowerButtonsGrid3.ColumnDefinitions.Add(new System.Windows.Controls.ColumnDefinition());

			// these rows will be added later, but we can create them now so they only get created once
			addedRow1	= new System.Windows.Controls.RowDefinition() { Height = new GridLength(31) };
			addedRow2	= new System.Windows.Controls.RowDefinition() { Height = new GridLength(40) };
			addedRow3	= new System.Windows.Controls.RowDefinition() { Height = new GridLength(49) };
			addedRow4	= new System.Windows.Controls.RowDefinition() { Height = new GridLength(58) };

			// this style (provided by NinjaTrader_MichaelM) gives the correct default minwidth (and colors) to make buttons appear like chart trader buttons
			Style basicButtonStyle	= Application.Current.FindResource("BasicEntryButton") as Style;

			// all of the buttons are basically the same so to save lines of code I decided to use a loop over an array
			buttonsArray = new System.Windows.Controls.Button[8];

			for (int i = 0; i < 8; ++i)
			{
				buttonsArray[i]	= new System.Windows.Controls.Button()
				{
					Content			= string.Format("MyButton{0}", i + 1),
					Height			= 30,
					Margin			= new Thickness(0,0,0,0),
					Padding			= new Thickness(0,0,0,0),
					Style			= basicButtonStyle
				};

				// change colors of the buttons if you'd like. i'm going to change the first and fourth.
				if (i % 3 != 0)
				{
					buttonsArray[i].Background	= Brushes.Gray;
					buttonsArray[i].BorderBrush	= Brushes.DimGray;
				}
			}

			buttonsArray[0].Click += Button1Click;
			buttonsArray[1].Click += Button2Click;
			buttonsArray[2].Click += Button3Click;
			buttonsArray[3].Click += Button4Click;

			System.Windows.Controls.Grid.SetColumn(buttonsArray[1], 2);
			// add button3 to the lower grid
			System.Windows.Controls.Grid.SetColumn(buttonsArray[2], 0);
			// add button4 to the lower grid
			System.Windows.Controls.Grid.SetColumn(buttonsArray[3], 2);
			// add button5 to the lower grid
			System.Windows.Controls.Grid.SetColumn(buttonsArray[4], 0);
			// add button6 to the lower grid
			System.Windows.Controls.Grid.SetColumn(buttonsArray[5], 2);
			// add button7 to the lower grid
			System.Windows.Controls.Grid.SetColumn(buttonsArray[6], 0);
			// add button8 to the lower grid
			System.Windows.Controls.Grid.SetColumn(buttonsArray[7], 2);
			
			
			for (int i = 0; i < 2; ++i)
				upperButtonsGrid.Children.Add(buttonsArray[i]);
			for (int i = 2; i < 4; ++i)
				lowerButtonsGrid.Children.Add(buttonsArray[i]);
			for (int i = 4; i < 6; ++i)
				lowerButtonsGrid2.Children.Add(buttonsArray[i]);
			for (int i = 6; i < 8; ++i)
				lowerButtonsGrid3.Children.Add(buttonsArray[i]);

			if (TabSelected())
				InsertWPFControls();

			chartWindow.MainTabControl.SelectionChanged += TabChangedHandler;
		}

		public void DisposeWPFControls()
		{
			if (chartWindow != null)
				chartWindow.MainTabControl.SelectionChanged -= TabChangedHandler;

			if (buttonsArray[0] != null)
				buttonsArray[0].Click -= Button1Click;
			if (buttonsArray[0] != null)
				buttonsArray[1].Click -= Button2Click;
			if (buttonsArray[0] != null)
				buttonsArray[2].Click -= Button3Click;
			if (buttonsArray[0] != null)
				buttonsArray[3].Click -= Button4Click;

			RemoveWPFControls();
		}
		
		public void InsertWPFControls()
		{
			if (panelActive)
				return;

			// add a new row (addedRow1) for upperButtonsGrid to the existing buttons grid
			chartTraderButtonsGrid.RowDefinitions.Add(addedRow1);
			// set our upper grid to that new panel
			System.Windows.Controls.Grid.SetRow(upperButtonsGrid, (chartTraderButtonsGrid.RowDefinitions.Count - 1));
			// and add it to the buttons grid
			chartTraderButtonsGrid.Children.Add(upperButtonsGrid);
			
			// add a new row (addedRow2) for our lowerButtonsGrid below the ask and bid prices and pnl display			
			chartTraderGrid.RowDefinitions.Add(addedRow2);
			System.Windows.Controls.Grid.SetRow(lowerButtonsGrid, (chartTraderGrid.RowDefinitions.Count - 1));
			chartTraderGrid.Children.Add(lowerButtonsGrid);
			
			// add a new row (addedRow2) for our lowerButtonsGrid below the ask and bid prices and pnl display			
			chartTraderGrid.RowDefinitions.Add(addedRow3);
			System.Windows.Controls.Grid.SetRow(lowerButtonsGrid2, (chartTraderGrid.RowDefinitions.Count - 1));
			chartTraderGrid.Children.Add(lowerButtonsGrid2);
			
			// add a new row (addedRow2) for our lowerButtonsGrid below the ask and bid prices and pnl display			
			chartTraderGrid.RowDefinitions.Add(addedRow4);
			System.Windows.Controls.Grid.SetRow(lowerButtonsGrid3, (chartTraderGrid.RowDefinitions.Count - 1));
			chartTraderGrid.Children.Add(lowerButtonsGrid3);

			panelActive = true;
		}

		protected override void OnBarUpdate() { }

		protected void RemoveWPFControls()
		{
			if (!panelActive)
				return;

			if (chartTraderButtonsGrid != null || upperButtonsGrid != null)
			{
				chartTraderButtonsGrid.Children.Remove(upperButtonsGrid);
				chartTraderButtonsGrid.RowDefinitions.Remove(addedRow1);
			}
			
			if (chartTraderGrid != null || lowerButtonsGrid != null)
			{
				chartTraderGrid.Children.Remove(lowerButtonsGrid);
				chartTraderGrid.RowDefinitions.Remove(addedRow2);
			}
			
			if (chartTraderGrid != null || lowerButtonsGrid2 != null)
			{
				chartTraderGrid.Children.Remove(lowerButtonsGrid2);
				chartTraderGrid.RowDefinitions.Remove(addedRow3);
			}
			
			if (chartTraderGrid != null || lowerButtonsGrid3 != null)
			{
				chartTraderGrid.Children.Remove(lowerButtonsGrid3);
				chartTraderGrid.RowDefinitions.Remove(addedRow4);
			}

			panelActive = false;
		}

		private bool TabSelected()
		{
			bool tabSelected = false;

			// loop through each tab and see if the tab this indicator is added to is the selected item
			foreach (System.Windows.Controls.TabItem tab in chartWindow.MainTabControl.Items)
				if ((tab.Content as Gui.Chart.ChartTab).ChartControl == ChartControl && tab == chartWindow.MainTabControl.SelectedItem)
					tabSelected = true;

			return tabSelected;
		}

		private void TabChangedHandler(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
		{
			if (e.AddedItems.Count <= 0)
				return;

			tabItem = e.AddedItems[0] as System.Windows.Controls.TabItem;
			if (tabItem == null)
				return;

			chartTab = tabItem.Content as Gui.Chart.ChartTab;
			if (chartTab == null)
				return;

			if (TabSelected())
				InsertWPFControls();
			else
				RemoveWPFControls();
		}
		
		[TypeConverter(typeof(NinjaTrader.NinjaScript.AccountNameConverter))]
		public string AccountName { get; set; }
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ChartTraderCustomButtonsExampleTestDispatcher[] cacheChartTraderCustomButtonsExampleTestDispatcher;
		public ChartTraderCustomButtonsExampleTestDispatcher ChartTraderCustomButtonsExampleTestDispatcher()
		{
			return ChartTraderCustomButtonsExampleTestDispatcher(Input);
		}

		public ChartTraderCustomButtonsExampleTestDispatcher ChartTraderCustomButtonsExampleTestDispatcher(ISeries<double> input)
		{
			if (cacheChartTraderCustomButtonsExampleTestDispatcher != null)
				for (int idx = 0; idx < cacheChartTraderCustomButtonsExampleTestDispatcher.Length; idx++)
					if (cacheChartTraderCustomButtonsExampleTestDispatcher[idx] != null &&  cacheChartTraderCustomButtonsExampleTestDispatcher[idx].EqualsInput(input))
						return cacheChartTraderCustomButtonsExampleTestDispatcher[idx];
			return CacheIndicator<ChartTraderCustomButtonsExampleTestDispatcher>(new ChartTraderCustomButtonsExampleTestDispatcher(), input, ref cacheChartTraderCustomButtonsExampleTestDispatcher);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ChartTraderCustomButtonsExampleTestDispatcher ChartTraderCustomButtonsExampleTestDispatcher()
		{
			return indicator.ChartTraderCustomButtonsExampleTestDispatcher(Input);
		}

		public Indicators.ChartTraderCustomButtonsExampleTestDispatcher ChartTraderCustomButtonsExampleTestDispatcher(ISeries<double> input )
		{
			return indicator.ChartTraderCustomButtonsExampleTestDispatcher(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ChartTraderCustomButtonsExampleTestDispatcher ChartTraderCustomButtonsExampleTestDispatcher()
		{
			return indicator.ChartTraderCustomButtonsExampleTestDispatcher(Input);
		}

		public Indicators.ChartTraderCustomButtonsExampleTestDispatcher ChartTraderCustomButtonsExampleTestDispatcher(ISeries<double> input )
		{
			return indicator.ChartTraderCustomButtonsExampleTestDispatcher(input);
		}
	}
}

#endregion
