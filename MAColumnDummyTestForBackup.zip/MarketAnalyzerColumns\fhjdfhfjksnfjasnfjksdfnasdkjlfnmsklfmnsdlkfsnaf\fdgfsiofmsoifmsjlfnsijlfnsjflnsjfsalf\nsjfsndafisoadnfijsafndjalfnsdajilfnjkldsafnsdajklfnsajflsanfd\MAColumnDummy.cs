#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.Core.FloatingPoint;
#endregion

//This namespace holds MarketAnalyzerColumns in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns.fhjdfhfjksnfjasnfjksdfnasdkjlfnmsklfmnsdlkfsnaf.fdgfsiofmsoifmsjlfnsijlfnsjflnsjfsalf.nsjfsndafisoadnfijsafndjalfnsdajilfnjkldsafnsdajklfnsajflsanfd
{
	public class MAColumnDummy : MarketAnalyzerColumn
	{
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"";
				Name										= "MAColumnDummy";
				Calculate									= Calculate.OnPriceChange;
				DataType   									= typeof(double);
        		IsEditable 									= false;
				FormatDecimals 								= 0;
			}
		}
	}
}
