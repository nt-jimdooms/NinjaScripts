#region Using declarations
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Indicator;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Strategy;
#endregion

namespace NinjaTrader.Strategy
{
	// the recommended approach is have a class that inherits from Strategy to prevent duplicate classes with other custom addons
	public partial class PartialClassExample : Strategy
	{

	}

	// alternatively a partial class can be made for Strategy so the methods are available to all strategies
	// this runs the risk of duplicating object or class names from other custom addons
	public partial class Strategy
	{
		public double	DoubleNumber;

		// public IOrder causes a reflection error if the [XmlIgnore()] attribute is not applied.
		// interface objects do not have members and cannot be serialized. anything public will automatically be serialized.
		// 12/16/2020 3:25:36 PM	Default	Failed to execute DB job 'StrategyUpdateJob': There was an error reflecting type 'NinjaTrader.Strategy.CallingPartialMethodsStrategyExample'.: Cannot serialize member 'NinjaTrader.Strategy.Strategy.EntryOrder' of type 'NinjaTrader.Cbi.IOrder', see inner exception for more details.: Cannot serialize member NinjaTrader.Strategy.Strategy.EntryOrder of type NinjaTrader.Cbi.IOrder because it is an interface.	
		[XmlIgnore()]
		public IOrder	EntryOrder;

		// should be called from a data driven method
		public void PrintTimeClose()
		{
			Print(string.Format("{0} | {1}", Time[0], Close[0]));
		}

		public void ChangePosition()
		{
			if (Position.MarketPosition == MarketPosition.Flat)
			{
				if (!Unmanaged)
					EntryOrder = EnterLong();
				else
					EntryOrder = SubmitOrder(0, OrderAction.Buy, OrderType.Market, 1, 0, 0, string.Empty, "PartialMethodSubmittedOrder");
			}
			else
			{
				if (!Unmanaged)
					ExitLong();
				else
					SubmitOrder(0, OrderAction.Sell, OrderType.Market, 1, 0, 0, string.Empty, "ExitLong");
			}
		}
		
		//Sample method which calculates the delta of two prices
		public double calculateDelta(double firstPrice, double secondPrice)
		{
			return Math.Abs(firstPrice - secondPrice);
		}

		//Sample method which prints Position information
		public void printPositionInfo(IPosition position)
		{
			Print(String.Format("{0}: {1} {2} at {3}", position.Instrument, position.Quantity, position.MarketPosition, position.AvgPrice));
		}
  	}
}
