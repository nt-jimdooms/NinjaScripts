#region Using declarations
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Indicator;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Strategy;
#endregion

namespace NinjaTrader.Strategy
{
    [Description("")]
    public class CallingPartialMethodsStrategyExample : Strategy
    {
        //#region Variables

       // #endregion
		
        protected override void Initialize()
        {
            CalculateOnBarClose = true;
			BarsRequired		= 0;
        }

        protected override void OnBarUpdate()
        {
			// to limit the amount of prints just running after the last 20 historical bars
			if (Historical && CurrentBar < Bars.Count - 20)
				return;

			// demonstrates calling a method and supplying values to return a value
			Print("calculateDelta: " + calculateDelta(100, 75).ToString());

			// demonstrates the class level series are available to the partial class method 
			PrintTimeClose();

			// demonstrates submitting orders from a partial class method
			ChangePosition();

			// demonstrates the EntryOrder created in the partial class can be used in the strategy class
			if (EntryOrder == null)
			{
				Print("entry order is null");
				return;
			}
			else
			{
				Print("EntryOrder: " + EntryOrder.ToString());
			}
		}
		
		protected override void OnPositionUpdate(IPosition position)
		{
			printPositionInfo(position);
		}

        //#region Properties

        //#endregion
    }
}
