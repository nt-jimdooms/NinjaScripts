#region Using declarations
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Indicator;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Strategy;
#endregion

// This namespace holds all strategies and is required. Do not change it.
namespace NinjaTrader.Strategy
{
    /// <summary>
    /// Stocks and Commodities - March 2013 - Camarilla Points
    /// </summary>
    [Description("Stocks and Commodities - March 2013 - Camarilla Points")]
    public class CamarillaPointsATS : Strategy
    {
        #region Variables
		private int 	sessionCount 	= 0;
		private bool	long1			= true;
		private bool	long2			= true;
		private bool 	short1			= true;
		private bool	short2			= true;
        #endregion

        /// <summary>
        /// This method is used to configure the strategy and is called once before any strategy method is called.
        /// </summary>
        protected override void Initialize()
        {
            CalculateOnBarClose = true;
			Add(CamarillaPoints());
        }

        /// <summary>
        /// Called on each bar update event (incoming tick)
        /// </summary>
        protected override void OnBarUpdate()
        {
			if (Bars.FirstBarOfSession)
			{
				long1 	= true;
				long2 	= true;
				short1	= true;
				short2	= true;
				
				if(sessionCount < 2)
					sessionCount++;
			}
			
			if (sessionCount < 2) return;
			
			if (CurrentDayOHL().CurrentOpen[0] > CamarillaPoints().S3[0] && CurrentDayOHL().CurrentOpen[0] < CamarillaPoints().R3[0])
			{
				if (High[0] >= CamarillaPoints().R3[0] && short1)
				{
					EnterShort();
					short1 = false;
				}
				
				if (Low[0] <= CamarillaPoints().S3[0] && long1)
				{
					EnterLong();
					long1 = false;
				}
			}
			
			else if (CurrentDayOHL().CurrentOpen[0] < CamarillaPoints().S3[0])
			{
				if (Low[0] <= CamarillaPoints().S3[0] && long2)
				{
					EnterLong();
					long2 = false;
				}
			}
			
			else if (CurrentDayOHL().CurrentOpen[0] > CamarillaPoints().R3[0])
			{
				if (High[0] >= CamarillaPoints().R3[0] && short2)
				{
					EnterShort();
					short2 = false;
				}
			}
			
			if (Position.MarketPosition == MarketPosition.Flat)
			{
				SetStopLoss(CalculationMode.Ticks, 100);
				SetProfitTarget(CalculationMode.Ticks, 100);				
			}
			
			if (Position.MarketPosition == MarketPosition.Long)
			{
				SetStopLoss(CalculationMode.Price, CamarillaPoints().S4[0] - TickSize);
				SetProfitTarget(CalculationMode.Price, CamarillaPoints().R3[0]);
			}	
			
			if (Position.MarketPosition == MarketPosition.Short)
			{
				SetStopLoss(CalculationMode.Price, CamarillaPoints().R4[0] + TickSize);
				SetProfitTarget(CalculationMode.Price, CamarillaPoints().S3[0]);				
			}
        }
		
        #region Properties
        #endregion
    }
}
