
#region Using declarations
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Gui.Chart;
#endregion

// This namespace holds all indicators and is required. Do not change it.
namespace NinjaTrader.Indicator
{
    /// <summary>
    /// Stocks and Commodities - March 2013 - Camarilla Points
    /// </summary>
    [Description("Stocks and Commodities - March 2013 - Camarilla Points")]
    public class CamarillaPoints : Indicator
    {
        #region Variables
		private int sessionCount = 0;
        #endregion

        /// <summary>
        /// This method is used to configure the indicator and is called once before any bar data is loaded.
        /// </summary>
        protected override void Initialize()
        {
            Add(new Plot(Color.FromKnownColor(KnownColor.Orange), PlotStyle.Line, "R5"));
			Add(new Plot(Color.FromKnownColor(KnownColor.Orange), PlotStyle.Line, "R4"));
			Add(new Plot(Color.FromKnownColor(KnownColor.Orange), PlotStyle.Line, "R3"));
			Add(new Plot(Color.FromKnownColor(KnownColor.Orange), PlotStyle.Line, "R2"));
			Add(new Plot(Color.FromKnownColor(KnownColor.Orange), PlotStyle.Line, "R1"));
			Add(new Plot(Color.FromKnownColor(KnownColor.Red), PlotStyle.Line, "S1"));
			Add(new Plot(Color.FromKnownColor(KnownColor.Red), PlotStyle.Line, "S2"));
			Add(new Plot(Color.FromKnownColor(KnownColor.Red), PlotStyle.Line, "S3"));
			Add(new Plot(Color.FromKnownColor(KnownColor.Red), PlotStyle.Line, "S4"));
			Add(new Plot(Color.FromKnownColor(KnownColor.Red), PlotStyle.Line, "S5"));
            Overlay				= true;
        }
				
        /// <summary>
        /// Called on each bar update event (incoming tick)
        /// </summary>
        protected override void OnBarUpdate()
        {
			if (Bars.FirstBarOfSession && sessionCount < 2)
				sessionCount++;
			
			if (sessionCount < 2) return;
			
			double high 	= PriorDayOHLC().PriorHigh[0];
			double low		= PriorDayOHLC().PriorLow[0];
			double close	= PriorDayOHLC().PriorClose[0];
			double range	= high - low;
						
			R5.Set((high / low) * close);
			R4.Set(close + range * (1.1) / 2);
			R3.Set(close + range * (1.1) / 4);
			R2.Set(close + range * (1.1) / 6);
			R1.Set(close + range * (1.1) / 12);
			S1.Set(close - range * (1.1) / 12);
			S2.Set(close - range * (1.1) / 6);
			S3.Set(close - range * (1.1) / 4);
			S4.Set(close - range * (1.1) / 2);
			S5.Set((close - (R5[0] - close)));				
		}

        #region Properties
        [Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
        [XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove
        public DataSeries R5
        {
            get { return Values[0]; }
        }

		[Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
        [XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove
        public DataSeries R4
        {
            get { return Values[1]; }
        }

		[Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
        [XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove
        public DataSeries R3
        {
            get { return Values[2]; }
        }
	
		[Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
        [XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove
        public DataSeries R2
        {
            get { return Values[3]; }
        }

		[Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
        [XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove
        public DataSeries R1
        {
            get { return Values[4]; }
        }

		[Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
        [XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove
        public DataSeries S1
        {
            get { return Values[5]; }
        }
		
		[Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
        [XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove
        public DataSeries S2
        {
            get { return Values[6]; }
        }
		
		[Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
        [XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove
        public DataSeries S3
        {
            get { return Values[7]; }
        }
		
		[Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
        [XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove
        public DataSeries S4
        {
            get { return Values[8]; }
        }
		
		[Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
        [XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove
        public DataSeries S5
        {
            get { return Values[9]; }
        }
        #endregion
    }
}

#region NinjaScript generated code. Neither change nor remove.
// This namespace holds all indicators and is required. Do not change it.
namespace NinjaTrader.Indicator
{
    public partial class Indicator : IndicatorBase
    {
        private CamarillaPoints[] cacheCamarillaPoints = null;

        private static CamarillaPoints checkCamarillaPoints = new CamarillaPoints();

        /// <summary>
        /// Stocks and Commodities - March 2013 - Camarilla Points
        /// </summary>
        /// <returns></returns>
        public CamarillaPoints CamarillaPoints()
        {
            return CamarillaPoints(Input);
        }

        /// <summary>
        /// Stocks and Commodities - March 2013 - Camarilla Points
        /// </summary>
        /// <returns></returns>
        public CamarillaPoints CamarillaPoints(Data.IDataSeries input)
        {
            if (cacheCamarillaPoints != null)
                for (int idx = 0; idx < cacheCamarillaPoints.Length; idx++)
                    if (cacheCamarillaPoints[idx].EqualsInput(input))
                        return cacheCamarillaPoints[idx];

            lock (checkCamarillaPoints)
            {
                if (cacheCamarillaPoints != null)
                    for (int idx = 0; idx < cacheCamarillaPoints.Length; idx++)
                        if (cacheCamarillaPoints[idx].EqualsInput(input))
                            return cacheCamarillaPoints[idx];

                CamarillaPoints indicator = new CamarillaPoints();
                indicator.BarsRequired = BarsRequired;
                indicator.CalculateOnBarClose = CalculateOnBarClose;
#if NT7
                indicator.ForceMaximumBarsLookBack256 = ForceMaximumBarsLookBack256;
                indicator.MaximumBarsLookBack = MaximumBarsLookBack;
#endif
                indicator.Input = input;
                Indicators.Add(indicator);
                indicator.SetUp();

                CamarillaPoints[] tmp = new CamarillaPoints[cacheCamarillaPoints == null ? 1 : cacheCamarillaPoints.Length + 1];
                if (cacheCamarillaPoints != null)
                    cacheCamarillaPoints.CopyTo(tmp, 0);
                tmp[tmp.Length - 1] = indicator;
                cacheCamarillaPoints = tmp;
                return indicator;
            }
        }
    }
}

// This namespace holds all market analyzer column definitions and is required. Do not change it.
namespace NinjaTrader.MarketAnalyzer
{
    public partial class Column : ColumnBase
    {
        /// <summary>
        /// Stocks and Commodities - March 2013 - Camarilla Points
        /// </summary>
        /// <returns></returns>
        [Gui.Design.WizardCondition("Indicator")]
        public Indicator.CamarillaPoints CamarillaPoints()
        {
            return _indicator.CamarillaPoints(Input);
        }

        /// <summary>
        /// Stocks and Commodities - March 2013 - Camarilla Points
        /// </summary>
        /// <returns></returns>
        public Indicator.CamarillaPoints CamarillaPoints(Data.IDataSeries input)
        {
            return _indicator.CamarillaPoints(input);
        }
    }
}

// This namespace holds all strategies and is required. Do not change it.
namespace NinjaTrader.Strategy
{
    public partial class Strategy : StrategyBase
    {
        /// <summary>
        /// Stocks and Commodities - March 2013 - Camarilla Points
        /// </summary>
        /// <returns></returns>
        [Gui.Design.WizardCondition("Indicator")]
        public Indicator.CamarillaPoints CamarillaPoints()
        {
            return _indicator.CamarillaPoints(Input);
        }

        /// <summary>
        /// Stocks and Commodities - March 2013 - Camarilla Points
        /// </summary>
        /// <returns></returns>
        public Indicator.CamarillaPoints CamarillaPoints(Data.IDataSeries input)
        {
            if (InInitialize && input == null)
                throw new ArgumentException("You only can access an indicator with the default input/bar series from within the 'Initialize()' method");

            return _indicator.CamarillaPoints(input);
        }
    }
}
#endregion
