#region Using declarations
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Indicator;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Strategy;
#endregion

// This namespace holds all strategies and is required. Do not change it.
namespace NinjaTrader.Strategy
{
    /// <summary>
    /// Enter the description of your strategy here
    /// </summary>
    [Description("Enter the description of your strategy here")]
    public class UnmanagedTemplate : Strategy
    {
        private IOrder 	shortEntry			= null;
		private IOrder 	longEntry			= null;
		private IOrder	targetLong			= null;
		private IOrder	targetShort			= null;
		private IOrder 	stopLossShort		= null;
		private IOrder 	stopLossLong		= null;

		//can be called to cancel open orders
		//OnOrderUpdate() will be used to set to null once canceled
		protected void CancelAll()
		{	
			if(shortEntry != null)
			{				
				CancelOrder(shortEntry);
			}
			if(longEntry != null)
			{				
				CancelOrder(longEntry);
			}
			if(targetLong != null)
			{				
				CancelOrder(targetLong);
			}
			if(targetShort != null)
			{				
				CancelOrder(targetShort);
			}
			if(stopLossShort != null)
			{				
				CancelOrder(stopLossShort);
			}
			if(stopLossLong != null)
			{				
				CancelOrder(stopLossLong);
			}				
		}
        /// <summary>
        /// This method is used to configure the strategy and is called once before any strategy method is called.
        /// </summary>
        protected override void Initialize()
        {
            CalculateOnBarClose = true;
			Unmanaged			= true;
			TraceOrders			= true;
        }

        /// <summary>
        /// Called on each bar update event (incoming tick)
        /// </summary>
        protected override void OnBarUpdate()
        {
			// Submit OCO entry limit orders if we currently don't have an entry order open
			if (longEntry == null && shortEntry == null
				&& Position.MarketPosition == MarketPosition.Flat)
			{
				/* The entry orders objects will take on a unique ID from our SubmitOrder() that we can use 
				later for order identification purposes in the OnOrderUpdate() and OnExecution() methods. */
				shortEntry 	= SubmitOrder(0, OrderAction.SellShort, OrderType.Limit, 1, High[0]+4*TickSize, 0, "entry", "Short limit entry");

				longEntry = SubmitOrder(0, OrderAction.Buy, OrderType.Limit, 1, Low[0]-4*TickSize, 0,  "entry", "Long limit entry");
			}
        }
		
		protected override void OnExecution(IExecution execution)
		{
			/* We advise monitoring OnExecution to trigger submission of stop/target orders instead of OnOrderUpdate() 
			since OnExecution() is called after OnOrderUpdate()	which ensures your strategy has received the execution 
			which is used for internal signal tracking. */
			if (longEntry != null && longEntry == execution.Order)
			{
				if (execution.Order.OrderState == OrderState.Filled 
					|| execution.Order.OrderState == OrderState.PartFilled 
					|| (execution.Order.OrderState == OrderState.Cancelled && execution.Order.Filled > 0))
				{					
					stopLossLong = SubmitOrder(0, OrderAction.Sell, OrderType.Stop, execution.Order.Filled, 0, execution.Order.AvgFillPrice - 4 * TickSize, "LongExits", "StopLossLong"); 

					targetLong = SubmitOrder(0, OrderAction.Sell, OrderType.Limit, execution.Order.Filled, execution.Order.AvgFillPrice + 8 * TickSize, 0, "LongExits", "TargetLong");
					
					// Resets the longTop object to null after the order has been filled
					if (execution.Order.OrderState != OrderState.PartFilled)
					{
						longEntry 	= null;
					}
				}
			}			
			if (shortEntry != null && shortEntry == execution.Order)
			{				
				if (execution.Order.OrderState == OrderState.Filled 
					|| execution.Order.OrderState == OrderState.PartFilled 
					|| (execution.Order.OrderState == OrderState.Cancelled && execution.Order.Filled > 0))
				{					
					stopLossShort = SubmitOrder(0, OrderAction.BuyToCover, OrderType.Stop, execution.Order.Filled, 0, execution.Order.AvgFillPrice + 4 * TickSize, "ShortExits", "StopLossShort"); 

					targetShort = SubmitOrder(0, OrderAction.BuyToCover, OrderType.Limit, execution.Order.Filled, execution.Order.AvgFillPrice - 8 * TickSize, 0, "ShortExits", "TargetShort");
					
					// Resets the longTop object to null after the order has been filled
					if (execution.Order.OrderState != OrderState.PartFilled)
					{
						shortEntry 	= null;
					}
				}
			}
			
			// Reset our stop order and target orders' IOrder objects after our position is closed.
			if ((stopLossLong != null && stopLossLong == execution.Order) || (targetLong != null && targetLong == execution.Order))
			{
				if (execution.Order.OrderState == OrderState.Filled 
					|| execution.Order.OrderState == OrderState.PartFilled)
				{
					stopLossLong = null;
					targetLong = null;
				}
			}
			if ((stopLossShort != null && stopLossShort == execution.Order) || (targetShort != null && targetShort == execution.Order))
			{
				if (execution.Order.OrderState == OrderState.Filled 
					|| execution.Order.OrderState == OrderState.PartFilled)
				{
					stopLossShort = null;
					targetShort = null;
				}
			}
		}

				/// <summary>
        /// Called on each incoming order event
        /// </summary>
        protected override void OnOrderUpdate(IOrder order)
        {
			if (longEntry != null && longEntry == order)
			{	
				// Reset the longTop object to null if order was cancelled without any fill
				if (order.OrderState == OrderState.Cancelled && order.Filled == 0)
				{
					longEntry = null;
				}
			}
			
			if (shortEntry != null && shortEntry == order)
			{	
				// Reset the shortTop object to null if order was cancelled without any fill
				if (order.OrderState == OrderState.Cancelled && order.Filled == 0)
				{
					shortEntry = null;
				}
			}
			//sets all targets and stops to null if one of them is canceled
			//PLEASE NOTE: setting IOrders to null ***DOES NOT*** cancel them
			if ((targetLong != null && targetLong == order)
				||(stopLossLong != null && stopLossLong == order)
				||(targetShort != null && targetShort == order)
				||(stopLossShort != null && stopLossShort == order)
				)
			{	
				if (order.OrderState == OrderState.Cancelled && order.Filled == 0)
				{
					targetLong = stopLossLong = targetShort = stopLossShort = null;
				}
			}
			
			
        }
        #region Properties
        #endregion
    }
}
