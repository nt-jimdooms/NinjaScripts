#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class ChangeChartTraderSelectedAccountExample : Indicator
	{
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Indicator here.";
				Name										= "ChangeChartTraderSelectedAccountExample";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
			}
			else if (State == State.DataLoaded)
			{
				foreach (var window in NinjaTrader.Core.Globals.AllWindows)
				{
					// New accountSelector Per Window
					NinjaTrader.Gui.Tools.AccountSelector accountSelector;
					// check if the found window is a Chart window, if not continue looking
					if (!(window is NinjaTrader.Gui.Chart.Chart)) continue;

					window.Dispatcher.InvokeAsync(new Action(() =>
					{
						// try to cast as a Chart, if it fails it will be null
						var foundChart = window as NinjaTrader.Gui.Chart.Chart;
						        
						// make sure we found a chart
						if (foundChart == null) return;
						
						// We have a chart, get the Account selctor from ChartTrader.
						accountSelector = Window.GetWindow(foundChart.ActiveChartControl.Parent).FindFirst("ChartTraderControlAccountSelector") as NinjaTrader.Gui.Tools.AccountSelector;
						
						// Change the Account Selctor's SelectedAccount
						accountSelector.SelectedAccount = Account.All.FirstOrDefault(a => a.Name == "Sim101");
					        
					}));
				}
			}
		}

		protected override void OnBarUpdate()
		{
			//Add your custom indicator logic here.
		}
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ChangeChartTraderSelectedAccountExample[] cacheChangeChartTraderSelectedAccountExample;
		public ChangeChartTraderSelectedAccountExample ChangeChartTraderSelectedAccountExample()
		{
			return ChangeChartTraderSelectedAccountExample(Input);
		}

		public ChangeChartTraderSelectedAccountExample ChangeChartTraderSelectedAccountExample(ISeries<double> input)
		{
			if (cacheChangeChartTraderSelectedAccountExample != null)
				for (int idx = 0; idx < cacheChangeChartTraderSelectedAccountExample.Length; idx++)
					if (cacheChangeChartTraderSelectedAccountExample[idx] != null &&  cacheChangeChartTraderSelectedAccountExample[idx].EqualsInput(input))
						return cacheChangeChartTraderSelectedAccountExample[idx];
			return CacheIndicator<ChangeChartTraderSelectedAccountExample>(new ChangeChartTraderSelectedAccountExample(), input, ref cacheChangeChartTraderSelectedAccountExample);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ChangeChartTraderSelectedAccountExample ChangeChartTraderSelectedAccountExample()
		{
			return indicator.ChangeChartTraderSelectedAccountExample(Input);
		}

		public Indicators.ChangeChartTraderSelectedAccountExample ChangeChartTraderSelectedAccountExample(ISeries<double> input )
		{
			return indicator.ChangeChartTraderSelectedAccountExample(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ChangeChartTraderSelectedAccountExample ChangeChartTraderSelectedAccountExample()
		{
			return indicator.ChangeChartTraderSelectedAccountExample(Input);
		}

		public Indicators.ChangeChartTraderSelectedAccountExample ChangeChartTraderSelectedAccountExample(ISeries<double> input )
		{
			return indicator.ChangeChartTraderSelectedAccountExample(input);
		}
	}
}

#endregion
