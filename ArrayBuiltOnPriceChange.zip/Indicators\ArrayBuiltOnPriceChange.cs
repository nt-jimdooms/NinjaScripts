#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class ArrayBuiltOnPriceChange : Indicator
	{
		private double[] Array1, Array2, ArrayToUse;
		private int PriceChangeCount;
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Indicator here.";
				Name										= "ArrayBuiltOnPriceChange";
				Calculate									= Calculate.OnPriceChange;
				IsOverlay									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
			}
			else if (State == State.DataLoaded)
			{
				Array1 = new double[1];
				Array2 = new double[1];
				PriceChangeCount = 1;
			}
			else if (State == State.Realtime)
			{
				ClearOutputWindow();
				for (int i = ArrayToUse.Length-1; i > 0; i--)
					Print(i + " " + ArrayToUse[i]);
			}
		}

		protected override void OnBarUpdate()
		{
			PriceChangeCount++;
			if (Array1.Length >= Array2.Length)
			{
				Array2 = new double[PriceChangeCount];
				for (int i = Array2.Length-1; i > 0; i--)
				{
					Array2[i] = Array1[i-1];
				}
				Array2[0] = Close[0];
				ArrayToUse = Array2;
			}
			else if (Array1.Length < Array2.Length)
			{
				Array1 = new double[PriceChangeCount];
				for (int i = Array1.Length-1; i > 0; i--)
				{
					Array1[i] = Array2[i-1];
				}
				Array1[0] = Close[0];
				ArrayToUse = Array1;
			}
			
			if (State == State.Realtime)
				Print(ArrayToUse[0]);
		}
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ArrayBuiltOnPriceChange[] cacheArrayBuiltOnPriceChange;
		public ArrayBuiltOnPriceChange ArrayBuiltOnPriceChange()
		{
			return ArrayBuiltOnPriceChange(Input);
		}

		public ArrayBuiltOnPriceChange ArrayBuiltOnPriceChange(ISeries<double> input)
		{
			if (cacheArrayBuiltOnPriceChange != null)
				for (int idx = 0; idx < cacheArrayBuiltOnPriceChange.Length; idx++)
					if (cacheArrayBuiltOnPriceChange[idx] != null &&  cacheArrayBuiltOnPriceChange[idx].EqualsInput(input))
						return cacheArrayBuiltOnPriceChange[idx];
			return CacheIndicator<ArrayBuiltOnPriceChange>(new ArrayBuiltOnPriceChange(), input, ref cacheArrayBuiltOnPriceChange);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ArrayBuiltOnPriceChange ArrayBuiltOnPriceChange()
		{
			return indicator.ArrayBuiltOnPriceChange(Input);
		}

		public Indicators.ArrayBuiltOnPriceChange ArrayBuiltOnPriceChange(ISeries<double> input )
		{
			return indicator.ArrayBuiltOnPriceChange(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ArrayBuiltOnPriceChange ArrayBuiltOnPriceChange()
		{
			return indicator.ArrayBuiltOnPriceChange(Input);
		}

		public Indicators.ArrayBuiltOnPriceChange ArrayBuiltOnPriceChange(ISeries<double> input )
		{
			return indicator.ArrayBuiltOnPriceChange(input);
		}
	}
}

#endregion
