#region Using declarations
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Gui.Chart;
#endregion

// This namespace holds all indicators and is required. Do not change it.
namespace NinjaTrader.Indicator
{
    /// <summary>
    /// Demonstrates plotting from a seondary data series
    /// </summary>
    [Description("Demonstrates plotting from a seondary data series")]
    public class PlotMultiTimeFrameNT7 : Indicator
    {
        #region Variables
        // Wizard generated variables
        // User defined variables (add any user defined variables below)
		
		private double mtfPlotValue;
        #endregion

        /// <summary>
        /// This method is used to configure the indicator and is called once before any bar data is loaded.
        /// </summary>
        protected override void Initialize()
        {
			Add(PeriodType.Range, 5);
			
            Add(new Plot(Color.FromKnownColor(KnownColor.Orange), PlotStyle.Line, "Plot0"));
            Add(new Plot(Color.FromKnownColor(KnownColor.Green), PlotStyle.Line, "Plot1"));
            Overlay				= false;
        }

        /// <summary>
        /// Called on each bar update event (incoming tick)
        /// </summary>
        protected override void OnBarUpdate()
        {
            if (BarsInProgress == 0)
			{
				Plot0.Set(Close[0]);
				//Values[0][0] = Close[0]; // This is the same assignment as used in Plot0's setter
				
				Plot1.Set(mtfPlotValue);
				//Values[1][0] = mtfPlotValue]; // This is the same assignment as used in Plot1's setter
				
			}
			else if (BarsInProgress == 1)
			{
				mtfPlotValue = Close[0];
			}
			
        }

        #region Properties
        [Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
        [XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove
        public DataSeries Plot0
        {
            get { return Values[0]; }
        }

        [Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
        [XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove
        public DataSeries Plot1
        {
            get { return Values[1]; }
        }

        #endregion
    }
}

#region NinjaScript generated code. Neither change nor remove.
// This namespace holds all indicators and is required. Do not change it.
namespace NinjaTrader.Indicator
{
    public partial class Indicator : IndicatorBase
    {
        private PlotMultiTimeFrameNT7[] cachePlotMultiTimeFrameNT7 = null;

        private static PlotMultiTimeFrameNT7 checkPlotMultiTimeFrameNT7 = new PlotMultiTimeFrameNT7();

        /// <summary>
        /// Demonstrates plotting from a seondary data series
        /// </summary>
        /// <returns></returns>
        public PlotMultiTimeFrameNT7 PlotMultiTimeFrameNT7()
        {
            return PlotMultiTimeFrameNT7(Input);
        }

        /// <summary>
        /// Demonstrates plotting from a seondary data series
        /// </summary>
        /// <returns></returns>
        public PlotMultiTimeFrameNT7 PlotMultiTimeFrameNT7(Data.IDataSeries input)
        {
            if (cachePlotMultiTimeFrameNT7 != null)
                for (int idx = 0; idx < cachePlotMultiTimeFrameNT7.Length; idx++)
                    if (cachePlotMultiTimeFrameNT7[idx].EqualsInput(input))
                        return cachePlotMultiTimeFrameNT7[idx];

            lock (checkPlotMultiTimeFrameNT7)
            {
                if (cachePlotMultiTimeFrameNT7 != null)
                    for (int idx = 0; idx < cachePlotMultiTimeFrameNT7.Length; idx++)
                        if (cachePlotMultiTimeFrameNT7[idx].EqualsInput(input))
                            return cachePlotMultiTimeFrameNT7[idx];

                PlotMultiTimeFrameNT7 indicator = new PlotMultiTimeFrameNT7();
                indicator.BarsRequired = BarsRequired;
                indicator.CalculateOnBarClose = CalculateOnBarClose;
#if NT7
                indicator.ForceMaximumBarsLookBack256 = ForceMaximumBarsLookBack256;
                indicator.MaximumBarsLookBack = MaximumBarsLookBack;
#endif
                indicator.Input = input;
                Indicators.Add(indicator);
                indicator.SetUp();

                PlotMultiTimeFrameNT7[] tmp = new PlotMultiTimeFrameNT7[cachePlotMultiTimeFrameNT7 == null ? 1 : cachePlotMultiTimeFrameNT7.Length + 1];
                if (cachePlotMultiTimeFrameNT7 != null)
                    cachePlotMultiTimeFrameNT7.CopyTo(tmp, 0);
                tmp[tmp.Length - 1] = indicator;
                cachePlotMultiTimeFrameNT7 = tmp;
                return indicator;
            }
        }
    }
}

// This namespace holds all market analyzer column definitions and is required. Do not change it.
namespace NinjaTrader.MarketAnalyzer
{
    public partial class Column : ColumnBase
    {
        /// <summary>
        /// Demonstrates plotting from a seondary data series
        /// </summary>
        /// <returns></returns>
        [Gui.Design.WizardCondition("Indicator")]
        public Indicator.PlotMultiTimeFrameNT7 PlotMultiTimeFrameNT7()
        {
            return _indicator.PlotMultiTimeFrameNT7(Input);
        }

        /// <summary>
        /// Demonstrates plotting from a seondary data series
        /// </summary>
        /// <returns></returns>
        public Indicator.PlotMultiTimeFrameNT7 PlotMultiTimeFrameNT7(Data.IDataSeries input)
        {
            return _indicator.PlotMultiTimeFrameNT7(input);
        }
    }
}

// This namespace holds all strategies and is required. Do not change it.
namespace NinjaTrader.Strategy
{
    public partial class Strategy : StrategyBase
    {
        /// <summary>
        /// Demonstrates plotting from a seondary data series
        /// </summary>
        /// <returns></returns>
        [Gui.Design.WizardCondition("Indicator")]
        public Indicator.PlotMultiTimeFrameNT7 PlotMultiTimeFrameNT7()
        {
            return _indicator.PlotMultiTimeFrameNT7(Input);
        }

        /// <summary>
        /// Demonstrates plotting from a seondary data series
        /// </summary>
        /// <returns></returns>
        public Indicator.PlotMultiTimeFrameNT7 PlotMultiTimeFrameNT7(Data.IDataSeries input)
        {
            if (InInitialize && input == null)
                throw new ArgumentException("You only can access an indicator with the default input/bar series from within the 'Initialize()' method");

            return _indicator.PlotMultiTimeFrameNT7(input);
        }
    }
}
#endregion
